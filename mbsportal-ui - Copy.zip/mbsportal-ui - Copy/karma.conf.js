module.exports = function (config) {

  process.env.HTTP_PROXY = 'http://zsproxy.fanniemae.com:10479';

  config.set({
    basePath: '',
    frameworks: ['jasmine', '@angular/cli'],
    plugins: [
      require('karma-jasmine'),
      require('karma-chrome-launcher'),
      require('karma-jasmine-html-reporter'),
      require('karma-coverage-istanbul-reporter'),
      require('@angular/cli/plugins/karma'),
      require('karma-spec-reporter'),
      require('karma-sauce-launcher'),
      require('karma-selenium-launcher')
    ],
    client:{
      clearContext: false // leave Jasmine Spec Runner output visible in browser
    },
    coverageIstanbulReporter: {
      reports: [ 'html', 'lcovonly' ],
      fixWebpackSourcePaths: true,
      includeAllSources: true
    },
    angularCli: {
      environment: 'dev'
    },
    reporters: ['kjhtml', 'spec'],
    specReporter: {
      showSpecTiming: true
    },
    hostname: require('ip').address(),
    port: 9876,
    colors: true,
    logLevel: config.LOG_INFO,
    autoWatch: true,
    browserDisconnectTimeout : 60*1000, // default 2000
    browserDisconnectTolerance : 1, // default 0
    browserNoActivityTimeout : 4*60*1000, //default 10000
    captureTimeout : 4*60*1000, //default 60000
    customLaunchers: {
      sl_chrome: {
        base: 'Selenium',
        config: {
          host: 'ondemand.saucelabs.com',
          port: 80,
          path: '/wd/hub',
          protocol: 'http',
          desiredCapabilities: {
            username: 'sso-fm-ievgenii_fedorenko',
            accesskey: 'a1c9b31f-43e4-4abf-8279-046f5ef72158',
            parentTunnel:'sso-fm-hima_bindu_x_peteti',
            tunnelIdentifier:'fm_tunnel_v12',
            browserName: 'Chrome',
            version: '58',
            platform: 'Windows 10',
            build: 'test-build',
            name: 'MBSP UI unit tests',
            idleTimeout: 360
          }
        },
        browserName: 'Chrome',
        version: '58',
        platform: 'Windows 10'
      },
      ChromeHeadless:  {
        base:   'Chrome',
        flags:  [
          '--headless',
          '--disable-gpu',
          '--remote-debugging-port=9222',
        ],
      }
    },
    browsers: ['sl_chrome'],
    singleRun: false,
    concurrency: Infinity
  });
};
