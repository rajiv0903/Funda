import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { UserTypeGuard } from './shared/guards/user-type.guard';
import { UserType } from './shared/enums/user-type.enum';

@NgModule({
  imports: [
    RouterModule.forRoot([
      {
        path: 'trading',
        loadChildren: 'app/lender-trading/lender-trading.module#LenderTradingModule',
        canLoad: [UserTypeGuard],
        data: {
          userType: UserType.EXTERNAL
        }
      },
      {
        path: 'pricing',
        loadChildren: 'app/trader-trading/trader-trading.module#TraderTradingModule',
        canLoad: [UserTypeGuard],
        data: {
          userType: UserType.INTERNAL
        }
      },
      {
        path: 'transaction-history',
        loadChildren: 'app/trades-history/trades-history.module#TradesHistoryModule',
      }
    ])
  ],
  exports: [RouterModule],
  providers: [UserTypeGuard]
})
export class AppRoutingModule { }

