/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { ErrorHandler, Injectable } from '@angular/core';
import { LoggerService } from '../shared/services/logger.service';

@Injectable()
export class CustomErrorHandler extends ErrorHandler {

  constructor(private logger: LoggerService) {
    super();
  }

  public handleError(error: any): void {
    this.logger.error('In Client ErrorHandler : Message: ' + error.message + ' & stack:' + error.stack);
    super.handleError(error);
  }
}
