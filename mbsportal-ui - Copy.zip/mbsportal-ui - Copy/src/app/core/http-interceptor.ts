/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpResponse, HttpErrorResponse } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { appName, retryDelay, retryTimes, sessionIdHeaderName, timezone } from '../shared/constants/system.constant';
import { LocalStorageService } from '../shared/services/local-storage.service';
import { environment } from '../../environments/environment';
import { LoggerService } from '../shared/services/logger.service';
import * as fromRoot from '../store';
import * as appActions from '../store/actions/app.actions';
import { Store } from '@ngrx/store';
import { genericError } from '../shared/constants/error.constant';
import * as actions from '../store/actions/session.actions';
import * as moment from 'moment-timezone';

@Injectable()
export class MbspHttpInterceptor implements HttpInterceptor {

  private headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'x-fnma-channel': 'web',
    'x-fnma-sub-channel': appName
  };

  constructor(
    private localStorageService: LocalStorageService,
    private loggerService: LoggerService,
    private store: Store<fromRoot.AppStore>
  ) {}

  private setHeaders(): void {
    this.setSessionIdHeader();
    this.setUserNameHeader();
  }

  private setSessionIdHeader(): void {
    const sessionId = this.localStorageService.get('sessionId');
    if (environment.name !== 'local' && sessionId) {
      this.headers[sessionIdHeaderName] = sessionId;
    }
  }

  private setUserNameHeader(): void {
    if (environment.name === 'local' && sessionStorage.getItem('userName')) {
      this.headers['userName'] = sessionStorage.getItem('userName');
    }
  }

  private isNotLoggingRequest(request: HttpRequest<any>): boolean {
    return !request.url.includes('/ui/logging');
  }
  private isSystemError(error: {status: number}): boolean {
    this.loggerService.error('error status: ' + error.status.toString());
    return error.status === 0 || error.status.toString().startsWith('5');
  }

  private shouldResetSession(req: HttpRequest<any>): boolean {
    return !req.url.includes('/events/') && this.isNotLoggingRequest(req) && !req.url.includes('/mbsprofileentitlements');
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.setHeaders();
    req = req.clone({
      setHeaders: this.headers
    });

    return next.handle(req)
      .do((event: HttpEvent<any>) => {
        if (event instanceof HttpResponse && this.shouldResetSession(req) && environment.name !== 'local') {
          if (event.status === 200 && event.headers.get('x-server-time')) {
            const serverTime = moment(event.headers.get('x-server-time')).tz(timezone).toObject();
            this.store.dispatch(new actions.TimerResetAction(serverTime));
          }
        }
      })
      .retryWhen(error => {
        let retryErrors = 0;
        return error.flatMap((errors: any) => {
          if (retryErrors++ < retryTimes && this.isSystemError(errors) && this.isNotLoggingRequest(req)) {
            return Observable.of(errors.status).delay(retryDelay);
          }
          return Observable.throw(errors)
        })
      })
      .catch((errorResponse: HttpErrorResponse) => {
        let errorObj: any = {};
        try {
          errorObj = errorResponse.error;
          this.loggerService.error('error json: ' + JSON.stringify(errorObj), errorResponse.status);
        } catch (e) {
          errorObj.message = genericError;
        }

        errorObj.status = errorResponse.status;
        if (this.isNotLoggingRequest(req)) {
          this.store.dispatch(new appActions.FailureAction(errorObj));
        }

        return Observable.throw(errorObj);
      });
  }

}
