/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */
import * as SockJS from 'sockjs-client';
import { StompConfig } from '@stomp/ng2-stompjs';
import { environment } from '../../environments/environment';
import { traderWSReconnectDelay } from '../shared/constants/system.constant';

export function socketProvider() {
  return new SockJS(environment.websocketUrl);
}

export const stompConfig: StompConfig = {
  url: socketProvider,

  headers: {
    'x-fnma-channel': 'web',
    'x-fnma-sub-channel': 'MBSP'
  },
  // Interval in milliseconds, set to 0 to disable
  heartbeat_in: 10000,
  heartbeat_out: 10000,
  reconnect_delay: traderWSReconnectDelay,
  debug: false
};
