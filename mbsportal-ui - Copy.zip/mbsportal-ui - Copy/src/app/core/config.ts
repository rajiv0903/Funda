import { configDefault } from './config-default';

export const config = {
  ...configDefault,
  testUsername: '{LDAP_USERNAME}',
  testPassword: '{LDAP_PASSWORD}'
}
