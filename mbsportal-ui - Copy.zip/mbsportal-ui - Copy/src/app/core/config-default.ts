export const configDefault = {
  baseHref: '/fmnui/mbsportal/',
  deployPath: '/',
  cdxApiBasePath: '/cdxapi'
};
