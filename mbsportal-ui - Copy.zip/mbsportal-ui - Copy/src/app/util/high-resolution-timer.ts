export class HighResolutionTimer {
  private totalTicks = 0;
  private timer: any;
  private startTime: number | undefined;
  private currentTime: number | undefined;
  private deltaTime = 0;
  private stopped: boolean;

  constructor(public duration: number, public callback: (timer: HighResolutionTimer) => void) {
  }

  run() {
    const lastTime = this.currentTime;
    this.currentTime = Date.now();

    if (!this.startTime) {
      this.startTime = this.currentTime;
    }
    if (lastTime !== undefined) {
      this.deltaTime = (this.currentTime - lastTime);
    }

    this.callback(this);

    const nextTick = this.duration - (this.currentTime - (this.startTime + (this.totalTicks * this.duration)));
    this.totalTicks++;

    if (!this.stopped) {
      this.timer = setTimeout(() => {
        this.run();
      }, nextTick);
    }
  }

  stop() {
    if (this.timer !== undefined) {
      clearTimeout(this.timer);
      this.timer = undefined;
      this.stopped = true;
    }
  }
}
