/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { transactionRequestReducer, TransactionRequestsState } from '../../store/reducers/transaction-request.reducer';
import * as actions from '../../store/actions/transaction-request.actions';
import { TransactionRequest } from '../../store/models/transaction-request.model';
import { deepCopy } from '../../../test';


export const getTransactionRequestReducerMock = (trList?: TransactionRequest[]) => {
  const mockTransactionRequests = deepCopy(require('../../../assets/data/transaction-requests.json'));
  const transRequestsListDefaultState: TransactionRequestsState = {
      isLoading: false,
      loaded: false,
      isCreating: false,
      isUpdating: {},
      isPolling: false,
      shouldPoll: false,
      lastPollTimestamp: '',
      entities: (trList && trList.length ? trList : mockTransactionRequests),
      error: null
    };
  return (state, action) => {
    return transactionRequestReducer(transRequestsListDefaultState, action);
  };
};

