import { APP_BASE_HREF, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TestBed } from '@angular/core/testing';
import { async } from '@angular/core/testing';

import { StoreModule } from '@ngrx/store';

import './core/operators';
import { FmCompositeComponentsModule } from '@fm-ui-adk/components/dist/fm-composite.module';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HomeModule } from './home/home.module';
import { HeaderModule } from './shared/components/header/header.module';
import { NavbarModule } from './shared/components/navbar/navbar.module';
import { FooterModule } from './shared/components/footer/footer.module';
import { reducers } from './store';
import { BsModalService, ComponentLoaderFactory, PositioningService } from 'ngx-bootstrap';
import { ModalService } from './shared/services/modal.service';
import { Component, Input } from '@angular/core';
import { LoggerService } from './shared/services/logger.service';
import { UserProfileService } from './shared/services/user-profile.service';
import { LocalStorageService } from './shared/services/local-storage.service';
import { NotificationsModule } from './shared/components/notifications/notifications.module';

@Component({
  selector: 'mbsp-growl',
  template: 'no markup for mocked child component'
})
class MockGrowlComponent {
  @Input() userErrors: any[];
}

describe('App component', () => {

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        FmCompositeComponentsModule,
        AppRoutingModule,
        HomeModule,
        HeaderModule,
        NotificationsModule,
        NavbarModule,
        FooterModule,
        StoreModule.forRoot(reducers)
      ],
      declarations: [
        AppComponent,
        MockGrowlComponent
      ],
      providers: [
        {
          provide: APP_BASE_HREF,
          useValue: '/'
        },
        BsModalService,
        ModalService,
        LoggerService,
        UserProfileService,
        LocalStorageService,
        DatePipe,
        ComponentLoaderFactory,
        PositioningService
      ]
    });
  });

  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));
});

