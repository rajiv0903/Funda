import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { TraderTradingComponent } from './trader-trading.component';
import { TraderTransactionRequestsLoadedGuard } from '../shared/guards/trader-transaction-requests-loaded.guard';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: '',
        component: TraderTradingComponent,
        canActivate: [
          TraderTransactionRequestsLoadedGuard
        ]
      }
    ])
  ],
  providers: [
    TraderTransactionRequestsLoadedGuard
  ],
  exports: [RouterModule]
})
export class TraderTradingRoutingModule { }
