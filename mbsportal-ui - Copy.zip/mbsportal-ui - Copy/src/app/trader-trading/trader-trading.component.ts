import { ChangeDetectionStrategy, Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Rx';

import * as fromRoot from '../store';
import { TransactionRequest } from '../store/models/transaction-request.model';

@Component({
  selector: 'mbsp-trader-trading',
  templateUrl: './trader-trading.component.html',
  styleUrls: ['./trader-trading.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TraderTradingComponent {

  constructor(private store: Store<fromRoot.AppStore>) {}

  get transactionRequests$(): Observable<TransactionRequest[]> {
    return this.store.select(fromRoot.getTransactionRequestsEntities);
  }

  get error$(): Observable<any> {
    return this.store.select(fromRoot.getTransactionRequestError);
  }

}
