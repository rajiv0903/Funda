/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { Component, Input, ViewEncapsulation } from '@angular/core';
import { Store } from '@ngrx/store';

import { TransactionRequest } from '../../store/models/transaction-request.model';
import { UserProfileService } from '../../shared/services/user-profile.service';
import { TransactionRequestService } from '../../shared/services/transaction-request.service';
import { Observable } from 'rxjs/Observable';
import { StringBooleanArray } from '../../shared/interfaces/misc.interface';
import * as fromRoot from '../../store';


@Component({
  selector: 'mbsp-pricing-requests-list',
  templateUrl: './pricing-requests-list.component.html',
  styleUrls: ['./pricing-requests-list.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PricingRequestsListComponent {

  @Input() rows: TransactionRequest[];
  @Input() error: any;

  constructor(
    private store: Store<fromRoot.AppStore>,
    public userProfile: UserProfileService,
    public trService: TransactionRequestService
  ) {}

  get isUpdating$(): Observable<StringBooleanArray> {
    return this.store.select(fromRoot.getTransactionRequestIsUpdating);
  }

  public rowIdentity(index: number, row: TransactionRequest) {
    return row ? row.transReqId : null;
  }

  public getRowColorClass(row: TransactionRequest) {
    return {
      'reserved': this.trService.isReserved(this.userProfile.id, row.traderId),
      'inactive': this.trService.isInactive(row.stateType),
      'accepted': this.trService.isExecuted(row.stateType),
      'locked': this.trService.isLocked(this.userProfile.id, row.traderId) && this.userProfile.canExecute,
      'read-only': this.trService.isLocked(this.userProfile.id, row.traderId) && !this.userProfile.canExecute
    };
  }

  public clearInactiveTrades(): void {
    this.trService.clearInactiveTrades(this.rows);
  }

  public disableClearAllButton(): boolean {
    return !this.trService.containsInactiveTrades(this.rows);
  }
}
