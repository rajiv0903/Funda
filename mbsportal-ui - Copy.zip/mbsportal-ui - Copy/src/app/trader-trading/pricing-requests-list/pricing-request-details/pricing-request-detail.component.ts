/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { ChangeDetectionStrategy, Component, ElementRef, Input, ViewChild, ViewEncapsulation } from '@angular/core';

import { Store } from '@ngrx/store';

import * as actions from '../../../store/actions/transaction-request.actions';
import { TransactionRequest } from '../../../store/models/transaction-request.model';
import * as fromRoot from '../../../store';
import { PricingRequestEditComponent } from './pricing-request-edit/pricing-request-edit.component';
import { UserProfileService } from '../../../shared/services/user-profile.service';
import { TransactionRequestService } from 'app/shared/services/transaction-request.service';
import { StringBooleanArray } from '../../../shared/interfaces/misc.interface';

@Component({
  selector: '[mbspPricingRequestDetail]',
  templateUrl: './pricing-request-detail.component.html',
  styleUrls: ['./pricing-request-detail.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class PricingRequestDetailComponent {

  @Input() transactionRequest: TransactionRequest;
  @Input() isUpdating: StringBooleanArray;
  @Input() error: any;

  @ViewChild('entity') entity: ElementRef;
  @ViewChild('tsp') tsp: ElementRef;
  @ViewChild('editComponent') editComponent: PricingRequestEditComponent;

  public entityTooltipDisabled: boolean;
  public tspTooltipDisabled: boolean;

  constructor(
    private store: Store<fromRoot.AppStore>,
    public userProfile: UserProfileService,
    public trService: TransactionRequestService
  ) {}

  get isUpdatingIndividual(): boolean {
    return !!this.isUpdating[this.transactionRequest.transReqId];
  }

  public onUpdate(row: TransactionRequest) {
    this.store.dispatch(new actions.UpdateAction(row));
  }

  public setTooltipVisibility(name) {
    this[name + 'TooltipDisabled'] = this[name].nativeElement.offsetWidth === this[name].nativeElement.scrollWidth;
  }

  public streamPriceColumnClickable(): boolean {
    return !(this.editComponent.notEditable(this.transactionRequest) || this.trService.isInactive(this.transactionRequest.stateType));
  }

  public copyStreamPrice() {
    if (this.streamPriceColumnClickable()) {
      this.editComponent.copyStreamPrice();
    }
  }

}
