import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'mbsp-pricing-dials',
  templateUrl: './pricing-dials.component.html',
  styleUrls: ['./pricing-dials.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PricingDialsComponent {

  @Input() ticksText: string;
  @Input() handleText: string;
  @Input() disableDials: boolean;

  @Output() updatedTicksText: EventEmitter<any> = new EventEmitter<any>();
  @Output() updatedHandleText: EventEmitter<any> = new EventEmitter<any>();

  private updateHandle(delta: number): void {
    const handleVal = parseInt(this.handleText, 10) + delta;
    if (handleVal) {
      this.updatedHandleText.emit(String(handleVal));
    }
  }

  private updateTick(delta: number): void {
    let tickValue = this.ticksText;
    tickValue = this.paddingZero('end', tickValue);
    if (tickValue.charAt(2) === '+') {
      tickValue = tickValue.substr(0, 2) + '4';
    }
    const updatedTickVal = (delta === 1) ? this.incrementTick(tickValue) : this.decrementTick(tickValue);
    tickValue = this.paddingZero('start', updatedTickVal);
    if (tickValue.charAt(2) === '4') {
      tickValue = tickValue.substr(0, 2) + '+';
    }
    this.updatedTicksText.emit(tickValue);
  }

  private incrementTick(val: string): string {
    let tickValue = val;
    if (tickValue.charAt(2) === '7') {
      tickValue = String(parseInt(tickValue, 10) + 3);
    } else {
      tickValue = String(parseInt(tickValue, 10) + 1);
    }
    return tickValue;
  }

  private decrementTick(val: string): string {
    let tickValue = val;
    let delta = 1;
    if (tickValue.charAt(2) === '0') {
      delta = 3;
    }
    tickValue = String(parseInt(tickValue, 10) - delta);
    return tickValue;
  }

  private paddingZero(place, val): string {
    let padVal = val || '0';
    padVal = String(padVal);
    while (padVal.length < 3) {
      padVal = (place === 'end') ? padVal + '0' : '0' + padVal;
    }
    return padVal;
  }

  public onDialUp() {
    if (!this.disableDials) {
      if (this.ticksText === '317') {
        this.updatedTicksText.emit('000');
        this.updateHandle(1);
      } else {
        this.updateTick(1);
      }
    }
  }

  public onDialDown() {
    if (!this.disableDials) {
      let tickValue = this.ticksText;
      tickValue = this.paddingZero('end', tickValue);
      if (tickValue === '000') {
        this.updatedTicksText.emit('317');
        this.updateHandle(-1);
      } else {
        this.updateTick(-1);
      }
    }
  }
}
