import { async, ComponentFixture, discardPeriodicTasks, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { StoreModule, Store } from '@ngrx/store';
import { By } from '@angular/platform-browser';
import { EffectsModule } from '@ngrx/effects';

import { AppStore } from '../../../../store';
import { PricingRequestEditComponent } from './pricing-request-edit.component';
import {
  LENDER_OPEN, TRADER_PRICED, LENDER_ACCEPTED, TRADER_CONFIRMED,
  TransactionRequest, TRADER_PASSED, TRADER_REJECTED, TRADER_REPRICED
} from '../../../../store/models/transaction-request.model';
import { UserProfileService } from '../../../../shared/services/user-profile.service';
import { TransactionRequestEffects } from '../../../../store/effects/transaction-request.effects';
import { TransactionRequestResource } from '../../../../shared/resources/transaction-request.resource';
import { TransactionRequestService } from '../../../../shared/services/transaction-request.service';
import { transactionRequestReducer } from '../../../../store/reducers/transaction-request.reducer';
import { LoggerService } from '../../../../shared/services/logger.service';
import { HttpModule } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { ProfileResource } from '../../../../shared/resources/profile.resource';
import { Component, Input, SimpleChange } from '@angular/core';
import { LocalStorageService } from '../../../../shared/services/local-storage.service';
import { DatePipe } from '@angular/common';
import { AllowedCharactersDirective } from '../../../../shared/directives/allowed-characters.directive';
import { getProfileReducerMock } from '../../../../util/stubs/mock-profile-reducer';
import { RoleType } from '../../../../shared/enums/role-type.enum';
import { deepCopy } from '../../../../../test';
import { StompRService } from '@stomp/ng2-stompjs';

@Component({
  selector: 'mbsp-pricing-dials',
  template: 'no markup for mocked child component'
})
class MockPricingDialsComponent {
  @Input() ticksText: string;
  @Input() handleText: string;
  @Input() disableDials: boolean;
}

@Component({
  selector: 'mbsp-transaction-timer',
  template: 'no markup for mocked child component'
})
class MockTransactionTimerComponent {
  @Input() type: 'lender' | 'trader';
  @Input() startFromSeconds: number = 0;
  @Input() countUpToSeconds?: number = 135;
  @Input() transReqId: string;
  @Input() diameter?: number = 40;
  @Input() strokeWidth?: number = 6;

  @Input() isVisible?: boolean = true;
}

describe('PricingRequestsComponentEdit', () => {
  let component: PricingRequestEditComponent;
  let fixture: ComponentFixture<PricingRequestEditComponent>;
  let store: Store<AppStore>;
  const mockTransactionRequests = deepCopy(require('../../../../../assets/data/transaction-requests.json'));
  const mockProfile = deepCopy(require('../../../../../assets/data/trader-profile.json'));

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule,
        ReactiveFormsModule,
        StoreModule.forRoot({
          profile: getProfileReducerMock(RoleType.TRADER, mockProfile),
          transactionRequests: transactionRequestReducer
        }),
        EffectsModule.forRoot([TransactionRequestEffects]),
      ],
      declarations: [
        PricingRequestEditComponent,
        MockPricingDialsComponent,
        MockTransactionTimerComponent,
        AllowedCharactersDirective
      ],
      providers: [
        LoggerService,
        LocalStorageService,
        DatePipe,
        {
          provide: ProfileResource,
          useValue: jasmine.createSpyObj('profileResource', ['log'])
        },
        {
          provide: TransactionRequestResource,
          useValue: jasmine.createSpyObj('transRequestResource', ['update'])
        },
        UserProfileService,
        TransactionRequestService,
        StompRService
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PricingRequestEditComponent);
    component = fixture.componentInstance;
    component.model = {...mockTransactionRequests[0]};
    store = fixture.debugElement.injector.get(Store);
    const profileResource = TestBed.get(ProfileResource);
    profileResource.log.and.returnValue(Observable.of());
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should check timerStartFromSeconds', () => {
    expect(component.timerStartFromSeconds).toEqual(1);
  });

  it('should set input fields with model handle and tick values', () => {
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    fixture.detectChanges();

    const handleEl  = fixture.debugElement.query(By.css('#' + component.priceHandleElementId));
    const tickEl  = fixture.debugElement.query(By.css('#' + component.priceTickElementId));

    expect(handleEl.nativeElement.value).toEqual('101');
    expect(tickEl.nativeElement.value).toEqual('116');
  });

  describe('testing stream prices', () => {
    let profileRoleName: string;
    beforeAll(() => {
      profileRoleName = mockProfile.roles[0].name;
    });

    it('should render the streaming prices for the first time', () => {
      component.model.pricePercentHandleText = '';
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      fixture.detectChanges();
      expect(component.form.get('pricePercentHandleText').value).toEqual('105');
      expect(component.form.get('pricePercentTicksText').value).toEqual('007');

      const handleEl  = fixture.debugElement.query(By.css('#' + component.priceHandleElementId));
      const tickEl  = fixture.debugElement.query(By.css('#' + component.priceTickElementId));

      expect(handleEl.nativeElement.value).toEqual('105');
      expect(tickEl.nativeElement.value).toEqual('007');
    });

    it('should be able to submit the trade on single click', () => {
      spyOn(component.submitted, 'emit');
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      fixture.detectChanges();
      const submitButton = fixture.debugElement.query(By.css('button#price-submit'));
      submitButton.triggerEventHandler('click', null);

      expect(component.submitted.emit).toHaveBeenCalledWith({...component.form.value, stateType: TRADER_PRICED});
    });

    it('should be able persist the form values of handle and tick even if model is changed', () => {
      component.form.get('pricePercentHandleText').setValue('109');
      component.form.get('pricePercentHandleText').markAsDirty();
      component.form.get('pricePercentTicksText').setValue('317');
      component.form.get('pricePercentTicksText').markAsDirty();

      const newModel = {...component.model, pricePercentHandleText: '105', pricePercentTicksText: '006'};

      component.ngOnChanges({
        model: new SimpleChange(component.model, newModel, false)
      });
      fixture.detectChanges();

      const handleEl  = fixture.debugElement.query(By.css('#' + component.priceHandleElementId));
      const tickEl  = fixture.debugElement.query(By.css('#' + component.priceTickElementId));

      expect(handleEl.nativeElement.value).toEqual('109');
      expect(tickEl.nativeElement.value).toEqual('317');
    });

    it('should detect the changes for the locked and read only traders', () => {
      component.model.stateType = 'TRADER_PRICED';
      mockProfile.userName = 'tdexec45';

      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });

      const handleEl  = fixture.debugElement.query(By.css('#' + component.priceHandleElementId));
      const tickEl  = fixture.debugElement.query(By.css('#' + component.priceTickElementId));

      expect(handleEl.nativeElement.value).toEqual('101');
      expect(tickEl.nativeElement.value).toEqual('116');

      component.model.pricePercentHandleText = '98';
      component.model.pricePercentTicksText = '125';

      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });

      expect(handleEl.nativeElement.value).toEqual('98');
      expect(tickEl.nativeElement.value).toEqual('125');
      mockProfile.userName = 'tdexec23';
    });

  });

  it('should disable input price fields when stateType is TRADER_CONFIRMED, TRADER_REJECTED, TRADER_PASSED', () => {
    expect(component.form.controls.pricePercentHandleText.disabled).toEqual(false);
    expect(component.form.controls.pricePercentTicksText.disabled).toEqual(false);

    component.model.stateType = TRADER_PASSED;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    fixture.detectChanges();

    expect(component.form.controls.pricePercentHandleText.disabled).toEqual(true);
    expect(component.form.controls.pricePercentTicksText.disabled).toEqual(true);

    component.model.stateType = TRADER_REJECTED;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    fixture.detectChanges();

    expect(component.form.controls.pricePercentHandleText.disabled).toEqual(true);
    expect(component.form.controls.pricePercentTicksText.disabled).toEqual(true);

    component.model.stateType = TRADER_CONFIRMED;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    fixture.detectChanges();

    expect(component.form.controls.pricePercentHandleText.disabled).toEqual(true);
    expect(component.form.controls.pricePercentTicksText.disabled).toEqual(true);
  });

  describe('testing read only role', () => {
    let profileRoleName: string;
    beforeAll(() => {
      profileRoleName = mockProfile.roles[0].name;
      mockProfile.roles[0].name = 'SG-MBSP-NonProd-FM-TRADER-READ-ONLY';
    });

    it('should disable input price fields when the trader role is READ-ONLY', () => {
      component.model.stateType = LENDER_OPEN;
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });

      expect(component.form.controls.pricePercentHandleText.disabled).toEqual(true);
      expect(component.form.controls.pricePercentTicksText.disabled).toEqual(true);
    });

    it('should check the disability of all the buttons for READ-ONLY trader', () => {
      component.model.stateType = LENDER_OPEN;
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      fixture.detectChanges();

      const submitButton = fixture.debugElement.query(By.css('button#price-submit'));
      expect(submitButton.nativeElement.disabled).toEqual(true);

      const passButton = fixture.debugElement.query(By.css('.btn-pass'));
      expect(passButton.nativeElement.disabled).toEqual(true);

      component.model.stateType = TRADER_PRICED;
      fixture.detectChanges();
      const cancelButton = fixture.debugElement.query(By.css('.btn-cancel'));
      expect(cancelButton.nativeElement.disabled).toEqual(true);

      component.model.stateType = LENDER_ACCEPTED;
      component.form.get('pricePercentHandleText').setValue('101');
      component.form.get('pricePercentTicksText').setValue('116');
      fixture.detectChanges();
      const confirmButton = fixture.debugElement.query(By.css('#price-execute'));
      expect(confirmButton.nativeElement.disabled).toEqual(true);
    });

    afterAll(() => {
      mockProfile.roles[0].name = profileRoleName;
    });

  });

  describe('should check the state of submit button ', () => {
    let submitButton;
    beforeEach(() => {
      component.model = {...mockTransactionRequests[0]};
      submitButton = fixture.debugElement.query(By.css('button#price-submit'));
    });
    it('for LENDER_OPEN', () => {
      component.model.stateType = LENDER_OPEN;
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      fixture.detectChanges();
      expect(submitButton.nativeElement.disabled).toEqual(false);
    });

    it('for TRADER_PASSED', () => {
      component.model.stateType = TRADER_PASSED;
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      fixture.detectChanges();
      submitButton = fixture.debugElement.query(By.css('button#price-submit'));
      expect(submitButton).toEqual(null);
    });

    it('for TRADER_PRICED', () => {
      component.model.stateType = TRADER_PRICED;
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      fixture.detectChanges();

      expect(submitButton.nativeElement.disabled).toEqual(true);
    });

    it('for TRADER_PRICED and tick and handle formValues changed', () => {
      component.model.stateType = TRADER_PRICED;
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      component.form.get('pricePercentHandleText').setValue('102');
      component.form.get('pricePercentTicksText').setValue('117');
      fixture.detectChanges();
      expect(submitButton.nativeElement.disabled).toEqual(false);
    });

    it('for TRADER_PASSED and tick and handle same as model value', () => {
      component.model.stateType = TRADER_PRICED;
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      component.form.get('pricePercentHandleText').setValue('101');
      component.form.get('pricePercentTicksText').setValue('116');
      fixture.detectChanges();
      expect(submitButton.nativeElement.disabled).toEqual(true);
    });

    it('for LENDER_ACCEPTED', () => {
      component.model.stateType = LENDER_ACCEPTED;
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      fixture.detectChanges();
      submitButton = fixture.debugElement.query(By.css('button#price-submit'));
      expect(submitButton).toEqual(null);
    });
  });

  it('should check the copyStreamPrice method', () => {
    spyOn(component, 'lock');
    component.copyStreamPrice();

    expect(component.lock).toHaveBeenCalled();
    expect(component.form.get('pricePercentHandleText').value).toEqual('105');
    expect(component.form.get('pricePercentTicksText').value).toEqual('007');

    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });

    expect(component.form.get('pricePercentHandleText').value).toEqual('105');
    expect(component.form.get('pricePercentTicksText').value).toEqual('007');

    component.model.streamPricePercentHandleText = '106';
    component.model.streamPricePercentTicksText = '008';

    component.copyStreamPrice();

    expect(component.form.get('pricePercentHandleText').value).toEqual('106');
    expect(component.form.get('pricePercentTicksText').value).toEqual('008');
  });

  it('should check the notEditable method', () => {
    component.model.traderId = 'tdexec23';
    expect(component.notEditable()).toEqual(false);
    const model2 = {...component.model, traderId: 'admin12'};
    expect(component.notEditable(model2)).toEqual(true);
  });

  it('should check disablePriceControls for Active trade Request', () => {
    component.model.stateType = TRADER_PRICED;
    component.model.traderId = 'tdexec23';
    component.notEditable();
    expect(component.disablePriceControls()).toEqual(false);

    const model2 = {...component.model, traderId: 'admin12'};
    component.notEditable(model2);
    expect(component.disablePriceControls()).toEqual(false);
  });

  it('should check disablePriceControls for InActive trade', () => {
    component.model.stateType = TRADER_REJECTED;
    component.model.traderId = 'tdexec23';
    component.notEditable();
    expect(component.disablePriceControls()).toEqual(true);

    const model2 = {...component.model, traderId: 'admin12'};
    component.notEditable(model2);
    expect(component.disablePriceControls()).toEqual(true);
  });

  describe(' should check the ', () => {
    let submitButton;
    beforeEach(() => {
      component.model = {...mockTransactionRequests[1]};
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      fixture.detectChanges();
      submitButton = fixture.debugElement.query(By.css('button#price-submit'));
    });
    it('handle price invalid low', () => {
      component.form.get('pricePercentHandleText').setValue('89');
      component.form.get('pricePercentHandleText').markAsDirty();
      component.form.get('pricePercentTicksText').setValue('116');
      component.form.get('pricePercentTicksText').markAsDirty();
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      fixture.detectChanges();
      submitButton.triggerEventHandler('click', null);
      expect(component.form.get('pricePercentHandleText').invalid).toEqual(true);
    });
    it('handle price invalid high', () => {
      component.form.get('pricePercentHandleText').setValue('116');
      component.form.get('pricePercentHandleText').markAsDirty();
      component.form.get('pricePercentTicksText').setValue('000');
      component.form.get('pricePercentTicksText').markAsDirty();
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      fixture.detectChanges();
      submitButton.triggerEventHandler('click', null);
      expect(component.form.get('pricePercentHandleText').invalid).toEqual(true);
    });
    it('handle price valid low', () => {
      component.form.get('pricePercentHandleText').setValue('90');
      component.form.get('pricePercentTicksText').setValue('116');
      fixture.detectChanges();
      submitButton.triggerEventHandler('click', null);
      expect(component.form.get('pricePercentHandleText').invalid).toEqual(false);
    });
    it('handle price valid high', () => {
      component.form.get('pricePercentHandleText').setValue('115');
      component.form.get('pricePercentTicksText').setValue('001');
      fixture.detectChanges();
      submitButton.triggerEventHandler('click', null);
      expect(component.form.get('pricePercentHandleText').invalid).toEqual(false);
    });
    it('tick price not valid', () => {
      component.form.get('pricePercentHandleText').setValue('115');
      component.form.get('pricePercentHandleText').markAsDirty();
      component.form.get('pricePercentTicksText').setValue('32');
      component.form.get('pricePercentTicksText').markAsDirty();
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      fixture.detectChanges();
      submitButton.triggerEventHandler('click', null);
      expect(component.form.get('pricePercentTicksText').invalid).toEqual(true);
    });
    it('tick price valid', () => {
      component.form.get('pricePercentHandleText').setValue('114');
      component.form.get('pricePercentTicksText').setValue('001');
      fixture.detectChanges();
      submitButton.triggerEventHandler('click', null);
      expect(component.form.get('pricePercentTicksText').invalid).toEqual(false);
    });
  });


  describe('should check the setDefaultTickValue() method', () => {
    let handleForm;
    let tickForm;
    beforeEach(() => {
      handleForm = component.form.get('pricePercentHandleText');
      tickForm = component.form.get('pricePercentTicksText');
      component.model.pricePercentTicksText = '00';
      component.model.stateType = LENDER_ACCEPTED;
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
    });
    it('for empty tick', () => {
      handleForm.setValue('101');
      tickForm.setValue('');
      component.onExecute();
      expect(tickForm.value).toEqual('00');
    });

    it('for Valid tick', () => {
      handleForm.setValue('101');
      tickForm.setValue('12+');
      component.onExecute();
      expect(tickForm.value).toEqual('12+');
    });

    it('for Invalid tick', () => {
      handleForm.setValue('114');
      tickForm.setValue('0');
      const transRequestResource = TestBed.get(TransactionRequestResource);
      transRequestResource.update.and.returnValue(Observable.of(component.model));
      component.onExecute();
      expect(tickForm.value).toEqual('0');
    });
  });

  describe('should check for markPriceAsValid for the tooltip', () => {
    let submitButton;
    beforeEach(() => {
      component.model = {...mockTransactionRequests[1]};
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      fixture.detectChanges();
      submitButton = fixture.debugElement.query(By.css('button#price-submit'));
    });
    it('tick price inValid', () => {
      component.form.get('pricePercentHandleText').setValue('114');
      component.form.get('pricePercentTicksText').setValue('365');
      fixture.detectChanges();
      submitButton.triggerEventHandler('click', null);
      expect(component.handleMarkedAsInvalid).toEqual(false);
      expect(component.tickMarkedAsInvalid).toEqual(true);
    });
    it('handle price inValid', () => {
      component.form.get('pricePercentHandleText').setValue('120');
      component.form.get('pricePercentTicksText').setValue('317');
      fixture.detectChanges();
      submitButton.triggerEventHandler('click', null);
      expect(component.handleMarkedAsInvalid).toEqual(true);
      expect(component.tickMarkedAsInvalid).toEqual(false);
    });
    it('both handle and tick are inValid', () => {
      component.form.get('pricePercentHandleText').setValue('120');
      component.form.get('pricePercentTicksText').setValue('347');
      fixture.detectChanges();
      submitButton.triggerEventHandler('click', null);
      expect(component.handleMarkedAsInvalid).toEqual(true);
      expect(component.tickMarkedAsInvalid).toEqual(true);
    });
    it('when focus after tooltip', () => {
      component.handleMarkedAsInvalid = true;
      component.tickMarkedAsInvalid = true;
      component.onFocus();
      expect(component.handleMarkedAsInvalid).toEqual(false);
      expect(component.tickMarkedAsInvalid).toEqual(false);
    });
    it('when clicking on dials after tooltip', () => {
      component.handleMarkedAsInvalid = true;
      component.tickMarkedAsInvalid = true;
      component.updatedTicksText('323');
      expect(component.handleMarkedAsInvalid).toEqual(false);
      expect(component.tickMarkedAsInvalid).toEqual(false);
    });
    it('when clicking on stream price column after tooltip', () => {
      component.handleMarkedAsInvalid = true;
      component.tickMarkedAsInvalid = true;
      component.copyStreamPrice();
      expect(component.handleMarkedAsInvalid).toEqual(false);
      expect(component.tickMarkedAsInvalid).toEqual(false);
    });
  });

  it('should check if the handle and tick values are not lost when there is an update on other trades', () => {
    component.form.get('pricePercentHandleText').setValue('115');
    component.form.get('pricePercentTicksText').setValue('115');

    component.onPriceSubmit();
    component.markPriceAsInvalid();

    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    fixture.detectChanges();

    const handlePriceField = fixture.debugElement.query(By.css('#' + component.priceHandleElementId));
    const tickPriceField = fixture.debugElement.query(By.css('#' + component.priceTickElementId));

    expect(handlePriceField.nativeElement.value).toEqual('115');
    expect(tickPriceField.nativeElement.value).toEqual('115');
  });

  it('should check the state of Pass button based on the stateType', () => {
    component.model.stateType = LENDER_OPEN;
    fixture.detectChanges();

    let passButton = fixture.debugElement.query(By.css('.btn-pass'));
    expect(passButton.nativeElement.disabled).toEqual(false);

    component.model.stateType = TRADER_PASSED;
    fixture.detectChanges();
    passButton = fixture.debugElement.query(By.css('.btn-pass'));
    expect(passButton).toEqual(null);

    component.model.stateType = TRADER_PRICED;
    fixture.detectChanges();
    passButton = fixture.debugElement.query(By.css('.btn-pass'));
    expect(passButton).toEqual(null);
  });

  it('should check the background and border colors of Pass Button', () => {
    component.model.stateType = LENDER_OPEN;
    fixture.detectChanges();

    const passButton = fixture.debugElement.query(By.css('.btn-pass'));
    const element = passButton.nativeElement;
    const styles = window.getComputedStyle(element);
    expect(styles.backgroundColor).toEqual('rgb(255, 239, 213)');
    expect(styles.borderColor).toEqual('rgb(245, 166, 35)');
  });

  it('should check the state of Cancel button based on the stateType', () => {
    component.model.stateType = LENDER_OPEN;
    fixture.detectChanges();

    let cancelButton = fixture.debugElement.query(By.css('.btn-cancel'));
    expect(cancelButton).toEqual(null);

    component.model.stateType = TRADER_PASSED;
    fixture.detectChanges();
    expect(cancelButton).toEqual(null);

    component.model.stateType = TRADER_PRICED;
    fixture.detectChanges();
    cancelButton = fixture.debugElement.query(By.css('.btn-cancel'));
    expect(cancelButton.nativeElement.disabled).toEqual(false);

    component.model.stateType = TRADER_REJECTED;
    fixture.detectChanges();
    cancelButton = fixture.debugElement.query(By.css('.btn-cancel'));
    expect(cancelButton).toEqual(null);

    component.model.stateType = TRADER_CONFIRMED;
    fixture.detectChanges();
    cancelButton = fixture.debugElement.query(By.css('.btn-cancel'));
    expect(cancelButton).toEqual(null);
  });

  it('should check the state of hit/lift button based on the stateType', () => {
    component.model.stateType = LENDER_OPEN;
    fixture.detectChanges();

    let confirmButton = fixture.debugElement.query(By.css('#price-execute'));
    expect(confirmButton).toEqual(null);

    component.model.stateType = LENDER_ACCEPTED;
    component.form.get('pricePercentHandleText').setValue('101');
    component.form.get('pricePercentTicksText').setValue('116');
    fixture.detectChanges();

    confirmButton = fixture.debugElement.query(By.css('#price-execute'));
    let submitButton = fixture.debugElement.query(By.css('#price-submit'));

    expect(confirmButton).toBeTruthy();
    expect(confirmButton.nativeElement.disabled).toEqual(false);
    expect(submitButton).toEqual(null);

    component.form.get('pricePercentHandleText').setValue('102');
    component.form.get('pricePercentTicksText').setValue('117');
    fixture.detectChanges();

    confirmButton = fixture.debugElement.query(By.css('#price-execute'));
    submitButton = fixture.debugElement.query(By.css('#price-submit'));

    expect(confirmButton).toEqual(null);
    expect(submitButton).toBeTruthy();

    component.form.get('pricePercentHandleText').setValue('101');
    component.form.get('pricePercentTicksText').setValue('116');
    fixture.detectChanges();

    confirmButton = fixture.debugElement.query(By.css('#price-execute'));
    expect(confirmButton.nativeElement.disabled).toEqual(false);
    submitButton = fixture.debugElement.query(By.css('#price-submit'));

    expect(confirmButton).toBeTruthy();
    expect(submitButton).toEqual(null);

    component.model.stateType = TRADER_CONFIRMED;
    fixture.detectChanges();
    confirmButton = fixture.debugElement.query(By.css('#price-execute'));

    expect(confirmButton).toEqual(null);

    component.model.stateType = TRADER_REJECTED;
    fixture.detectChanges();
    confirmButton = fixture.debugElement.query(By.css('#price-execute'));

    expect(confirmButton).toEqual(null);
  });

  it('should check to preserve the price and not show execute button when lender accepts and a trader is in a process of ' +
    'repricing', () => {
    component.model.stateType = LENDER_ACCEPTED;
    component.form.get('pricePercentHandleText').setValue('101');
    component.form.get('pricePercentTicksText').setValue('116');
    fixture.detectChanges();
    let submitButton = fixture.debugElement.query(By.css('#price-submit'));
    let confirmButton = fixture.debugElement.query(By.css('#price-execute'));

    expect(confirmButton.nativeElement.disabled).toEqual(false);
    expect(submitButton).toEqual(null);
    component.model.stateType = TRADER_REPRICED;

    component.form.get('pricePercentHandleText').setValue('102');
    component.form.get('pricePercentHandleText').markAsDirty();
    component.form.get('pricePercentTicksText').setValue('118');
    component.form.get('pricePercentTicksText').markAsDirty();
    fixture.detectChanges();
    component.model.stateType = LENDER_ACCEPTED;
    component.model.pricePercentHandleText = '101';
    component.model.pricePercentTicksText = '116';
    component.ngOnChanges({});

    submitButton = fixture.debugElement.query(By.css('#price-submit'));
    confirmButton = fixture.debugElement.query(By.css('#price-execute'));

    expect(submitButton.nativeElement.disabled).toEqual(false);
    expect(confirmButton).toEqual(null);
    expect(component.form.get('pricePercentHandleText').value).toEqual('102');
    expect(component.form.controls.pricePercentTicksText.value).toEqual('118');
  });

  it('should raise submitted event when trader is pricing the trade', () => {
    component.model.stateType = LENDER_OPEN;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    fixture.detectChanges();

    const submitButton = fixture.debugElement.query(By.css('#price-submit'));

    component.submitted.subscribe((transRequest: TransactionRequest) => {
      expect(transRequest.stateType).toEqual(TRADER_PRICED);
    });

    submitButton.triggerEventHandler('click', null);
  });

  it('should raise submitted event when trader is pricing the trade', () => {
    component.model.stateType = TRADER_PRICED;
    component.ngOnChanges({});
    fixture.detectChanges();

    const submitButton = fixture.debugElement.query(By.css('#price-submit'));
    component.form.get('pricePercentHandleText').setValue('102');
    component.form.get('pricePercentTicksText').setValue('117');
    fixture.detectChanges();

    component.submitted.subscribe((transRequest: TransactionRequest) => {
      expect(transRequest.stateType).toEqual(TRADER_REPRICED);
    });

    submitButton.triggerEventHandler('click', null);
  });

  it('should raise submitted event when trader is confirming the trade', () => {
    component.model.stateType = LENDER_ACCEPTED;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    fixture.detectChanges();

    const confirmButton = fixture.debugElement.query(By.css('#price-execute'));

    component.submitted.subscribe((transRequest: TransactionRequest) => {
      expect(transRequest.stateType).toEqual(TRADER_CONFIRMED);
    });

    confirmButton.triggerEventHandler('click', null);
  });

  it('should check for lock method being called', () => {
    component.model = {...mockTransactionRequests[1]};
    fixture.detectChanges();

    spyOn(component, 'lock');

    const priceField = fixture.debugElement.query(By.css('#' + component.priceHandleElementId));
    priceField.triggerEventHandler('focus', null);
    fixture.detectChanges();

    expect(component.lock).toHaveBeenCalled();
  });

  it('should check for traderId form value for locking', fakeAsync(() => {
    component.model = {...mockTransactionRequests[1]};
    component.model.traderId = 'tdexec23';
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    const transRequestResource = TestBed.get(TransactionRequestResource);
    transRequestResource.update.and.returnValue(Observable.of(component.model));
    fixture.detectChanges();
    component.lock();

    expect(component.form.get('traderId').value).toEqual('tdexec23');
    discardPeriodicTasks();
  }));

  it('should check for showReleaseButton() method for reserved trader', () => {
    component.model = {...mockTransactionRequests[0]};
    component.model.traderId = 'tdexec23';
    fixture.detectChanges();

    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });

    expect(component.showReleaseButton()).toEqual(true);
  });

  it('should check for showReleaseButton() method for locked trader', () => {
    component.model = {...mockTransactionRequests[0]};
    component.model.traderId = 'admin45';
    fixture.detectChanges();

    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });

    expect(component.showReleaseButton()).toEqual(false);
  });

  it('should check for traderId form value for releasing', fakeAsync(() => {
    const transRequestResource = TestBed.get(TransactionRequestResource);
    component.model = {...mockTransactionRequests[1]};
    component.model.pricePercentHandleText = '';
    component.model.pricePercentTicksText = '';
    component.model.traderId = 'tdexec23';
    component.model.stateType = 'LENDER_OPEN';
    transRequestResource.update.and.returnValue(Observable.of(component.model));
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    fixture.detectChanges();
    component.release();

    expect(component.form.get('traderId').value).toEqual('');
  }));

  describe('check isTickRepriced method', () => {
    it('model and form tick is empty', () => {
      component.model.pricePercentTicksText = '';
      component.form.get('pricePercentTicksText').setValue('');

      expect(component.isTickRepriced()).toEqual(false);
    });

    it('model has tick, form is empty', () => {
      component.model.pricePercentTicksText = '11';
      component.form.get('pricePercentTicksText').setValue('');

      expect(component.isTickRepriced()).toEqual(true);
    });

    it('model has tick, form has the same tick', () => {
      component.model.pricePercentTicksText = '11';
      component.form.get('pricePercentTicksText').setValue('11');

      expect(component.isTickRepriced()).toEqual(false);
    });

    it('model tick is 101, form tick is 102', () => {
      component.model.pricePercentTicksText = '101';
      component.form.get('pricePercentTicksText').setValue('102');

      expect(component.isTickRepriced()).toEqual(true);
    });

    it('model tick is 101, form tick is 104', () => {
      component.model.pricePercentTicksText = '101';
      component.form.get('pricePercentTicksText').setValue('104');

      expect(component.isTickRepriced()).toEqual(true);
    });

    it('model tick is 10+, form tick is 104', () => {
      component.model.pricePercentTicksText = '10+';
      component.form.get('pricePercentTicksText').setValue('104');

      expect(component.isTickRepriced()).toEqual(false);
    });

    it('model tick is 10+, form tick is 204', () => {
      component.model.pricePercentTicksText = '10+';
      component.form.get('pricePercentTicksText').setValue('204');

      expect(component.isTickRepriced()).toEqual(true);
    });

    it('model tick is 14, form tick is 15', () => {
      component.model.pricePercentTicksText = '14';
      component.form.get('pricePercentTicksText').setValue('15');

      expect(component.isTickRepriced()).toEqual(true);
    });

    it('model tick is 00, form tick is empty', () => {
      component.model.pricePercentTicksText = '00';
      component.form.get('pricePercentTicksText').setValue('');

      expect(component.isTickRepriced()).toEqual(false);
    });

  });

  it('should set the stream price in the inputs', () => {
    const model = {
      ...component.model,
      stateType: LENDER_ACCEPTED,
      pricePercentHandleText: '',
      pricePercentTicksText: '',
      streamPricePercentHandleText: '95',
      streamPricePercentTicksText: '27'
    };
    component.model = model;
    component.ngOnChanges({
      model: new SimpleChange(null, model, false)
    });
    expect(component.form.get('pricePercentHandleText').value).toEqual('95');
    expect(component.form.get('pricePercentTicksText').value).toEqual('27');

    model.traderId = 'someTraderId';
    model.streamPricePercentHandleText = '95';
    model.streamPricePercentTicksText = '27+';
    component.ngOnChanges({
      model: new SimpleChange(null, model, false)
    });
    expect(component.form.get('pricePercentHandleText').value).toEqual('95');
    expect(component.form.get('pricePercentTicksText').value).toEqual('27');

    model.traderId = null;
    component.ngOnChanges({
      model: new SimpleChange({...model, traderId: 'someTraderId'}, model, false)
    });
    expect(component.form.get('pricePercentHandleText').value).toEqual('95');
    expect(component.form.get('pricePercentTicksText').value).toEqual('27+');
  });
});
