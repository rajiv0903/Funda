/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { Component, OnChanges, Input, ViewEncapsulation, Output, EventEmitter, SimpleChanges, OnInit, SimpleChange } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import isEqual from 'lodash-es/isEqual';
import { Store } from '@ngrx/store';

import {
  TransactionRequest, LENDER_OPEN, LENDER_ACCEPTED, TRADER_PRICED,
  TRADER_CONFIRMED, TRADER_PASSED, TRADER_REJECTED, TRADER_REPRICED
} from '../../../../store/models/transaction-request.model';
import { TransactionRequestService } from '../../../../shared/services/transaction-request.service';
import { UserProfileService } from '../../../../shared/services/user-profile.service';
import { AppStore } from '../../../../store';
import * as actions from '../../../../store/actions/transaction-request.actions';
import { LoggerService } from '../../../../shared/services/logger.service';
import { enableWS } from '../../../../shared/constants/system.constant';
import { priceThresholdHigh, priceThresholdLow } from '../../../../shared/constants/business.constant';
import { invalidPriceErrorText } from '../../../../shared/constants/validation.constant';

@Component({
  selector: 'mbsp-pricing-request-edit',
  templateUrl: './pricing-request-edit.component.html',
  styleUrls: ['./pricing-request-edit.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PricingRequestEditComponent implements OnChanges, OnInit {

  @Input() model: TransactionRequest;
  @Input() isUpdating: boolean;
  @Input() error: any;

  @Output() submitted = new EventEmitter<TransactionRequest>();

  private initialStreamPricePercentHandleText: string;
  private initialStreamPricePercentTicksText: string;
  public form: FormGroup;
  // TODO refactor when we have robust form validation concept
  public handleMarkedAsInvalid = false;
  public tickMarkedAsInvalid = false;
  public invalidPriceErrorText = invalidPriceErrorText;
  public timerStartFromSeconds: number;
  public numberChar: RegExp = /^([0-9]{1,3})$/;
  public numberAndPlusChar: RegExp = /^([0-9|+]{1,3})$/;

  constructor(
    private store: Store<AppStore>,
    public trService: TransactionRequestService,
    private loggerService: LoggerService,
    private userProfile: UserProfileService,
    public formBuilder: FormBuilder,
  ) {
    this.createForm();
  }

  get priceHandleElementId(): string {
    return 'price-handle-' + this.model.transReqId;
  }

  get priceTickElementId(): string {
    return 'price-tick-' + this.model.transReqId;
  }

  ngOnInit() {
    this.timerStartFromSeconds = this.trService.getAge(this.model.lastPublishTime, this.model.submissionDate);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.error && !changes.error.previousValue && changes.error.currentValue) {
      if (this.isPriceControlValidationError(changes.error.currentValue)) {
        this.markPriceAsInvalid();
      }
    }
    if (changes.model && !isEqual(changes.model.previousValue, changes.model.currentValue)) {
      this.updateForm();
      this.setInitialStreamPrice(changes.model);
      this.populateStreamPrice();
      this.managePriceControls();
    }
    if (this.model.updateNeeded && this.trService.isActive(this.model.stateType)) {
      this.store.dispatch(new actions.LoadOneAndReplaceAction({transReqId: this.model.transReqId}));
    }
  }

  private setInitialStreamPrice(modelChanges: SimpleChange) {
    if (!modelChanges.currentValue.traderId && modelChanges.previousValue && modelChanges.previousValue.traderId) {
      this.initialStreamPricePercentHandleText = null;
      this.initialStreamPricePercentTicksText = null;
    }
    if (!this.initialStreamPricePercentHandleText && this.model.streamPricePercentHandleText) {
      this.initialStreamPricePercentHandleText = this.model.streamPricePercentHandleText;
    }
    if (!this.initialStreamPricePercentTicksText && this.model.streamPricePercentTicksText) {
      this.initialStreamPricePercentTicksText = this.model.streamPricePercentTicksText;
    }
  }

  private populateStreamPrice(): void {
    if (!this.form.get('pricePercentHandleText').value && this.form.get('pricePercentHandleText').pristine) {
      this.form.get('pricePercentHandleText').setValue(this.initialStreamPricePercentHandleText);
      this.form.get('pricePercentTicksText').setValue(this.initialStreamPricePercentTicksText);
    }
  }

  public copyStreamPrice() {
    this.form.get('pricePercentHandleText').setValue(this.model.streamPricePercentHandleText);
    this.form.get('pricePercentTicksText').setValue(this.model.streamPricePercentTicksText);
    this.form.get('pricePercentHandleText').markAsDirty();
    this.form.get('pricePercentTicksText').markAsDirty();
    this.lock();
    this.markPriceAsValid();
  }

  private isPriceControlValidationError(error: any): boolean {
    // TODO fix when exception framework is in place (check error code etc)
    return error.status === 400 && error.messages && error.messages.length > 0
      && error.messages[0].messageCode === 'TRAN_5003' && this.model.transReqId === error.transReqId;
  }

  private updateForm(): void {
    Object.keys(this.form.controls).forEach(formControlName => {
      if (this.form.get(formControlName).pristine) {
        this.form.get(formControlName).setValue(this.model[formControlName]);
      }
    });
  }

  private managePriceControls(): void {
    this.form.get('pricePercentHandleText').enable();
    this.form.get('pricePercentTicksText').enable();
    if (this.disablePriceControls()) {
      this.markPriceAsValid();
      this.form.get('pricePercentHandleText').disable();
      this.form.get('pricePercentTicksText').disable();
    }
  }

  private createForm(): void {
    this.form = this.formBuilder.group({
      'transReqId': '',
      'traderId': '',
      'pricePercentHandleText': [
        '',
        [
          Validators.required,
          Validators.min(priceThresholdLow),
          Validators.max(priceThresholdHigh)
        ]
      ],
      'pricePercentTicksText': [
        '',
        [
          Validators.pattern(/^[0-2][0-9][0-7|+]$|^[3][0-1][0-7|+]$|^[0-2][0-9]$|^[3][0-1]$/)
        ]
      ],
      'stateType': '',
      'activeVersion': ''
    });
  }

  private markPriceAsValid(): void {
    this.handleMarkedAsInvalid = false;
    this.tickMarkedAsInvalid = false;
  }

  public markPriceAsInvalid(): void {
    this.handleMarkedAsInvalid = true;
    this.tickMarkedAsInvalid = true;
    this.form.get('pricePercentTicksText').markAsDirty();
    this.form.get('pricePercentHandleText').markAsDirty();
    this.loggerService.info('Invalid Value for handle/tick field '
      + this.form.get('pricePercentHandleText').value + ': ' + this.form.get('pricePercentTicksText').value);
  }

  public updatedHandleText(val: string) {
    this.form.get('pricePercentHandleText').setValue(val);
  }

  public updatedTicksText(val: string) {
    this.form.get('pricePercentTicksText').setValue(val);
    this.onFocus();
  }

  public setDefaultTickValue(): void {
    if (!this.form.get('pricePercentTicksText').value) {
      this.form.get('pricePercentTicksText').setValue('00');
    }
  }

  public onPriceSubmit(): void {
    if (this.form.valid) {
      const stateType = this.inLenderOpenState() ? TRADER_PRICED : TRADER_REPRICED;
      this.loggerService.info('Trader submitted ' + stateType + ' for transaction: ' + this.model.transReqId);
      this.form.markAsPristine();
      this.submitted.emit({
        ...this.form.value,
        stateType: stateType
      });
    } else {
      this.lock();
      this.validateHandleText();
      this.validateTicksText();
    }
  }

  public onExecute(): void {
    this.loggerService.info('Trader confirmed transaction: ' + this.model.transReqId);
    this.setDefaultTickValue();
    this.submitted.emit({
      ...this.form.value,
      stateType: TRADER_CONFIRMED
    });
  }

  public onTraderPass(): void {
    this.loggerService.info('Trader passed transaction: ' + this.model.transReqId);
    this.submitted.emit({
      ...this.form.value,
      stateType: TRADER_PASSED
    });
  }

  public onTraderCancel(): void {
    this.loggerService.info('Trader rejected transaction: ' + this.model.transReqId);
    this.submitted.emit({
      ...this.form.value,
      stateType: TRADER_REJECTED
    });
  }

  public onFocus(): void {
    this.lock();
    this.form.get('pricePercentTicksText').markAsDirty();
    this.form.get('pricePercentHandleText').markAsDirty();
    this.markPriceAsValid();
  }

  public lock(): void {
    if (this.trService.isLenderOpen(this.model.stateType)) {
      if (!this.form.get('traderId').value) {
        this.form.get('traderId').setValue(this.userProfile.id);
        this.store.dispatch(new actions.UpdateAction(this.form.value));
      }
    }
  }

  public release(): void {
    if (this.trService.isLenderOpen(this.model.stateType)) {
      if (this.form.get('traderId').value === this.userProfile.id) {
        this.markPriceAsValid();
        this.form.get('traderId').setValue('');
        this.form.get('pricePercentHandleText').markAsPristine();
        this.form.get('pricePercentTicksText').markAsPristine();
        this.store.dispatch(new actions.UpdateAction(this.form.value));
      }
    }
  }

  public notEditable(tr?: TransactionRequest): boolean {
    const model = tr || this.model;
    return !this.userProfile.canExecute || this.trService.isLocked(this.userProfile.id, model.traderId);
  }

  // TODO negate the logic so that name makes sense
  public isNotRepriced(): boolean {
    return ((this.model.pricePercentHandleText === this.form.get('pricePercentHandleText').value)
    && !this.isTickRepriced());
  }

  public isTickRepriced(): boolean {
    let repriced = false;

    const modelTick = this.model.pricePercentTicksText || '';
    const formTick = this.form.get('pricePercentTicksText').value || '';

    if (modelTick !== formTick) {
      repriced = true;
    }

    if (
      modelTick.charAt(2) === '+' && formTick.charAt(2) === '4'
      && modelTick.charAt(0) === formTick.charAt(0)
      && modelTick.charAt(1) === formTick.charAt(1)
    ) {
      repriced = false;
    }

    if (modelTick === '00' && formTick === '') {
      repriced = false;
    }

    return repriced;
  }

  public validateHandleText(): boolean {
    this.handleMarkedAsInvalid = false;
    if (this.form.get('pricePercentHandleText').invalid) {
      this.handleMarkedAsInvalid = true;
      this.loggerService.info('Invalid Value for handle ' + this.form.get('pricePercentHandleText').value);
    }
    return this.handleMarkedAsInvalid;
  }

  public validateTicksText(): boolean {
    this.tickMarkedAsInvalid = false;
    if (this.form.get('pricePercentTicksText').invalid) {
      this.tickMarkedAsInvalid = true;
      this.loggerService.info('Invalid Value for tick field ' + this.form.get('pricePercentTicksText').value);
    }
    return this.tickMarkedAsInvalid;
  }

  public dismissInactiveTrade(row: TransactionRequest) {
    this.store.dispatch(new actions.DeleteSuccessAction(row));
  }

  public showSubmitButton(): boolean {
    // TODO refactor when using single submit/execute button
    return [
        LENDER_OPEN,
        TRADER_PRICED,
        TRADER_REPRICED,
      ].includes(this.model.stateType) || (!this.isNotRepriced() && this.trService.isActive(this.model.stateType));
  }

  public showPassButton(): boolean {
    return [LENDER_OPEN].includes(this.model.stateType);
  }

  public showCancelButton(): boolean {
    return [
      TRADER_PRICED,
      TRADER_REPRICED,
      LENDER_ACCEPTED
    ].includes(this.model.stateType);
  }

  public showExecuteButton(): boolean {
    return (this.inLenderAcceptedState() && this.isNotRepriced());
  }

  public showReleaseButton(): boolean {
    return this.trService.isLenderOpen(this.model.stateType) &&
      this.trService.isReserved(this.userProfile.id, this.form.get('traderId').value)
  }

  public isActive(): boolean {
    return this.trService.isActive(this.model.stateType);
  }

  public isInactive(): boolean {
    return this.trService.isInactive(this.model.stateType);
  }

  public disableSubmitButton(): boolean {
    return this.notEditable() || this.isUpdating || (([TRADER_PRICED, TRADER_REPRICED].includes(this.model.stateType)
      && this.isNotRepriced()) || [TRADER_PASSED, TRADER_REJECTED].includes(this.model.stateType));
  }

  public disablePassButton(): boolean {
    return this.notEditable() || this.inTraderPassedState() || this.isUpdating;
  }

  public disablePriceControls(): boolean {
    return this.notEditable() || this.trService.isInactive(this.model.stateType);
  }

  public disableCancelButton(): boolean {
    return this.notEditable() || this.inTraderRejectedState() || this.inTraderConfirmedState() || this.isUpdating;
  }

  public disableExecuteButton(): boolean {
    return this.notEditable() || this.inTraderConfirmedState() || this.isUpdating;
  }

  public inLenderOpenState(): boolean {
    return this.trService.isLenderOpen(this.model.stateType);
  }

  public inTraderPassedState(): boolean {
    return this.trService.isTraderPassed(this.model.stateType);
  }

  public inTraderRejectedState(): boolean {
    return this.trService.isTraderRejected(this.model.stateType);
  }

  public inLenderAcceptedState(): boolean {
    return this.trService.isLenderAccepted(this.model.stateType);
  }

  public inTraderConfirmedState(): boolean {
    return this.trService.isTraderConfirmed(this.model.stateType);
  }

}
