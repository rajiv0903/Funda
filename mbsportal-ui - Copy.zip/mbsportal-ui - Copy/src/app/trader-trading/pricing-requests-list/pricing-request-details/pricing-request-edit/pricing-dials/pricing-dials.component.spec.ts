import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PricingDialsComponent } from './pricing-dials.component';
import { By } from '@angular/platform-browser';

describe('PricingDialsComponent', () => {
  let component: PricingDialsComponent;
  let fixture: ComponentFixture<PricingDialsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PricingDialsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PricingDialsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  describe('should check for up dial', () => {
    beforeEach(() => {
      spyOn(component.updatedTicksText, 'emit');
      spyOn(component.updatedHandleText, 'emit');
    });

    it('when there is no tick', () => {
      component.ticksText = '';
      const upDial = fixture.debugElement.query(By.css('.dial-up'));

      upDial.triggerEventHandler('click', null);
      expect(component.updatedTicksText.emit).toHaveBeenCalledWith('001');
    });

    it('when the tick is 001', () => {
      component.ticksText = '001';
      const upDial = fixture.debugElement.query(By.css('.dial-up'));

      upDial.triggerEventHandler('click', null);
      expect(component.updatedTicksText.emit).toHaveBeenCalledWith('002');
    });

    it('when the tick is ending with 3', () => {
      component.ticksText = '123';
      const upDial = fixture.debugElement.query(By.css('.dial-up'));

      upDial.triggerEventHandler('click', null);
      expect(component.updatedTicksText.emit).toHaveBeenCalledWith('12+');
    });

    it('when the tick is ending with +', () => {
      component.ticksText = '16+';
      const upDial = fixture.debugElement.query(By.css('.dial-up'));

      upDial.triggerEventHandler('click', null);
      expect(component.updatedTicksText.emit).toHaveBeenCalledWith('165');
    });

    it('when the tick two digits', () => {
      component.ticksText = '25';
      const upDial = fixture.debugElement.query(By.css('.dial-up'));

      upDial.triggerEventHandler('click', null);
      expect(component.updatedTicksText.emit).toHaveBeenCalledWith('251');
    });

    it('when the tick is 217', () => {
      component.ticksText = '217';
      const upDial = fixture.debugElement.query(By.css('.dial-up'));

      upDial.triggerEventHandler('click', null);
      expect(component.updatedTicksText.emit).toHaveBeenCalledWith('220');
    });

    it('when the tick is 317', () => {
      component.ticksText = '317';
      component.handleText = '101';

      const upDial = fixture.debugElement.query(By.css('.dial-up'));

      upDial.triggerEventHandler('click', null);

      expect(component.updatedHandleText.emit).toHaveBeenCalledWith('102');
      expect(component.updatedTicksText.emit).toHaveBeenCalledWith('000');
    });

  });

  describe('should check for down dial', () => {
    beforeEach(() => {
      spyOn(component.updatedTicksText, 'emit');
      spyOn(component.updatedHandleText, 'emit');
    });

    it('when there is no tick', () => {
      component.ticksText = '';
      component.handleText = '103';
      const downDial = fixture.debugElement.query(By.css('.dial-down'));

      downDial.triggerEventHandler('click', null);
      expect(component.updatedHandleText.emit).toHaveBeenCalledWith('102');
      expect(component.updatedTicksText.emit).toHaveBeenCalledWith('317');
    });

    it('when the tick is 000', () => {
      component.ticksText = '000';
      component.handleText = '101';

      const downDial = fixture.debugElement.query(By.css('.dial-down'));

      downDial.triggerEventHandler('click', null);

      expect(component.updatedHandleText.emit).toHaveBeenCalledWith('100');
      expect(component.updatedTicksText.emit).toHaveBeenCalledWith('317');
    });

    it('when the tick is 126', () => {
      component.ticksText = '126';
      const downDial = fixture.debugElement.query(By.css('.dial-down'));

      downDial.triggerEventHandler('click', null);
      expect(component.updatedTicksText.emit).toHaveBeenCalledWith('125');
    });

    it('when the tick is ending with 5', () => {
      component.ticksText = '105';
      const downDial = fixture.debugElement.query(By.css('.dial-down'));

      downDial.triggerEventHandler('click', null);
      expect(component.updatedTicksText.emit).toHaveBeenCalledWith('10+');
    });

    it('when the tick is ending with +', () => {
      component.ticksText = '16+';
      const downDial = fixture.debugElement.query(By.css('.dial-down'));

      downDial.triggerEventHandler('click', null);
      expect(component.updatedTicksText.emit).toHaveBeenCalledWith('163');
    });

    it('when the tick two digits', () => {
      component.ticksText = '25';
      const downDial = fixture.debugElement.query(By.css('.dial-down'));

      downDial.triggerEventHandler('click', null);
      expect(component.updatedTicksText.emit).toHaveBeenCalledWith('247');
    });

  });
});
