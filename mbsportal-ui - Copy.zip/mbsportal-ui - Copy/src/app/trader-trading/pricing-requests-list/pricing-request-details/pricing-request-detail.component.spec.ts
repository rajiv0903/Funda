import { Component, Input } from '@angular/core';

import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { StoreModule, Store } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { reducers, AppStore } from '../../../store';
import { PricingRequestDetailComponent } from './pricing-request-detail.component';
import {
  LENDER_ACCEPTED,
  LENDER_OPEN, LENDER_REJECTED, LENDER_TIMEOUT, TRADER_CONFIRMED, TRADER_PASSED, TRADER_PRICED, TRADER_REJECTED,
  TRADER_REPRICED,
  TRADER_TIMEOUT,
  TransactionRequest
} from '../../../store/models/transaction-request.model';
import { UserProfileService } from '../../../shared/services/user-profile.service';
import { TransactionRequestEffects } from '../../../store/effects/transaction-request.effects';
import { TransactionRequestResource } from '../../../shared/resources/transaction-request.resource';
import { TransactionRequestService } from '../../../shared/services/transaction-request.service';
import { NameFormat } from '../../../shared/pipes/name-format.pipe';
import { TooltipModule } from 'ngx-tooltip';
import { LoggerService } from '../../../shared/services/logger.service';
import { LocalStorageService } from '../../../shared/services/local-storage.service';
import { DatePipe } from '@angular/common';
import { deepCopy } from '../../../../test';
import { StompRService } from '@stomp/ng2-stompjs';
import { DateTimezoneFormat } from '../../../shared/pipes/date-format.pipe';

@Component({
  selector: 'mbsp-pricing-request-edit',
  template: 'no markup for mocked child component'
})
class MockPricingRequestEditComponent {
  @Input() model: TransactionRequest;
  @Input() error: any;
  @Input() isUpdating: boolean;

  public notEditable(tr?: TransactionRequest) {}
  public copyStreamPrice() {}
}

describe('PricingRequestDetailComponent', () => {
  let component: PricingRequestDetailComponent;
  let fixture: ComponentFixture<PricingRequestDetailComponent>;
  let store: Store<AppStore>;
  const mockTransactionRequests = deepCopy(require('../../../../assets/data/transaction-requests.json'));

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        StoreModule.forRoot(reducers),
        EffectsModule.forRoot([TransactionRequestEffects]),
        TooltipModule
      ],
      declarations: [
        PricingRequestDetailComponent,
        MockPricingRequestEditComponent,
        NameFormat,
        DateTimezoneFormat
      ],
      providers: [
        {
          provide: TransactionRequestResource,
          useValue: jasmine.createSpyObj('transRequestResource', ['update'])
        },
        UserProfileService,
        LoggerService,
        DatePipe,
        LocalStorageService,
        TransactionRequestService,
        StompRService
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PricingRequestDetailComponent);
    component = fixture.componentInstance;
    component.transactionRequest = mockTransactionRequests[0];
    component.isUpdating = {};
    store = fixture.debugElement.injector.get(Store);
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
    expect(component).toBeTruthy();
  });

  it('should check initial values', () => {
    expect(component.transactionRequest).toEqual(mockTransactionRequests[0]);
  });

  it('should dispatch update action onUpdate', () => {
    spyOn(store, 'dispatch');
    component.onUpdate(component.transactionRequest);
    expect(store.dispatch).toHaveBeenCalled();
  });

  describe('check streamPriceColumnClickable method', () => {
    it('for stateType LENDER_OPEN', () => {
      component.transactionRequest.stateType = LENDER_OPEN;
      expect(component.streamPriceColumnClickable()).toEqual(true);
    });

    it('for stateType TRADER_PRICED', () => {
      component.transactionRequest.stateType = TRADER_PRICED;
      expect(component.streamPriceColumnClickable()).toEqual(true);
    });

    it('for stateType TRADER_REPRICED', () => {
      component.transactionRequest.stateType = TRADER_REPRICED;
      expect(component.streamPriceColumnClickable()).toEqual(true);
    });

    it('for stateType LENDER_ACCEPTED', () => {
      component.transactionRequest.stateType = LENDER_ACCEPTED;
      expect(component.streamPriceColumnClickable()).toEqual(true);
    });

    it('for stateType TRADER_CONFIRMED', () => {
      component.transactionRequest.stateType = TRADER_CONFIRMED;
      expect(component.streamPriceColumnClickable()).toEqual(false);
    });

    it('for stateType TRADER_REJECTED', () => {
      component.transactionRequest.stateType = TRADER_REJECTED;
      expect(component.streamPriceColumnClickable()).toEqual(false);
    });

    it('for stateType LENDER_REJECTED', () => {
      component.transactionRequest.stateType = LENDER_REJECTED;
      expect(component.streamPriceColumnClickable()).toEqual(false);
    });

    it('for stateType TRADER_PASSED', () => {
      component.transactionRequest.stateType = TRADER_PASSED;
      expect(component.streamPriceColumnClickable()).toEqual(false);
    });

    it('for stateType TRADER_TIMEOUT', () => {
      component.transactionRequest.stateType = TRADER_TIMEOUT;
      expect(component.streamPriceColumnClickable()).toEqual(false);
    });

    it('for stateType LENDER_TIMEOUT', () => {
      component.transactionRequest.stateType = LENDER_TIMEOUT;
      expect(component.streamPriceColumnClickable()).toEqual(false);
    });
  });

  it('should be able to call copyStreamPrice function', () => {
    spyOn(component.editComponent, 'copyStreamPrice');
    component.transactionRequest.stateType = TRADER_PRICED;
    component.copyStreamPrice();
    expect(component.editComponent.copyStreamPrice).toHaveBeenCalled();
  });

  it('should not be able to call copyStreamPrice function', () => {
    spyOn(component.editComponent, 'copyStreamPrice');
    component.transactionRequest.stateType = TRADER_CONFIRMED;
    component.copyStreamPrice();
    expect(component.editComponent.copyStreamPrice).not.toHaveBeenCalled();
  });

});
