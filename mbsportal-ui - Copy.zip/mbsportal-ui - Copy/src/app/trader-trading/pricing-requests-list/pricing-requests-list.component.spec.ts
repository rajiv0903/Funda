import { Component, Input } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { StoreModule, Store } from '@ngrx/store';

import { AppStore } from '../../store';
import { PricingRequestsListComponent } from './pricing-requests-list.component';
import { TransactionRequest } from '../../store/models/transaction-request.model';
import { TransactionRequestService } from '../../shared/services/transaction-request.service';
import { By } from '@angular/platform-browser';
import { Profile } from '../../store/models/profile.model';
import { NameFormat } from '../../shared/pipes/name-format.pipe';
import { UserProfileService } from '../../shared/services/user-profile.service';
import { transactionRequestReducer } from '../../store/reducers/transaction-request.reducer';
import { TooltipModule } from 'ngx-tooltip';
import { LoggerService } from '../../shared/services/logger.service';
import { LocalStorageService } from '../../shared/services/local-storage.service';
import { DatePipe } from '@angular/common';
import { getProfileReducerMock } from '../../util/stubs/mock-profile-reducer';
import { RoleType } from '../../shared/enums/role-type.enum';
import { deepCopy } from '../../../test';
import { StringBooleanArray } from '../../shared/interfaces/misc.interface';
import { DateTimezoneFormat } from '../../shared/pipes/date-format.pipe';

@Component({
  selector: '[mbspPricingRequestDetail]',
  templateUrl: './pricing-request-details/pricing-request-detail.component.html',
})
class MockPricingRequestDetailComponent {
  @Input() transactionRequest: TransactionRequest;
  @Input() isUpdating: StringBooleanArray;
  @Input() error: any;

  public tooltipDisabled() {}
  public streamPriceColumnClickable() {}
}

@Component({
  selector: 'mbsp-pricing-request-edit',
  template: 'some price',
})
class MockPricingRequestEditComponent {
  @Input() model: TransactionRequest;
  @Input() profile: Profile;
  @Input() isUpdating: boolean;
  @Input() error: any;
}

describe('PricingRequestsListComponent', () => {
  let component: PricingRequestsListComponent;
  let fixture: ComponentFixture<PricingRequestsListComponent>;
  let store: Store<AppStore>;
  const mockTransactionRequests = deepCopy(require('../../../assets/data/transaction-requests.json'));
  const mockProfile = deepCopy(require('../../../assets/data/trader-profile.json'));
  const tableColumns = 12;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        TooltipModule,
        StoreModule.forRoot({
          profile: getProfileReducerMock(RoleType.TRADER, mockProfile),
          transactionRequests: transactionRequestReducer
        }),
      ],
      declarations: [
        PricingRequestsListComponent,
        MockPricingRequestDetailComponent,
        MockPricingRequestEditComponent,
        NameFormat,
        DateTimezoneFormat
      ],
      providers: [
        TransactionRequestService,
        LoggerService,
        LocalStorageService,
        DatePipe,
        UserProfileService
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PricingRequestsListComponent);
    component = fixture.componentInstance;
    component.rows = mockTransactionRequests;
    store = fixture.debugElement.injector.get(Store);
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should check initial values', () => {
    expect(component.rows).toEqual(mockTransactionRequests);
  });

  it('should check the table request time headers', () => {
    const tableHeaders = fixture.debugElement.query(By.css('tr.th_row'));
    expect(tableHeaders.children.length).toEqual(tableColumns);
    expect(tableHeaders.children[0].nativeElement.innerText).toEqual('REQUEST TIME');
  });

  it('should check the table headers', () => {
    const tableHeaders = fixture.debugElement.query(By.css('tr.th_row'));
    expect(tableHeaders.children.length).toEqual(tableColumns);
    expect(tableHeaders.children[4].nativeElement.innerText).toEqual('TSP');
  });

  it('should check the table data with mock data', () => {
    const tableData = fixture.debugElement.query(By.css('tr.td_row'));
    expect(tableData.children.length).toEqual(tableColumns);
    expect(tableData.children[4].nativeElement.innerText).toEqual('TSSE');
  });

  it('should check for the background color for the transaction Request for trader priced', () => {
    component.rows[1] = {...mockTransactionRequests[1], traderId: 'tdexec23'};
    fixture.detectChanges();

    const traderPricedTransReq = fixture.debugElement.query(By.css('.transactionRequest_17H00002'));
    const traderPricedStyles = window.getComputedStyle(traderPricedTransReq.nativeElement);
    expect(traderPricedStyles.backgroundColor).toEqual('rgb(197, 241, 254)');

    const lenderAcceptedTransReq = fixture.debugElement.query(By.css('.transactionRequest_17H00003'));
    const lenderAcceptedStyles = window.getComputedStyle(lenderAcceptedTransReq.nativeElement);
    expect(lenderAcceptedStyles.backgroundColor).toEqual('rgb(239, 248, 250)');
  });

  describe('testing read only role', () => {
    let profileRole: string;
    beforeAll(() => {
      profileRole = mockProfile.roles[0].name;
      mockProfile.roles[0].name = 'SG-MBSP-NonProd-FM-TRADER-READ-ONLY';
    });

    it('should check for the background color for the transaction Request for trader priced on read only', () => {
      const traderPricedTransReq = fixture.debugElement.query(By.css('.transactionRequest_17H00002'));
      const traderPricedStyles = window.getComputedStyle(traderPricedTransReq.nativeElement);
      expect(traderPricedStyles.backgroundColor).toEqual('rgb(197, 241, 254)');

      const lenderAcceptedTransReq = fixture.debugElement.query(By.css('.transactionRequest_17H00003'));
      const lenderAcceptedStyles = window.getComputedStyle(lenderAcceptedTransReq.nativeElement);
      expect(lenderAcceptedStyles.backgroundColor).toEqual('rgb(197, 241, 254)');
    });

    afterAll(() => {
      mockProfile.roles[0].name = profileRole;
    });
  });

});
