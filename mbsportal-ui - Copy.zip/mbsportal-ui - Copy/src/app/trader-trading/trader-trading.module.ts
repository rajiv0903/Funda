import { NgModule } from '@angular/core';

import { SharedModule } from '../shared/shared.module';
import { TraderTradingRoutingModule } from './trader-trading-routing.module';
import { TraderTradingComponent } from './trader-trading.component';
import { PricingRequestsListComponent } from './pricing-requests-list/pricing-requests-list.component';
import {
  PricingRequestDetailComponent
} from './pricing-requests-list/pricing-request-details/pricing-request-detail.component';
import {
  PricingRequestEditComponent
} from './pricing-requests-list/pricing-request-details/pricing-request-edit/pricing-request-edit.component';
import {
  PricingDialsComponent
} from './pricing-requests-list/pricing-request-details/pricing-request-edit/pricing-dials/pricing-dials.component';

@NgModule({
  imports: [
    SharedModule,
    TraderTradingRoutingModule,
  ],
  declarations: [
    TraderTradingComponent,
    PricingRequestsListComponent,
    PricingRequestDetailComponent,
    PricingRequestEditComponent,
    PricingDialsComponent
  ]
})
export class TraderTradingModule { }
