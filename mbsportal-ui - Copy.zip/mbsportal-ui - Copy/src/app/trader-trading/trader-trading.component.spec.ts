import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';
import { Observable } from 'rxjs/Rx';
import { ReactiveFormsModule } from '@angular/forms';
import { StoreModule, Store } from '@ngrx/store';

import { reducers, AppStore } from '../store';
import * as actions from '../store/actions/transaction-request.actions';
import { TraderTradingComponent } from './trader-trading.component';
import { PricingRequestsListComponent } from './pricing-requests-list/pricing-requests-list.component';
import {
  PricingRequestDetailComponent
} from './pricing-requests-list/pricing-request-details/pricing-request-detail.component';
import {
  PricingRequestEditComponent
} from './pricing-requests-list/pricing-request-details/pricing-request-edit/pricing-request-edit.component';
import { TransactionRequestResource } from '../shared/resources/transaction-request.resource';
import { TransactionRequestService } from '../shared/services/transaction-request.service';
import { NameFormat } from '../shared/pipes/name-format.pipe';
import { UserProfileService } from '../shared/services/user-profile.service';
import { TooltipModule } from 'ngx-tooltip';
import {
  PricingDialsComponent
} from './pricing-requests-list/pricing-request-details/pricing-request-edit/pricing-dials/pricing-dials.component';
import { TransactionTimerComponent } from '../shared/components/transaction-timer/transaction-timer.component';
import { LoggerService } from '../shared/services/logger.service';
import { LocalStorageService } from '../shared/services/local-storage.service';
import { DatePipe } from '@angular/common';
import { AllowedCharactersDirective } from '../shared/directives/allowed-characters.directive';
import { deepCopy } from '../../test';
import { DateTimezoneFormat } from '../shared/pipes/date-format.pipe';

describe('TraderTradingComponent', () => {
  let component: TraderTradingComponent;
  let fixture: ComponentFixture<TraderTradingComponent>;
  let store: Store<AppStore>;
  let tradingDOM: HTMLElement;
  const mockTransactionRequests = deepCopy(require('../../assets/data/transaction-requests.json'));

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        ReactiveFormsModule,
        TooltipModule,
        StoreModule.forRoot(reducers)
      ],
      declarations: [
        TraderTradingComponent,
        PricingRequestsListComponent,
        PricingRequestDetailComponent,
        PricingRequestEditComponent,
        PricingDialsComponent,
        TransactionTimerComponent,
        NameFormat,
        AllowedCharactersDirective,
        DateTimezoneFormat
      ],
      providers: [
        TransactionRequestService,
        LoggerService,
        LocalStorageService,
        DatePipe,
        {
          provide: TransactionRequestResource,
          useValue: jasmine.createSpyObj('transRequestResource', ['get'])
        },
        UserProfileService
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TraderTradingComponent);
    component = fixture.componentInstance;
    store = fixture.debugElement.injector.get(Store);
    tradingDOM = fixture.debugElement.nativeElement;
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should return observable', () => {
    expect(component.transactionRequests$ instanceof Observable).toEqual(true);
  });

  it('should render pricing requests component', () => {
    expect(fixture.debugElement.query(By.css('mbsp-pricing-requests-list'))).toBeTruthy();
  });

  it('should load trans requests rows', () => {
    store.dispatch(new actions.LoadSuccessAction(mockTransactionRequests));

    component.transactionRequests$.subscribe(transactionRequests => {
      expect(transactionRequests).toEqual(mockTransactionRequests);
    })
  });

});
