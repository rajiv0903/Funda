import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Rx';
import { NavigationStart, Router } from '@angular/router';

import * as fromRoot from './store';
import { ModalService } from './shared/services/modal.service';
import { LoggerService } from './shared/services/logger.service';

@Component({
  moduleId: module.id,
  selector: 'mbsp-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {

  constructor(
    private store: Store<fromRoot.AppStore>,
    private router: Router,
    private loggerService: LoggerService,
    private modalService: ModalService
  ) {
    this.appError$.subscribe(error => {
      if (error) {
        this.modalService.show(error);
      }
    });
  }

  ngOnInit() {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        switch (event.url) {
          case '/pricing':
          case '/trading':
            this.loggerService.info('Navigate to trading tab');
            break;
          case '/transaction-history':
            this.loggerService.info('Navigate to history tab');
            break;
        }
      }
    });
    this.overrideRouterErrorHandler();

  }

  get appIsInitialized$(): Observable<boolean> {
    return this.store.select(fromRoot.getAppInitialized);
  }

  get appError$(): Observable<any> {
    return this.store.select(fromRoot.getAppError);
  }

  get appLevelUserErrors$(): Observable<any> {
    return this.store.select(fromRoot.getAppLevelUserErrors);
  }

  get transactionRequests$(): Observable<any> {
    return this.store.select(fromRoot.getTransactionRequestsEntities);
  }

  get getIsExportInProgress$(): Observable<boolean> {
    return this.store.select(fromRoot.getIsExportInProgress);
  }

  private overrideRouterErrorHandler(): void {
    const routerErrorHandler = this.router.errorHandler;

    this.router.errorHandler = (err) => {
      this.modalService.show(err);
      routerErrorHandler(err);
    }
  }
}
