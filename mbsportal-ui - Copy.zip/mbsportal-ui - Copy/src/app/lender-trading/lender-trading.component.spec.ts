import { Component, Input } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Observable } from 'rxjs/Rx';
import { StoreModule, Store } from '@ngrx/store';

import { TooltipModule } from 'ngx-tooltip';

import { reducers, AppStore } from '../store';
import * as actions from '../store/actions/transaction-request.actions';
import { LenderTradingComponent } from './lender-trading.component';
import { TransactionRequest } from '../store/models/transaction-request.model';
import { Product } from '../store/models/product.model';
import { Profile } from '../store/models/profile.model';
import { deepCopy } from '../../test';

describe('LenderTradingComponent', () => {
  let component: LenderTradingComponent;
  let fixture: ComponentFixture<LenderTradingComponent>;
  let store: Store<AppStore>;
  let tradingDOM: HTMLElement;
  const mockTransactionRequests = deepCopy(require('../../assets/data/transaction-requests.json'));

  @Component({
    selector: 'mbsp-product-select',
    template: 'no markup for mocked child component'
  })
  class MockProductSelectComponent {
    @Input() model: TransactionRequest;
    @Input() products: Product[];
    @Input() profile: Profile;
    @Input() error: any;
    @Input() isCreating: boolean;
    @Input() isUpdating: boolean;
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot(reducers),
        TooltipModule
      ],
      declarations: [
        LenderTradingComponent,
        MockProductSelectComponent
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LenderTradingComponent);
    component = fixture.componentInstance;
    store = fixture.debugElement.injector.get(Store);
    tradingDOM = fixture.debugElement.nativeElement;
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should return observable', () => {
    expect(component.transactionRequest$ instanceof Observable).toEqual(true);
  });

  it('should render product select component', () => {
    expect(fixture.debugElement.query(By.css('mbsp-product-select'))).toBeTruthy();
  });

  it('should load an single trans request', () => {
    store.dispatch(new actions.LoadSuccessAction(mockTransactionRequests));

    component.transactionRequest$.subscribe(transactionRequest => {
      expect(transactionRequest).toEqual(mockTransactionRequests[0]);
    })
  });

});
