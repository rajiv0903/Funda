import { Component } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { Store } from '@ngrx/store';

import { TransactionRequest } from '../store/models/transaction-request.model';
import * as fromRoot from '../store';
import { Product } from '../store/models/product.model';
import { StringBooleanArray } from '../shared/interfaces/misc.interface';

@Component({
  moduleId: module.id,
  selector: 'mbsp-lender-trading',
  templateUrl: './lender-trading.component.html',
  styleUrls: ['./lender-trading.component.scss'],
})
export class LenderTradingComponent {

  constructor(private store: Store<fromRoot.AppStore>) {}

  get transactionRequest$(): Observable<TransactionRequest> {
    return this.store.select(fromRoot.getTransactionRequest);
  }

  get products$(): Observable<Product[]> {
    return this.store.select(fromRoot.getProductsEntities);
  }

  get error$(): Observable<any> {
    return this.store.select(fromRoot.getTransactionRequestError);
  }

  get isCreating$(): Observable<boolean> {
    return this.store.select(fromRoot.getTransactionRequestIsCreating);
  }

  get isUpdating$(): Observable<StringBooleanArray> {
    return this.store.select(fromRoot.getTransactionRequestIsUpdating);
  }

}
