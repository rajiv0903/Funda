/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { NgModule } from '@angular/core';

import { FmAlertModalModule } from '@fm-ui-adk/components/dist/fm-alert-modal/fm-alert-modal.module';

import { SharedModule } from '../shared/shared.module';
import { LenderTradingRoutingModule } from './lender-trading-routing.module';
import { LenderTradingComponent } from './lender-trading.component';
import { ProductSelectComponent } from './product-select/product-select.component';
import { ProductPricingGridComponent } from './product-select/product-pricing-grid/product-pricing-grid.component';
import { AutofocusDirective } from './product-select/autofocus.directive';

@NgModule({
  imports: [
    SharedModule,
    LenderTradingRoutingModule,
    FmAlertModalModule.forRoot(),
  ],
  declarations: [
    LenderTradingComponent,
    ProductSelectComponent,
    ProductPricingGridComponent,
    AutofocusDirective
  ]
})
export class LenderTradingModule { }
