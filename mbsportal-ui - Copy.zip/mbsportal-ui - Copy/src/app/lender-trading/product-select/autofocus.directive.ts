import { Directive, ElementRef, Input, OnChanges } from '@angular/core';

@Directive({
  selector: '[mbspAutofocus]'
})
export class AutofocusDirective implements OnChanges {

  @Input() mbspAutofocus: any;

  constructor(private el: ElementRef) { }

  ngOnChanges() {
    setTimeout(() => {
      this.el.nativeElement.focus();
    }, 0);
  }

}
