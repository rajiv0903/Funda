/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { AutofocusDirective } from './autofocus.directive';
import { Component, Input, SimpleChange } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { async, TestBed, ComponentFixture, fakeAsync, tick } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Response, ResponseOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { StoreModule, Store } from '@ngrx/store';
import { EffectsModule, Actions } from '@ngrx/effects';
import * as moment from 'moment';

import { FmAlertModalModule } from '@fm-ui-adk/components/dist/fm-alert-modal/fm-alert-modal.module';

import { ProductSelectComponent } from './product-select.component';
import { AppStore } from '../../store';
import { UserProfileService } from '../../shared/services/user-profile.service';
import * as fromRoot from '../../store';
import { Product } from '../../store/models/product.model';
import {
  LENDER_ACCEPTED, LENDER_OPEN, LENDER_REJECTED, LENDER_TIMEOUT, PENDING_EXECUTION, TRADER_CONFIRMED,
  TRADER_PASSED, TRADER_PRICED, TRADER_REJECTED, TRADER_REPRICED, TRADER_TIMEOUT, TransactionRequest
} from '../../store/models/transaction-request.model';
import { Pricing } from '../../store/models/pricing.model';
import { PricingResource } from './pricing.resource';
import { TransactionRequestEffects } from '../../store/effects/transaction-request.effects';
import { NameFormat } from '../../shared/pipes/name-format.pipe';
import { Profile } from '../../store/models/profile.model';
import { productsReducer } from '../../store/reducers/product.reducer';
import { pricingReducer } from '../../store/reducers/pricing.reducer';
import { TransactionRequestResource } from '../../shared/resources/transaction-request.resource';
import { TransactionRequestService } from '../../shared/services/transaction-request.service';
import * as trActions from '../../store/actions/transaction-request.actions'
import * as pActions from '../../store/actions/pricing.actions';
import { TooltipModule } from 'ngx-tooltip';
import { DatePipe, DecimalPipe } from '@angular/common';
import { LoggerService } from '../../shared/services/logger.service';
import { ProfileResource } from '../../shared/resources/profile.resource';
import { LocalStorageService } from '../../shared/services/local-storage.service';
import { cancelReactivateTimeout } from '../../shared/constants/system.constant';
import { getProfileReducerMock } from '../../util/stubs/mock-profile-reducer';
import { RoleType } from '../../shared/enums/role-type.enum';
import { getTransactionRequestReducerMock } from '../../util/stubs/mock-transaction-request-reducer';
import { deepCopy } from '../../../test';
import { StompRService } from '@stomp/ng2-stompjs';
import { MiscService } from '../../shared/services/misc.service';
import { DisableControlDirective } from '../../shared/directives/disable-control.directive';

describe('ProductSelect component', () => {
  let component: ProductSelectComponent;
  let fixture: ComponentFixture<ProductSelectComponent>;
  let store: Store<AppStore>;
  let actions: Actions;
  let pricingResource;
  const mockProducts = deepCopy(require('../../../assets/data/products.json'));
  const mockPricing = deepCopy(require('../../../assets/data/pricing.json'));
  const mockTransactionRequests = deepCopy(require('../../../assets/data/transaction-requests.json'));

  @Component({
    selector: 'mbsp-search-and-select',
    template: 'no markup for mocked child component'
  })
  class MockSearchAndSelectComponent {
    @Input() items: Array<{'id': string, 'text': string}>;
    @Input() disabled: boolean;
    @Input() clearSelectedValue: boolean;
    @Input() selectedOption: {'id': string, 'text': string};
  }

  @Component({
    selector: 'mbsp-dropdown',
    template: 'no markup for mocked child component'
  })
  class MockDropdownComponent {
    @Input() selectedIndex: any = '';
    @Input() options: any[];
    @Input() labelPropName = 'text';
    @Input() valuePropName: any = 'value';
    @Input() defaultOption = 'Select';
    @Input() disabled: boolean;
  }

  @Component({
    selector: 'mbsp-product-pricing-grid',
    template: 'no markup for mocked child component'
  })
  class MockProductPricingGridComponent {
    @Input() transactionRequest: TransactionRequest;
    @Input() transRequestExists: boolean;
    @Input() products: Product[];
    @Input() pricing: Pricing[];
    @Input() isPricingLoading: boolean;
    @Input() profile: Profile;
  }

  @Component({
    selector: 'mbsp-transaction-timer',
    template: 'no markup for mocked child component'
  })
  class MockTransactionTimerComponent {
    @Input() type: 'lender' | 'trader';
    @Input() startFromSeconds: number = 0;
    @Input() transReqId: string;
    @Input() countUpToSeconds?: number = 135;
    @Input() diameter?: number = 40;
    @Input() strokeWidth?: number = 6;

    @Input() isVisible?: boolean = true;
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        StoreModule.forRoot({
          profile: getProfileReducerMock(RoleType.TSP),
          transactionRequests: getTransactionRequestReducerMock(),
          products: productsReducer,
          pricing: pricingReducer
        }),
        EffectsModule.forRoot([TransactionRequestEffects]),
        TooltipModule,
        FmAlertModalModule.forRoot()
      ],
      declarations: [
        ProductSelectComponent,
        MockDropdownComponent,
        MockSearchAndSelectComponent,
        MockTransactionTimerComponent,
        MockProductPricingGridComponent,
        AutofocusDirective,
        DisableControlDirective
      ],
      providers: [
        {
          provide: TransactionRequestResource,
          useValue: jasmine.createSpyObj('transRequestResource', ['create', 'update'])
        },
        {
          provide: PricingResource,
          useValue: jasmine.createSpyObj('pricingResource', ['query', 'get'])
        },
        {
          provide: ProfileResource,
          useValue: jasmine.createSpyObj('profileResource', ['log'])
        },
        UserProfileService,
        LoggerService,
        DatePipe,
        LocalStorageService,
        TransactionRequestService,
        MiscService,
        DecimalPipe,
        NameFormat,
        StompRService
      ]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductSelectComponent);
    component = fixture.componentInstance;
    component.model = mockTransactionRequests[0];
    component.products = mockProducts;
    component.isCreating = false;
    component.isUpdating = {};
    store = fixture.debugElement.injector.get(Store);
    actions = fixture.debugElement.injector.get(Actions);
    pricingResource = TestBed.get(PricingResource);
  });

  it('should check formValue when model is changing', async(() => {
    component.model = mockTransactionRequests[0];
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });

    expect(component.formValue.product.productId).toEqual(component.model.product.productId);
    // need to get raw value since amount field is disabled
    expect(component.form.getRawValue()['tradeAmount']).toEqual('25,000');
    expect(component.formValue.tradeBuySellType).toEqual(component.model.tradeBuySellType);
    expect(component.formValue.tradeCouponRate).toEqual(component.model.tradeCouponRate);
  }));

  it('should check the disability of product dropdown on tsp value', async(() => {
    component.model = mockTransactionRequests[0];
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    expect(component.disableProductSelect()).toEqual(true);

    component.model = mockTransactionRequests[1];
    component.model.transReqId = '';
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    expect(component.disableProductSelect()).toEqual(false);
  }));

  it('should clear the form values on change of tsp dropdown value', async(() => {
    const productId = {
      'identifier': 2,
      'sourceType': 'PU',
      'type': 'MBS'
    };
    component.formValue.product.productId = productId;
    component.formValue.tradeAmount = '35000';
    component.formValue.tradeBuySellType = 'SELL';
    component.formValue.oboLenderSellerServicerNumber = '10601';

    const selectedTspOption1 = {
      'id': '10601',
      'text': 'some text'
    };
    component.onTspLenderSelect(selectedTspOption1);

    expect(component.formValue.product.productId).toEqual(productId);
    expect(component.formValue.tradeAmount).toEqual('35000');
    expect(component.formValue.tradeBuySellType).toEqual('SELL');

    const selectedTspOption2 = {
      'id': '10602',
      'text': 'some text'
    };
    component.onTspLenderSelect(selectedTspOption2);

    expect(component.formValue.product.productId).toEqual('');
    expect(component.formValue.tradeAmount).toEqual('');
    expect(component.formValue.tradeBuySellType).toEqual('');
  }));

  it('should check for prepareTspLenders', async(() => {
    component.ngOnInit();
    expect(component.tspLenders.length).toEqual(10);
    expect(component.tspLenders[2]).toEqual({
      'id': '27092',
      'text': 'Fairway Independent Mortgage Corp.'
    });
  }));

  it('should check for sorting of TspLenders', async(() => {
    component.tspLenders =
      [{
        'id': '27093',
        'text': 'Fairway Independent Mortgage Corp.'
      },
      {
        'id': '27094',
        'text': 'First Federal Bank of Florida'
      },
      {
        'id': '27095',
        'text': 'Atlantic Coast Mortgage, LLC'
      },
      {
        'id': '27096',
        'text': 'Lake Michigan Credit Union'
      }];

    component.sortTspLenders();

    expect(component.tspLenders).toEqual(
      [
        {
          'id': '27095',
          'text': 'Atlantic Coast Mortgage, LLC'
        },
        {
          'id': '27093',
          'text': 'Fairway Independent Mortgage Corp.'
        },
        {
          'id': '27094',
          'text': 'First Federal Bank of Florida'
        },
        {
          'id': '27096',
          'text': 'Lake Michigan Credit Union'
        }
      ]
    );
  }));

  it('should return correct product name', async(() => {
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });

    expect(component.productName).toEqual('FN15');

    component.model = mockTransactionRequests[1];
    component.ngOnChanges({
      model: new SimpleChange(mockTransactionRequests[0], component.model, false)
    });

    expect(component.productName).toEqual('PC30');
  }));

  it('should update the form value on product select', async(() => {
    pricingResource.get.and.returnValue(Observable.of(mockPricing));

    component.onProductSelect(mockTransactionRequests[1].product.productId);

    expect(component.formValue.product.productId).toEqual(mockTransactionRequests[1].product.productId);
    expect(component.formValue.tradeBuySellType).toEqual('');
    expect(component.formValue.tradeAmount).toEqual('');
  }));

  describe('should update the form value on product select for ', () => {
    let productIndex = 0;
    let mockProduct: Product;
    const expectedProd: { identifier: number, nameCode: string }[] = [
      {identifier: 2, nameCode: 'PC30'},
      {identifier: 4, nameCode: 'GN30'},
      {identifier: 1, nameCode: 'FN15'},
      {identifier: 5, nameCode: 'G230'},
      {identifier: 3, nameCode: 'PC15'},
      {identifier: 0, nameCode: 'FN30'}
    ];

    beforeEach(() => {
      pricingResource.get.and.returnValue(Observable.of(mockPricing));
      expect(component.formValue.product.productId).toEqual('');
      spyOn(store, 'dispatch');

    });
    expectedProd.forEach((value, key) => {
      it('product name ' + value.nameCode, async(() => {
        mockProduct = {...mockProducts[productIndex++]};
        component.onProductSelect(mockProduct.productId);

        expect(component.formValue.product.productId.identifier).toEqual(value.identifier);
        expect(component.formValue.product.nameCode).toEqual(value.nameCode);
        expect(component.formValue.tradeBuySellType).toEqual('');
        expect(component.formValue.tradeAmount).toEqual('');
        expect(store.dispatch).toHaveBeenCalledWith(new pActions.LoadAction(mockProduct.productId));
      }));
    });
  });

  it('should update the form value on trade type select', async(() => {
    component.onPricingSelect({
      tradeBuySellType: 'SELL',
      tradeCouponRate: '4.000',
      tradeSettlementDate: '2017-09-24'
    });

    expect(component.formValue.tradeBuySellType).toEqual('SELL');
    expect(component.formValue.tradeCouponRate).toEqual('4.000');
    expect(component.formValue.tradeSettlementDate).toEqual('2017-09-24');
  }));

  describe('should test SUBMIT button click', () => {
    beforeEach(() => {
      pricingResource.get.and.returnValue(Observable.of(mockPricing));

      component.onProductSelect(mockProducts[0].productId);
      component.onPricingSelect({
        tradeBuySellType: 'SELL',
        tradeCouponRate: '4.000',
        tradeSettlementDate: '2017-09-24'
      });

      fixture.detectChanges();

      const transRequestToReturn = new Response(
        new ResponseOptions(
          {
            body: mockTransactionRequests[0]
          }
        )
      );

      const transRequestResource = TestBed.get(TransactionRequestResource);
      transRequestResource.create.and.returnValue(Observable.of(transRequestToReturn.json()));
    });
    it('invalid amount should be submitted with a validation error', async(() => {
      component.form.get('tradeAmount').setValue('25,00');
      component.form.controls['tradeAmount'].setErrors({minMax: 2500});
      fixture.detectChanges();

      const profileResource = TestBed.get(ProfileResource);
      profileResource.log.and.returnValue(Observable.of());

      const createButton = fixture.debugElement.query(By.css('#transaction-submit'));
      createButton.triggerEventHandler('click', null);

      expect(component.amountMarkedAsInvalid).toEqual(true);
    }));

    it('valid amount should be submitted with no errors', async(() => {
      component.form.get('tradeAmount').setValue('25,000');
      fixture.detectChanges();
      spyOn(store, 'dispatch');
      const createButton = fixture.debugElement.query(By.css('#transaction-submit'));
      createButton.triggerEventHandler('click', null);
      expect(component.amountMarkedAsInvalid).toEqual(false);
      expect(store.dispatch).toHaveBeenCalledWith(new trActions.CreateAction({
        ...component.formValue,
        tradeAmount: '25000',
        stateType: LENDER_OPEN
      }));
    }));

  });

  describe('should test HIT/LIFT and CANCEL button click', () => {
    beforeEach(() => {
      component.model = mockTransactionRequests[1];
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      fixture.detectChanges();
    });

    it('should call onAccept and HIT/LIFT button is clicked', async(() => {
      spyOn(store, 'dispatch');

      const createButton = fixture.debugElement.query(By.css('#price-accept'));
      createButton.triggerEventHandler('click', null);
      expect(store.dispatch).toHaveBeenCalledWith(new trActions.UpdateAction({
        ...component.formValue,
        stateType: LENDER_ACCEPTED
      }));

    }));

    it('should call onCancel when CANCEL button is clicked', async(() => {
      spyOn(store, 'dispatch');
      const createButton = fixture.debugElement.query(By.css('#cancel-button'));
      createButton.triggerEventHandler('click', null);

      expect(store.dispatch).toHaveBeenCalledWith(new trActions.UpdateAction({
        ...component.formValue,
        stateType: LENDER_REJECTED
      }));

    }));
  });

  it('should show alert modal with error when settlement date is past the cutoff date', async(() => {
    const errorText = 'Fannie Mae is no longer trading this settlement month';
    component.error = {
      message: errorText
    };

    component.ngOnChanges({
      error: new SimpleChange(null, component.error, false)
    });

    fixture.detectChanges();

    const acceptedLabel = fixture.debugElement.query(By.css('.status-message'));
    expect(acceptedLabel.nativeElement.innerText).toEqual(errorText);
  }));

  it('should dispatch cancel action on Cancel button click', async(() => {

    // need to create first so it is in the store
    pricingResource.get.and.returnValue(Observable.of(mockPricing));

    const profileResource = TestBed.get(ProfileResource);
    profileResource.log.and.returnValue(Observable.of());

    component.onProductSelect(mockProducts[0].productId);
    component.onPricingSelect({
      tradeBuySellType: 'SELL',
      tradeCouponRate: '4.000',
      tradeSettlementDate: '2017-09-24'
    });

    fixture.detectChanges();

    const transRequestToReturn_ = new Response(
      new ResponseOptions(
        {
          body: mockTransactionRequests[0]
        }
      )
    );

    component.formValue.tradeAmount = '10000';

    const transRequestResource = TestBed.get(TransactionRequestResource);
    transRequestResource.create.and.returnValue(Observable.of(transRequestToReturn_.json()));

    const createButton = fixture.debugElement.query(By.css('#transaction-submit'));
    createButton.triggerEventHandler('click', null);

    // actual test code
    component.model.stateType = LENDER_OPEN;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    fixture.detectChanges();

    const transRequestToReturn = new Response(
      new ResponseOptions(
        {
          body: {
            ...mockTransactionRequests[0],
            stateType: TRADER_CONFIRMED
          }
        }
      )
    );

    transRequestResource.update.and.returnValue(Observable.of(transRequestToReturn.json()));

    const cancelButton = fixture.debugElement.query(By.css('#cancel-button'));
    cancelButton.triggerEventHandler('click', null);

    actions
      .filter(action => action.type === trActions.DELETE_SUCCESS)
      .subscribe(() => {
        store.select(fromRoot.getTransactionRequestsEntities).subscribe(list => {
          expect(list).toEqual([]);
        });
      });
  }));

  it('should check if Accepted is displayed after trader Hits DONE', async(() => {
    component.model.stateType = TRADER_CONFIRMED;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    fixture.detectChanges();

    const acceptedLabel = fixture.debugElement.query(By.css('.ticket-header span'));

    expect(acceptedLabel.nativeElement.innerText).toEqual('ACCEPTED');
  }));

  it('should check for Trader Cancelled and Passed statuses', async(() => {
    component.model.stateType = TRADER_PASSED;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    fixture.detectChanges();

    let label = fixture.debugElement.query(By.css('.ticket-header span'));

    expect(label.nativeElement.innerText).toEqual('FANNIE MAE PASSED');

    component.model.stateType = TRADER_REJECTED;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    fixture.detectChanges();

    label = fixture.debugElement.query(By.css('.ticket-header span'));

    expect(label.nativeElement.innerText).toEqual('FANNIE MAE CANCELLED');
  }));

  it('should check for Trader Timed Out and Lender Timed Out Statues', async(() => {
    component.model.stateType = TRADER_TIMEOUT;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    fixture.detectChanges();

    let label = fixture.debugElement.query(By.css('.ticket-header span'));

    expect(label.nativeElement.innerText).toEqual('FANNIE MAE TIMED OUT');

    component.model.stateType = LENDER_TIMEOUT;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    fixture.detectChanges();

    label = fixture.debugElement.query(By.css('.ticket-header span'));

    expect(label.nativeElement.innerText).toEqual('TIMED OUT');
  }));

  it('should check showClearTicketButton', () => {
    expect(component.showClearTicketButton()).toEqual(false);

    component.form.get('stateType').setValue(TRADER_CONFIRMED);
    component.form.get('product').setValue({
      productId: {
        identifier: 5,
        sourceType: 'PU',
        type: 'MBS'
      }
    });
    expect(component.showClearTicketButton()).toEqual(true);

    component.form.get('stateType').setValue('some state');
    component.form.get('product').setValue({
      productId: {
        identifier: 5,
        sourceType: 'PU',
        type: 'MBS'
      }
    });
    expect(component.showClearTicketButton()).toEqual(true);

    component.form.get('transReqId').setValue('someId');
    component.form.get('stateType').setValue('some state');
    component.form.get('product').setValue({
      productId: {
        identifier: 5,
        sourceType: 'PU',
        type: 'MBS'
      }
    });
    expect(component.showClearTicketButton()).toEqual(false);

    component.form.get('transReqId').setValue('');
    component.form.get('stateType').setValue(PENDING_EXECUTION);
    component.form.get('product').setValue({
      productId: {
        identifier: 5,
        sourceType: 'PU',
        type: 'MBS'
      }
    });
    expect(component.showClearTicketButton()).toEqual(true);

    component.form.get('transReqId').setValue('');
    component.form.get('stateType').setValue(PENDING_EXECUTION);
    component.form.get('product').setValue({
      productId: ''
    });
    expect(component.showClearTicketButton()).toEqual(false);

    component.form.get('transReqId').setValue('someId');
    component.form.get('stateType').setValue(PENDING_EXECUTION);
    component.form.get('product').setValue({
      productId: ''
    });
    expect(component.showClearTicketButton()).toEqual(false);
  });

  it('should check clear ticket function and verify dispatch method called', () => {
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });

    spyOn(store, 'dispatch');
    component.form.get('stateType').setValue('LENDER_TIMEOUT');
    component.onClearTicket();

    expect(store.dispatch).toHaveBeenCalledWith(new trActions.DeleteSuccessAction({
      ...component.formValue
    }));

    component.model.transReqId = '';
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    component.form.get('tradeAmount').enable();
    component.onClearTicket();
    expect(component.formValue).toEqual(component.initialFormValue);
    component.model.transReqId = '17H00001';
  });

  it('should check showCancelTicketButton', () => {
    component.model.stateType = LENDER_OPEN;

    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });

    expect(component.showCancelTicketButton()).toEqual(true);
  });

  it('should check the label when CANCEL button is clicked', () => {
    component.model.stateType = LENDER_REJECTED;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    fixture.detectChanges();

    const cancelledLabel = fixture.debugElement.query(By.css('.ticket-header span'));
    expect(cancelledLabel.nativeElement.innerText).toEqual('CANCELLED');
  });

  it('should check the label for Reprice', () => {
    component.model.stateType = TRADER_REPRICED;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    fixture.detectChanges();

    const repricedLabel = fixture.debugElement.query(By.css('.ticket-header span'));
    expect(repricedLabel.nativeElement.innerText).toEqual('NEW QUOTE');
  });

  it('should check ngOnChanges when model is removed from the store, need to set default state and clear the form', () => {
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });

    expect(component.formValue.tradeBuySellType).not.toBeFalsy();
    expect(component.formValue.tradeSettlementDate).not.toBeFalsy();

    component.ngOnChanges({
      model: new SimpleChange(component.model, null, false)
    });

    expect(component.formValue.tradeBuySellType).toBeFalsy();
    expect(component.formValue.tradeSettlementDate).toBeFalsy();
  });

  describe('should check Amount formatting on the input field', () => {
    it('should check for alphabets', () => {
      component.form.get('tradeAmount').setValue('abcdef');
      component.addNumberMask();

      expect(component.form.get('tradeAmount').value).toEqual('');
    });

    it('should check for alphanumeric and special characters', () => {
      component.form.get('tradeAmount').setValue('47,<.:47abc!@%%^)47&*(47#$47def');
      component.addNumberMask();

      expect(component.form.get('tradeAmount').value).toEqual('4,747,474,747');
    });

    it('should check for number formatting', () => {
      component.form.get('tradeAmount').setValue('447447447');
      component.addNumberMask();

      expect(component.form.get('tradeAmount').value).toEqual('447,447,447');
    });

    it('should check for 3-digit number formatting', () => {
      component.form.get('tradeAmount').setValue('447');
      component.addNumberMask();

      expect(component.form.get('tradeAmount').value).toEqual('447');
    });

    it('should return clean amount', () => {
      component.form.get('tradeAmount').setValue('447,447,447');

      expect(component.getCleanTradeAmount()).toEqual('447447447');
    });

  });

  describe('should validate Amount formatting on the input field', () => {
    beforeEach(() => {
      component.onProductSelect(mockProducts[0].productId);
      component.onPricingSelect({
        tradeBuySellType: 'SELL',
        tradeCouponRate: '4.000',
        tradeSettlementDate: '2017-09-24'
      });
      const transRequestToReturn = new Response(
        new ResponseOptions(
          {
            body: mockTransactionRequests[0]
          }
        )
      );
      component.form.get('tradeAmount').setValue('');
      fixture.detectChanges();

      const transRequestResource = TestBed.get(TransactionRequestResource);
      transRequestResource.create.and.returnValue(Observable.of(transRequestToReturn.json()));

      const profileResource = TestBed.get(ProfileResource);
      profileResource.log.and.returnValue(Observable.of());
    });

    it('check tradeAmount 24,999', () => {
      component.form.get('tradeAmount').setValue('24,999');

      const submitButton = fixture.debugElement.query(By.css('#transaction-submit'));
      submitButton.triggerEventHandler('click', null);
      expect(component.amountMarkedAsInvalid).toEqual(true);
    });

    it('check tradeAmount 250,000,001', () => {
      component.form.get('tradeAmount').setValue('250,000,001');

      const submitButton = fixture.debugElement.query(By.css('#transaction-submit'));
      submitButton.triggerEventHandler('click', null);
      expect(component.amountMarkedAsInvalid).toEqual(true);
    });

    it('check tradeAmount 25,000', () => {
      component.form.get('tradeAmount').setValue('25,000');

      const submitButton = fixture.debugElement.query(By.css('#transaction-submit'));
      submitButton.triggerEventHandler('click', null);
      expect(component.amountMarkedAsInvalid).toEqual(false);
    });

    it('check tradeAmount 249,999,999', () => {
      component.form.get('tradeAmount').setValue('249,999,999');

      const submitButton = fixture.debugElement.query(By.css('#transaction-submit'));
      submitButton.triggerEventHandler('click', null);
      expect(component.amountMarkedAsInvalid).toEqual(false);
    });

  });

  describe('should check isPrimaryButtonDisabled method', () => {
    it('in LENDER_OPEN state button should be disabled', () => {
      component.model.stateType = LENDER_OPEN;
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      expect(component.isPrimaryButtonDisabled()).toEqual(true);
    });
    it('in LENDER_ACCEPTED state button should be disabled', () => {
      component.model.stateType = LENDER_ACCEPTED;
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      expect(component.isPrimaryButtonDisabled()).toEqual(true);
    });
    it('in TRADER_PRICED state button should be enabled', () => {
      component.model.stateType = TRADER_PRICED;
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      expect(component.isPrimaryButtonDisabled()).toEqual(false);
    });
    it('in TRADER_REPRICED state button should be enabled', () => {
      component.model.stateType = TRADER_REPRICED;
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      expect(component.isPrimaryButtonDisabled()).toEqual(false);
    });
    it('when request is processing(create) button should be disabled', () => {
      component.isCreating = true;
      expect(component.isPrimaryButtonDisabled()).toEqual(true);
    });

    it('when request is processing(update) button should be disabled', () => {
      component.isUpdating['17H00001'] = true;
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      expect(component.isPrimaryButtonDisabled()).toEqual(true);
    });
  });

  describe('should check isCancelButtonDisabled method', () => {
    beforeEach(() => {
      component.model.stateType = LENDER_OPEN;
    });

    it('LENDER_OPEN - button should be enabled', () => {
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      expect(component.isCancelButtonDisabled()).toEqual(false);
    });
    it('when no state - button should be disabled', () => {
      component.model.stateType = '';
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      expect(component.isCancelButtonDisabled()).toEqual(true);
    });
    it('in LENDER_ACCEPTED state button should be disabled', () => {
      component.model.stateType = LENDER_ACCEPTED;
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      expect(component.isCancelButtonDisabled()).toEqual(true);
    });
    it('when request is processing(update) button should be disabled', () => {
      component.isUpdating['17H00001'] = true;
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      expect(component.isCancelButtonDisabled()).toEqual(true);
    });
    it('when cancel is reactivated button should be enabled', () => {
      component.model.stateType = '';
      component.ngOnChanges({
        model: new SimpleChange(null, component.model, false)
      });
      expect(component.isCancelButtonDisabled()).toEqual(true);

      component.isCancelReactivated = true;
      expect(component.isCancelButtonDisabled()).toEqual(false);
    });

  });

  it('should check how manageCancelReactivateState sets isCancelReactivated flag', fakeAsync(() => {

    component.model.lastUpdatedDate = component.model.lastPublishTime;
    expect(component.isCancelReactivated).toBeUndefined();
    component.model.stateType = LENDER_ACCEPTED;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    expect(component.isCancelReactivated).toEqual(false);
    const tick1 = 1000;
    tick(tick1);
    component.model.stateType = TRADER_PRICED;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    const tick2 = 2000;
    tick(tick2);
    component.model.stateType = LENDER_ACCEPTED;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    tick(cancelReactivateTimeout - tick1 - tick2);
    expect(component.isCancelReactivated).toEqual(false);
    tick(tick1 + tick2);
    expect(component.isCancelReactivated).toEqual(true);

    component.model.stateType = TRADER_PRICED;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    expect(component.isCancelReactivated).toEqual(false);
    tick(cancelReactivateTimeout);
    expect(component.isCancelReactivated).toEqual(false);

    component.model.stateType = LENDER_ACCEPTED;
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    expect(component.isCancelReactivated).toEqual(false);
    tick(cancelReactivateTimeout);
    expect(component.isCancelReactivated).toEqual(true);

    const publishDelay = 5000;
    component.model.lastUpdatedDate = moment(component.model.lastPublishTime).subtract(publishDelay, 'milliseconds').toISOString();
    component.ngOnChanges({
      model: new SimpleChange(null, component.model, false)
    });
    expect(component.isCancelReactivated).toEqual(false);
    tick(cancelReactivateTimeout - publishDelay - 5000);
    expect(component.isCancelReactivated).toEqual(false);
    tick(cancelReactivateTimeout - publishDelay - 6000);
    expect(component.isCancelReactivated).toEqual(false);
    tick(cancelReactivateTimeout - publishDelay - 9000);
    expect(component.isCancelReactivated).toEqual(true);
  }));

});
