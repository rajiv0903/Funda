import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SimpleChange } from '@angular/core';
import { DatePipe } from '@angular/common';
import { By } from '@angular/platform-browser';

import { TooltipModule } from 'ngx-tooltip';

import { ProductPricingGridComponent, PricingInfo } from './product-pricing-grid.component';
import { deepCopy } from '../../../../test';

describe('ProductPricingGridComponent', () => {
  let component: ProductPricingGridComponent;
  let fixture: ComponentFixture<ProductPricingGridComponent>;
  const mockPricing = deepCopy(require('../../../../assets/data/pricing.json'));
  const mockTransRequests = deepCopy(require('../../../../assets/data/transaction-requests.json'));

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ProductPricingGridComponent
      ],
      imports: [
        TooltipModule
      ],
      providers: [
        DatePipe
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductPricingGridComponent);
    component = fixture.componentInstance;
    component.transactionRequest = mockTransRequests[0];
    component.pricing = mockPricing;
    component.isPricingLoading = false;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should test ngOnChanges method', () => {
    component.tradeTypeButtonsState['SELL-4.000-Sep'] = true;

    component.ngOnChanges({
      transactionRequest: new SimpleChange(null, component.transactionRequest, true)
    });

    expect(component.tradeTypeButtonsState['SELL-4.000-Sep']).toEqual(true);

    component.transactionRequest = mockTransRequests[1];
    component.transactionRequest.tradeBuySellType = 'SELL';
    component.transactionRequest.tradeCouponRate = '3.500';
    component.transactionRequest.tradeSettlementDate = '2017-08-04';
    component.transRequestExists = true;
    component.ngOnChanges({
      transactionRequest: new SimpleChange(mockTransRequests[1], component.transactionRequest, false)
    });

    expect(component.tradeTypeButtonsState['SELL-3.500-Aug']).toEqual(true);
  });

  it('should test ngOnChanges method for product change', () => {
    component.transactionRequest = mockTransRequests[1];
    component.transactionRequest.product.productId.identifier = 2;
    component.ngOnChanges({
      transactionRequest: new SimpleChange(mockTransRequests[0], component.transactionRequest, false)
    });

    expect(component.tradeTypeButtonsState).toEqual({});
  });

  it('it should check isActionDisabled method', () => {
    component.transRequestExists = false;
    component.transactionRequest.product.productId = {
      identifier: 1,
      sourceType: 'PU',
      type: 'MBS'
    };
    expect(component.isActionDisabled(component.pricing[0])).toEqual(false);

    expect(component.isActionDisabled(component.pricing[1])).toEqual(true);

    component.transRequestExists = false;
    component.transactionRequest.product.productId = null;
    expect(component.isActionDisabled(component.pricing[0])).toEqual(true);

    component.transRequestExists = true;
    component.transactionRequest.product.productId = null;
    expect(component.isActionDisabled(component.pricing[0])).toEqual(true);

    component.transRequestExists = true;
    component.transactionRequest.product.productId = {
      identifier: 1,
      sourceType: 'PU',
      type: 'MBS'
    };
    expect(component.isActionDisabled(component.pricing[0])).toEqual(true);

    component.transRequestExists = false;
    component.transactionRequest.product.productId = {
      identifier: 1,
      sourceType: 'PU',
      type: 'MBS'
    };
    component.isPricingLoading = true;
    expect(component.isActionDisabled(component.pricing[0])).toEqual(true);
  });

  it('should check getter coupons', () => {
    expect(component.coupons.sort((a, b) => parseFloat(a) - parseFloat(b))).toEqual(['4.000', '4.500']);
  });

  it('should check distinct pricing getter', () => {
    const expected = component.pricing
      .filter(p => p.passThroughRate === component.coupons[0])
      .sort((a, b) => {
        return parseInt(a.settlementDate.replace(/-/g, ''), 10) - parseInt(b.settlementDate.replace(/-/g, ''), 10)
      });
    expect(component.distinctPricing).toEqual(expected);
  });

  it('should check getMonth method', () => {
    expect(component.getMonth('2017-09-20')).toEqual('Sep');
    expect(component.getMonth('2017-10-20')).toEqual('Oct');
    expect(component.getMonth('2017-11-20')).toEqual('Nov');
  });

  it('should test onPricingSelect callback', () => {
    component.onPricingSelect('SELL', '4.000', '2017-10-22');
    component.changed.subscribe((pricingInfo: PricingInfo) => {
      expect(pricingInfo).toEqual({
        tradeBuySellType: 'SELL',
        tradeCouponRate: '4.000',
        tradeSettlementDate: '2017-10-22'
      });
    });
    expect(component.tradeTypeButtonsState['SELL-4.000-Oct']).toEqual(true);
  });

  it('should check if the class is picked after the product is selected', () => {
    component.transactionRequest.product.productId = {
      identifier: 1,
      sourceType: 'PU',
      type: 'MBS'
    };
    const button = fixture.debugElement.query(By.css('button'));
    fixture.detectChanges();
    expect(button.nativeElement.className).toEqual('sell change-on-hover');
  });

  it('should disable the action control if pricing is not active', () => {
    const button = <HTMLInputElement> document.getElementById('SELL-4.500-Oct');
    expect(button.disabled).toEqual(true);

    component.pricing[1].active = true;
    fixture.detectChanges();
    expect(button.disabled).toEqual(false);
  });

});
