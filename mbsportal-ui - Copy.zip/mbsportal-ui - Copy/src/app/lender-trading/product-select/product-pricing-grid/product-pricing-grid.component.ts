import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { DatePipe } from '@angular/common';

import { Pricing } from '../../../store/models/pricing.model';
import { TransactionRequest } from '../../../store/models/transaction-request.model';

export interface PricingInfo {
  tradeBuySellType: string;
  tradeCouponRate: string;
  tradeSettlementDate: string;
}

@Component({
  moduleId: module.id,
  selector: 'mbsp-product-pricing-grid',
  templateUrl: 'product-pricing-grid.component.html',
  styleUrls: ['product-pricing-grid.component.scss']
})
export class ProductPricingGridComponent implements OnChanges {

  @Input() transactionRequest: TransactionRequest;
  @Input() transRequestExists: boolean;
  @Input() pricing: Pricing[];
  @Input() isPricingLoading: boolean;

  @Output() changed = new EventEmitter<PricingInfo>();

  public tradeTypeButtonsState: {string?: boolean} = {};

  constructor(private datePipe: DatePipe) {}

  ngOnChanges(changes: SimpleChanges) {
    if (this.isProductIdChanged(changes)) {
      this.tradeTypeButtonsState = {};
    }
    if (this.transRequestExists) {
      const tr = this.transactionRequest;
      this.setTradeTypeButtonsState(tr.tradeBuySellType, tr.tradeCouponRate, tr.tradeSettlementDate);
    }
  }

  get coupons(): string[] {
    const coupons = this.pricing.map((perProduct: Pricing) => perProduct.passThroughRate);
    return coupons.filter(function(item, pos) {
      return coupons.indexOf(item) === pos;
    });
  }

  // need to filter to get distinct settlement dates since there are copies for each coupon
  get distinctPricing(): Pricing[] {
    return this.pricing
      .filter(p => p.passThroughRate === this.coupons[0])
      .sort((a, b) => {
        return parseInt(a.settlementDate.replace(/-/g, ''), 10) - parseInt(b.settlementDate.replace(/-/g, ''), 10)
      });
  }

  private isProductIdChanged(changes: SimpleChanges): boolean {
    let changed = false;
    if (changes.transactionRequest) {
      const prev = changes.transactionRequest.previousValue;
      const curr = changes.transactionRequest.currentValue;
      changed = prev && prev.product.productId.identifier !== curr.product.productId.identifier;
    }
    return changed;
  }

  private setTradeTypeButtonsState(action, coupon, settlementDate) {
    this.tradeTypeButtonsState = {};
    this.tradeTypeButtonsState[`${action}-${coupon}-${this.getMonth(settlementDate)}`] = true;
  }

  public isActionDisabled(p: Pricing): boolean {
    return this.transRequestExists || !this.transactionRequest.product.productId || !p.active || this.isPricingLoading
  }

  public getMonth(date: string) {
    return this.datePipe.transform(date, 'MMM');
  }

  // TODO move this to pricing-cell.component later
  public onPricingSelect(action: string, coupon: string, settlementDate: string) {
    this.setTradeTypeButtonsState(action, coupon, settlementDate);
    this.changed.emit({
      tradeBuySellType: action,
      tradeCouponRate: coupon,
      tradeSettlementDate: settlementDate
    });
  }

}
