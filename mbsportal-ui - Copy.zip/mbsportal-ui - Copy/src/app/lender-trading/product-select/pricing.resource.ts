/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Pricing } from '../../store/models/pricing.model';
import { ProductId } from '../../store/models/product.model';

@Injectable()
export class PricingResource {

  private path = environment.apiBasePath + '/mbsproductpricing';

  constructor(private httpClient: HttpClient) { }

  public get(id: ProductId): Observable<Pricing[]> {
    const compositeId = `${id.identifier}/${id.sourceType}/${id.type}`;
    return this.httpClient.get<Pricing[]>(this.path + '/' + compositeId);
  }

}
