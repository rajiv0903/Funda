/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { Component, ElementRef, Input, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl, ValidatorFn } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Rx';

import * as fromRoot from '../../store';
import * as trActions from '../../store/actions/transaction-request.actions';
import * as pActions from '../../store/actions/pricing.actions';
import { UserProfileService } from '../../shared/services/user-profile.service';
import { Product, ProductId } from '../../store/models/product.model';
import {
  TransactionRequest,
  LENDER_OPEN,
  LENDER_ACCEPTED,
  TRADER_PRICED,
  LENDER_REJECTED,
  TRADER_REPRICED
} from '../../store/models/transaction-request.model';
import { PricingInfo } from './product-pricing-grid/product-pricing-grid.component';
import { Pricing } from '../../store/models/pricing.model';
import { TransactionRequestService } from '../../shared/services/transaction-request.service';
import { DecimalPipe } from '@angular/common';
import { cancelReactivateTimeout } from '../../shared/constants/system.constant';
import { MiscService } from '../../shared/services/misc.service';
import { LoggerService } from '../../shared/services/logger.service';
import { getInvalidAmountErrorText } from '../../shared/constants/validation.constant';
import { maxAmountValue, minAmountValue } from '../../shared/constants/business.constant';
import { StringBooleanArray } from '../../shared/interfaces/misc.interface';

@Component({
  moduleId: module.id,
  selector: 'mbsp-product-select',
  templateUrl: 'product-select.component.html',
  styleUrls: ['product-select.component.scss']
})

export class ProductSelectComponent implements OnChanges, OnInit {

  @Input() model: TransactionRequest;
  @Input() products: Product[];
  @Input() error: any;
  @Input() isCreating: boolean;
  @Input() isUpdating: StringBooleanArray;

  @ViewChild('lenderEntity') lenderEntity: ElementRef;
  @ViewChild('lenderName') lenderName: ElementRef;
  @ViewChild('timer') timer: ElementRef;

  public form: FormGroup;
  public alerts = [];
  public amountMarkedAsInvalid = false;
  public entityTooltipDisabled: boolean;
  public nameTooltipDisabled: boolean;
  public tspLenders = [];
  public timerStartFromSeconds: number;
  public isCancelReactivated: boolean;
  public cancelReactivateTimeout: any;
  public invalidAmountErrorText: string;

  constructor(
    private store: Store<fromRoot.AppStore>,
    public userProfile: UserProfileService,
    private trService: TransactionRequestService,
    public formBuilder: FormBuilder,
    private numberPipe: DecimalPipe,
    private loggerService: LoggerService,
    public miscService: MiscService
  ) {
    this.createForm();
  }

  ngOnInit() {
    this.prepareTspLenders();
    this.formatInvalidAmountErrorText();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.model) {
      this.form.patchValue({...this.model, product: {productId: this.findProductIdReference()}});
      this.transformTradeAmountNumber(this.model.tradeAmount);
      this.form.get('tradeAmount').disable();
      this.timerStartFromSeconds = this.trService.getAge(this.model.lastPublishTime, this.model.submissionDate);
      this.manageCancelReactivateState(this.model.stateType);
    }
    if (changes.model && changes.model.previousValue && !changes.model.currentValue) {
      this.form.patchValue(this.initialFormValue);
      this.form.get('tradeAmount').enable();
    }
    if (changes.error && changes.error.currentValue) {
      this.handleErrors();
    }
  }

  get initialFormValue() {
    return {
      'transReqId': '',
      'oboLenderSellerServicerNumber': '',
      'product': {
        'productId': '',
        'nameCode': ''
      },
      'stateType': '',
      'tradeAmount': '',
      'pricePercentHandleText': '',
      'pricePercentTicksText': '',
      'tradeBuySellType': '',
      'tradeCouponRate': '',
      'tradeSettlementDate': '',
      'activeVersion': ''
    }
  };

  get tradeAmountValidators(): ValidatorFn[] {
    return [
      Validators.required,
      this.minMaxValidator()
    ];
  }

  get fullName() {
    return this.userProfile.firstName + ' ' + this.userProfile.lastName;
  }

  get pricing$(): Observable<Pricing[]> {
    return this.store.select(fromRoot.getPricingEntities);
  }

  get isPricingLoading$(): Observable<any> {
    return this.store.select(fromRoot.getPricingIsLoading);
  }

  get formValue() {
    return this.form.value;
  }

  get productName(): string {
    let productName = '';
    if (this.formValue.product.productId) {
      productName = this.findProduct(this.formValue.product).nameCode;
    }
    return productName;
  }

  get ticketLenderEntity(): string {
    let entity = this.userProfile.entityName;
    if (this.userProfile.isTsp) {
      entity = '';
      if (this.formValue.oboLenderSellerServicerNumber) {
        entity = this.findTSPLender(this.formValue.oboLenderSellerServicerNumber).text;
      }
    }
    return entity;
  }

  get ticketLenderName(): string {
    let name = this.fullName;
    if (!this.ticketLenderEntity) {
      name = '';
    }
    return name;
  }

  getCleanTradeAmount(tradeAmount?: string): string {
    const amount = tradeAmount || this.formValue.tradeAmount;
    return amount ? amount.replace(/\D/g, '') : null;
  }

  get primaryButtonText() {
    let text = '';
    if (this.isSubmitButton()) {
      text = 'submit';
    } else if (this.isHitButton()) {
      text = 'hit';
    } else if (this.isLiftButton()) {
      text = 'lift';
    }
    return text;
  }

  get selectedTSPLender() {
    let lender = null;
    if (this.model && this.model.oboLenderSellerServicerNumber) {
      lender = [this.findTSPLender(this.model.oboLenderSellerServicerNumber)];
    }
    return lender;
  }

  private createForm() {
    this.form = this.formBuilder.group({
      ...this.initialFormValue,
      tradeAmount: [
        '',
        this.tradeAmountValidators
      ]
    });
  }

  private prepareTspLenders(): void {
    if (this.userProfile.isTsp && this.userProfile.tspLenders) {
      this.userProfile.tspLenders.forEach(item => {
        this.tspLenders.push({'id': item.lenderSellerServicerNumber, 'text': item.name});
      });
      this.sortTspLenders();
    }
  }

  private findTSPLender(ssn: string) {
    return this.tspLenders.find(lender => {
      return lender.id === ssn
    });
  }

  private findProduct(selectedProduct: Product): Product {
    return this.products.find(p => {
      return p.productId.identifier === selectedProduct.productId.identifier
    });
  }

  // needed for dropdown to have the same object reference as product.productId
  // TODO possibly simplify when generalize dropdown (either flatten the id or use compare function
  private findProductIdReference() {
    return this.findProduct(this.model.product).productId;
  }

  private handleErrors(): void {
    // TODO fix to check based on error code or in other generic way, move errors text outside
    if (this.error.message) {
      if (this.error.message.includes('Fannie Mae is no longer trading this settlement month')) {
        this.alerts = [{
          type: 'warning',
          message: this.error.message
        }];
        this.store.dispatch(new pActions.LoadAction(this.formValue.product.productId));
      } else if (this.error.message.includes('Invalid amount. Amount must be between 25,000 to 250,000,000')) {
        this.markAmountAsInvalid();
      }
    }
  }

  private minMaxValidator(): ValidatorFn {
    const minValue = minAmountValue;
    const maxValue = maxAmountValue;
    return (control: AbstractControl): {[key: string]: any} => {
      const amountNumber = control.value ? parseInt(this.getCleanTradeAmount(control.value), 10) : 0;
      const isInvalid = amountNumber < minValue || amountNumber > maxValue;
      return isInvalid ? {'minMax': amountNumber} : null;
    }
  }

  private transformTradeAmountNumber(tradeAmountFormValue) {
    let transformedValue: any = tradeAmountFormValue;
    if (tradeAmountFormValue) {
      transformedValue = this.numberPipe.transform(tradeAmountFormValue);
    }
    this.form.get('tradeAmount').setValue(transformedValue);
  }

  private manageCancelReactivateState(stateType: string) {
    this.isCancelReactivated = false;
    if (stateType === LENDER_ACCEPTED) {
      clearTimeout(this.cancelReactivateTimeout);
      const timeAfterLenderAccepted = this.trService.getAge(this.model.lastPublishTime, this.model.lastUpdatedDate, 'milliseconds');
      const waitBeforeReactivate = Math.max(cancelReactivateTimeout - timeAfterLenderAccepted, 0);
      if (waitBeforeReactivate > 0) {
        this.cancelReactivateTimeout = setTimeout(() => {
          this.isCancelReactivated = true;
        }, waitBeforeReactivate);
      } else {
        this.isCancelReactivated = true;
      }
    }
  }

  private formatInvalidAmountErrorText(): void {
    const min = this.numberPipe.transform(minAmountValue);
    const max = this.numberPipe.transform(maxAmountValue);
    this.invalidAmountErrorText = getInvalidAmountErrorText(min, max);
  }

  public sortTspLenders() {
    this.miscService.sortItems(this.tspLenders, 'text');
  }

  public showCancelTicketButton(): boolean {
    return [
        LENDER_OPEN,
        TRADER_PRICED,
        TRADER_REPRICED
      ].includes(this.formValue.stateType) && !!this.formValue.transReqId;
  }

  public showPriceBlock(): boolean {
    return !!(this.formValue.pricePercentHandleText && this.formValue.pricePercentTicksText);
  }

  public showClearTicketButton(): boolean {
    const transReqId = this.formValue.transReqId;
    const stateType = this.formValue.stateType;
    const productIdSet = !!this.formValue.product.productId;
    return (!transReqId || this.trService.isInactive(stateType)) && productIdSet;
  }

  public addNumberMask() {
    this.transformTradeAmountNumber(this.getCleanTradeAmount());
  }

  public inLenderOpenState(): boolean {
    return this.trService.isLenderOpen(this.formValue.stateType);
  }

  public inTraderPricedState(): boolean {
    return this.trService.isTraderPriced(this.formValue.stateType);
  }

  public inTraderRepricedState(): boolean {
    return this.trService.isTraderRepriced(this.formValue.stateType);
  }

  public inTraderPassedState(): boolean {
    return this.trService.isTraderPassed(this.formValue.stateType);
  }

  public inTraderRejectedState(): boolean {
    return this.trService.isTraderRejected(this.formValue.stateType);
  }

  public inLenderCancelledState(): boolean {
    return this.trService.isLenderCancelled(this.formValue.stateType);
  }

  public inLenderAcceptedState(): boolean {
    return this.trService.isLenderAccepted(this.formValue.stateType);
  }

  public inTraderExecutedState(): boolean {
    return this.trService.isExecuted(this.formValue.stateType);
  }

  public inLenderTimeoutState(): boolean {
    return this.trService.isLenderTimeout(this.formValue.stateType);
  }

  public inTraderTimeoutState(): boolean {
    return this.trService.isTraderTimeout(this.formValue.stateType);
  }

  public isActive(): boolean {
    return this.trService.isActive(this.formValue.stateType);
  }

  public isInactive(): boolean {
    return this.trService.isInactive(this.formValue.stateType);
  }

  public showButtons(): boolean {
    return !this.formValue.stateType || this.trService.isActive(this.formValue.stateType);
  }

  public getTradeBuySellTypeLabelClass() {
    return {
      'sell-type': this.formValue.tradeBuySellType === 'SELL',
      'buy-type': this.formValue.tradeBuySellType === 'BUY'
    };
  }

  public getTicketHeaderClass() {
    return {
      'quoted': this.inTraderPricedState(),
      'requoted': this.inTraderRepricedState(),
      'passed': this.inTraderPassedState(),
      'accepted': this.inTraderExecutedState(),
      'cancelled': this.inTraderRejectedState() || this.inLenderCancelledState(),
      'time-out': this.inTraderTimeoutState() || this.inLenderTimeoutState(),
      'inactive': this.isInactive()
    };
  }

  public markAmountAsInvalid(): void {
    this.amountMarkedAsInvalid = true;
  }

  public markAmountAsValid(): void {
    this.amountMarkedAsInvalid = false;
  }

  public setEntityTooltipDisability(): void {
    this.entityTooltipDisabled = this.lenderEntity.nativeElement.offsetWidth === this.lenderEntity.nativeElement.scrollWidth
      && this.lenderEntity.nativeElement.offsetHeight === this.lenderEntity.nativeElement.scrollHeight;
  }

  public setNameTooltipDisability(): void {
    this.nameTooltipDisabled = this.lenderName.nativeElement.offsetWidth === this.lenderName.nativeElement.scrollWidth;
  }

  public isRequestProcessing(): boolean {
    return this.isCreating || !!this.isUpdating[this.formValue.transReqId];
  }

  public isPrimaryButtonDisabled(): boolean {
    return this.inLenderOpenState() || this.inLenderAcceptedState() || this.isRequestProcessing();
  }

  public isCancelButtonDisabled(): boolean {
    return (!this.formValue.stateType || this.inLenderAcceptedState() || this.isRequestProcessing()) && !this.isCancelReactivated;
  }

  public isHitButton(): boolean {
    return !this.isSubmitButton() && this.formValue.tradeBuySellType === 'SELL';
  }

  public isLiftButton(): boolean {
    return !this.isSubmitButton() && this.formValue.tradeBuySellType === 'BUY';
  }

  public isSubmitButton(): boolean {
    return !this.formValue.stateType || this.inLenderOpenState();
  }

  public onProductSelect(selectedProductId: ProductId) {
    const productName = this.findProduct({productId: selectedProductId}).nameCode;
    if (selectedProductId && (selectedProductId.identifier || selectedProductId.identifier === 0)) {
      this.loggerService.info('Lender selects product name: ' + productName);
      this.store.dispatch(new pActions.LoadAction(selectedProductId));
    }
    this.form.patchValue({
      'product': {
        productId: selectedProductId,
        nameCode: productName
      },
      'tradeBuySellType': '',
      'tradeAmount': ''
    });
  }

  public onTspLenderSelect(selectedTspOption) {
    if (this.formValue.oboLenderSellerServicerNumber !== selectedTspOption.id) {
      this.loggerService.info('Lender selects TSP lender: ' + selectedTspOption.id + ' ' + selectedTspOption.text);
      this.form.patchValue({
        'product': {
          productId: '',
          nameCode: ''
        },
        'tradeBuySellType': '',
        'tradeAmount': ''
      });
      this.form.get('oboLenderSellerServicerNumber').setValue(selectedTspOption.id);
    }
  }

  public onPricingSelect(gridData: PricingInfo) {
    this.loggerService.info('Lender selects type:  ' + gridData.tradeBuySellType);
    this.form.patchValue({...gridData, tradeAmount: ''});
  }

  public onSubmit() {
    if (this.form.valid) {
      if (!this.formValue.stateType) {
        this.markAmountAsValid();
        this.onCreate();
      } else {
        this.onAccept();
      }
    } else {
      this.markAmountAsInvalid();
    }
  }

  public onCreate() {
    const amount = this.getCleanTradeAmount();
    if (amount) {
      delete this.formValue.transReqId;
      if (!this.userProfile.isTsp) {
        delete this.formValue.oboLenderSellerServicerNumber;
      }
      this.loggerService.info('Lender opens transaction');
      this.store.dispatch(new trActions.CreateAction({
        ...this.formValue,
        tradeAmount: amount,
        stateType: LENDER_OPEN
      }));
    }
  }

  public onAccept() {
    this.loggerService.info('Lender accepts transaction id: ' + this.formValue.transReqId);
    this.store.dispatch(new trActions.UpdateAction({
      ...this.formValue,
      stateType: LENDER_ACCEPTED
    }));
  }

  public onCancel() {
    this.loggerService.info('Lender rejects transaction id: ' + this.formValue.transReqId);
    this.store.dispatch(new trActions.UpdateAction({
      ...this.formValue,
      stateType: LENDER_REJECTED
    }));
  }

  public onClearTicket() {
    if (this.formValue.transReqId) {
      this.loggerService.info('Lender selects new trade and clears transaction with transaction id: ' + this.formValue.transReqId);
      this.store.dispatch(new trActions.DeleteSuccessAction(this.formValue));
    } else {
      this.loggerService.info('Lender selects new trade');
      this.form.patchValue(this.initialFormValue);
    }
    this.markAmountAsValid();
  }

  public disableProductSelect(): boolean {
    return (!!this.formValue.transReqId || (this.userProfile.isTsp && !this.formValue.oboLenderSellerServicerNumber));
  }

}
