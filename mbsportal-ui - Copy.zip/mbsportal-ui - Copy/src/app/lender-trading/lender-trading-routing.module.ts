import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { LenderTradingComponent } from './lender-trading.component';
import { LenderTransactionRequestsLoadedGuard } from '../shared/guards/lender-transaction-requests-loaded.guard';
import { ProductsLoadedGuard } from '../shared/guards/products-loaded.guard';
import { PricingLoadedGuard } from '../shared/guards/pricing-loaded.guard';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: '',
        component: LenderTradingComponent,
        canActivate: [
          LenderTransactionRequestsLoadedGuard,
          ProductsLoadedGuard,
          PricingLoadedGuard
        ]
      }
    ])
  ],
  providers: [
    LenderTransactionRequestsLoadedGuard,
    ProductsLoadedGuard,
    PricingLoadedGuard
  ],
  exports: [RouterModule]
})
export class LenderTradingRoutingModule { }

