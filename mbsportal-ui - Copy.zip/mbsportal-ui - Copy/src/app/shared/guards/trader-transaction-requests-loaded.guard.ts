import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Rx';

import * as fromRoot from '../../store';
import * as actions from '../../store/actions/transaction-request.actions';

@Injectable()
export class TraderTransactionRequestsLoadedGuard implements CanActivate {

  constructor(private store: Store<fromRoot.AppStore>) {}

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {

    this.store.dispatch(new actions.LoadAction());

    return this.store.select(fromRoot.getTransactionRequestsLoaded)
      .filter(loaded => loaded)
      .take(1);
  }
}
