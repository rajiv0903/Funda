import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Rx';

import * as fromRoot from '../../store';
import * as actions from '../../store/actions/trade.actions';
import { TradesList, tradesListDefaultState } from '../../store/reducers/trade.reducer';

@Injectable()
export class TradesLoadedGuard implements CanActivate {

  constructor(
    private store: Store<fromRoot.AppStore>) {}

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    this.store.select(fromRoot.getTradesList)
      .take(1)
      .subscribe((listObject: TradesList) => this.store.dispatch(new actions.LoadAction({
          acceptedTrades: listObject.acceptedTrades,
          sortBy: tradesListDefaultState.listObject.sortBy,
          sortOrder: tradesListDefaultState.listObject.sortOrder,
          pageIndex: tradesListDefaultState.listObject.pageIndex,
          pageSize: tradesListDefaultState.listObject.pageSize
        }))
      );

    return this.store.select(fromRoot.getTradesLoaded)
      .filter(loaded => loaded)
      .take(1);
  }
}
