import { Injectable } from '@angular/core';
import { CanLoad, Route } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Rx';

import * as fromRoot from '../../store';
import { ProfileState } from '../../store/reducers/profile.reducer';
import { UserProfileService } from '../services/user-profile.service';

@Injectable()
export class UserTypeGuard implements CanLoad {

  constructor(
    private store: Store<fromRoot.AppStore>,
    private profile: UserProfileService
  ) {}

  canLoad(route: Route): Observable<boolean> {
    return this.store.select(fromRoot.getProfileState)
      .filter((profileState: ProfileState) => profileState.loaded)
      .map(() => {
        return this.profile.userType === route.data.userType
      })
      .take(1);
  }
}
