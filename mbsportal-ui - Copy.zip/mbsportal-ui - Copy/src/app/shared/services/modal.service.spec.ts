import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NgModule } from '@angular/core';
import { BrowserModule, By } from '@angular/platform-browser';

import { StoreModule } from '@ngrx/store';
import { BsModalService, ModalModule } from 'ngx-bootstrap';

import { ModalService  } from './modal.service';
import { UserProfileService } from './user-profile.service';
import { ModalComponent } from '../components/modal/modal.component';

import { UserType } from '../enums/user-type.enum';
import { getProfileReducerMock } from '../../util/stubs/mock-profile-reducer';
import { RoleType } from '../enums/role-type.enum';
import { modalContent } from '../constants/error.constant';

@NgModule({
  imports: [
    BrowserModule,
    StoreModule.forRoot({
      profile: getProfileReducerMock(RoleType.TRADER)
    }),
    ModalModule.forRoot()
  ],
  declarations: [ModalComponent],
  entryComponents: [ModalComponent]
})
export class ModalModuleStub {}

describe('ModalService ', () => {
  let service: ModalService ;
  let bsModalService: BsModalService;
  let fixture: ComponentFixture<ModalComponent>;
  let component: ModalComponent;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        ModalModuleStub
      ],
      providers: [
        ModalService,
        BsModalService,
        UserProfileService
      ]
    });

    service = TestBed.get(ModalService);
    bsModalService = TestBed.get(BsModalService);

    fixture = TestBed.createComponent(ModalComponent);
    component = fixture.componentInstance;
  });

  it('should create an instance', () => {
    expect(service).toBeDefined();
  });

  describe('check show method', () => {
    it('showing 401 modal and checking its contents', () => {
      const modal = service.show({status: 401});
      expect(modal.content.content).toBe(modalContent.unauthorized);
      expect(modal.content.closeBtnText).toBe('Log In');
      expect(modal.content.type).toBe('warning');
      expect(modal.content.status).toBe(401);
      modal.hide();
    });

    it('should show 401 modal ', () => {
      const modal = service.show({status: 401});
      expect(fixture.debugElement.query(By.css('.modal-dialog'))).toBeDefined();
      modal.hide();
    });

    it('showing 500 modal and checking its contents', () => {
      const modal = service.show({status: 500});
      expect(modal.content.content).toBe(modalContent[UserType.INTERNAL + '-server-error']);
      expect(modal.content.closeBtnText).toBe('Ok');
      expect(modal.content.type).toBe('warning');
      expect(modal.content.status).toBe(500);
      modal.hide();
    });

    it('should show 500 modal ', () => {
      const modal = service.show({status: 500});
      expect(fixture.debugElement.query(By.css('.modal-dialog'))).toBeDefined();
      modal.hide();
    });

    it('should not show the modal ', () => {
      const modal = service.show({
        status: 500,
        messages: [
          {
            messageType: 'NONDSP_ERROR'
          }
        ]
      });
      expect(modal).toBeUndefined();
    });


  });

});
