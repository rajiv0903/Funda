/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { TestBed } from '@angular/core/testing';
import { Store, StoreModule } from '@ngrx/store';
import { getProfileReducerMock } from '../../util/stubs/mock-profile-reducer';
import { RoleType } from '../enums/role-type.enum';
import { WSService } from './ws.service';
import { StompRService } from '@stomp/ng2-stompjs';
import { LoggerService } from './logger.service';
import { LocalStorageService } from './local-storage.service';
import { UserProfileService } from './user-profile.service';
import { DatePipe } from '@angular/common';
import { UserType } from '../enums/user-type.enum';
import { Observable } from 'rxjs/Observable';
import { deepCopy } from '../../../test';
import * as trActions from '../../store/actions/transaction-request.actions';
import * as prActions from '../../store/actions/profile.actions';
import { environment } from '../../../environments/environment';

fdescribe('WSService ', () => {
  let wsService;
  let stompService;
  let localStorageService;
  let store;
  const mockTransactionRequests = deepCopy(require('../../../assets/data/transaction-requests.json'));
  const mockProfile = deepCopy(require('../../../assets/data/lender-profile.json'));

  const wsMessage = {
    headers: {
      'content-length': 813,
      'content-type': 'text/plain;charset=UTF-8',
      'destination': '/mbsp/topic/transaction/p3hbrmnt',
      'message-id': '43a5uogq-5',
      'subscription': 'sub-0'
    },
    body: JSON.stringify(mockTransactionRequests[0])
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot({
          profile: getProfileReducerMock(RoleType.LENDER, mockProfile),
        })
      ],
      providers: [
        WSService,
        {
          provide: StompRService,
          useValue: {
            ...jasmine.createSpyObj('stompService', ['initAndConnect', 'subscribe']),
            state: Observable.of(2) // 'CONNECTED' state
          }
        },

        LoggerService,
        LocalStorageService,
        UserProfileService,
        DatePipe,
        LocalStorageService,
      ]
    });
    wsService = TestBed.get(WSService);
    stompService = TestBed.get(StompRService);
    localStorageService = TestBed.get(LocalStorageService);
    store = TestBed.get(Store);

    stompService.initAndConnect.and.returnValue(null);
  });

  it('should check stomp config values', () => {
    stompService.subscribe.and.returnValue(Observable.of(wsMessage));

    localStorageService.set('sessionId', 'testSessionId');
    wsService.initAndConnect(UserType.EXTERNAL);

    expect(stompService.config.headers['x-fnma-channel']).toEqual('web');
    expect(stompService.config.headers['x-fnma-sub-channel']).toEqual('MBSP');
    if (environment.name !== 'local') {
      expect(stompService.config.headers['x-fnma-sessionid']).toEqual('testSessionId');
    }
  });

  it('should check lender transaction topic subscription logic', () => {
    stompService.subscribe.and.returnValue(Observable.of(wsMessage));

    spyOn(store, 'dispatch');
    wsService.initAndConnect(UserType.EXTERNAL);
    expect(store.dispatch).toHaveBeenCalledWith(new trActions.UpdateWSSuccessAction(mockTransactionRequests[0]));
  });

  it('should check trader transaction topic subscription logic', () => {
    stompService.subscribe.and.returnValue(Observable.of({
      ...wsMessage,
      headers: {
        ...wsMessage.headers,
        destination: '/mbsp/topic/transaction/trader'
      }
    }));

    spyOn(store, 'dispatch');
    wsService.initAndConnect(UserType.INTERNAL);
    expect(store.dispatch).toHaveBeenCalledWith(new trActions.UpdateWSSuccessAction(mockTransactionRequests[0]));
  });

  it('should check trader connect to pricing topic', () => {
    stompService.subscribe.and.returnValue(Observable.of({
      ...wsMessage,
      headers: {
        ...wsMessage.headers,
        destination: '/mbsp/topic/tbapricing'
      }
    }));

    spyOn(store, 'dispatch');
    wsService.initAndConnect(UserType.INTERNAL);
    expect(store.dispatch).toHaveBeenCalledWith(new trActions.UpdatePriceAction(mockTransactionRequests[0]));
  });


  it('should check the state in connected status', () => {
    stompService.subscribe.and.returnValue(Observable.of({
      ...wsMessage,
      headers: {
        ...wsMessage.headers,
        destination: '/mbsp/topic/tbapricing'
      }
    }));

    spyOn(store, 'dispatch');
    wsService.initAndConnect(UserType.INTERNAL);
    expect(store.dispatch).toHaveBeenCalledWith(new trActions.LoadAction());
  });

  xit('should check the state in closed status', () => {
    stompService.subscribe.and.returnValue(Observable.of({
      ...wsMessage,
      headers: {
        ...wsMessage.headers,
        destination: '/mbsp/topic/tbapricing'
      }
    }));

    stompService.state = Observable.of(0);

    spyOn(store, 'dispatch');
    wsService.initAndConnect(UserType.INTERNAL);
    expect(store.dispatch).toHaveBeenCalledWith(new prActions.LoadConfigAction());
  });
});
