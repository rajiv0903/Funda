/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';

import { Profile } from '../../store/models/profile.model';
import * as fromRoot from '../../store';
import { Role } from '../enums/role.enum';
import { RoleType } from '../enums/role-type.enum';
import { UserType } from '../enums/user-type.enum';
import { UserConfig } from '../../store/models/user-config';

@Injectable()
export class UserProfileService {

  private profile: Profile;
  private _userType: UserType;
  private _roleType: RoleType;
  private _canExecute: boolean;
  private roles: Role[];
  private externalUserTypes = [
    RoleType.LENDER,
    RoleType.TSP
  ];
  private internalUserTypes = [
    RoleType.TRADER,
    RoleType.ADMIN
  ];
  private traderRoles = [
    Role.TRADER_READ_ONLY_PROD,
    Role.TRADER_READ_ONLY_NON_PROD,
    Role.TRADER_EXECUTE_PROD,
    Role.TRADER_EXECUTE_NON_PROD
  ];
  private adminRoles = [
    Role.ADMIN_PROD,
    Role.ADMIN_NON_PROD
  ];
  private internalUserExecuteRoles = [
    Role.TRADER_EXECUTE_PROD,
    Role.TRADER_EXECUTE_NON_PROD,
    Role.ADMIN_PROD,
    Role.ADMIN_NON_PROD
  ];

  constructor(private store: Store<fromRoot.AppStore>) {
    this.store.select(fromRoot.getProfileData).subscribe(profile => {
      if (profile) {
        this.profile = profile;
        this.setRoles();
        this.setRoleType();
        this.setUserType();
        this.setCanExecute();
      }
    });
  }

  get id(): string {
    return this.profile.userName
  }

  get firstName(): string {
    return this.profile.firstName
  }

  get lastName(): string {
    return this.profile.lastName
  }

  get entityName(): string {
    return this.profile.dealerOrgName
  }

  get userType(): UserType {
    return this._userType;
  }

  get roleType(): RoleType {
    return this._roleType;
  }

  get isTsp(): boolean {
    return this.profile.tspUser;
  }

  get tspLenders(): any[] {
    return this.profile.tspLenders;
  }

  get canExecute(): boolean {
    return this._canExecute;
  }

  get userConfig(): UserConfig {
    return this.profile.userConfig;
  }

  private setRoles(): void {
    this.roles = this.profile.roles.map(role => role.name);
  }

  private setUserType(): void {
    let userType;

    if (this.internalUserTypes.includes(this.roleType)) {
      userType = UserType.INTERNAL;
    } else if (this.externalUserTypes.includes(this.roleType)) {
      userType = UserType.EXTERNAL;
    }
    this._userType = userType;
  }

  private setRoleType(): void {
    let roleType;

    if (this.hasRole(Role.LENDER)) {
      roleType = RoleType.LENDER;
    } else if (this.hasRole(Role.TSP)) {
      roleType = RoleType.TSP;
    } else if (this.hasAnyRole(this.traderRoles)) {
      roleType = RoleType.TRADER;
    } else if (this.hasAnyRole(this.adminRoles)) {
      roleType = RoleType.ADMIN;
    }
    this._roleType = roleType;
  }

  private setCanExecute(): void {
    let canExecute = true;
    if (this.userType === UserType.INTERNAL) {
      canExecute = this.hasAnyRole(this.internalUserExecuteRoles);
    }
    this._canExecute = canExecute;
  }

  public hasRole(role: Role): boolean {
    return this.roles.includes(role);
  }

  public hasAnyRole(roles: Role[]): boolean {
    for (let i = 0; i < roles.length; i++) {
      if (this.roles.includes(roles[i])) {
        return true;
      }
    }
    return false;
  }

}
