/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { Injectable } from '@angular/core';
import { LocalStorageService } from './local-storage.service';
import { interval } from 'rxjs/observable/interval';
import { logBatchSize, logKeyPrefix, logPostingInterval } from '../constants/logger.constant';
import { LoggerService } from './logger.service';
import { catchError } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import { LoggerResource } from '../resources/logger.resource';
import { LogMessage } from '../interfaces/log-message.interface';
import { ModalService } from './modal.service';

@Injectable()
export class ServerLoggerService {
  public stopPostingLogs = false;

  constructor(
    private loggerResource: LoggerResource,
    private localStorageService: LocalStorageService,
    private logger: LoggerService,
    private modalService: ModalService
  ) { }

  public startLogPosting() {
    this.logger.debug('started startLogPosting');
    const that = this;
    interval(logPostingInterval)
      .subscribe(() => {
        const logMap: Map<string, string> = this.localStorageService.getAllByLimit(logKeyPrefix, logBatchSize);
        if (logMap.size > 0 && !this.stopPostingLogs) {
          const storageKeys: string[] = [];
          const storageValues: string[] = [];
          logMap.forEach(function(value, key) {
            storageKeys.push(key);
            storageValues.push(value);
          });
          that.postToServer(storageValues)
            .pipe(
              catchError(this.handleError<any>('error logger'))
            )
            .subscribe(() => {
              that.localStorageService.clearByKeys(storageKeys);
            });
        }
      });
  }

  private postToServer(messages: string[]) {
    const logMessages: LogMessage[] = [];
    for (const entry of messages) {
      const logMessage: LogMessage = JSON.parse(entry);
      logMessages.push(logMessage);
    }
    return this.loggerResource.log(logMessages);
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      this.stopPostingLogs = true;
      this.modalService.show(error);
      return Observable.throw(error);
    };
  }
}
