/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { Injectable } from '@angular/core';

import * as moment from 'moment';

import {
  LENDER_ACCEPTED, LENDER_OPEN, PENDING_EXECUTION, TRADER_CONFIRMED,
  TRADER_PASSED, TRADER_PRICED, TRADER_REJECTED, TRADER_REPRICED,
  EXECUTED, LENDER_REJECTED, LENDER_TIMEOUT, TRADER_TIMEOUT, EXECUTION_IN_PROGRESS
} from '../../store/models/transaction-request.model';
import { AppStore } from '../../store';
import { Store } from '@ngrx/store';
import * as trActions from '../../store/actions/transaction-request.actions';
import { unitOfTime } from 'moment';
import { isActiveTransaction } from '../../store/reducers/transaction-request.reducer';

@Injectable()
export class TransactionRequestService {

  constructor(
    private store: Store<AppStore>
  ) { }

  isLenderOpen(stateType: string): boolean {
    return stateType === LENDER_OPEN;
  }

  isLenderAccepted(stateType: string): boolean {
    return stateType === LENDER_ACCEPTED;
  }

  isLenderCancelled(stateType: string): boolean {
    return stateType === LENDER_REJECTED;
  }

  isTraderPassed(stateType: string): boolean {
    return stateType === TRADER_PASSED;
  }

  isTraderPriced(stateType: string): boolean {
    return stateType === TRADER_PRICED;
  }

  isTraderRepriced(stateType: string): boolean {
    return stateType === TRADER_REPRICED;
  }

  isTraderRejected(stateType: string): boolean {
    return stateType === TRADER_REJECTED;
  }

  isTraderConfirmed(stateType: string): boolean {
    return stateType === TRADER_CONFIRMED;
  }

  isLenderTimeout(stateType: string): boolean {
    return stateType === LENDER_TIMEOUT;
  }

  isTraderTimeout(stateType: string): boolean {
    return stateType === TRADER_TIMEOUT;
  }

  private filterInactiveTrades(rows) {
    return (rows.filter(row => this.isInactive(row.stateType) === true));
  }

  public isActive(stateType: string): boolean {
    return isActiveTransaction(stateType);

  }

  public isInactive(stateType: string): boolean {
    return [
      TRADER_PASSED,
      LENDER_REJECTED,
      TRADER_REJECTED,
      TRADER_CONFIRMED,
      PENDING_EXECUTION,
      EXECUTION_IN_PROGRESS,
      EXECUTED,
      LENDER_TIMEOUT,
      TRADER_TIMEOUT
    ].includes(stateType);
  }

  public containsInactiveTrades(rows): boolean {
    return (this.filterInactiveTrades(rows).length !== 0);
  }

  public clearInactiveTrades(rows): void {
    const clearTrades = this.filterInactiveTrades(rows);
    clearTrades.forEach((row) => {
      this.store.dispatch(new trActions.DeleteSuccessAction(row));
    })
  }

  public isExecuted(stateType: string): boolean {
    return [
      TRADER_CONFIRMED,
      PENDING_EXECUTION,
      EXECUTION_IN_PROGRESS,
      EXECUTED
    ].includes(stateType);
  }

  public isLocked(userProfileId: string, transRequestTraderId: string): boolean {
    return transRequestTraderId && transRequestTraderId !== userProfileId;
  }

  public isReserved(userProfileId: string, transRequestTraderId: string): boolean {
    return transRequestTraderId === userProfileId;
  }

  public getAge(lastPublishTime: string, submissionDate: string, timeUnit: unitOfTime.Diff = 'seconds'): number {
    if (!lastPublishTime) {
      throw new Error('lastPublishTime is not set');
    }

    return moment(lastPublishTime).diff(moment(submissionDate), timeUnit);
  }

}
