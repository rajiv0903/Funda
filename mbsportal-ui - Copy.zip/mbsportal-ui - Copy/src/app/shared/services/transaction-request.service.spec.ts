import { TransactionRequestService } from './transaction-request.service';
import {
  EXECUTED, LENDER_ACCEPTED, LENDER_OPEN, LENDER_REJECTED,
  PENDING_EXECUTION, TRADER_CONFIRMED, TRADER_PASSED, TRADER_PRICED,
  TRADER_REJECTED, TRADER_REPRICED, TRADER_TIMEOUT, LENDER_TIMEOUT
} from '../../store/models/transaction-request.model';
import { TestBed } from '@angular/core/testing';
import { StoreModule } from '@ngrx/store';
import { LoggerService } from './logger.service';
import { UserProfileService } from './user-profile.service';
import { getProfileReducerMock } from '../../util/stubs/mock-profile-reducer';
import { LocalStorageService } from './local-storage.service';
import { DatePipe } from '@angular/common';
import { RoleType } from '../enums/role-type.enum';
import { deepCopy } from '../../../test';
import { getTransactionRequestReducerMock } from '../../util/stubs/mock-transaction-request-reducer';

describe('TransactionRequestService', () => {
  let service: TransactionRequestService;
  const mockTransactionRequests = deepCopy(require('../../../assets/data/transaction-requests.json'));

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot({
          profile: getProfileReducerMock(RoleType.TRADER),
          transactionRequests: getTransactionRequestReducerMock(mockTransactionRequests)
        })
      ],
      providers: [
        TransactionRequestService,
        LoggerService,
        UserProfileService,
        LocalStorageService,
        DatePipe
      ]
    });
    service = TestBed.get(TransactionRequestService);
  });

  it('should check isLenderOpen', () => {
    expect(service.isLenderOpen('')).toEqual(false);
    expect(service.isLenderOpen(null)).toEqual(false);
    expect(service.isLenderOpen(LENDER_OPEN)).toEqual(true);
    expect(service.isLenderOpen(LENDER_ACCEPTED)).toEqual(false);
  });

  it('should check isLenderAccepted', () => {
    expect(service.isLenderAccepted('')).toEqual(false);
    expect(service.isLenderAccepted(null)).toEqual(false);
    expect(service.isLenderAccepted(LENDER_ACCEPTED)).toEqual(true);
    expect(service.isLenderAccepted(LENDER_OPEN)).toEqual(false);
  });

  it('should check isTraderPassed', () => {
    expect(service.isTraderPassed('')).toEqual(false);
    expect(service.isTraderPassed(null)).toEqual(false);
    expect(service.isTraderPassed(TRADER_PASSED)).toEqual(true);
    expect(service.isTraderPassed(LENDER_OPEN)).toEqual(false);
  });

  it('should check isTraderRepriced', () => {
    expect(service.isTraderRepriced('')).toEqual(false);
    expect(service.isTraderRepriced(null)).toEqual(false);
    expect(service.isTraderRepriced(TRADER_REPRICED)).toEqual(true);
    expect(service.isTraderRepriced(LENDER_ACCEPTED)).toEqual(false);
  });

  it('should check isTraderRejected', () => {
    expect(service.isTraderRejected('')).toEqual(false);
    expect(service.isTraderRejected(null)).toEqual(false);
    expect(service.isTraderRejected(TRADER_REJECTED)).toEqual(true);
    expect(service.isTraderRejected(TRADER_REPRICED)).toEqual(false);
  });

  it('should check containsInactiveTrades method', () => {
    expect(service.containsInactiveTrades(mockTransactionRequests)).toEqual(false);
    mockTransactionRequests[0].stateType = 'LENDER_REJECTED';
    mockTransactionRequests[1].stateType = 'TRADER_TIMEOUT';
    expect(service.containsInactiveTrades(mockTransactionRequests)).toEqual(true);
    mockTransactionRequests[1].stateType = 'LENDER_OPEN';
  });

  // it('should check clearInactiveTrades method', () => {
  //   spyOn(store, 'dispatch');
  //   service.clearInactiveTrades(mockTransactionRequests);
  //   expect(store.dispatch).toHaveBeenCalledWith(new trActions.DeleteSuccessAction(mockTransactionRequests[0]));
  // });

  it('should check isActive', () => {
    expect(service.isActive('')).toEqual(false);
    expect(service.isActive(null)).toEqual(false);
    expect(service.isInactive('some unknown state')).toEqual(false);

    expect(service.isActive(LENDER_OPEN)).toEqual(true);
    expect(service.isActive(LENDER_ACCEPTED)).toEqual(true);
    expect(service.isActive(TRADER_PRICED)).toEqual(true);
    expect(service.isActive(TRADER_REPRICED)).toEqual(true);

    expect(service.isActive(TRADER_PASSED)).toEqual(false);
    expect(service.isActive(LENDER_REJECTED)).toEqual(false);
    expect(service.isActive(LENDER_REJECTED)).toEqual(false);
    expect(service.isActive(PENDING_EXECUTION)).toEqual(false);
    expect(service.isActive(TRADER_CONFIRMED)).toEqual(false);
    expect(service.isActive(EXECUTED)).toEqual(false);
    expect(service.isActive(LENDER_TIMEOUT)).toEqual(false);
    expect(service.isActive(TRADER_TIMEOUT)).toEqual(false);
  });

  it('should check isInactive', () => {
    expect(service.isInactive('')).toEqual(false);
    expect(service.isInactive(null)).toEqual(false);
    expect(service.isInactive('some unknown state')).toEqual(false);

    expect(service.isInactive(TRADER_PASSED)).toEqual(true);
    expect(service.isInactive(LENDER_REJECTED)).toEqual(true);
    expect(service.isInactive(TRADER_REJECTED)).toEqual(true);
    expect(service.isInactive(TRADER_CONFIRMED)).toEqual(true);
    expect(service.isInactive(PENDING_EXECUTION)).toEqual(true);
    expect(service.isInactive(EXECUTED)).toEqual(true);
    expect(service.isInactive(LENDER_TIMEOUT)).toEqual(true);
    expect(service.isInactive(TRADER_TIMEOUT)).toEqual(true);

    expect(service.isInactive(LENDER_OPEN)).toEqual(false);
    expect(service.isInactive(LENDER_ACCEPTED)).toEqual(false);
    expect(service.isInactive(TRADER_PRICED)).toEqual(false);
    expect(service.isInactive(TRADER_REPRICED)).toEqual(false);
  });

  it('should check isExecuted', () => {
    expect(service.isExecuted('')).toEqual(false);
    expect(service.isExecuted(null)).toEqual(false);
    expect(service.isExecuted('some unknown state')).toEqual(false);

    expect(service.isExecuted(TRADER_CONFIRMED)).toEqual(true);
    expect(service.isExecuted(PENDING_EXECUTION)).toEqual(true);
    expect(service.isExecuted(EXECUTED)).toEqual(true);

    expect(service.isExecuted(LENDER_OPEN)).toEqual(false);
    expect(service.isExecuted(LENDER_ACCEPTED)).toEqual(false);
    expect(service.isExecuted(TRADER_PRICED)).toEqual(false);
    expect(service.isExecuted(TRADER_REPRICED)).toEqual(false);
    expect(service.isExecuted(TRADER_PASSED)).toEqual(false);
    expect(service.isExecuted(LENDER_REJECTED)).toEqual(false);
    expect(service.isExecuted(TRADER_REJECTED)).toEqual(false);
    expect(service.isExecuted(LENDER_TIMEOUT)).toEqual(false);
    expect(service.isExecuted(TRADER_TIMEOUT)).toEqual(false);
  });

});
