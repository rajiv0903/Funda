/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/Rx'
import { exportFileNotFound } from '../constants/error.constant';
import { TradeResource } from '../../trades-history/trade.resource';

@Injectable()
export class TradeService {

  constructor(private tradeResource: TradeResource) { }

  public exportFile(action): void {
    if (action.payload === null) {
      throw new Error(exportFileNotFound);
    } else if (action.payload.status === 'ready') {
      window.open(action.payload.location, '_self');
    } else {
      this.tradeResource.getExportFileForNotReadyStatus(action.payload.statusUrl).subscribe(
        response => {
          window.open(response.location, '_self');
        }
      )
    }
  }
}
