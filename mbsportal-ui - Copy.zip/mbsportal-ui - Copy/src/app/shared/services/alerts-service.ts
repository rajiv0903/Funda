import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppStore } from '../../store';
import * as actions from '../../store/actions/app.actions';

@Injectable()
export class AlertsService {

  constructor(private store: Store<AppStore>) {}

  private prepare(error): any {
    return {
      type: 'error',
      summary: 'Error',
      message: error.message || error.error || 'Unknown Error'
    };
  }

  public show(msg): void {
    this.store.dispatch(new actions.FailureAction(this.prepare(msg)));
  }
}
