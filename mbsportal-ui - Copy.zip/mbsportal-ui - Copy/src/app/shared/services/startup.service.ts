/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { Store } from '@ngrx/store';
import { Injectable } from '@angular/core';

import { AppStore } from '../../store';
import * as actions from '../../store/actions/app.actions';
import { environment } from '../../../environments/environment';
import { LoggerService } from './logger.service';
import { WSService } from './ws.service';
import { UserType } from '../enums/user-type.enum';
import { UserProfileService } from './user-profile.service';
import { StompRService } from '@stomp/ng2-stompjs';

export function startupFactory(startupService: StartupService): Function {
  return () => startupService.init();
}

@Injectable()
export class StartupService {
  constructor(
    private store: Store<AppStore>,
    private wsService: WSService,
    private profileService: UserProfileService,
    private stompService: StompRService,
    private logger: LoggerService
  ) { }

  public setTraderCName() {
    const cNameUrl = this.profileService.userConfig.directApiUrl;
    if (cNameUrl === null) {
      this.logger.warn('Not able to change CName : ' + cNameUrl + ' for host: ' + window.location.host);
    } else {
      this.logger.info('LOG INFO: changing to CName : ' + cNameUrl + ' for host: ' + window.location.host);
      environment.apiBasePath = cNameUrl;
    }
  }

  private load() {
    this.store.dispatch(new actions.InitializeAction());
  }

  public reload() {
    console.log('Application re-initialized: ');
    this.stompService.disconnect();
    this.setProfileConfigs();
    console.log('got ws slave url: ' + environment.websocketUrl);
    this.stompService.initAndConnect();
  }

  public setProfileConfigs() {
    const wsUrl = this.profileService.userConfig.webSocketUrl;
    if (wsUrl) {
      this.logger.info('LOG INFO: using websocket url : ' + wsUrl);
      environment.websocketUrl = wsUrl;
    } else {
      throw new Error('Not able to get websocket url for host');
    }
  }

  public init() {
    this.load();
  }

  public initAndConnectWS(userType: UserType) {
    this.wsService.initAndConnect(userType);
  }
}
