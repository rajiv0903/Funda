import { TestBed } from '@angular/core/testing';
import { MiscService } from './misc.service';

describe('MiscService', () => {
  let service: MiscService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [],
      providers: [ MiscService ]
    });

    service = TestBed.get(MiscService);

    beforeEach(() => {
    });
  });

  describe('should check the sortItems', () => {
    const ObjectListItems = [
      {'ID': 135, 'Name': 'Fargo Chan', 'Address': '34, Baker Street'},
      {'ID': 432, 'Name': 'Aaron Luke', 'Address': 'BLDG 1, J Street'},
      {'ID': 252, 'Name': 'Dilip Singh', 'Address': 'Hotel J, SE'}
    ];

    const primitiveListItems = ['Angular', 'Code', '123', 'Development'];

    it('for specific fieldName', () => {
      expect(service.sortItems(ObjectListItems, 'Address')).toEqual([
        {'ID': 135, 'Name': 'Fargo Chan', 'Address': '34, Baker Street'},
        {'ID': 432, 'Name': 'Aaron Luke', 'Address': 'BLDG 1, J Street'},
        {'ID': 252, 'Name': 'Dilip Singh', 'Address': 'Hotel J, SE'}
      ]);
    });

    it('for specific fieldName and desc', () => {
      expect(service.sortItems(ObjectListItems, 'Name', 'desc')).toEqual([
        {'ID': 135, 'Name': 'Fargo Chan', 'Address': '34, Baker Street'},
        {'ID': 252, 'Name': 'Dilip Singh', 'Address': 'Hotel J, SE'},
        {'ID': 432, 'Name': 'Aaron Luke', 'Address': 'BLDG 1, J Street'}
      ]);
    });

    it('for no fieldName and sortBy', () => {
      expect(service.sortItems(ObjectListItems)).toEqual([
        {'ID': 135, 'Name': 'Fargo Chan', 'Address': '34, Baker Street'},
        {'ID': 252, 'Name': 'Dilip Singh', 'Address': 'Hotel J, SE'},
        {'ID': 432, 'Name': 'Aaron Luke', 'Address': 'BLDG 1, J Street'}
      ]);
    });

    it('for primitiveListElements', () => {
      expect(service.sortItems(primitiveListItems)).toEqual(['123', 'Angular', 'Code', 'Development']);
    });

    it('for primitiveListElements and desc', () => {
      expect(service.sortItems(primitiveListItems, '', 'desc')).toEqual(['Development', 'Code', 'Angular', '123']);
    });

    it('for empty list', () => {
      const emptyList = [];
      expect(service.sortItems(emptyList, '', 'desc')).toEqual([]);
    });
  });

});
