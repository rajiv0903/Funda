import { LocalStorageService  } from './local-storage.service';

describe('LocalStorageService ', () => {
  let service: LocalStorageService ;

  beforeEach(() => {
    service = new LocalStorageService ();
  });

  it('\'set\' should be setting a value in the local storage ', () => {
    service.set('key', 'value');
    expect(localStorage.getItem('key')).toEqual('value');
  });

  it('\'get\' should be getting a value in the local storage ', () => {
    expect(service.get('key')).toEqual('value');
  });

  it('\'clearAll\' should be removing all values from the local storage ', () => {
    service.set('key1', 'value1');
    expect(service.get('key')).toEqual('value');
    expect(service.get('key1')).toEqual('value1');

    service.clearAll();

    expect(service.get('key')).toEqual(null);
    expect(service.get('key1')).toEqual(null);
  });

});
