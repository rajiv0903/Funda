/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { LocalStorageService } from './local-storage.service';
import { LoggerService } from './logger.service';
import { DatePipe } from '@angular/common';
import { UserProfileService } from './user-profile.service';
import { TestBed } from '@angular/core/testing';
import { StoreModule } from '@ngrx/store';
import { getProfileReducerMock } from '../../util/stubs/mock-profile-reducer';
import { RoleType } from '../enums/role-type.enum';

class MockLocalStorageService extends LocalStorageService {
  getSize() {
    return 5;
  }
}

describe('LoggerService ', () => {
  let localStorageService: LocalStorageService;
  let loggerService: LoggerService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot({
          profile: getProfileReducerMock(RoleType.LENDER)
        })
      ],
      providers: [
        LoggerService,
        UserProfileService,
        {
        provide: LocalStorageService,
          useClass: MockLocalStorageService
        },
        DatePipe
      ]
    });
    localStorageService = TestBed.get(LocalStorageService);
    loggerService = TestBed.get(LoggerService);
  });

  it('Service injected via component should be and instance of MockLocalStorageService', () => {
    expect(localStorageService instanceof MockLocalStorageService).toBeTruthy();
  });

  /*  it('\'set\' should be setting a value in the local storage ', () => {
   loggerService.isLogEnabled('key', 'value');
   //expect(localStorage.getItem('key')).toEqual('value');
   });*/

});
