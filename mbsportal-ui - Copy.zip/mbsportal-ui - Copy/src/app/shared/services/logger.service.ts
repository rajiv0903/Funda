/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */
import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common';

import { UserProfileService } from './user-profile.service';
import { LogLevel, logLevel, logMaxStore } from '../constants/logger.constant';
import { LocalStorageService } from './local-storage.service';
import { LogMessage } from '../interfaces/log-message.interface';

@Injectable()
export class LoggerService {

  constructor(
    private profileService: UserProfileService,
    private localStorageService: LocalStorageService,
    private datePipe: DatePipe
  ) { }

  public debug(message: string) {
    this.writeTolog(message, LogLevel.DEBUG);
  }

  public info(message: string) {
    this.writeTolog(message, LogLevel.INFO);
  }

  public warn(message: string) {
    this.writeTolog(message, LogLevel.WARN);
  }

  public error(message: string, errorCode?: number) {
    this.writeTolog(message, LogLevel.ERROR, errorCode);
  }

  private writeTolog(message: string, level: LogLevel, errorCode?: number) {
    if (this.localStorageService.getSize() >= logMaxStore) {
      return;
    }
    if (this.isLogEnabled(level)) {
      const logMessage = this.createLogMessage(level, message, errorCode);
      // this.logToConsole(level, logMessage);
      this.logToLocal(level, logMessage);
    }
  }

  private isLogEnabled(level: LogLevel): boolean {
    let isEnabled = false;
    if (logLevel !== LogLevel.OFF && level >= logLevel) {
      isEnabled = true;
    }
    return isEnabled;
  }

  private prepareMessage(logMessage: LogMessage): LogMessage {
    logMessage.channel = logMessage.channel || 'WEB';
    logMessage.code = logMessage.code || 0;
    try {
      logMessage.userName = this.profileService.id;
    } catch (e) {
      logMessage.userName = null;
    }
    return logMessage;
  }

  private createLogMessage(level: LogLevel, message: string, errorCode?: number, module?: string,
                           functionality?: string, objId?: string): LogMessage {
    const logMessage = {
      functionality: functionality,
      message: message,
      messageDescription: '',
      timeStamp: this.datePipe.transform(new Date(), 'MMMM d, y, h:mm:ss a z'),
      module: module,
      type: LogLevel[level],
      code: errorCode
    };
    return this.prepareMessage(logMessage);
  }

  public log(logMessage: LogMessage, level: LogLevel = LogLevel.DEBUG) {
    if (this.localStorageService.getSize() >= logMaxStore) {
      return;
    }
    if (this.isLogEnabled(level)) {
      logMessage = this.prepareMessage(logMessage);
      // this.logToConsole(level, logMessage);
      this.logToLocal(level, logMessage);
    }
  }

  private logToConsole(level: LogLevel, logMessage: LogMessage) {
    switch (level) {
      case LogLevel.ERROR:
        console.error(LogLevel[level] + ':' + JSON.stringify(logMessage));
        break;
      case LogLevel.WARN:
        console.warn(LogLevel[level] + ':' + JSON.stringify(logMessage));
        break;
      case LogLevel.INFO:
        console.info(LogLevel[level] + ':' + JSON.stringify(logMessage));
        break;
      case LogLevel.DEBUG:
        console.debug(LogLevel[level] + ':' + JSON.stringify(logMessage));
        break;
      default:
        console.log(LogLevel[level] + ':' + JSON.stringify(logMessage));
        break;
    }
  }

  private logToLocal(level: LogLevel, logMessage: LogMessage) {
    this.localStorageService.set('MBSP_LOG_KEY_' + Date.now(), JSON.stringify(logMessage));
  }
}
