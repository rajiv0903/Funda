/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { StompConfig, StompRService, StompState } from '@stomp/ng2-stompjs';
import { Injectable } from '@angular/core';
import { LoggerService } from './logger.service';
import { stompConfig } from '../../core/stomp-config';
import { Message } from '@stomp/stompjs';
import {
  lenderTransactionsWSTopic, lenderWSReconnectDelay, traderPricingWSTopic, traderTransactionsWSTopic, wsTopics
} from '../constants/system.constant';
import { LocalStorageService } from './local-storage.service';
import { UserType } from '../enums/user-type.enum';
import * as trActions from '../../store/actions/transaction-request.actions';
import * as profileActions from '../../store/actions/profile.actions';
import { AppStore } from '../../store/index';
import { Store } from '@ngrx/store';
import { environment } from '../../../environments/environment';
import { UserProfileService } from './user-profile.service';
import { TransactionRequest } from '../../store/models/transaction-request.model';

@Injectable()
export class WSService {

  private headers;

  constructor(
    private store: Store<AppStore>,
    private stompService: StompRService,
    private logger: LoggerService,
    private localStorageService: LocalStorageService,
    private userProfile: UserProfileService
  ) { }

  private subscribe(userType: UserType) {
    wsTopics[userType].forEach((topic) => {
      topic = this.getPersonalizedTopic(topic);

      this.logger.info('Connecting to topic: ' + topic);

      this.stompService.subscribe(topic, this.headers).subscribe((msg: Message) => {
          const msgObject = this.prepMessage(msg);
          switch (this.getGeneralizedTopic(msg.headers.destination)) {
            case traderTransactionsWSTopic:
            case lenderTransactionsWSTopic:
              this.store.dispatch(new trActions.UpdateWSAction(<TransactionRequest>msgObject));
              this.logger.info('Message for topic ' + msg.headers.destination + ': ' + msg.body);
              break;
            case traderPricingWSTopic:
              this.store.dispatch(new trActions.UpdatePriceAction(msgObject));
              break;
          }
        },
        error => {
          this.logger.warn('Subscription failed for topic ' + topic + ' and user '
            + this.userProfile.id + ' with error ' + JSON.stringify(error));
        });
    })
  }

  private getPersonalizedTopic(topic: string): string {
    return topic.replace('{userId}', this.userProfile.id);
  }

  private getGeneralizedTopic(topic: string): string {
    return topic.replace(this.userProfile.id, '{userId}');
  }

  private prepMessage(message: Message): any {
    return JSON.parse(message.body);
  }

  private getConfig(): StompConfig {
    this.headers = stompConfig.headers;
    if (environment.name === 'local') {
      this.headers = {
        ...this.headers,
        'userName': sessionStorage.getItem('userName')
      };
    } else if (this.localStorageService.get('sessionId')) {
      this.headers = {
        ...this.headers,
        'x-fnma-sessionid': this.localStorageService.get('sessionId')
      };
    } else {
      this.logger.error('Missing session/user info');
    }

    let reconnectDelay = stompConfig.reconnect_delay;
    if (this.userProfile.userType === UserType.EXTERNAL) {
      reconnectDelay = lenderWSReconnectDelay;
    }

    return {
      ...stompConfig,
      reconnect_delay: reconnectDelay,
      headers: this.headers
    };
  }

  public initAndConnect(userType: UserType) {
    this.stompService.config = this.getConfig();

    this.stompService.initAndConnect();
    this.subscribe(userType);

    this.stompService.state
      .distinctUntilChanged()
      .filter((state) => {
        return ['CONNECTED', 'CLOSED'].includes(StompState[state])
      })
      .map((state: number) => StompState[state])
      .subscribe((status: string) => {
        if (status === 'CONNECTED') {
          this.logger.info('Connected to WS');
          this.store.dispatch(new trActions.LoadAction());
        } else {
          this.logger.warn('WS is down, starting polling');
          this.store.dispatch(new trActions.LoadAction());
        }
      });
  }
}
