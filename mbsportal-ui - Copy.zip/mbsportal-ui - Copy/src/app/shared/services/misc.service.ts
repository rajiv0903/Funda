/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { Injectable } from '@angular/core';
import isObject from 'lodash-es/isObject';

@Injectable()
export class MiscService {

  constructor() {}

  public sortItems(list: any, fieldName?: string, sortBy = 'asc') {
    const order = (sortBy === 'desc') ? 1 : -1;
    const isObj = isObject(list[0]);
    return list.sort(function(a, b) {
      const textA = isObj ? (fieldName ? a[fieldName] : a[Object.keys(a)[0]]) : a;
      const textB = isObj ? (fieldName ? b[fieldName] : b[Object.keys(b)[0]]) : b;
      return (textA < textB) ? order : (textA > textB) ? -order : 0;
    })
  }
}
