/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */
import { Injectable } from '@angular/core';
import { logKeyPrefix } from '../constants/logger.constant';

@Injectable()
export class LocalStorageService {

  get(key: string): string {
    return localStorage.getItem(key);
  }

  public getSize(): number {
    return localStorage.length;
  }

  public getAll(key: string): Map<string, string> {
    const mapObjs: Map<string, string> = new Map<string, string>();
    const keys = Object.keys(localStorage);
    for (const entry of keys) {
      if (entry.startsWith(key)) {
        mapObjs.set(entry, this.get(entry));
      }
    }
    return mapObjs;
  }

  public getAllByLimit(key: string, limit: number): Map<string, string> {
    const mapObjs: Map<string, string> = new Map<string, string>();
    const keys = Object.keys(localStorage);
    let i = 0;
    for (const entry of keys) {
      if (i >= limit) {
        return mapObjs;
      }
      if (entry.startsWith(key)) {
        mapObjs.set(entry, this.get(entry));
        i++;
      }
    }
    return mapObjs;
  }

  public getAllObjects(): string[] {
    const messages = [];
    const keys = Object.keys(localStorage);
    for (const entry of keys) {
      messages.push(this.get(entry));
    }
    return messages;
  }

  set(key: string, item: string): void {
    localStorage.setItem(key, item);
  }

  remove(key: string): void {
    localStorage.removeItem(key);
  }

  public clearAll(): void {
    localStorage.clear();
  }

  public clearByKeys(logKeys: string[]): void {
    for (const entry of logKeys) {
      this.clearByKey(entry);
    }
  }

  public clearByKey(logKey: string): void {
    if (logKey && logKey.startsWith(logKeyPrefix)) {
      localStorage.removeItem(logKey);
    } else {
      console.log('NOT removing key:' + logKey);
    }
  }
}
