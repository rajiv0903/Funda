import { Injectable } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';

import { ModalComponent } from '../components/modal/modal.component';
import { ModalOptions } from 'ngx-bootstrap';

@Injectable()
export class ModalService {

  constructor(private bsModalService: BsModalService) { }

  private getType(): string {
    return 'warning';
  }

  private getOptions(): ModalOptions {
    return {
      class: this.getType(),
      keyboard: false,
      ignoreBackdropClick: true
    };
  }

  public show(error: any): BsModalRef {
    if (!this.doNotDisplay(error)) {
      return this.bsModalService.show(ModalComponent, {
        ...this.getOptions(),
        initialState: {
          status: error.status,
          type: this.getType()
        }
      });
    }
  }

  private doNotDisplay(error: any): boolean {
    const messages: any[] = error.messages || [];
    let noDisplayFlag = false;

    for (let i = 0; i < messages.length; i++) {
      if (messages[i].messageType === 'NONDSP_ERROR') {
        noDisplayFlag = true;
        break;
      }
    }
    return noDisplayFlag || this.bsModalService.getModalsCount() > 0;
  }
}
