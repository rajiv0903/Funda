import { AllowedCharactersDirective } from './allowed-characters.directive';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Component } from '@angular/core';

@Component({
  template: `<input class="handleText" type="text" ngModel [mbspAllowedCharacters] = numberChar>
  <input class="ticksText" type="text" ngModel [mbspAllowedCharacters] = numberAndPlusChar>`
})
class TestAllowedCharactersComponent {
  numberChar: RegExp = /^([0-9]{1,3})$/;
  numberAndPlusChar: RegExp = /^([0-9|+]{1,3})$/;
}

describe('Directive: AllowedCharacters', () => {

  let component: TestAllowedCharactersComponent;
  let fixture: ComponentFixture<TestAllowedCharactersComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        TestAllowedCharactersComponent,
        AllowedCharactersDirective
      ]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TestAllowedCharactersComponent);
    component = fixture.componentInstance;
  });

  it('check isMatchingRegExp()', () => {
    const directive = new AllowedCharactersDirective();
    directive.pattern = /^([0-9]{1,3})$/;
    expect(directive.isMatchingRegExp('1')).toEqual(true);
    expect(directive.isMatchingRegExp('12')).toEqual(true);
    expect(directive.isMatchingRegExp('123')).toEqual(true);
    expect(directive.isMatchingRegExp('1234')).toEqual(false);
    expect(directive.isMatchingRegExp('i')).toEqual(false);
    expect(directive.isMatchingRegExp('do')).toEqual(false);
    expect(directive.isMatchingRegExp('not')).toEqual(false);
    expect(directive.isMatchingRegExp('love')).toEqual(false);
    expect(directive.isMatchingRegExp('12+')).toEqual(false);
    expect(directive.isMatchingRegExp('12*')).toEqual(false);
    expect(directive.isMatchingRegExp('!@#')).toEqual(false);

    directive.pattern = /^([0-9|+]{1,3})$/;
    expect(directive.isMatchingRegExp('+')).toEqual(true);
    expect(directive.isMatchingRegExp('+1')).toEqual(true);
    expect(directive.isMatchingRegExp('11+')).toEqual(true);
  });

  it('check onChange() for handleText', () => {
    const directive = new AllowedCharactersDirective();
    directive.pattern = /^([0-9]{1,3})$/;
    fixture.detectChanges();
    const handleElement: HTMLElement = fixture.nativeElement.querySelector('.handleText');

    let newValue = new KeyboardEvent('keypress', {
      'key': '123',
    });
    spyOn(newValue, 'preventDefault');
    handleElement.dispatchEvent(newValue);
    expect(newValue.preventDefault).not.toHaveBeenCalled();

    newValue = new KeyboardEvent('keypress', {
      'key': '1234',
    });
    spyOn(newValue, 'preventDefault');
    handleElement.dispatchEvent(newValue);
    expect(newValue.preventDefault).toHaveBeenCalled();

    newValue = new KeyboardEvent('keypress', {
      'key': '12+',
    });
    spyOn(newValue, 'preventDefault');
    handleElement.dispatchEvent(newValue);
    expect(newValue.preventDefault).toHaveBeenCalled();
  });

  it('check onChange() for ticksText', () => {
    const directive = new AllowedCharactersDirective();
    directive.pattern = /^([0-9|+]{1,3})$/;
    fixture.detectChanges();
    const handleElement: HTMLElement = fixture.nativeElement.querySelector('.ticksText');

    let newValue = new KeyboardEvent('keypress', {
      'key': '14+',
    });
    spyOn(newValue, 'preventDefault');
    handleElement.dispatchEvent(newValue);
    expect(newValue.preventDefault).not.toHaveBeenCalled();

    newValue = new KeyboardEvent('keypress', {
      'key': '+5&',
    });
    spyOn(newValue, 'preventDefault');
    handleElement.dispatchEvent(newValue);
    expect(newValue.preventDefault).toHaveBeenCalled();

    newValue = new KeyboardEvent('keypress', {
      'key': '+5+',
    });
    spyOn(newValue, 'preventDefault');
    handleElement.dispatchEvent(newValue);
    expect(newValue.preventDefault).not.toHaveBeenCalled();
  });
});
