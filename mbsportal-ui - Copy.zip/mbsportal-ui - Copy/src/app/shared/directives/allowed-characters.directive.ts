import { Directive, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[mbspAllowedCharacters]'
})
export class AllowedCharactersDirective {

  @Input() set mbspAllowedCharacters(value) {
    if (value) {
      this.pattern = value;
    }
  }

  public pattern: RegExp;

  constructor() {}

  @HostListener('keypress', ['$event'])
  onChange(newValue) {
    const target = newValue.target;
    const newKey = newValue.key;
    const currentInputValue = target.value;
    let changedInputValue;
    if ((target.selectionEnd - target.selectionStart) > 0) {
      changedInputValue = currentInputValue.substring(0, target.selectionStart)
        + newKey + currentInputValue.substring(target.selectionEnd + 1, target.length);
    } else {
      changedInputValue = (currentInputValue).concat(newKey);
    }
    if (!this.isMatchingRegExp(changedInputValue)) {
      newValue.preventDefault();
    }
    return;
  }

  isMatchingRegExp(val): boolean {
    if (val && this.pattern) {
      return this.pattern.test(val);
    }
  }

}
