import { Component, Input, Output, EventEmitter, ElementRef, ViewChild, ChangeDetectorRef } from '@angular/core';

import isEqual from 'lodash-es/isEqual';

@Component({
  selector: 'mbsp-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss']
})
export class DropdownComponent {

  @Input() selectedIndex: any = '';
  @Input() options: any[];
  @Input() labelPropName = 'text';
  @Input() valuePropName: any = 'value';
  @Input() defaultOption = 'Select';
  @Input() disabled: boolean;

  @ViewChild('ul') ul: ElementRef;

  @Output() changed = new EventEmitter<number>();

  public isOpen: boolean = false;

  constructor(private ref: ChangeDetectorRef) {}

  get selectedOptionLabel() {
    let selectedOptionLabel = this.defaultOption;
    if (this.selectedIndex !== '') {
      const index = this.options.findIndex(option => option[this.valuePropName] === this.selectedIndex);
      selectedOptionLabel = this.options[index][this.labelPropName];
    }
    return selectedOptionLabel;
  }

  private clickListener = (e: Event) => {
    if (this.isOpen && this.ul.nativeElement.contains(e.target)) {
      return false;
    }
    this.hideOptions();
  };

  private initializeEventHandlers(): void {
    document.addEventListener('click', this.clickListener);
  }

  private releaseEventHandlers(): void {
    document.removeEventListener('click', this.clickListener);
  }

  private hideOptions(): void {
    this.isOpen = false;
    this.ref.markForCheck(); // need to run change detection here due to options not being closed automatically
    this.releaseEventHandlers();
  }

  public selectIndex(index): void {
    if (!isEqual(index, this.selectedIndex)) {
      this.selectedIndex = index;
      this.changed.emit(index);
    }
    this.hideOptions();
  }

  public showOptions(e): void {
    if (!this.isOpen && !this.disabled) {
      e.stopPropagation();
      this.isOpen = true;
      this.initializeEventHandlers();
    }
  }

  public isCurrentlySelected(current, selectedIndex): boolean {
    return isEqual(current, selectedIndex);
  }

}

