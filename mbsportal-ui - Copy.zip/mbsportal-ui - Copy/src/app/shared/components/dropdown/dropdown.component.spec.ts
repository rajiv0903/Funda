import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DropdownComponent } from './dropdown.component';
import { deepCopy } from '../../../../test';

describe('DropDown Component', () => {
  let component: DropdownComponent;
  let fixture: ComponentFixture<DropdownComponent>;
  let event;
  const mockProducts = deepCopy(require('../../../../assets/data/products.json'));
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DropdownComponent ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DropdownComponent);
    component = fixture.componentInstance;
    component.options = mockProducts;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('selectedIndex test - default', () => {
    const index = '';
    spyOn(component.changed, 'emit');
    component.selectIndex(index);
    fixture.detectChanges();
    expect(component.selectedIndex).toBe(index);
    expect(component.selectedOptionLabel).toBe('Select');
    expect(component.changed.emit).not.toHaveBeenCalled();
  });

  it('selectedIndex test - index 0', () => {
    const index = mockProducts[5].productId;
    spyOn(component.changed, 'emit');
    component.selectIndex(index);
    component.valuePropName = 'productId';
    component.labelPropName = 'nameCode';
    fixture.detectChanges();
    expect(component.selectedIndex).toBe(index);
    expect(component.selectedOptionLabel).toBe('FN30');
    expect(component.changed.emit).toHaveBeenCalled();
  });

  it('selectedIndex test - index 3', () => {
    const index = mockProducts[4].productId;
    spyOn(component.changed, 'emit');
    component.selectIndex(index);
    component.valuePropName = 'productId';
    component.labelPropName = 'nameCode';
    fixture.detectChanges();
    expect(component.selectedIndex).toBe(index);
    expect(component.selectedOptionLabel).toBe('PC15');
    expect(component.changed.emit).toHaveBeenCalled();
  });
  it('showOptions test', () => {
    component.isOpen = false;
    event = {
      stopPropagation: function () {}
    };
    spyOn(event, 'stopPropagation');
    component.showOptions(event);
    fixture.detectChanges();
    expect(event.stopPropagation).toHaveBeenCalled();
    expect(component.isOpen).toBe(true);
  });
  it('showOptions Else test', () => {
    component.isOpen = true;
    event = {
      stopPropagation: function () {}
    };
    spyOn(event, 'stopPropagation');
    component.showOptions(event);
    fixture.detectChanges();
    expect(event.stopPropagation).not.toHaveBeenCalled();
    expect(component.isOpen).toBe(true);
  });

});


