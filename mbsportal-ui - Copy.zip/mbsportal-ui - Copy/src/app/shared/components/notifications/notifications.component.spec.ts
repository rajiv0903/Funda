import { async, ComponentFixture, discardPeriodicTasks, fakeAsync, TestBed, tick } from '@angular/core/testing';

import { NotificationsComponent } from './notifications.component';
import { UserProfileService } from '../../services/user-profile.service';
import { LoggerService } from '../../services/logger.service';
import { LENDER_ACCEPTED, LENDER_OPEN, TRADER_PRICED } from '../../../store/models/transaction-request.model';
import { deepCopy } from '../../../../test';
import { StoreModule } from '@ngrx/store';
import { getProfileReducerMock } from '../../../util/stubs/mock-profile-reducer';
import { RoleType } from '../../enums/role-type.enum';
import { transactionRequestReducer } from '../../../store/reducers/transaction-request.reducer';
import { TransactionRequestService } from '../../services/transaction-request.service';

class LoggerServiceStub {
  public error(log: string) {}
  public debug(log: string) {}
}

describe('NotificationsComponent', () => {
  let component: NotificationsComponent;
  let fixture: ComponentFixture<NotificationsComponent>;

  const mockProfileData = deepCopy(require('../../../../assets/data/trader-profile.json'));
  const mockTransactionRequests = deepCopy(require('../../../../assets/data/transaction-requests.json'));

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotificationsComponent ],
      imports: [
        StoreModule.forRoot({
          profile: getProfileReducerMock(RoleType.TRADER, mockProfileData),
          transactionRequests: transactionRequestReducer
        })
      ],
      providers: [
        UserProfileService,
        TransactionRequestService,
        {
          provide: LoggerService,
          useClass: LoggerServiceStub
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotificationsComponent);
    component = fixture.componentInstance;
    component.rows = [...mockTransactionRequests];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load audio for traders', () => {
    expect(component.audioLenderOpen).toBeDefined();
    expect(component.audioLenderAccepted).toBeDefined();
  });

  describe('setting lender role', () => {
    let profileRole: string;
    beforeAll(() => {
      profileRole = mockProfileData.roles[0].name;
      mockProfileData.roles[0].name = 'MBS Trade - Execute';
    });
    it('should not load audio for lenders', () => {
      expect(component.audioLenderOpen).not.toBeDefined();
      expect(component.audioLenderAccepted).not.toBeDefined();
    });
    afterAll(() => {
      mockProfileData.roles[0].name = profileRole;
    });
  });

  describe('setting tsp role', () => {
    let profileRole: string;
    beforeAll(() => {
      profileRole = mockProfileData.roles[0].name;
      mockProfileData.roles[0].name = 'MBS Trade_TSP - Execute';
    });
    it('should not load audio for tsp', () => {
      expect(component.audioLenderOpen).not.toBeDefined();
      expect(component.audioLenderAccepted).not.toBeDefined();
    });

    afterAll(() => {
      mockProfileData.roles[0].name = profileRole;
    });
  });

  describe('setting read only trader role', () => {
    let profileRole: string;
    beforeAll(() => {
      profileRole = mockProfileData.roles[0].name;
      mockProfileData.roles[0].name = 'SG-MBSP-NonProd-FM-TRADER-READ-ONLY';
    });
    it('should not load audio for read-only traders', () => {
      expect(component.audioLenderOpen).not.toBeDefined();
      expect(component.audioLenderAccepted).not.toBeDefined();
    });

    afterAll(() => {
      mockProfileData.roles[0].name = profileRole;
    });
  });

  it('should play for the audio alert on incoming trade', fakeAsync(() => {
    spyOn(component.audioLenderOpen, 'play');
    component.ngOnChanges();
    expect(component.audioLenderOpen.play).toHaveBeenCalledTimes(1);
    tick(11000);
    expect(component.audioLenderOpen.play).toHaveBeenCalledTimes(2);
    discardPeriodicTasks();
  }));

  it('should play for the audio alert on incoming trade for 2 trades', fakeAsync(() => {
    component.rows[1] = {
      ...mockTransactionRequests[1],
      activeVersion: 1,
      stateType: LENDER_OPEN
    };
    spyOn(component.audioLenderOpen, 'play');
    component.ngOnChanges();
    expect(component.audioLenderOpen.play).toHaveBeenCalledTimes(2);
    tick(11000);
    expect(component.audioLenderOpen.play).toHaveBeenCalledTimes(4);
    discardPeriodicTasks();
  }));

  it('should not play the audio alert of the changed trade with a delay of 10 sec', fakeAsync(() => {
    spyOn(component.audioLenderOpen, 'play');
    component.ngOnChanges();
    expect(component.audioLenderOpen.play).toHaveBeenCalledTimes(1);
    discardPeriodicTasks();

    component.rows[0] = {...mockTransactionRequests[0], activeVersion: 2};
    component.ngOnChanges();
    tick(11000);
    expect(component.audioLenderOpen.play).toHaveBeenCalledTimes(1);
    discardPeriodicTasks();
  }));

  it('should play for the audio alert on lender hit/lift', fakeAsync(() => {
    spyOn(component.audioLenderAccepted, 'play');
    component.ngOnChanges();
    expect(component.audioLenderAccepted.play).toHaveBeenCalledTimes(1);
    tick(11000);
    expect(component.audioLenderAccepted.play).toHaveBeenCalledTimes(2);
    discardPeriodicTasks();
  }));

  it('should play for the audio alert on lender hit/lift for 2 trades', fakeAsync(() => {
    component.rows[1] = {
      ...mockTransactionRequests[1],
      activeVersion: 3,
      stateType: LENDER_ACCEPTED
    };
    spyOn(component.audioLenderAccepted, 'play');
    component.ngOnChanges();
    expect(component.audioLenderAccepted.play).toHaveBeenCalledTimes(2);
    tick(11000);
    expect(component.audioLenderAccepted.play).toHaveBeenCalledTimes(4);
    discardPeriodicTasks();
  }));

  it('should not play the audio alert of the changed trade with a delay of 10 sec', fakeAsync(() => {
    spyOn(component.audioLenderAccepted, 'play');
    component.ngOnChanges();
    expect(component.audioLenderAccepted.play).toHaveBeenCalledTimes(1);
    discardPeriodicTasks();

    component.rows[2] = {...mockTransactionRequests[2], stateType: TRADER_PRICED};
    component.ngOnChanges();
    tick(11000);
    expect(component.audioLenderAccepted.play).toHaveBeenCalledTimes(1);
    discardPeriodicTasks();

  }));


});
