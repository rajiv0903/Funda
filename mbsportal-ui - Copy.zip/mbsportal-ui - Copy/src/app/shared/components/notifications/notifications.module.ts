import { NotificationsComponent } from './notifications.component';
import { NgModule } from '@angular/core';

import { FmCompositeComponentsModule } from '@fm-ui-adk/components/dist/fm-composite.module';

@NgModule({
  declarations: [NotificationsComponent],
  exports: [NotificationsComponent]
})
export class NotificationsModule { }
