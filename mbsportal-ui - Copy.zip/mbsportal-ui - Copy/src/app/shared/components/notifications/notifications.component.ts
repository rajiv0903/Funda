import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { TransactionRequest } from '../../../store/models/transaction-request.model';
import { incomingAlertInterval } from '../../constants/system.constant';
import { UserProfileService } from '../../services/user-profile.service';
import { UserType } from '../../enums/user-type.enum';
import { environment } from '../../../../environments/environment';
import { LoggerService } from '../../services/logger.service';
import { TransactionRequestService } from '../../services/transaction-request.service';

@Component({
  selector: 'mbsp-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss']
})
export class NotificationsComponent implements OnChanges, OnInit {

  @Input() rows: TransactionRequest[];

  private currentlyAlerting = {};
  public audioLenderOpen;
  public audioLenderAccepted;

  constructor(
    private profile: UserProfileService,
    private logger: LoggerService,
    private trService: TransactionRequestService
  ) {}

  ngOnInit() {
    if (this.profile.userType === UserType.INTERNAL && this.profile.canExecute) {
      this.audioLenderOpen = this.loadAudio(environment.apiBasePath + '/media/audio/LENDER_OPEN.mp3');
      this.audioLenderAccepted = this.loadAudio(environment.apiBasePath + '/media/audio/LENDER_ACCEPTED.m4a');
    }
  }

  ngOnChanges() {
    if (this.profile.userType === UserType.INTERNAL && this.profile.canExecute) {
      this.rows.forEach(row => this.playAlert(row));
    }
  }

  private loadAudio(pathToAudio: string): HTMLAudioElement {
    const audio = new Audio(pathToAudio);
    audio.addEventListener('loadeddata', () => this.logger.debug(`Audio file ${pathToAudio} loaded`));
    audio.addEventListener('error', () => this.logger.error(`Audio file ${pathToAudio} not loaded`));
    return audio;
  }

  public playAlert(row: TransactionRequest): void {
    if (row.activeVersion === 1 && this.trService.isLenderOpen(row.stateType) && !row.updateNeeded) {
      this.playAudio(row.transReqId, this.audioLenderOpen);
    } else if (this.trService.isLenderAccepted(row.stateType) && !row.updateNeeded) {
      this.playAudio(row.transReqId, this.audioLenderAccepted);
    } else {
      clearInterval(this.currentlyAlerting[row.transReqId]);
      delete this.currentlyAlerting[row.transReqId];
    }
  }

  private playAudio(id: string, audio: HTMLAudioElement): void {
    if (!this.currentlyAlerting.hasOwnProperty(id)) {
      audio.play();
      this.currentlyAlerting[id] = setInterval(() => {
        audio.play();
      }, incomingAlertInterval);
    }
  }

}
