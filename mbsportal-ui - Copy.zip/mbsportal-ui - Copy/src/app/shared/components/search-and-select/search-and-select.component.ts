import {
  AfterViewChecked, Component, ElementRef, EventEmitter, Input, OnChanges, Output,
  ViewChild
} from '@angular/core';
import { SelectComponent } from 'ng2-select/ng2-select';

@Component({
  selector: 'mbsp-search-and-select',
  templateUrl: './search-and-select.component.html',
  styleUrls: ['./search-and-select.component.scss']
})

export class SearchAndSelectComponent implements AfterViewChecked, OnChanges {

  @Input() items: Array<{'id': string, 'text': string}>;
  @Input() disabled: boolean;
  @Input() clearSelectedValue: boolean;
  @Input() selectedOption: {'id': string, 'text': string};

  @Output() changed = new EventEmitter<number>();

  @ViewChild('searchAndSelect')
  public mySelectList: SelectComponent;

  ngAfterViewChecked() {
    this.addChevron();
  }

  constructor(private hostElement: ElementRef) { }

  ngOnChanges() {
    if (this.clearSelectedValue) {
      this.clearValue();
    }
  }

  private addChevron() {
    const caret = this.hostElement.nativeElement.querySelector('.caret');
    if (caret) {
      caret.classList.add('fas');
      caret.classList.add('fa-chevron-down');
      caret.classList.remove('caret');
    }
  }

  public onSelect(option): void {
    this.changed.emit(option);
  }

  public clearValue() {
    if (this.mySelectList) {
      this.mySelectList.disabled = false;
      const activeItem = this.mySelectList.activeOption;
      if (activeItem) {
        this.mySelectList.remove(activeItem)
      }
    }
  }

}
