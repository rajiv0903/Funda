import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchAndSelectComponent } from './search-and-select.component';
import { SelectModule } from 'ng2-select';
import { profileReducer } from '../../../store/reducers/profile.reducer';
import { StoreModule } from '@ngrx/store';
import { getProfileReducerMock } from '../../../util/stubs/mock-profile-reducer';
import { RoleType } from '../../enums/role-type.enum';

describe('SearchAndSelectComponent', () => {
  let component: SearchAndSelectComponent;
  let fixture: ComponentFixture<SearchAndSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        SelectModule,
        StoreModule.forRoot({
          profile: getProfileReducerMock(RoleType.TSP),
        }),
      ],
      declarations: [ SearchAndSelectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchAndSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create and check for place holder', () => {
    expect(component).toBeTruthy();
    expect(component.mySelectList.placeholder).toEqual('Select Client or Type Name');
  });

});
