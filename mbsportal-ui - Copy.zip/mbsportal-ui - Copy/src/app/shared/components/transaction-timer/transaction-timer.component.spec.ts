import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';

import { TransactionTimerComponent } from './transaction-timer.component';
import { SimpleChange } from '@angular/core';

describe('TransactionTimerComponent', () => {
  let component: TransactionTimerComponent;
  let fixture: ComponentFixture<TransactionTimerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        TransactionTimerComponent
      ]
    })
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransactionTimerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('should check ngOnInit', () => {
    it('diameter 90 strokeWidth 8', () => {
      component.diameter = 80;
      component.strokeWidth = 8;
      component.ngOnInit();

      expect(component.radius).toBe(36);
      expect(component.fill).toBe('#ffffff');
      expect(component.backgroundStroke).toBe('#dedede');
      expect(component.initialOffset).toBe(226.1946710584651);
      expect(component.strokeDashoffset).toBe(226.1946710584651);
    });

    it('diameter 50 strokeWidth 4', () => {
      component.diameter = 50;
      component.strokeWidth = 4;
      component.ngOnInit();

      expect(component.radius).toBe(23);
      expect(component.initialOffset).toBe(144.51326206513048);
      expect(component.strokeDashoffset).toBe(144.51326206513048);
    });

    it('type is lender', () => {
      component.type = 'lender';
      component.ngOnInit();

      expect(component.diameter).toBe(28);
      expect(component.fill).toBe('none');
      expect(component.backgroundStroke).toBe('rgba(255, 255, 255, 0.29)');
      expect(component.radius).toBe(11);
      expect(component.initialOffset).toBe(69.11503837897544);
      expect(component.strokeDashoffset).toBe(69.11503837897544);
    });
  });

  describe('should check ngOnChange', () => {
    it('isVisible is true', fakeAsync(() => {

      component.countUpToSeconds = 5;
      component.ngOnChanges({
        isVisible: new SimpleChange(null, true, true)
      });

      expect(component.stroke).toBe('#43e045');
      expect(component.clock).toBe('0:00');
      tick(20000); // actual tick should be 10s but due to the high resolution timer weirdly we need 20s
      expect(component.clock).toBe('0:05');
    }));

    it('isVisible is false', () => {
      component.ngOnChanges({
        isVisible: new SimpleChange(true, false, true)
      });

      expect(component.stroke).toBeUndefined();
      expect(component.clock).toBeUndefined();
    });

    it('isVisible is true and startFromSeconds is bigger than countUpToSeconds', () => {
      component.countUpToSeconds = 10;
      component.startFromSeconds = 11;
      component.ngOnChanges({
        isVisible: new SimpleChange(false, true, true)
      });

      expect(component.clock).toBe('0:10');
    });
  });


});
