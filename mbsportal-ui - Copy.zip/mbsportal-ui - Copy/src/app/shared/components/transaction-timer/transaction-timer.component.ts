import { ChangeDetectorRef, Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { HighResolutionTimer } from '../../../util/high-resolution-timer';

@Component({
  selector: 'mbsp-transaction-timer',
  templateUrl: './transaction-timer.component.html',
  styleUrls: ['./transaction-timer.component.scss']
})
export class TransactionTimerComponent implements OnInit, OnChanges, OnDestroy {

  @Input() type: 'lender' | 'trader';
  @Input() startFromSeconds: number = 0;
  @Input() countUpToSeconds?: number = 135;
  @Input() diameter?: number = 40;
  @Input() strokeWidth?: number = 6;
  @Input() isVisible?: boolean = true;

  private counter: number;
  private color1 = '#43e045';
  private color2 = '#ff9e01';
  private color3 = '#ff3f3f';

  public clock: any;
  public radius: number;
  public stroke: string;
  public backgroundStroke = '#dedede';
  public fill = '#ffffff';
  public initialOffset: number;
  public strokeDashoffset: number;
  public timer: HighResolutionTimer;
  public timerStep = 1000;

  constructor(private ref: ChangeDetectorRef) {}

  ngOnInit() {
    if (this.type === 'lender') {
      this.diameter = 28;
      this.fill = 'none';
      this.backgroundStroke = 'rgba(255, 255, 255, 0.29)';
    }

    this.setCounter();
    this.setRadius();
    this.setInitialOffset();
    if (this.startFromSeconds < this.countUpToSeconds) {
      this.setInitialStrokeDashoffset();
    }
  }

  ngOnDestroy() {
    this.counter = this.countUpToSeconds;
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.isVisible && changes.isVisible.currentValue && !changes.isVisible.previousValue) {
      this.run();
    }
  }

  private setCounter() {
    this.counter = this.startFromSeconds + 1;
  }

  public setInitialStrokeDashoffset(): void {
    this.strokeDashoffset = this.initialOffset;

    setTimeout(() => {
      this.strokeDashoffset = this.initialOffset - (this.counter * (this.initialOffset / this.countUpToSeconds));
      this.ref.markForCheck();
    }, 10);
  }

  public setRadius(): void {
    this.radius = this.diameter / 2 - this.strokeWidth / 2;
  }

  public setInitialOffset(): void {
    this.initialOffset = 2 * Math.PI * this.radius;
  }

  public run() {
    this.setStroke();
    this.clock = this.convertToTime(this.startFromSeconds <= this.countUpToSeconds ? this.startFromSeconds : this.countUpToSeconds);

    if (this.startFromSeconds < this.countUpToSeconds) {
      setTimeout(() => {
        this.timer = new HighResolutionTimer(this.timerStep, (timer: HighResolutionTimer) => {
          this.clock = this.convertToTime(this.counter);

          if (this.counter > this.countUpToSeconds * 0.44) {
            this.stroke = this.color2;
          }
          if (this.counter > this.countUpToSeconds * 0.88) {
            this.stroke = this.color3;
          }
          this.ref.markForCheck();
          if (this.counter >= this.countUpToSeconds) {
            timer.stop();
            return;
          }
          this.strokeDashoffset = this.initialOffset - (++this.counter * (this.initialOffset / this.countUpToSeconds));
          this.ref.markForCheck();
        });
        this.timer.run();
      }, this.timerStep);
    } else {
      this.stroke = this.color3;
    }
  }

  public setStroke() {
    this.stroke = this.color1;
  }

  public convertToTime(totalSeconds: number): string {
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return minutes + ':' + (seconds.toString().length < 2 ? ('0' + seconds) : seconds);
  }

}
