import { Component, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'mbsp-growl',
  templateUrl: './growl.component.html',
  styleUrls: ['./growl.component.scss']
})
export class GrowlComponent implements OnChanges {

  @Input() userErrors: any[];

  public messages = [];

  constructor() { }

  ngOnChanges() {
    if (this.userErrors.length > 0) {
      this.messages = [...this.messages, this.userErrors.pop()];
    }
  }

}
