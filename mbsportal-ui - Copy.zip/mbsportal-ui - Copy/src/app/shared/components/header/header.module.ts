import { HeaderComponent } from './header.component';
import { NgModule } from '@angular/core';

import { FmCompositeComponentsModule } from '@fm-ui-adk/components/dist/fm-composite.module';

@NgModule({
  imports: [FmCompositeComponentsModule.forRoot()],
  declarations: [HeaderComponent],
  exports: [HeaderComponent],
})
export class HeaderModule { }
