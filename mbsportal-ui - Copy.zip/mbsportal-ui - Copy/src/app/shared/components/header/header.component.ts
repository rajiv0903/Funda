import { Component, Input, OnChanges, OnInit } from '@angular/core';

import { environment } from '../../../../environments/environment';
import { LogoutResource } from '../../resources/logout.resource';
import { UserProfileService } from '../../services/user-profile.service';
import { TransactionRequest } from '../../../store/models/transaction-request.model';

@Component({
  moduleId: module.id,
  selector: 'mbsp-header',
  templateUrl: 'header.component.html',
  styleUrls: ['header.component.scss']
})

export class HeaderComponent {

  @Input() rows: TransactionRequest[];

  constructor(
    private logoutResource: LogoutResource,
    private profile: UserProfileService
  ) {}

  get username(): any {
    return {
      firstName: this.profile.firstName,
      lastName: this.profile.lastName
    };
  }

  get userLinks(): any {
    const links = [];
    if (environment.name !== 'local') {
      links.push({
        title: 'Logout',
        url: ''
      });
    }
    return links;
  }

  public onLogout(event): void {
    this.logoutResource.logout().subscribe(() => {
      window.location.href = '/';
    });
  }

}
