import { HttpModule } from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FmCompositeComponentsModule } from '@fm-ui-adk/components/dist/fm-composite.module';

import { StoreModule } from '@ngrx/store';

import { HeaderComponent } from './header.component';
import { LogoutResource } from '../../resources/logout.resource';
import { UserProfileService } from '../../services/user-profile.service';
import { TransactionRequestService } from '../../services/transaction-request.service';
import { TransactionRequestResource } from '../../resources/transaction-request.resource';
import { transactionRequestReducer } from '../../../store/reducers/transaction-request.reducer';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { getProfileReducerMock } from '../../../util/stubs/mock-profile-reducer';
import { RoleType } from '../../enums/role-type.enum';
import { deepCopy } from '../../../../test';
import { environment } from '../../../../environments/environment';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;
  const mockProfileData = deepCopy(require('../../../../assets/data/trader-profile.json'));
  const mockTransactionRequests = deepCopy(require('../../../../assets/data/transaction-requests.json'));

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FmCompositeComponentsModule.forRoot(),
        HttpModule,
        RouterTestingModule,
        StoreModule.forRoot({
          profile: getProfileReducerMock(RoleType.TRADER, mockProfileData),
          transactionRequests: transactionRequestReducer
        })
      ],
      declarations: [ HeaderComponent ],
      providers: [
        LogoutResource,
        HttpClient,
        HttpHandler,
        UserProfileService,
        {
          provide: TransactionRequestResource,
          useValue: jasmine.createSpyObj('transRequestResource', ['update'])
        },
        TransactionRequestService
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.rows = mockTransactionRequests;
  });

  it('should check for the get userName method', () => {
    expect(component.username.firstName).toEqual('TraderD');
    expect(component.username.lastName).toEqual('ExecuteD');
  });

  it('should check for the get userLinks method', () => {
    if (environment.name === 'local') {
      expect(component.userLinks.length).toEqual(0);
    } else {
      expect(component.userLinks.length).toEqual(1);
      expect(component.userLinks[0].title).toEqual('Logout');
    }
  });
});
