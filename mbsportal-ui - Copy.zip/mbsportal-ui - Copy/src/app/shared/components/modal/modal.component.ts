import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';

import { UserProfileService } from '../../services/user-profile.service';
import { UserType } from '../../enums/user-type.enum';
import { BsModalService } from 'ngx-bootstrap/modal';
import { modalContent } from '../../constants/error.constant';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'modal-content',
  templateUrl: 'modal.component.html',
  styleUrls: ['modal.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ModalComponent implements OnInit {

  @ViewChild('iconEl') iconEl: ElementRef;
  @ViewChild('contentEl') contentEl: ElementRef;
  public content: string;
  public closeBtnText: string;
  public type: string;
  public status: number;

  constructor(private profile: UserProfileService,
    private bsModalService: BsModalService) { }

  ngOnInit() {
    const userType = this.profile.userType || UserType.EXTERNAL;
    this.content = modalContent[userType + '-server-error'];
    this.closeBtnText = 'Ok';

    if (this.status === 401) {
      this.content = modalContent.unauthorized;
      this.closeBtnText = 'Log In';
    }

    if (this.status === 400) {
      this.content = modalContent.invalidDateSelection;
      this.closeBtnText = 'OK';
    }
  }

  public getIconClass() {
    const iconHeight = this.iconEl.nativeElement.offsetHeight;
    const contentHeight = this.contentEl.nativeElement.offsetHeight;
    const shouldAlightOnTop = iconHeight && contentHeight && iconHeight <= contentHeight;
    return { 'align-top': shouldAlightOnTop };
  }

  public onClick(): void {
    if (this.status === 400) {
      this.bsModalService.hide(1);
    } else {
      this.goToPortalMainPage();
    }
  }

  public goToPortalMainPage(): void {
    let href = '/portal/#/signin/logout';
    if (environment.name === 'local') {
      href = '/';
    }
    window.location.href = href;
  }

}
