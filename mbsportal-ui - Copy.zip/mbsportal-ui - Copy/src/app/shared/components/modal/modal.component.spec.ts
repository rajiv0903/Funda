import { async, ComponentFixture, TestBed  } from '@angular/core/testing';
import { ModalComponent } from './modal.component';
import { UserProfileService } from '../../services/user-profile.service';
import { BsModalService, ComponentLoaderFactory, PositioningService } from 'ngx-bootstrap';

class UserProfileServiceStub {}

describe('Modal Component', () => {
  let component: ModalComponent;
  let fixture: ComponentFixture<ModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ModalComponent
      ],
      providers: [
        {
          provide: UserProfileService,
          useClass: UserProfileServiceStub
        },
        BsModalService,
        ComponentLoaderFactory,
        PositioningService
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('onClick should call goToPortalMainPage', () => {
    spyOn(component, 'goToPortalMainPage');
    component.onClick();

    expect(component.goToPortalMainPage).toHaveBeenCalled();
  });

});


