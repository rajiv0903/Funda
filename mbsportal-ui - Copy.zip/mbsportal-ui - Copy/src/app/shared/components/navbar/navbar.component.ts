import { Component, ChangeDetectorRef } from '@angular/core';

import { UserProfileService } from '../../services/user-profile.service';
import { UserType } from '../../enums/user-type.enum';

@Component({
  moduleId: module.id,
  selector: 'mbsp-navbar',
  templateUrl: 'navbar.component.html',
  styleUrls: ['navbar.component.scss'],
})
export class NavbarComponent {

  constructor(
    private ref: ChangeDetectorRef,
    private profile: UserProfileService
  ) { }

  get menu(): any {
    const menu = [{
      title: 'TBA Trading',
      url: 'trading',
      exactMatch: true,
      list: []
    }];

    if (this.profile.userType === UserType.INTERNAL) {
      menu[0].url = 'pricing';
    }

    menu.push({
      title: 'Transaction History',
      url: 'transaction-history',
      exactMatch: true,
      list: []
    });

    // disabling change detection due to a bug which crashes the browsers otherwise
    this.ref.detach();

    return menu;
  }

}
