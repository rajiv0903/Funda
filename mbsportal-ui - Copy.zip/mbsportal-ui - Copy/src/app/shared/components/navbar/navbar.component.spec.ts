import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { StoreModule } from '@ngrx/store';

import { FmCompositeComponentsModule } from '@fm-ui-adk/components/dist/fm-composite.module';

import { NavbarComponent } from './navbar.component';
import { UserProfileService } from '../../services/user-profile.service';
import { UserType } from '../../enums/user-type.enum';
import { getProfileReducerMock } from '../../../util/stubs/mock-profile-reducer';
import { RoleType } from '../../enums/role-type.enum';

describe('NavbarComponent', () => {
  let component: NavbarComponent;
  let fixture: ComponentFixture<NavbarComponent>;
  let profileService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FmCompositeComponentsModule.forRoot(),
        RouterTestingModule,
        StoreModule.forRoot({
          profile: getProfileReducerMock(RoleType.LENDER)
        })
      ],
      declarations: [ NavbarComponent ],
      providers: [ UserProfileService ],
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavbarComponent);
    component = fixture.componentInstance;
    profileService = TestBed.get(UserProfileService);
    fixture.detectChanges();
  });

  it('should check the menu for trader Profile', () => {
    spyOnProperty(profileService, 'userType', 'get').and.returnValue(UserType.INTERNAL);
    expect(component.menu.length).toEqual(2);
    expect(component.menu[0].url).toEqual('pricing');
    expect(component.menu[1].url).toEqual('transaction-history');

  });

  it('should check the menu for lender Profile', () => {
    spyOnProperty(profileService, 'userType', 'get').and.returnValue(UserType.EXTERNAL);
    expect(component.menu.length).toEqual(2);
    expect(component.menu[0].url).toEqual('trading');
    expect(component.menu[1].url).toEqual('transaction-history');
  })

});
