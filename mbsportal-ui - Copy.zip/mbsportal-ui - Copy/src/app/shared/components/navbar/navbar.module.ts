import { NavbarComponent } from './navbar.component';
import { NgModule } from '@angular/core';

import { FmCompositeComponentsModule } from '@fm-ui-adk/components/dist/fm-composite.module';

@NgModule({
  imports: [FmCompositeComponentsModule.forRoot()],
  declarations: [NavbarComponent],
  exports: [NavbarComponent]
})
export class NavbarModule { }
