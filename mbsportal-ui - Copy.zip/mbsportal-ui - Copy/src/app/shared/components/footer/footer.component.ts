import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'mbsp-footer',
  templateUrl: 'footer.component.html',
  styleUrls: ['footer.component.scss'],
  providers: []
})

export class FooterComponent {}
