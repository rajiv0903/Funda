import { FooterComponent } from './footer.component';
import { NgModule } from '@angular/core';

@NgModule({
  imports: [],
  declarations: [FooterComponent],
  exports: [FooterComponent],
  providers: []
})
export class FooterModule { }
