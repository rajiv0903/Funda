/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

export interface LogMessage {
  userName?: string;
  transReqId?: string;
  code?: number;
  type?: string;
  channel?: string;
  functionality?: string;
  message?: string;
  messageDescription?: string;
  timeStamp?: string;
  module?: string;
  page?: string;
}
