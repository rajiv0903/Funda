import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'nameFormat'})
export class NameFormat implements PipeTransform {
  transform(value: string): string {
    let newStr = '';
    for (let i = 0; i <= value.length - 1; i++) {
      if (value.charAt(i) === ',') {
        newStr += value.charAt(i + 1).toUpperCase() + '. ' + value.substring(0, i);
      }
    }
    return newStr;
  }
}

