import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';

import { environment } from '../../../environments/environment';
import { TransactionRequest } from '../../store/models/transaction-request.model';
import { UserProfileService } from '../services/user-profile.service';
import { UserType } from '../enums/user-type.enum';

@Injectable()
export class TransactionRequestResource {

  constructor(
    private profile: UserProfileService,
    private httpClient: HttpClient
  ) { }

  private getPath(): string {
    let subRouteName: string;
    if (this.profile.userType === UserType.EXTERNAL) {
      subRouteName = 'lender';
    } else if (this.profile.userType === UserType.INTERNAL) {
      subRouteName = 'trader';
    }
   return environment.apiBasePath + '/mbs' + subRouteName + 'transactions';
  }

  public query(): Observable<TransactionRequest[]> {
    return this.httpClient.get<TransactionRequest[]>(this.getPath());
  }

  public get(obj: {transReqId: string}): Observable<TransactionRequest> {
    return this.httpClient.get<TransactionRequest>(this.getPath() + `/${obj.transReqId}`);
  }

  public create(transReq: TransactionRequest): Observable<TransactionRequest> {
    return this.httpClient.post<TransactionRequest>(this.getPath(), transReq);
  }

  public update(transReq: TransactionRequest): Observable<TransactionRequest> {
    return this.httpClient.put<TransactionRequest>(this.getPath() + `/${transReq.transReqId}`, transReq);
  }

  public poll(obj: {lastPollTimestamp: string}): Observable<{'eventsAvailable': boolean, serverTime: string}> {
    const path = this.getPath() + `/events/${obj.lastPollTimestamp}`;
    return this.httpClient.get<{'eventsAvailable': boolean, serverTime: string}>(path);
  }

}
