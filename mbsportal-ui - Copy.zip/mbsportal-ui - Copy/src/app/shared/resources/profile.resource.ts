/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';

import { environment } from '../../../environments/environment';
import { Profile } from '../../store/models/profile.model';

@Injectable()
export class ProfileResource {

  private path = environment.apiBasePath + '/mbsprofileentitlements';

  constructor(private httpClient: HttpClient) { }

  public get(): Observable<any> {
    if (environment.name === 'local') {
      return this.getMockedProfile();
    } else {
      return this.httpClient.get<Profile>(this.path);
    }
  }

  private getMockedProfile(): Observable<Profile> {
    const currentUrl: string = window.location.href;
    let userType = sessionStorage.getItem('userType');

    if (!userType) {
      userType = 'lender';
    }
    if (currentUrl.includes('/?login-as=')) {
      const roleInUrl = currentUrl.split('=');
      userType = roleInUrl[1];
    }

    return this.httpClient.get<Profile>('./assets/data/' + userType + '-profile.json')
      .map((data: Profile) => {
        sessionStorage.setItem('userType', data.tspUser ? 'tsp' : (data.fannieMaeUser ? 'trader' : 'lender'));
        sessionStorage.setItem('userName', data.userName);
        return data;
      });
  }

}
