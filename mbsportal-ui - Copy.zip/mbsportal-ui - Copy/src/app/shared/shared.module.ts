/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule, DatePipe, DecimalPipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { FmCompositeComponentsModule } from '@fm-ui-adk/components/dist/fm-composite.module';
import { ModalModule } from 'ngx-bootstrap/modal';
import { TooltipModule } from 'ngx-tooltip';
import { SelectModule } from 'ng2-select';

import { UserProfileService } from './services/user-profile.service';
import { AlertsService } from './services/alerts-service';
import { DropdownComponent } from './components/dropdown/dropdown.component';
import { LocalStorageService } from './services/local-storage.service';
import { NameFormat } from './pipes/name-format.pipe';
import { TransactionRequestResource } from './resources/transaction-request.resource';
import { TradeResource } from '../trades-history/trade.resource';
import { ProfileResource } from './resources/profile.resource';
import { PricingResource } from '../lender-trading/product-select/pricing.resource';
import { LogoutResource } from './resources/logout.resource';
import { TransactionRequestService } from './services/transaction-request.service';
import { LoggerService } from './services/logger.service';
import { ModalService } from './services/modal.service';
import { TransactionTimerComponent } from './components/transaction-timer/transaction-timer.component';
import { ServerLoggerService } from './services/server-logger.service';
import { DateTimezoneFormat } from './pipes/date-format.pipe';
import { SearchAndSelectComponent } from './components/search-and-select/search-and-select.component';
import { GrowlComponent } from './components/growl/growl.component';
import { FMGrowlModule } from '@fm-ui-adk/components/dist/fm-growl/fm-growl.module';
import { WSService } from './services/ws.service';
import { ProductResource } from '../lender-trading/product-select/product.resource';
import { LoggerResource } from './resources/logger.resource';
import { AllowedCharactersDirective } from './directives/allowed-characters.directive';
import { TradeService } from './services/trade.service';
import { MiscService } from './services/misc.service';
import { DisableControlDirective } from './directives/disable-control.directive';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ModalModule.forRoot(),
    TooltipModule,
    SelectModule,
    FMGrowlModule.forRoot(),
    FmCompositeComponentsModule.forRoot(),
  ],
  exports: [
    CommonModule,
    FormsModule,
    FmCompositeComponentsModule,
    ModalModule,
    TooltipModule,
    ReactiveFormsModule,
    DropdownComponent,
    GrowlComponent,
    NameFormat,
    DateTimezoneFormat,
    TransactionTimerComponent,
    SearchAndSelectComponent,
    AllowedCharactersDirective,
    DisableControlDirective
  ],
  declarations: [
    DropdownComponent,
    GrowlComponent,
    NameFormat,
    DateTimezoneFormat,
    TransactionTimerComponent,
    SearchAndSelectComponent,
    GrowlComponent,
    AllowedCharactersDirective,
    DisableControlDirective
  ]
})

export class SharedModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: SharedModule,
      providers: [
        DatePipe,
        UserProfileService,
        AlertsService,
        LocalStorageService,
        NameFormat,
        DecimalPipe,
        TradeService,
        MiscService,
        TransactionRequestService,
        LoggerService,
        ModalService,
        ServerLoggerService,
        TransactionRequestResource,
        LogoutResource,
        ProfileResource,
        LoggerResource,
        TradeResource,
        ProductResource,
        PricingResource,
        WSService
      ]
    };
  }
}
