/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

export enum Role {
  LENDER = 'MBS Trade - Execute',
  TSP = 'MBS Trade_TSP - Execute',
  TRADER_READ_ONLY_PROD = 'SG-MBSP-Prod-FM-TRADER-READ-ONLY',
  TRADER_READ_ONLY_NON_PROD = 'SG-MBSP-NonProd-FM-TRADER-READ-ONLY',
  TRADER_EXECUTE_PROD = 'SG-MBSP-Prod-FM-TRADER-EXECUTE',
  TRADER_EXECUTE_NON_PROD = 'SG-MBSP-NonProd-FM-TRADER-EXECUTE',
  ADMIN_PROD = 'SG-MBSP-Prod-ADMINISTRATOR',
  ADMIN_NON_PROD = 'SG-MBSP-NonProd-ADMINISTRATOR',
}
