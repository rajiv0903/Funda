/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { UserType } from '../enums/user-type.enum';

export const appName = 'MBSP';
export const sessionIdHeaderName = 'x-fnma-sessionid';
export const pollingInterval = 500;
export const requestDebounceTime = 500;
export const retryTimes = 3;
export const retryDelay = 1000;
export const incomingAlertInterval = 10000;
export const cancelReactivateTimeout = 15000;
export const timezone = 'America/New_York';

// web socket constants
export const traderWSReconnectDelay = 1000 * 10;
export const lenderWSReconnectDelay = 0;
export const enableWS = true;
export const wsTopicPrefix = '/mbsp/topic/';
export const traderTransactionsWSTopic = wsTopicPrefix + 'transaction/trader';
export const traderPricingWSTopic = wsTopicPrefix + 'tbapricing';
export const lenderTransactionsWSTopic = wsTopicPrefix + 'transaction/{userId}';

export const wsTopics = {
  [UserType.INTERNAL]: [
    traderTransactionsWSTopic,
    traderPricingWSTopic
  ],
  [UserType.EXTERNAL]: [
    lenderTransactionsWSTopic
  ]
};
