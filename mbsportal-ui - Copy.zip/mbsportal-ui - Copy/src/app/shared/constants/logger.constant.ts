/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

export const logPostingInterval = 10000;
export const logKeyPrefix = 'MBSP_LOG_KEY_';
export const logMaxStore = 50;
export const logBatchSize = 10;
export const logMaxBatch = 1;
export enum LogLevel {
  ALL = 0,
  DEBUG = 1,
  INFO = 2,
  WARN = 3,
  ERROR = 4,
  FATAL = 5,
  OFF = 6
}

export const APPENDERS: { appender: string }[] = [
  {appender: 'CONSOLE'},
  {appender: 'LOCAL'},
  {appender: 'REMOTE'}
];
export const logLevel: LogLevel = LogLevel.INFO;
