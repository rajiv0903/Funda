/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { UserType } from '../enums/user-type.enum';

export const exportFileNotFound = 'File Not Found. Administrator Has Been Notified.';
export const unexpectedError = 'Unexpected System Error, Please Try Again.';

// for Alert messages
export const genericError = 'There was a system error.<br>Please log-out, then log-in again.';
export const modalContent = {
  'unauthorized': 'You have been logged out because your session has expired.',
  [UserType.EXTERNAL + '-server-error']: genericError + ' <br><br>'
  + 'If you continue to have problems, please call the Fannie Mae Capital Markets Sales Desk.',
  [UserType.INTERNAL + '-server-error']: genericError + ' <br><br>'
  + 'If you continue to have problems, please call:<br><b>Vinay Sharma</b> at (202) 752-3077, '
  + 'or<br><b>Nitin Sahasranaman</b> at (703) 833-5117',
  'invalidDateSelection': 'You can export a maximum of 12 months at one time. Please select a valid date range to export.'
};
