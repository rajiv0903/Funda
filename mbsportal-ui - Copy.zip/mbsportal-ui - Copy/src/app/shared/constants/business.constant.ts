/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

export const priceThresholdLow = 90;
export const priceThresholdHigh = 115;

export const minAmountValue = 25000;
export const maxAmountValue = 250000000;

// Trades List Pagination Constants
export const maxRecordsPerPage = 25;
export const tradesListFirstPage = 1;
export const tradesListSortOrder  = 'desc';
export const tradesListSortBy = 'submissionDate';
export const tradesListDateType = 'submissionDate';

// Session Timeouts
export const lenderTimerReset = 1800000 ;
export const traderNonBusinessHourReset = 3600000 ;
export const traderBusinessHoursReset = 36000000 ;
export const traderBusinessHrsPreStart = 5;
export const traderBusinessHrsStart = 9;
export const traderBusinessHrsEnd = 19;
