import { Action, ActionReducerMap } from '@ngrx/store';
import { createSelector } from 'reselect';

import { ProfileState, profileReducer } from './reducers/profile.reducer';
import { transactionRequestReducer, TransactionRequestsState } from './reducers/transaction-request.reducer';
import { TradesState, tradesReducer } from './reducers/trade.reducer';
import { ProductsState, productsReducer } from './reducers/product.reducer';
import { PricingState, pricingReducer } from './reducers/pricing.reducer';
import { AppState, appReducer } from './reducers/app.reducer';
import { sessionReducer, SessionState } from './reducers/session.reducer';

export interface AppStore {
  app: AppState;
  profile: ProfileState;
  transactionRequests: TransactionRequestsState;
  trades: TradesState;
  products: ProductsState;
  pricing: PricingState;
  session: SessionState
}

export interface ActionWithPayload<T> extends Action {
  payload: T;
}

export const reducers: ActionReducerMap<AppStore> = {
  app: appReducer,
  profile: profileReducer,
  transactionRequests: transactionRequestReducer,
  trades: tradesReducer,
  products: productsReducer,
  pricing: pricingReducer,
  session: sessionReducer
};

// TODO introduce store freeze later
// const developmentReducer = compose(storeFreeze, combineReducers)(reducers);
// const productionReducer = combineReducers(reducers);
//
// export function reducer(state: any, action: any) {
//   return productionReducer(state, action);

// if (environment.production) {
//   return productionReducer(state, action);
// } else {
//   return developmentReducer(state, action);
// }
// }

// GENERAL
export const getEntities = state => state.entities;
export const getOne = state => state.entities[0];
export const getListObject = state => state.listObject;
export const getLoaded = state => state.loaded;
export const getError = state => state.error;
export const getIsCreating = state => state.isCreating;
export const getIsUpdating = state => state.isUpdating;
export const getIsLoading = state => state.isLoading;

// APP
export const getAppSate = (state: AppStore) => state.app;
export const getInitialized = state => state.initialized;
export const getAppInitialized = createSelector(getAppSate, getInitialized);
export const getAppError = createSelector(getAppSate, getError);
export const getUserErrors = state => state.userErrors;
export const getAppLevelUserErrors = createSelector(getAppSate, getUserErrors);

// PROFILE
export const getProfileState = (state: AppStore) => state.profile;
export const getData = state => state.profile;
export const getProfileData = createSelector(getProfileState, getData);

// TRANSACTION REQUESTS
export const getTransactionRequestsState = (state: AppStore) => state.transactionRequests;
export const getTransactionRequestsEntities = createSelector(getTransactionRequestsState, getEntities);
export const getTransactionRequestsLoaded = createSelector(getTransactionRequestsState, getLoaded);
export const getTransactionRequest = createSelector(getTransactionRequestsState, getOne);
export const getTransactionRequestError = createSelector(getTransactionRequestsState, getError);
export const getTransactionRequestIsCreating = createSelector(getTransactionRequestsState, getIsCreating);
export const getTransactionRequestIsUpdating = createSelector(getTransactionRequestsState, getIsUpdating);

// TRADES
export const getTradesState = (state: AppStore) => state.trades;
export const getTradesList = createSelector(getTradesState, getListObject);
export const getTradesLoaded = createSelector(getTradesState, getLoaded);
export const getTradesIsLoading = createSelector(getTradesState, getIsLoading);
export const getExport = state => state.isExporting;
export const getIsExportInProgress = createSelector(getTradesState, getExport);

// PRODUCTS
export const getProductsState = (state: AppStore) => state.products;
export const getProductsLoaded = createSelector(getProductsState, getLoaded);
export const getProductsEntities = createSelector(getProductsState, getEntities);
export const getProductIdForPricingLoad = createSelector(
  getProductsEntities,
  getTransactionRequest,
  getProductsLoaded,
  getTransactionRequestsLoaded,
  (products, transaction, pLoaded, trLoaded) => {
    let productId;
    if (pLoaded && trLoaded) {
      productId = products[0].productId;
      if (transaction) {
        productId = transaction.product.productId;
      }
    }
    return productId;
  }
);

// PRICING
export const getPricingState = (state: AppStore) => state.pricing;
export const getPricingLoaded = createSelector(getPricingState, getLoaded);
export const getPricingEntities = createSelector(getPricingState, getEntities);
export const getPricingIsLoading = createSelector(getPricingState, getIsLoading);
