import { discardPeriodicTasks, TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { fakeAsync } from '@angular/core/testing';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { StoreModule , Store} from '@ngrx/store';

import { UserProfileService } from '../../shared/services/user-profile.service';
import { UserType } from '../../shared/enums/user-type.enum';
import { SessionEffects } from './session.effects';
import { getProfileReducerMock } from '../../util/stubs/mock-profile-reducer';
import { RoleType } from '../../shared/enums/role-type.enum';
import { tick } from '@angular/core/testing';
import * as sActions from '../actions/session.actions';
import { LoggerService } from '../../shared/services/logger.service';
import { LocalStorageService } from '../../shared/services/local-storage.service';
import { DatePipe } from '@angular/common';
import { AppStore } from '../../store/index';
import { TimeObject } from '../../shared/interfaces/time-object.interface';
describe('SessionEffects', () => {
  let effects: SessionEffects;
  let userProfileService: UserProfileService;
  let loggerService: LoggerService;
  let actions;
  let store: Store<AppStore>;
  const timeObj = {
    years: 0,
    months: 0,
    date: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  };
  const time: TimeObject = {
    years: 2018,
    months: 6,
    date: 10,
    hours: 10,
    minutes: 30,
    seconds: 30
  };
  const timeOutOfBusinessTime: TimeObject = {
    years: 2018,
    months: 6,
    date: 10,
    hours: 5,
    minutes: 30,
    seconds: 30
  };
  const timePlusTenInBusinessTime: TimeObject = {
    years: 2018,
    months: 6,
    date: 10,
    hours: 7,
    minutes: 30,
    seconds: 30
  };

  const timePlusTenLessThanAnBusinessHourEnd: TimeObject = {
    years: 2018,
    months: 6,
    date: 10,
    hours: 14,
    minutes: 30,
    seconds: 30
  }
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot({
          profile: getProfileReducerMock(RoleType.TRADER)
        })
      ],
      providers: [
        SessionEffects,
        UserProfileService,
        LoggerService,
        LocalStorageService,
        DatePipe,
        provideMockActions(() => actions),
      ]
    })
  });
  beforeEach(() => {
    effects = TestBed.get(SessionEffects);
    userProfileService = TestBed.get(UserProfileService);
    loggerService = TestBed.get(LoggerService);
    store = TestBed.get(Store);
    spyOn(store, 'dispatch').and.callThrough();
  });

  it('should test external user  reset timer expired', fakeAsync(() => {
    spyOnProperty(userProfileService, 'userType', 'get').and.returnValue(UserType.EXTERNAL);
    const action = new sActions.TimerResetAction(timeObj);

    actions = new ReplaySubject(1);
    actions.next(action);

    effects.resetTimer$.subscribe(result => {
      expect(result).toEqual(new sActions.TimerExpiredAction());
    });
    tick(1800010);

  }));

  it('should test not external reset timer success', fakeAsync(() => {
    spyOnProperty(userProfileService, 'userType', 'get').and.returnValue(UserType.INTERNAL);
    const action = new sActions.TimerResetAction(timeObj);

    actions = new ReplaySubject(1);
    actions.next(action);

    effects.resetTimer$.subscribe(result => {
      expect(result).toEqual(new sActions.TimerExpiredAction());
      // expect(result).toEqual(null);
    });
    tick(60000);
    discardPeriodicTasks();
  }));

  it('should test user timer expired', fakeAsync(() => {
    const action = new sActions.TimerExpiredAction();

    actions = new ReplaySubject(1);
    actions.next(action);

    effects.timerExpired$.subscribe(result => {
      expect(result.payload.status).toEqual(401);
    });
  }));

  it('should call sessionTimerReset', fakeAsync(() => {
    spyOnProperty(userProfileService, 'userType', 'get').and.returnValue(UserType.INTERNAL);
    const action = new sActions.TimerResetAction(time);
    actions = new ReplaySubject(1);
    actions.next(action);
    effects.resetTimer$.subscribe(result => {
      expect(result).toEqual(new sActions.TimerExpiredAction());
    });
    tick(30570000);
    discardPeriodicTasks();
  }));

  it('should call sessionTimerReset out of work hours', fakeAsync(() => {
    spyOnProperty(userProfileService, 'userType', 'get').and.returnValue(UserType.INTERNAL);
    const action = new sActions.TimerResetAction(timeOutOfBusinessTime);
    actions = new ReplaySubject(1);
    actions.next(action);
    effects.resetTimer$.subscribe(result => {
      expect(result).toEqual(new sActions.TimerExpiredAction());
    });
    tick(36000000);
    discardPeriodicTasks();
  }));

  it('should call sessionTimerReset time plusTen in BusinessTime', fakeAsync(() => {
    spyOnProperty(userProfileService, 'userType', 'get').and.returnValue(UserType.INTERNAL);
    const action = new sActions.TimerResetAction(timePlusTenInBusinessTime);
    actions = new ReplaySubject(1);
    actions.next(action);
    effects.resetTimer$.subscribe(result => {
      expect(result).toEqual(new sActions.TimerExpiredAction());
    });
    tick(36000000);
    discardPeriodicTasks();
  }));

  it('should call sessionTimerReset timePlusTen LessThan AnBusinessHourEnd', fakeAsync(() => {
    spyOnProperty(userProfileService, 'userType', 'get').and.returnValue(UserType.INTERNAL);
    const action = new sActions.TimerResetAction(timePlusTenLessThanAnBusinessHourEnd);
    actions = new ReplaySubject(1);
    actions.next(action);
    effects.resetTimer$.subscribe(result => {
      expect(result).toEqual(new sActions.TimerExpiredAction());
    });
    tick(36000000);
    discardPeriodicTasks();
  }));

  it('should call sessionTimerReset to reset previous timer', fakeAsync(() => {
    spyOnProperty(userProfileService, 'userType', 'get').and.returnValue(UserType.INTERNAL);
    const action = new sActions.TimerResetAction(timePlusTenLessThanAnBusinessHourEnd);
    actions = new ReplaySubject(2);
    let res = null;
    effects.resetTimer$.subscribe(result => {
      res = result;
    });
    // fire first action time set at 16170000
    actions.next(action);
    tick(16170000 - 1000);
    // fire second action to reset time back to 16170000
    actions.next(action);
    tick(1000);
    // check if effects.resetTimer return TimerExpiredAction when first set timer is time up
    expect(res).toBeNull();
    tick(16170000 - 1000);
    // check if effects.resetTimer return TimerExpiredAction when second set timer is time up
    expect(res).not.toBeNull();
  }));
});
