import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';
import { Observable } from 'rxjs/Rx';
import { Store } from '@ngrx/store';

import * as actions from '../actions/transaction-request.actions'
import { TransactionRequest } from '../models/transaction-request.model';
import { TransactionRequestResource } from '../../shared/resources/transaction-request.resource';
import * as fromRoot from '../';
import { pollingInterval, requestDebounceTime } from '../../shared/constants/system.constant';
import { UserProfileService } from '../../shared/services/user-profile.service';
import { TransactionRequestService } from '../../shared/services/transaction-request.service';
import { TransactionRequestsState } from '../reducers/transaction-request.reducer';
import { UserType } from '../../shared/enums/user-type.enum';
import { StompRService, StompState } from '@stomp/ng2-stompjs';
import { LoggerService } from '../../shared/services/logger.service';

@Injectable()
export class TransactionRequestEffects {

  @Effect()
  load$;

  @Effect()
  startPolling$;

  @Effect()
  pollOnSuccess$;

  @Effect()
  pollOnFailure$;

  @Effect()
  poll$;

  @Effect()
  pollSuccess$;

  @Effect()
  pollFailure$;

  @Effect()
  loadOne$;

  @Effect()
  loadOneAndReplace$;

  @Effect()
  create$;

  @Effect()
  update$;

  @Effect()
  updateWS$;

  @Effect()
  createFailure$;

  @Effect()
  updateFailure$;

  constructor(
    private actions$: Actions,
    private transRequestResource: TransactionRequestResource,
    private transRequestService: TransactionRequestService,
    private store: Store<fromRoot.AppStore>,
    private profile: UserProfileService,
    private stompService: StompRService,
    private logger: LoggerService
  ) {

    let pollingTimes = 0;

    const shouldPoll = (state: TransactionRequestsState): boolean => {
      const lenderHasActiveTrade = state.entities.length > 0 && transRequestService.isActive(fromRoot.getOne(state).stateType);
      if (this.profile.userType === UserType.INTERNAL) {
        return state.shouldPoll;
      }
      return (this.profile.userType === UserType.EXTERNAL && lenderHasActiveTrade) && state.shouldPoll;
    };

    const shouldUpdateWS = (state: TransactionRequestsState, payload: TransactionRequest): boolean => {
      return this.profile.userType === UserType.INTERNAL || fromRoot.getOne(state).transReqId === payload.transReqId;
    };

    this.load$ = this.actions$
      .ofType(actions.LOAD)
      .switchMap(() => this.transRequestResource.query()
        .map(body => new actions.LoadSuccessAction(body))
        .catch((err) => Observable.of(new actions.LoadFailureAction(err)))
      );

    this.startPolling$ = this.actions$
      .ofType(actions.LOAD)
      .map(() => new actions.StartPollingAction());

    this.pollOnSuccess$ = this.actions$
      .ofType(actions.LOAD_SUCCESS, actions.CREATE_SUCCESS, actions.LOAD_ONE_SUCCESS)
      .map(() => new actions.PollAction());

    this.pollOnFailure$ = this.actions$
      .ofType(actions.LOAD_FAILURE, actions.CREATE_FAILURE, actions.LOAD_ONE_FAILURE)
      .map(() => new actions.PollAction());

    this.poll$ = this.actions$
      .ofType(actions.POLL)
      .switchMap(() => this.stompService.state
        .distinctUntilChanged()
        .map((state: number) => StompState[state])
        .filter((stateName: string) => stateName !== 'CONNECTED')
        .take(1)
        .switchMap(() => this.store.select(fromRoot.getTransactionRequestsState)
          .filter((state: TransactionRequestsState) => shouldPoll(state))
          .take(1)
          .switchMap((s: TransactionRequestsState) => {
            const state = s;
            return Observable.timer(pollingInterval)
              .switchMap(() => {
                return this.transRequestResource.poll({lastPollTimestamp: state.lastPollTimestamp})
                  .map(body => new actions.PollSuccessAction(body))
                  .catch((err) => Observable.of(new actions.PollFailureAction(err)))
              });
          })));

    this.pollSuccess$ = this.actions$
      .ofType(actions.POLL_SUCCESS)
      .map((action: actions.PollSuccessAction) => {
        let act: any = new actions.PollAction();
        if (++pollingTimes % 50 === 0) {
          this.logger.info('Still polling');
        }
        if (action.payload['eventsAvailable']) {
          this.logger.info('Events available - about to load transactions list');
          act = this.profile.userType === UserType.INTERNAL ? new actions.LoadAction() : new actions.LoadOneAction();
        }
        return act;
      });

    this.pollFailure$ = this.actions$
      .ofType(actions.POLL_FAILURE)
      .map(() => new actions.PollAction());

    this.loadOne$ = this.actions$
      .ofType(actions.LOAD_ONE)
      .switchMap(() => this.store.select(fromRoot.getTransactionRequest)
        .take(1)
        .filter((tr: TransactionRequest) => !!(tr && this.transRequestService.isActive(tr.stateType)))
        .switchMap((tr: TransactionRequest) => {
          this.logger.info('Making request to get updates for trans id' + tr.transReqId);
          return this.transRequestResource.get({transReqId: tr.transReqId})
            .map(body => new actions.LoadOneSuccessAction(body))
            .catch((err) => Observable.of(new actions.LoadOneFailureAction(err)))
        }));

    this.loadOneAndReplace$ = this.actions$
      .ofType(actions.LOAD_ONE_AND_REPLACE)
      .flatMap((action: actions.LoadOneAndReplaceAction) => {
        return this.transRequestResource.get({transReqId: action.payload.transReqId})
          .map(body => {
            return new actions.UpdateSuccessAction(body)
          })
          .catch((err) => Observable.of(new actions.UpdateFailureAction(err)));
      });

    this.create$ = this.actions$
      .ofType(actions.CREATE)
      .map((action: actions.CreateAction) => action.payload)
      .debounceTime(requestDebounceTime)
      .switchMap((payload) => {
          return this.transRequestResource.create(payload)
            .map(res => new actions.CreateSuccessAction(res))
            .catch((err) => Observable.of(new actions.CreateFailureAction(err)))
        }
      );

    this.update$ = this.actions$
      .ofType(actions.UPDATE)
      .map((action: actions.UpdateAction) => action.payload)
      // .debounceTime(requestDebounceTime) TODO figure out how to debounce for all updates but lock/unlock
      .switchMap((payload) => {
          return this.transRequestResource.update(payload)
            .map(res => new actions.UpdateSuccessAction(res))
            .catch((err) => Observable.of(new actions.UpdateFailureAction({
              ...err,
              transReqId: payload.transReqId
            })))
        }
      );

    this.updateWS$ = this.actions$
      .ofType(actions.UPDATE_WS)
      .switchMap((action: actions.UpdateAction) => {
          const payload = action.payload;
          return this.store.select(fromRoot.getTransactionRequestsState)
            .take(1)
            .filter((state: TransactionRequestsState) => shouldUpdateWS(state, payload))
            .map(res => new actions.UpdateWSSuccessAction(payload))
      });

    this.createFailure$ = this.actions$
      .ofType(actions.CREATE_FAILURE)
      // TODO fix when exception framework is in place (check error code etc)
      .filter((action: actions.CreateFailureAction) => action.payload.message === 'LENDER_TRADE_REQUEST_ALREADY_PRESENT')
      .map((action: actions.CreateFailureAction) => new actions.LoadAction());

    this.updateFailure$ = this.actions$
      .ofType(actions.UPDATE_FAILURE)
      // TODO fix when exception framework is in place (check error code etc)
      .filter((action: actions.UpdateFailureAction) => action.payload.message === 'INVALID_VERSION_TO_PERFORM_ACTION')
      .map((action: actions.UpdateFailureAction) => new actions.LoadOneAndReplaceAction({
        transReqId: action.payload.transReqId
      }));

  }
}
