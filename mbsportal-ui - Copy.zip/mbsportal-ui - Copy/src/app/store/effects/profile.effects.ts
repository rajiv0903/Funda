import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';
import { Observable } from 'rxjs/Rx';

import * as actions from '../actions/profile.actions';
import * as appActions from '../actions/app.actions';
import { ProfileResource } from '../../shared/resources/profile.resource';

@Injectable()
export class ProfileEffects {

  @Effect()
  load$;

  @Effect()
  loadSuccess$;

  @Effect()
  loadConfig$;

  @Effect()
  loadConfigSuccess$;

  constructor(
    private actions$: Actions,
    private profileResource: ProfileResource
  ) {

    this.load$ = this.actions$
      .ofType(actions.LOAD)
      .switchMap(() => this.profileResource.get()
        .map(body => new actions.LoadSuccessAction(body))
        .catch((err) => Observable.of(new actions.LoadFailureAction(err)))
      );

    this.loadSuccess$ = this.actions$
      .ofType(actions.LOAD_SUCCESS)
      .map((action: actions.LoadSuccessAction) => new appActions.InitializeSuccessAction(action.payload));

    this.loadConfig$ = this.actions$
      .ofType(actions.LOAD_CONFIG)
      .switchMap(() => this.profileResource.get()
        .map(body => new actions.LoadConfigSuccessAction(body))
        .catch((err) => Observable.of(new actions.LoadConfigFailureAction(err)))
      );

    this.loadConfigSuccess$ = this.actions$
      .ofType(actions.LOAD_CONFIG_SUCCESS)
      .map((action: actions.LoadConfigSuccessAction) => new appActions.ReInitializeSuccessAction(action.payload));
  }
}
