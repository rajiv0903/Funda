import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, Effect } from '@ngrx/effects';

import * as appActions from '../actions/app.actions'
import * as trActions from '../actions/transaction-request.actions'
import * as profileActions from '../actions/profile.actions';
import { ServerLoggerService } from '../../shared/services/server-logger.service';
import { StartupService } from '../../shared/services/startup.service';
import { LoggerService } from '../../shared/services/logger.service';
import { Observable } from 'rxjs/Observable';
import { enableWS } from '../../shared/constants/system.constant';
import { UserType } from '../../shared/enums/user-type.enum';
import { environment } from '../../../environments/environment';

@Injectable()
export class AppEffects {

  @Effect()
  initialize$;

  @Effect()
  initializeSuccess$;

  @Effect()
  reInitializeSuccess$;

  @Effect()
  failure$;

  constructor(
    private actions$: Actions,
    private router: Router,
    private startupService: StartupService,
    private logger: LoggerService,
    private serverLoggerService: ServerLoggerService
  ) {
    this.initialize$ = this.actions$
      .ofType(appActions.INITIALIZE)
      .map(() => new profileActions.LoadAction());

    this.initializeSuccess$ = this.actions$
      .ofType(appActions.INITIALIZE_SUCCESS)
      .mergeMap((action: appActions.InitializeSuccessAction) => {
        serverLoggerService.startLogPosting();
        startupService.setProfileConfigs();
        if (enableWS) {
          let userType: UserType;
          if (action.payload.fannieMaeUser) {
            userType = UserType.INTERNAL;
          } else {
            userType = UserType.EXTERNAL;
          }
          startupService.initAndConnectWS(userType);
        } else {
          this.logger.info('WS feature disabled');
        }
        if (action.payload.fannieMaeUser) {
          this.logger.info('Trader Logged in : ');
          startupService.setTraderCName();
          this.router.navigateByUrl('/pricing');
        } else {
          this.logger.info('Lender Logged in : ');
          this.router.navigateByUrl('/trading');
        }
        return Observable.empty();
      });
    this.reInitializeSuccess$ = this.actions$
      .ofType(appActions.RE_INITIALIZE_SUCCESS)
      .switchMap((action: appActions.ReInitializeSuccessAction) => {
        startupService.reload();
        return Observable.of(new trActions.LoadAction());
      });

    this.failure$ = this.actions$
      .ofType(appActions.FAILURE)
      .switchMap((action: appActions.FailureAction) => {
        let act = Observable.empty();
        if (action.payload.status !== 400) {
          act = Observable.of(new trActions.StopPollingAction());
        }
        return act;
      });
  }
}
