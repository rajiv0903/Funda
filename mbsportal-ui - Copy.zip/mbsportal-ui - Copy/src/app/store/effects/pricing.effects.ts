/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';
import { Observable } from 'rxjs/Rx';

import * as actions from '../actions/pricing.actions'
import { PricingResource } from '../../lender-trading/product-select/pricing.resource';

@Injectable()
export class PricingEffects {

  @Effect()
  load$;

  constructor(
    private actions$: Actions,
    private pricingResource: PricingResource
  ) {

    this.load$ = this.actions$
      .ofType(actions.LOAD)
      .switchMap((action: actions.LoadAction) => this.pricingResource.get(action.payload)
        .map(p => p.sort((a, b) => parseFloat(a.passThroughRate) - parseFloat(b.passThroughRate)))
        .map(body => new actions.LoadSuccessAction(body))
        .catch((err) => Observable.of(new actions.LoadFailureAction(err)))
      );

  }
}
