import { TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs/Rx';
import { provideMockActions } from '@ngrx/effects/testing';
import { Response, ResponseOptions, ResponseType } from '@angular/http';

import { TradeEffects } from './trade.effects';
import * as tradeActions from '../actions/trade.actions'
import * as trActions from '../actions/transaction-request.actions';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { UserProfileService } from '../../shared/services/user-profile.service';
import { TradeResource } from '../../trades-history/trade.resource';
import { cold, hot } from 'jasmine-marbles';
import { StoreModule } from '@ngrx/store';
import { getProfileReducerMock } from '../../util/stubs/mock-profile-reducer';
import { RoleType } from '../../shared/enums/role-type.enum';
import { UserType } from '../../shared/enums/user-type.enum';
import { deepCopy } from '../../../test';
import { TradeService } from '../../shared/services/trade.service';

describe('TradeEffects', () => {
  let effects: TradeEffects, tradeResource;
  let actions: Observable<any>;
  let userProfileService;
  const mockTrades = deepCopy(require('../../../assets/data/trades.json'));

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot({
          tradeEffects: mockTrades,
          profile: getProfileReducerMock(RoleType.TRADER)
        })
      ],
      providers: [
        TradeEffects,
        provideMockActions(() => actions),
        {
          provide: TradeResource,
          useValue: jasmine.createSpyObj('tradeResource', ['query'])
        },
        UserProfileService,
        HttpClient,
        HttpHandler,
        TradeService
      ]
    })
  });

  beforeEach(() => {
    effects = TestBed.get(TradeEffects);
    tradeResource = TestBed.get(TradeResource);
    userProfileService = TestBed.get(UserProfileService);
  });

  it('should return a LOAD_SUCCESS action type, on success for lender', () => {
    const tradesToReturn = new Response(
      new ResponseOptions(
        {
          body: mockTrades
        }
      )
    );

    spyOnProperty(userProfileService, 'userType', 'get').and.returnValue(UserType.EXTERNAL);
    tradeResource.query.and.returnValue(Observable.of(tradesToReturn.json()));
    actions = hot('--a-', {
        'a': new tradeActions.LoadAction({
          acceptedTrades: true,
          sortBy: 'submissionDate',
          sortOrder: 'desc',
          pageIndex: 1,
          pageSize: 25
        })
      });
    const expected = cold('--b', {
      'b': new tradeActions.LoadSuccessAction(tradesToReturn.json())
    });
    expect(effects.load$).toBeObservable(expected);
  });

  it('should return a LOAD_SUCCESS, on success for trader', () => {
    const tradesToReturn = new Response(
      new ResponseOptions(
        {
          body: mockTrades
        }
      )
    );

    spyOnProperty(userProfileService, 'userType', 'get').and.returnValue(UserType.INTERNAL);

    tradeResource.query.and.returnValue(Observable.of(tradesToReturn.json()));

    actions = hot('--a-', {
      'a': new tradeActions.LoadAction({
        acceptedTrades: true,
        sortBy: 'submissionDate',
        sortOrder: 'desc',
        pageIndex: 1,
        pageSize: 3
      })
    });

    const expected = cold('--b', {
      'b': new tradeActions.LoadSuccessAction(tradesToReturn.json()),
    });

    expect(effects.load$).toBeObservable(expected);
  });

  it('should return a UPDATE_FAILURE action type, on failure', () => {
    const tradesToReturn = new Response(
      new ResponseOptions(
        {
          status: 500,
          type: ResponseType.Error,
          body: {
            error: 'some error'
          }
        }
      )
    );

    tradeResource.query.and.returnValue(Observable.throw(tradesToReturn.json()));

    const expected = cold('--b', {'b': new tradeActions.LoadFailureAction(tradesToReturn.json())});

    actions = hot('--a-', {
      'a': new tradeActions.LoadAction({
        acceptedTrades: true,
        sortBy: 'submissionDate',
        sortOrder: 'desc',
          pageIndex: 1,
          pageSize: 3
      })
    });

    expect(effects.load$).toBeObservable(expected);
  });

});
