import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { Observable } from 'rxjs/Rx';
import { provideMockActions } from '@ngrx/effects/testing';
import { Response, ResponseOptions, ResponseType } from '@angular/http';

import { TransactionRequestEffects } from './transaction-request.effects';
import * as trActions from '../actions/transaction-request.actions'
import { UserProfileService } from '../../shared/services/user-profile.service';
import { StoreModule } from '@ngrx/store';
import { transactionRequestReducer, TransactionRequestsState } from '../reducers/transaction-request.reducer';
import { TransactionRequestResource } from '../../shared/resources/transaction-request.resource';
import { TransactionRequestService } from '../../shared/services/transaction-request.service';
import { cold, hot } from 'jasmine-marbles';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { pollingInterval, requestDebounceTime } from '../../shared/constants/system.constant';
import { LoggerService } from '../../shared/services/logger.service';
import { LocalStorageService } from '../../shared/services/local-storage.service';
import { DatePipe } from '@angular/common';
import { getProfileReducerMock } from '../../util/stubs/mock-profile-reducer';
import { RoleType } from '../../shared/enums/role-type.enum';
import { UserType } from '../../shared/enums/user-type.enum';
import { deepCopy } from '../../../test';
import { StompRService } from '@stomp/ng2-stompjs';


describe('TransactionRequestEffects', () => {
  let effects: TransactionRequestEffects, transRequestResource, transRequestService;
  let actions;
  let userProfileService;
  const mockTransactionRequests = deepCopy(require('../../../assets/data/transaction-requests.json'));

  const transaction = {
    'transReqId': '17H00001',
    'product': {
      'productId': {
        'identifier': 1,
        'sourceType': 'PU',
        'type': 'MBS'
      }
    },
    'tradeCouponRate': '4.000',
    'tradeBuySellType': 'SELL',
    'stateType': 'LENDER_OPEN',
    'tradeSettlementDate': (new Date()).toISOString().slice(0, 10)
  };

  const mockTransactionRequestDefaultState: TransactionRequestsState = {
    isLoading: false,
    loaded: false,
    isCreating: false,
    isUpdating: {},
    isPolling: false,
    shouldPoll: true,
    lastPollTimestamp: '',
    entities: [ transaction ],
    error: null
  };

  const mockTransactionRequestReducer = (transactionRequestsState, action) => {
    return transactionRequestReducer(mockTransactionRequestDefaultState, action);
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot({
          transactionRequests: mockTransactionRequestReducer,
          profile: getProfileReducerMock(RoleType.TRADER)
        })
      ],
      providers: [
        TransactionRequestEffects,
        provideMockActions(() => actions),
        LoggerService,
        LocalStorageService,
        UserProfileService,
        {
          provide: TransactionRequestResource,
          useValue: jasmine.createSpyObj('transRequestResource', ['query', 'create', 'update', 'poll', 'get'])
        },
        TransactionRequestService,
        DatePipe,
        StompRService
      ]
    })
  });

  beforeEach(() => {
    effects = TestBed.get(TransactionRequestEffects);
    transRequestResource = TestBed.get(TransactionRequestResource);
    transRequestService = TestBed.get(TransactionRequestService);
    userProfileService = TestBed.get(UserProfileService);
  });

  it('should return a LOAD_SUCCESS action type, on success', () => {
    const transRequestsToReturn = new Response(
      new ResponseOptions(
        {
          body: mockTransactionRequests
        }
      )
    );

    transRequestResource.query.and.returnValue(Observable.of(transRequestsToReturn.json()));

    actions = hot('--a-', {'a': new trActions.LoadAction()});
    const expected = cold('--b-', {
      'b': new trActions.LoadSuccessAction(transRequestsToReturn.json()),
    });

    expect(effects.load$).toBeObservable(expected);

  });

  it('should return a LOAD_FAILURE action type, on LOAD', () => {
    const transRequestsToReturn = new Response(
      new ResponseOptions(
        {
          status: 500,
          type: ResponseType.Error,
          body: {
            error: 'some error'
          }
        }
      )
    );

    transRequestResource.query.and.returnValue(Observable.throw(transRequestsToReturn.json()));

    const expected = cold('--b', {'b': new trActions.LoadFailureAction(transRequestsToReturn.json())});

    actions = hot('--a-', {'a': new trActions.LoadAction()});

    expect(effects.load$).toBeObservable(expected);
  });

  it('should return a PollSuccess action type, on Poll Action', fakeAsync(() => {
    const pollResponse = {
      'eventsAvailable': false,
      'serverTime': '2017-12-0815:02:25'
    };

    spyOnProperty(userProfileService, 'userType', 'get').and.returnValue(UserType.INTERNAL);

    transRequestResource.poll.and.returnValue(Observable.of(pollResponse));

    actions = new ReplaySubject(1);
    actions.next(new trActions.PollAction());

    effects.poll$.subscribe(result => {
      expect(result).toEqual(new trActions.PollSuccessAction(pollResponse));
    });
    tick(pollingInterval);
  }));

  it('should return a PollFailure action type, on Poll Action', fakeAsync(() => {
    const transRequestsToReturn = new Response(
      new ResponseOptions(
        {
          status: 500,
          type: ResponseType.Error,
          body: {
            error: 'some error'
          }
        }
      )
    );

    spyOnProperty(userProfileService, 'userType', 'get').and.returnValue(UserType.INTERNAL);

    transRequestResource.poll.and.returnValue(Observable.throw(transRequestsToReturn.json()));

    actions = new ReplaySubject(1);

    actions.next(new trActions.PollAction());

    effects.poll$.subscribe(result => {
      expect(result).toEqual(new trActions.PollFailureAction(transRequestsToReturn.json()));
    });

    tick(pollingInterval);
  }));

  it('should return a PollAction action type, on Poll Success', () => {
    const expected = cold('--b', {'b': new trActions.PollAction()});

    actions = hot('--a-', {'a': new trActions.PollSuccessAction({'eventsAvailable': false, 'serverTime': '2017-12-0815:02:25'})});

    expect(effects.pollSuccess$).toBeObservable(expected);

  });

  it('should return a LoadAction action type, on Poll Success for trader', () => {
    spyOnProperty(userProfileService, 'userType', 'get').and.returnValue(UserType.INTERNAL);

    const expected = cold('--b', {'b': new trActions.LoadAction()});

    actions = hot('--a-', {'a': new trActions.PollSuccessAction({'eventsAvailable': true, 'serverTime': '2017-12-0815:02:25'})});

    expect(effects.pollSuccess$).toBeObservable(expected);
  });
  //
  it('should return a LoadOneAction action type, on Poll Success for lender', () => {
    spyOnProperty(userProfileService, 'userType', 'get').and.returnValue(UserType.EXTERNAL);

    const expected = cold('--b', {'b': new trActions.LoadOneAction()});

    actions = hot('--a', {'a': new trActions.PollSuccessAction({'eventsAvailable': true, 'serverTime': '2017-12-0815:02:25'})});

    expect(effects.pollSuccess$).toBeObservable(expected);
  });

  it('should return a PollAction type, on POLL_FAILURE', () => {
    const expected = cold('--b', {'b': new trActions.PollAction()});

    actions = hot('--a-', {'a': new trActions.PollFailureAction({})});

    expect(effects.pollFailure$).toBeObservable(expected);
  });

  it('should return a LoadOneSuccess action type, on LOAD_ONE action', () => {
    const transRequestToReturn = new Response(
      new ResponseOptions(
        {
          body: mockTransactionRequests[0]
        }
      )
    );

    transRequestResource.get.and.returnValue(Observable.of(transRequestToReturn.json()));

    const expected = cold('--b-', {'b': new trActions.LoadOneSuccessAction(transRequestToReturn.json())});

    actions = hot('--a-', {'a': new trActions.LoadOneAction()});

    expect(effects.loadOne$).toBeObservable(expected);
  });

  it('should return a LoadOneFailure action type, on LOAD_ONE failure', () => {
    const transRequestsToReturn = new Response(
      new ResponseOptions(
        {
          status: 500,
          type: ResponseType.Error,
          body: {
            error: 'some error'
          }
        }
      )
    );

    transRequestResource.get.and.returnValue(Observable.throw(transRequestsToReturn.json()));

    const expected = cold('--b', {'b': new trActions.LoadOneFailureAction(transRequestsToReturn.json())});

    actions = hot('--a-', {'a': new trActions.LoadOneAction()});

    expect(effects.loadOne$).toBeObservable(expected);
  });

  it('should return a CREATE_SUCCESS action type, on success', fakeAsync(() => {
    const transRequestToReturn = new Response(
      new ResponseOptions(
        {
          body: mockTransactionRequests[0]
        }
      )
    );

    transRequestResource.create.and.returnValue(Observable.of(transRequestToReturn.json()));

    actions = new ReplaySubject(1);

    actions.next(new trActions.CreateAction(mockTransactionRequests[0]));

    effects.create$.subscribe(result => {
      expect(result).toEqual(new trActions.CreateSuccessAction(transRequestToReturn.json()));
    });
    tick(requestDebounceTime);

  }));

  it('should return a CREATE_FAILURE action type, on failure', fakeAsync(() => {
    const transRequestsToReturn = new Response(
      new ResponseOptions(
        {
          status: 500,
          type: ResponseType.Error,
          body: {
            error: 'some error'
          }
        }
      )
    );

    transRequestResource.create.and.returnValue(Observable.throw(transRequestsToReturn.json()));

    const expected = new trActions.CreateFailureAction(transRequestsToReturn.json());

    actions = new ReplaySubject(1);

    actions.next(new trActions.CreateAction(mockTransactionRequests[0]));

    effects.create$.subscribe(result => {
      expect(result).toEqual(expected);
    });
    tick(requestDebounceTime);

  }));

  it('should return an UPDATE_SUCCESS action type, on success', fakeAsync(() => {
    const transRequestsToReturn = new Response(
      new ResponseOptions(
        {
          body: mockTransactionRequests[0]
        }
      )
    );

    transRequestResource.update.and.returnValue(Observable.of(transRequestsToReturn.json()));

    const expected = new trActions.UpdateSuccessAction(transRequestsToReturn.json());

    actions = new ReplaySubject(1);

    actions.next(new trActions.UpdateAction(mockTransactionRequests[0]));

    effects.update$.subscribe(result => {
      expect(result).toEqual(expected);
    });
    tick(requestDebounceTime);

  }));

  it('should return a UPDATE_FAILURE action type, on failure', fakeAsync(() => {

    const transRequestsToReturn = new Response(
      new ResponseOptions(
        {
          status: 500,
          type: ResponseType.Error,
          body: {
            error: 'some error'
          }
        }
      )
    );

    transRequestResource.update.and.returnValue(Observable.throw(transRequestsToReturn.json()));

    const expected = new trActions.UpdateFailureAction({
      ...transRequestsToReturn.json(),
      transReqId: mockTransactionRequests[0].transReqId
    });

    actions = new ReplaySubject(1);

    actions.next(new trActions.UpdateAction(mockTransactionRequests[0]));

    effects.update$.subscribe(result => {
      expect(expected.type).toBe(result.type);
      expect(expected.payload).toEqual(result.payload);
    });
    tick(requestDebounceTime);
  }));



});
