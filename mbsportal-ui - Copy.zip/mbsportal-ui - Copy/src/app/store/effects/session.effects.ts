/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import {Injectable} from '@angular/core';
import {Actions, Effect} from '@ngrx/effects';
import {Observable} from 'rxjs/Rx';

import * as actions from '../actions/session.actions';
import {UserProfileService} from '../../shared/services/user-profile.service';
import {LoggerService} from '../../shared/services/logger.service';
import {UserType} from '../../shared/enums/user-type.enum';
import {
  lenderTimerReset, traderBusinessHoursReset, traderBusinessHrsEnd, traderBusinessHrsPreStart,
  traderBusinessHrsStart, traderNonBusinessHourReset
} from '../../shared/constants/business.constant';
import {FailureAction} from '../actions/app.actions';
import { TimeObject } from '../../shared/interfaces/time-object.interface';

@Injectable()
export class SessionEffects {

  @Effect()
  resetTimer$;

  @Effect()
  timerExpired$;

  constructor(
    private actions$: Actions,
    private profile: UserProfileService,
    private loggerService: LoggerService
  ) {

    const getResetTimer = (currentServerTime: TimeObject): number => {
      let timerReset = lenderTimerReset;

      if (this.profile.userType === UserType.INTERNAL) {
        if (traderBusinessHrsPreStart < currentServerTime.hours && currentServerTime.hours < traderBusinessHrsEnd) {
          if ((traderBusinessHrsPreStart < currentServerTime.hours || traderBusinessHrsPreStart === currentServerTime.hours) &&
            (currentServerTime.hours < traderBusinessHrsStart || currentServerTime.hours === traderBusinessHrsStart)) {
            timerReset = traderBusinessHoursReset;
          } else {
            if (traderBusinessHrsEnd - currentServerTime.hours > 1) {
              const diff = ((traderBusinessHrsEnd - currentServerTime.hours) * 3600 * 1000) - (currentServerTime.minutes * 60 * 1000)
                - (currentServerTime.seconds * 1000);
              timerReset = diff;
            } else {
              timerReset = traderNonBusinessHourReset;
            }
          }
        } else {
          timerReset = traderNonBusinessHourReset;
        }
      }
      return timerReset;
    };

    this.resetTimer$ = this.actions$
      .ofType(actions.TIMER_RESET)
      .switchMap((action: actions.TimerResetAction) => {
      const timer = getResetTimer(action.payload);
        loggerService.info('Resetting the session timer to ' + timer);
        return Observable.timer(timer).switchMap(() => Observable.of(new actions.TimerExpiredAction()))
      });

    this.timerExpired$ = this.actions$
      .ofType(actions.TIMER_EXPIRED)
      .do(() => loggerService.warn('Activity not detected! Session Timer has expired'))
      .map(() => new FailureAction({'status' : 401}));
  }
}
