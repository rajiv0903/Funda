import { TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs/Rx';
import { provideMockActions } from '@ngrx/effects/testing';
import { Response, ResponseOptions, ResponseType } from '@angular/http';

import * as productActions from '../actions/product.actions'
import { UserProfileService } from '../../shared/services/user-profile.service';
import { ProductEffects } from './product.effects';
import { ProductResource } from '../../lender-trading/product-select/product.resource';
import { cold, hot } from 'jasmine-marbles';
import { deepCopy } from '../../../test';

describe('ProductEffects', () => {
  let effects: ProductEffects, productResource;
  let actions: Observable<any>;
  const mockProducts = deepCopy(require('../../../assets/data/products.json'));

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ProductEffects,
        provideMockActions(() => actions),
        {
          provide: ProductResource,
          useValue: jasmine.createSpyObj('ProductResource', ['query'])
        },
        UserProfileService
      ]
    })
  });

  beforeEach(() => {
    effects = TestBed.get(ProductEffects);
    productResource = TestBed.get(ProductResource);
  });

  it('should return a LOAD_SUCCESS action type, on success', () => {
    const productsToReturn = new Response(
      new ResponseOptions(
        {
          body: mockProducts
        }
      )
    );

    productResource.query.and.returnValue(Observable.of(productsToReturn.json()));

    const expected = cold('--b', {'b': new productActions.LoadSuccessAction(productsToReturn.json())});

    actions = hot('--a-', {'a': new productActions.LoadAction()});

    expect(effects.load$).toBeObservable(expected);

  });

  it('should return a UPDATE_FAILURE action type, on failure', () => {
    const productsToReturn = new Response(
      new ResponseOptions(
        {
          status: 500,
          type: ResponseType.Error,
          body: {
            error: 'some error'
          }
        }
      )
    );

    productResource.query.and.returnValue(Observable.throw(productsToReturn.json()));

    const expected = cold('--b', {'b': new productActions.LoadFailureAction(productsToReturn.json())});

    actions = hot('--a-', {'a': new productActions.LoadAction()});

    expect(effects.load$).toBeObservable(expected);
  });

});
