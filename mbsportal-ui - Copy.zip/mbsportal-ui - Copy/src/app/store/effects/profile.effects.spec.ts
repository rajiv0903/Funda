import { TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs/Rx';
import { provideMockActions } from '@ngrx/effects/testing';
import { Response, ResponseOptions, ResponseType } from '@angular/http';

import * as profileActions from '../actions/profile.actions';
import * as appActions from '../actions/app.actions'
import { UserProfileService } from '../../shared/services/user-profile.service';
import { ProfileEffects } from './profile.effects';
import { ProfileResource } from '../../shared/resources/profile.resource';
import { cold, hot } from 'jasmine-marbles';
import { deepCopy } from '../../../test';

describe('ProfileEffects', () => {
  let effects: ProfileEffects, profileResource;
  let actions: Observable<any>;
  const mockLenderProfile = deepCopy(require('../../../assets/data/lender-profile.json'));

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ProfileEffects,
        provideMockActions(() => actions),
        {
          provide: ProfileResource,
          useValue: jasmine.createSpyObj('ProfileResource', ['get'])
        },
        UserProfileService
      ]
    })
  });

  beforeEach(() => {
    effects = TestBed.get(ProfileEffects);
    profileResource = TestBed.get(ProfileResource);
  });

  it('should return a LOAD_SUCCESS action type, on success', () => {
    const profileToReturn = new Response(
      new ResponseOptions(
        {
          body: mockLenderProfile
        }
      )
    );

    profileResource.get.and.returnValue(Observable.of(profileToReturn.json()));

    const expected = cold('--b', {'b': new profileActions.LoadSuccessAction(profileToReturn.json())});

    actions = hot('--a-', {'a': new profileActions.LoadAction()});

    expect(effects.load$).toBeObservable(expected);

  });

  it('should return a UPDATE_FAILURE action type, on failure', () => {
    const profileToReturn = new Response(
      new ResponseOptions(
        {
          status: 500,
          type: ResponseType.Error,
          body: {
            error: 'some error'
          }
        }
      )
    );

    profileResource.get.and.returnValue(Observable.throw(profileToReturn.json()));

    const expected = cold('--b', {'b': new profileActions.LoadFailureAction(profileToReturn.json())});

    actions = hot('--a-', {'a': new profileActions.LoadAction()});

    expect(effects.load$).toBeObservable(expected);
  });

  it('should return a INITIALIZE_SUCCESS action type, on LOAD_SUCCESS', () => {
    const profileToReturn = new Response(
      new ResponseOptions(
        {
          body: mockLenderProfile
        }
      )
    );

    profileResource.get.and.returnValue(Observable.of(profileToReturn.json()));

    const expected = cold('--b', {'b': new appActions.InitializeSuccessAction(profileToReturn.json())});

    actions = hot('--a-', {'a': new profileActions.LoadSuccessAction(profileToReturn.json())});

    expect(effects.loadSuccess$).toBeObservable(expected);
  });

});
