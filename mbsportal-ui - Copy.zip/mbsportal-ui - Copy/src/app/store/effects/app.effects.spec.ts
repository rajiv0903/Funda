import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { hot, cold } from 'jasmine-marbles';

import { Observable } from 'rxjs/Rx';

import * as profileActions from '../actions/profile.actions'
import * as appActions from '../actions/app.actions'
import { UserProfileService } from '../../shared/services/user-profile.service';
import { AppEffects } from 'app/store/effects/app.effects';
import { Router } from '@angular/router';
import { StartupService } from '../../shared/services/startup.service';
import { StoreModule } from '@ngrx/store';
import { LoggerService } from '../../shared/services/logger.service';
import { LocalStorageService } from '../../shared/services/local-storage.service';
import { DatePipe } from '@angular/common';
import { ServerLoggerService } from '../../shared/services/server-logger.service';
import { ProfileResource } from '../../shared/resources/profile.resource';
import { StompRService } from '@stomp/ng2-stompjs';
import { WSService } from '../../shared/services/ws.service';
import { TransactionRequestService } from '../../shared/services/transaction-request.service';
import { LoggerResource } from '../../shared/resources/logger.resource';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { getProfileReducerMock } from '../../util/stubs/mock-profile-reducer';
import { RoleType } from '../../shared/enums/role-type.enum';
import { ModalService } from '../../shared/services/modal.service';
import { BsModalService, ComponentLoaderFactory, PositioningService } from 'ngx-bootstrap';

class MockProfileResource  {
}

describe('AppEffects', () => {
  let effects: AppEffects;
  let actions: Observable<any>;

  class MockRouter {
    navigate = jasmine.createSpy('navigate');
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot({
          profile: getProfileReducerMock(RoleType.LENDER)
        })
      ],
      providers: [
        AppEffects,
        StartupService,
        provideMockActions(() => actions),
        {
          provide: Router,
          useClass: MockRouter
        },
        UserProfileService,
        StompRService,
        LoggerService,
        WSService,
        TransactionRequestService,
        LoggerResource,
        HttpClient,
        HttpHandler,
        LocalStorageService,
        ServerLoggerService,
        {
          provide: ProfileResource,
          useClass: MockProfileResource
        },
        DatePipe,
        ModalService,
        BsModalService,
        ComponentLoaderFactory,
        PositioningService
      ]
    });
    effects = TestBed.get(AppEffects);
  });

  it('should return a profile LOAD_ACTION action type, on app InitializeAction', () => {
    actions = hot('--a-', {a: new appActions.InitializeAction()});
    const expected = cold('--b', {b: new profileActions.LoadAction()});

    expect(effects.initialize$).toBeObservable(expected);
  });

});
