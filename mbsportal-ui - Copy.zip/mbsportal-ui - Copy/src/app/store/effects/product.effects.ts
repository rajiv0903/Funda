import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';
import { Observable } from 'rxjs/Rx';

import * as actions from '../actions/product.actions'
import { ProductResource } from '../../lender-trading/product-select/product.resource';

@Injectable()
export class ProductEffects {

  @Effect()
  load$;

  constructor(
    private actions$: Actions,
    private productResource: ProductResource
  ) {

    this.load$ = this.actions$
      .ofType(actions.LOAD)
      .switchMap(() => this.productResource.query()
        .map(products => products.sort((a, b) => a.nameCodeSortOrder - b.nameCodeSortOrder))
        .map(body => new actions.LoadSuccessAction(body))
        .catch((err) => Observable.of(new actions.LoadFailureAction(err)))
      );

  }
}
