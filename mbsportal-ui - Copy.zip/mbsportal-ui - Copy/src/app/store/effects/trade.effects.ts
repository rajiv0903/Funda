import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';
import { Observable } from 'rxjs/Rx';

import * as actions from '../actions/trade.actions'
import { TradeResource } from '../../trades-history/trade.resource';
import { TradeService } from '../../shared/services/trade.service';

@Injectable()
export class TradeEffects {

  @Effect()
  load$;

  @Effect()
  export$;

  @Effect()
  exportSuccess$;

  constructor(
    private actions$: Actions,
    private tradeResource: TradeResource,
    private tradeService: TradeService
  ) {

    this.load$ = this.actions$
      .ofType(actions.LOAD)
      .switchMap((action: actions.LoadAction) => this.tradeResource.query(action.payload)
        .map(body => new actions.LoadSuccessAction(body))
        .catch((err) => Observable.of(new actions.LoadFailureAction(err)))
      );

    this.export$ = this.actions$
      .ofType(actions.EXPORT)
      .switchMap((action: actions.ExportAction) => this.tradeResource.exportQuery(action.payload)
        .map(body => new actions.ExportSuccessAction(body))
        .catch((err) => Observable.of(new actions.ExportFailureAction(err)))
      );

    this.exportSuccess$ = this.actions$
      .ofType(actions.EXPORT_SUCCESS)
      .switchMap((action: actions.ExportSuccessAction) => {
        this.tradeService.exportFile(action);
        return Observable.empty();
      });
  }
}
