import { TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs/Rx';
import { provideMockActions } from '@ngrx/effects/testing';
import { Response, ResponseOptions, ResponseType } from '@angular/http';

import * as pricingActions from '../actions/pricing.actions'
import { UserProfileService } from '../../shared/services/user-profile.service';
import { PricingEffects } from './pricing.effects';
import { PricingResource } from '../../lender-trading/product-select/pricing.resource';
import { cold, hot } from 'jasmine-marbles';
import { deepCopy } from '../../../test';

describe('PricingEffects', () => {
  let effects: PricingEffects, pricingResource;
  let actions: Observable<any>;
  const mockPricing = deepCopy(require('../../../assets/data/pricing.json'));

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PricingEffects,
        provideMockActions(() => actions),
        {
          provide: PricingResource,
          useValue: jasmine.createSpyObj('PricingResource', ['get'])
        },
        UserProfileService
      ]
    })
  });

  beforeEach(() => {
    effects = TestBed.get(PricingEffects);
    pricingResource = TestBed.get(PricingResource);
  });

  it('should return a LOAD_SUCCESS action type, on success', () => {
    const pricingToReturn = new Response(
      new ResponseOptions(
        {
          body: mockPricing
        }
      )
    );

    pricingResource.get.and.returnValue(Observable.of(pricingToReturn.json()));

    actions = hot('--a-', {a: new pricingActions.LoadAction(mockPricing)});

    const expected = cold('--b', { b: new pricingActions.LoadSuccessAction(pricingToReturn.json())});

    expect(effects.load$).toBeObservable(expected);

  });

  it('should return a UPDATE_FAILURE action type, on failure', () => {
    const pricingToReturn = new Response(
      new ResponseOptions(
        {
          status: 500,
          type: ResponseType.Error,
          body: {
            error: 'some error'
          }
        }
      )
    );

    pricingResource.get.and.returnValue(Observable.throw(pricingToReturn.json()));

    actions = hot('--a-', {a: new pricingActions.LoadAction(mockPricing)});

    const expected = cold('--b', { b: new pricingActions.LoadFailureAction(pricingToReturn.json())});

    expect(effects.load$).toBeObservable(expected);

  });

});
