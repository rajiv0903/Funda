import { Pricing } from './pricing.model';
export class ProductId {
  identifier: number;
  sourceType: string;
  type: string;
}

export class Product {
  productId: ProductId;
  nameCode?: string;
  nameCodeSortOrder?: number;
  agencyType?: string;
  securityTerm?: number;
  pricing?: Pricing[];
}
