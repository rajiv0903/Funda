import { ProductId } from './product.model';

export interface Pricing {
  productId: ProductId;
  passThroughRate: string;
  marketTermType: string;
  settlementDate: string;
  active: boolean;
}
