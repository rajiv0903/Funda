import { Product } from './product.model';

export const LENDER_OPEN = 'LENDER_OPEN';
export const TRADER_PRICED = 'TRADER_PRICED';
export const TRADER_REPRICED = 'TRADER_REPRICED';
export const TRADER_PASSED = 'TRADER_PASSED';
export const LENDER_ACCEPTED = 'LENDER_ACCEPTED';
export const LENDER_REJECTED = 'LENDER_REJECTED';
export const TRADER_CONFIRMED = 'TRADER_CONFIRMED';
export const TRADER_REJECTED = 'TRADER_REJECTED';
export const PENDING_EXECUTION = 'PENDING_EXECUTION';
export const EXECUTION_IN_PROGRESS = 'EXECUTION_IN_PROGRESS';
export const EXECUTED = 'EXECUTED';
export const LENDER_TIMEOUT = 'LENDER_TIMEOUT';
export const TRADER_TIMEOUT = 'TRADER_TIMEOUT';
export const ERROR = 'ERROR';

export class TransactionRequest {
  transReqId?: string;
  lenderEntityShortName?: string;
  dealerOrgName?: string;
  product: Product;
  lenderId?: string;
  traderId?: string;
  traderName?: string;
  stateType?: string;
  pricePercent?: string;
  streamPricePercentHandleText?: string;
  streamPricePercentTicksText?: string;
  pricePercentHandleText?: string;
  pricePercentTicksText?: string;
  tradeAmount?: string;
  tradeBuySellType: string;
  tradeCouponRate: string;
  tradeSettlementDate: string;
  submissionDate?: string;
  lastPublishTime?: string;
  lastUpdatedDate?: string;
  updateNeeded?: boolean;
  activeVersion?: number;
  oboLenderSellerServicerNumber?: string;
  tspShortName?: string;
}
