import { TransactionRequest } from './transaction-request.model';

export class Trade extends TransactionRequest {
  tradeSubPortfolioShortName?: string;
  tradeSrcPrimaryId?: string;
  lenderEntityName: string;
  lenderName: string;
  traderName: string;
  tradeDate: Date;
  nameCode: string;
}
