/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { Role } from '../../shared/enums/role.enum';
import { UserConfig } from './user-config';

export interface Profile {
  userName: string;
  emailAddress: string;
  firstName: string;
  lastName: string;
  fannieMaeUser: boolean;
  institutionId: string;
  mobileNumber: number;
  workNumber: number;
  roles: Array<{
    name: Role,
    appCode: string,
    permissions: any[]
  }>;
  tspLenders: Profile[];
  tspUser: boolean;
  dealerOrgName: string;
  dealerOrgId?: string;
  partyShortName?: string;
  sellerServicerNo?: string;
  userConfig: UserConfig;
}
