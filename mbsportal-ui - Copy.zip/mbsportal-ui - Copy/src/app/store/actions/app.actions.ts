import { Action } from '@ngrx/store';
import { Profile } from '../models/profile.model';
import { ActionWithPayload } from '../index';

export const INITIALIZE = '[App] Initialize';
export const INITIALIZE_SUCCESS = '[App] Initialize Success';
export const RE_INITIALIZE = '[App] Re-Initialize';
export const RE_INITIALIZE_SUCCESS = '[App] Re-Initialize Success';
export const FAILURE = '[App] Failure';

export class InitializeAction implements Action {
  readonly type = INITIALIZE;
}

export class InitializeSuccessAction implements ActionWithPayload<Profile> {
  readonly type = INITIALIZE_SUCCESS;

  constructor(public payload: Profile) { }
}
export class ReInitializeAction implements Action {
  readonly type = RE_INITIALIZE;
}

export class ReInitializeSuccessAction implements ActionWithPayload<Profile> {
  readonly type = RE_INITIALIZE_SUCCESS;

  constructor(public payload: Profile) { }
}

export class FailureAction implements ActionWithPayload<any> {
  readonly type = FAILURE;

  constructor(public payload: any) { }
}

export type ActionsTypes =
  InitializeAction
  | InitializeSuccessAction
  | ReInitializeAction
  | ReInitializeSuccessAction
  | FailureAction
