import { Action } from '@ngrx/store';
import { Pricing } from '../models/pricing.model';
import { ProductId } from '../models/product.model';
import { ActionWithPayload } from '../index';

export const LOAD = '[Pricing] Load';
export const LOAD_SUCCESS = '[Pricing] Load Success';
export const LOAD_FAILURE = '[Pricing] Load Failure';

export class LoadAction implements ActionWithPayload<ProductId> {
  readonly type = LOAD;
  constructor(public payload: ProductId) { }
}

export class LoadSuccessAction implements ActionWithPayload<Pricing[]> {
  readonly type = LOAD_SUCCESS;

  constructor(public payload: Pricing[]) { }
}

export class LoadFailureAction implements ActionWithPayload<any> {
  readonly type = LOAD_FAILURE;

  // TODO fix the type when errors are consistent
  constructor(public payload: any) { }
}

export type ActionsTypes
  = LoadAction
  | LoadSuccessAction
  | LoadFailureAction
