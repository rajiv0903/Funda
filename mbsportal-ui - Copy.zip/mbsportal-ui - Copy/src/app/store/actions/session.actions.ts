/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { ActionWithPayload } from '../index';
import { TimeObject } from '../../shared/interfaces/time-object.interface';

export const TIMER_RESET = '[Session] Timer Reset';
export const TIMER_EXPIRED = '[Session] Timer Expired';

export class TimerResetAction implements ActionWithPayload<TimeObject> {
  readonly type = TIMER_RESET;

  constructor(public payload: TimeObject) { }
}

export class TimerExpiredAction {
  readonly type = TIMER_EXPIRED;
}

export type ActionsTypes
  = TimerExpiredAction
  | TimerResetAction;
