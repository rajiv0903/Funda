import { Action } from '@ngrx/store';
import { Profile } from '../models/profile.model';
import { ActionWithPayload } from '../index';

export const LOAD = '[Profile] Load';
export const LOAD_SUCCESS = '[Profile] Load Success';
export const LOAD_FAILURE = '[Profile] Load Failure';
export const LOAD_CONFIG = '[Profile] Load Config';
export const LOAD_CONFIG_SUCCESS = '[Profile] Load Config Success';
export const LOAD_CONFIG_FAILURE = '[Profile] Load Config Failure';

export class LoadAction implements Action {
  readonly type = LOAD;
}

export class LoadSuccessAction implements ActionWithPayload<Profile> {
  readonly type = LOAD_SUCCESS;

  constructor(public payload: Profile) { }
}

export class LoadFailureAction implements ActionWithPayload<any> {
  readonly type = LOAD_FAILURE;

  // TODO fix the type when errors are consistent
  constructor(public payload: any) { }
}
export class LoadConfigAction implements Action {
  readonly type = LOAD_CONFIG;
}
export class LoadConfigSuccessAction implements ActionWithPayload<Profile> {
  readonly type = LOAD_CONFIG_SUCCESS;

  constructor(public payload: Profile) { }
}
export class LoadConfigFailureAction implements ActionWithPayload<any> {
  readonly type = LOAD_CONFIG_FAILURE;

  // TODO fix the type when errors are consistent
  constructor(public payload: any) { }
}

export type ActionsTypes
  = LoadAction
  | LoadSuccessAction
  | LoadFailureAction
  | LoadConfigAction
  | LoadConfigSuccessAction
  | LoadConfigFailureAction
