import { ActionWithPayload } from '../index';
import { TradesList, TradeExportList } from '../reducers/trade.reducer';

export const LOAD = '[Trades] Load';
export const LOAD_SUCCESS = '[Trades] Load Success';
export const LOAD_FAILURE = '[Trades] Load Failure';
export const EXPORT = '[TradesExport] Export';
export const EXPORT_SUCCESS = '[TradesExport] Export Success';
export const EXPORT_FAILURE = '[TradesExport] Export Failure';

export class LoadAction implements ActionWithPayload<{acceptedTrades: boolean, sortBy: string, sortOrder: string, pageIndex: number,
  pageSize: number}> {
  readonly type = LOAD;

  constructor(public payload: {acceptedTrades: boolean, sortBy: string, sortOrder: string, pageIndex: number, pageSize: number}) { }
}

export class LoadSuccessAction implements ActionWithPayload<TradesList> {
  readonly type = LOAD_SUCCESS;

  constructor(public payload: TradesList) { }
}

export class LoadFailureAction implements ActionWithPayload<any> {
  readonly type = LOAD_FAILURE;

  // TODO fix the type when errors are consistent
  constructor(public payload: any) { }
}
export class ExportAction
  implements
  ActionWithPayload<{
    acceptedTrades: boolean;
    sortBy: string;
    sortOrder: string;
    startDate: string;
    endDate: string;
    exportType: string;
    dateType: string;
  }> {
  readonly type = EXPORT;

  constructor(
    public payload: {
      acceptedTrades: boolean;
      sortBy: string;
      sortOrder: string;
      startDate: string;
      endDate: string;
      exportType: string;
      dateType: string;
    }
  ) { }
}

export class ExportSuccessAction implements ActionWithPayload<TradeExportList> {
  readonly type = EXPORT_SUCCESS;

  constructor(public payload: any) { }
}

export class ExportFailureAction implements ActionWithPayload<TradeExportList> {
  readonly type = EXPORT_FAILURE;

  // TODO fix the type when errors are consistent
  constructor(public payload: any) { }
}

export type ActionsTypes
  = LoadAction
  | LoadSuccessAction
  | LoadFailureAction
  | ExportAction
  | ExportSuccessAction
  | ExportFailureAction;
