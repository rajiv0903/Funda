import { Action } from '@ngrx/store';
import { Product } from '../models/product.model';
import { ActionWithPayload } from '../index';

export const LOAD = '[Products] Load';
export const LOAD_SUCCESS = '[Products] Load Success';
export const LOAD_FAILURE = '[Products] Load Failure';

export class LoadAction implements Action {
  readonly type = LOAD;
}

export class LoadSuccessAction implements ActionWithPayload<Product[]> {
  readonly type = LOAD_SUCCESS;

  constructor(public payload: Product[]) { }
}

export class LoadFailureAction implements ActionWithPayload<any> {
  readonly type = LOAD_FAILURE;

  // TODO fix the type when errors are consistent
  constructor(public payload: any) { }
}

export type ActionsTypes
  = LoadAction
  | LoadSuccessAction
  | LoadFailureAction
