import { Action } from '@ngrx/store';
import { TransactionRequest } from '../models/transaction-request.model';
import { ActionWithPayload } from '../index';
import { Price } from '../../shared/interfaces/price.interface';

export const LOAD = '[Transaction Requests] Load';
export const LOAD_SUCCESS = '[Transaction Requests] Load Success';
export const LOAD_FAILURE = '[Transaction Request] Load Failure';
export const LOAD_ONE = '[Transaction Requests] Load One';
export const LOAD_ONE_SUCCESS = '[Transaction Requests] Load One Success';
export const LOAD_ONE_FAILURE = '[Transaction Request] Load One Failure';
export const LOAD_ONE_AND_REPLACE = '[Transaction Requests] Load One And Replace In List';
export const POLL = '[Transaction Requests] Poll';
export const POLL_SUCCESS = '[Transaction Requests] Poll Success';
export const POLL_FAILURE = '[Transaction Request] Poll Failure';
export const CREATE = '[Transaction Request] Create';
export const CREATE_SUCCESS = '[Transaction Request] Create Success';
export const CREATE_FAILURE = '[Transaction Request] Create Failure';
export const UPDATE = '[Transaction Request] Update';
export const UPDATE_SUCCESS = '[Transaction Request] Update Success';
export const UPDATE_FAILURE = '[Transaction Request] Update Failure';
export const UPDATE_WS = '[Transaction Request] WS Update';
export const UPDATE_WS_SUCCESS = '[Transaction Request] WS Update Success';
export const DELETE_SUCCESS = '[Transaction Request] Delete Success';
export const DISMISS = '[Transaction Request] Dismiss';
export const START_POLLING = '[Transaction Request] Start Polling';
export const STOP_POLLING = '[Transaction Request] Stop Polling';
export const UPDATE_PRICE = '[Transaction Request] Update Price';


export class LoadAction implements Action {
  readonly type = LOAD;
}

export class LoadSuccessAction implements ActionWithPayload<TransactionRequest[]> {
  readonly type = LOAD_SUCCESS;

  constructor(public payload: TransactionRequest[]) { }
}

export class LoadFailureAction implements ActionWithPayload<any> {
  readonly type = LOAD_FAILURE;

  // TODO fix the type when errors are consistent
  constructor(public payload: any) { }
}

export class LoadOneAction implements Action {
  readonly type = LOAD_ONE;
}

export class LoadOneAndReplaceAction implements ActionWithPayload<{transReqId: string}> {
  readonly type = LOAD_ONE_AND_REPLACE;

  constructor(public payload: {transReqId: string}) { }
}

export class LoadOneSuccessAction implements ActionWithPayload<TransactionRequest> {
  readonly type = LOAD_ONE_SUCCESS;

  constructor(public payload: TransactionRequest) { }
}

export class LoadOneFailureAction implements ActionWithPayload<any> {
  readonly type = LOAD_ONE_FAILURE;

  // TODO fix the type when errors are consistent
  constructor(public payload: any) { }
}

export class PollAction implements Action {
  readonly type = POLL;
}

export class PollSuccessAction implements ActionWithPayload<{eventsAvailable: boolean, serverTime: string}> {
  readonly type = POLL_SUCCESS;

  constructor(public payload: {eventsAvailable: boolean, serverTime: string}) { }
}

export class PollFailureAction implements ActionWithPayload<any> {
  readonly type = POLL_FAILURE;

  // TODO fix the type when errors are consistent
  constructor(public payload: any) { }
}

export class CreateAction implements ActionWithPayload<TransactionRequest> {
  readonly type = CREATE;

  constructor(public payload: TransactionRequest) { }
}

export class CreateSuccessAction implements ActionWithPayload<TransactionRequest> {
  readonly type = CREATE_SUCCESS;

  constructor(public payload: TransactionRequest) { }
}

export class CreateFailureAction implements ActionWithPayload<any> {
  readonly type = CREATE_FAILURE;

  // TODO fix the type when errors are consistent
  constructor(public payload: any) { }
}

export class UpdateAction implements ActionWithPayload<TransactionRequest> {
  readonly type = UPDATE;

  constructor(public payload: TransactionRequest) { }
}

export class UpdateSuccessAction implements ActionWithPayload<TransactionRequest> {
  readonly type = UPDATE_SUCCESS;

  constructor(public payload: TransactionRequest) { }
}

export class UpdateWSAction implements ActionWithPayload<TransactionRequest> {
  readonly type = UPDATE_WS;

  constructor(public payload: TransactionRequest) { }
}


export class UpdateWSSuccessAction implements ActionWithPayload<TransactionRequest> {
  readonly type = UPDATE_WS_SUCCESS;

  constructor(public payload: TransactionRequest) { }
}

export class UpdateFailureAction implements ActionWithPayload<any> {
  readonly type = UPDATE_FAILURE;

  // TODO fix the type when errors are consistent
  constructor(public payload: any) { }
}

export class DeleteSuccessAction implements ActionWithPayload<TransactionRequest> {
  readonly type = DELETE_SUCCESS;

  constructor(public payload: TransactionRequest) { }
}

export class DismissAction implements ActionWithPayload<TransactionRequest> {
  readonly type = DISMISS;

  constructor(public payload: TransactionRequest) { }
}

export class StartPollingAction implements Action {
  readonly type = START_POLLING;
}

export class StopPollingAction implements Action {
  readonly type = STOP_POLLING;
}


export class UpdatePriceAction implements ActionWithPayload<Price> {
  readonly type = UPDATE_PRICE;

  constructor(public payload: Price) { }
}

export type ActionsTypes
  = LoadAction
  | LoadSuccessAction
  | LoadFailureAction
  | LoadOneAction
  | LoadOneAndReplaceAction
  | LoadOneSuccessAction
  | LoadOneFailureAction
  | PollAction
  | PollSuccessAction
  | PollFailureAction
  | CreateAction
  | CreateSuccessAction
  | CreateFailureAction
  | UpdateAction
  | UpdateSuccessAction
  | UpdateWSAction
  | UpdateWSSuccessAction
  | UpdateFailureAction
  | DeleteSuccessAction
  | DismissAction
  | StartPollingAction
  | StopPollingAction
  | UpdatePriceAction
