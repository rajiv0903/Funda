import { Profile } from '../models/profile.model';
import * as actions from '../actions/profile.actions';

export class ProfileState {
  isLoading: boolean;
  loaded: boolean;
  profile: Profile;
  // TODO update type when error type is available
  error: any;
}

const profileDefaultState = {
  isLoading: false,
  loaded: false,
  profile: null,
  error: null
};

export function profileReducer(state: ProfileState = profileDefaultState, action: actions.ActionsTypes) {
  switch (action.type) {
    case actions.LOAD:
      return {
        ...state,
        isLoading: true,
        error: null
      };
    case actions.LOAD_SUCCESS:
      return {
        ...state,
        profile: action.payload,
        isLoading: false,
        loaded: true,
        error: null
      };
    case actions.LOAD_FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.payload
      };
    case actions.LOAD_CONFIG:
      return {
        ...state,
        isLoading: true,
        error: null
      };
    case actions.LOAD_CONFIG_SUCCESS:
      return {
        ...state,
        profile: {...state.profile, userConfig: action.payload.userConfig},
        isLoading: false,
        loaded: true,
        error: null
      };
    case actions.LOAD_CONFIG_FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.payload
      };
    default:
      return state;
  }
}
