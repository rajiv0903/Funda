import { Pricing } from '../models/pricing.model';
import * as actions from '../actions/pricing.actions'

export class PricingState {
  isLoading: boolean;
  loaded: boolean;
  entities: Pricing[];
  // TODO update type when error type is available
  error: any;
}

const pricingListDefaultState = {
  isLoading: false,
  loaded: false,
  entities: [],
  error: null
};

export function pricingReducer(state: PricingState = pricingListDefaultState, action: actions.ActionsTypes) {
  switch (action.type) {
    case actions.LOAD:
      return {
        ...state,
        isLoading: true,
        error: null
      };
    case actions.LOAD_SUCCESS:
      return {
        ...state,
        entities: action.payload,
        isLoading: false,
        loaded: true,
        error: null
      };
    case actions.LOAD_FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.payload
      };
    default:
      return state;
  }
}
