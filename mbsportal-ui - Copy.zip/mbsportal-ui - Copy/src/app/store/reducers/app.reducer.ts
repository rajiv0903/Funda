import * as actions from '../actions/app.actions'

export class AppState {
  isInitializing: boolean;
  initialized: boolean;
  error: any;
  userErrors: any[];
}

const appDefaultState = {
  isInitializing: false,
  initialized: false,
  initFailure: false,
  error: null,
  userErrors: []
};

export function appReducer(state: AppState = appDefaultState, action: actions.ActionsTypes) {
  switch (action.type) {
    case actions.INITIALIZE:
      return {
        ...state,
        isInitializing: true,
        error: null
      };
    case actions.INITIALIZE_SUCCESS:
      return {
        ...state,
        isInitializing: false,
        initialized: true,
        error: null
      };
    case actions.RE_INITIALIZE:
      return {
        ...state,
        isInitializing: true,
        error: null
      };
    case actions.RE_INITIALIZE_SUCCESS:
      return {
        ...state,
        isInitializing: false,
        initialized: true,
        error: null
      };
    case actions.FAILURE:
      if (action.payload.status === 400) {
        if (isAppLevelUserError(action.payload)) {
          state.userErrors = [...state.userErrors, {
            type: 'error',
            summary: 'User data error',
            message: action.payload.message || 'Unknown error'
          }];
        }
      } else {
        state.error = action.payload;
      }
      return {...state};
    default:
      return state;
  }
}

// TODO improve the check based on the error codes later (this is ugly I know :()
function isAppLevelUserError(error) {
  return (
    error.message !== 'LENDER_TRADE_REQUEST_ALREADY_PRESENT'
    && error.message !== 'INVALID_VERSION_TO_PERFORM_ACTION'
    && error.message !== 'Fannie Mae is no longer trading this settlement month'
    && error.message !== 'Invalid amount. Amount must be between 25,000 to 250,000,000'
    && error.message !== 'Invalid Value'
  )
}
