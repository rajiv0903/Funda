/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import * as actions from '../actions/session.actions';

export class SessionState {
  timerReset: boolean;
  timerExpired: boolean;
  error: any;
}

const sessionDefaultState = {
  timerReset: false,
  timerExpired: false,
  error: null
};


export function sessionReducer(state: SessionState = sessionDefaultState, action: actions.ActionsTypes) {
  switch (action.type) {
    case actions.TIMER_RESET:
      return {
        ...state,
        timerReset: true,
        timerExpired: false,
        error: null
      };
    case actions.TIMER_EXPIRED:
      return {
        ...state,
        timerReset: false,
        timerExpired: true,
        error: {'status': 401}
      };
    default:
      return state;
  }
}
