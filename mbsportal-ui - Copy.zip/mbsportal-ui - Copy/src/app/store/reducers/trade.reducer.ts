import {Trade} from '../models/trade.model';
import * as actions from '../actions/trade.actions';
import {
  maxRecordsPerPage,
  tradesListFirstPage,
  tradesListSortBy,
  tradesListSortOrder
} from '../../shared/constants/business.constant';

export class TradesState {
  isLoading: boolean;
  loaded: boolean;
  listObject: TradesList;
  // TODO update type when error type is available
  error: any;
}

export class TradesList {
  list: Trade[];
  pageIndex: number;
  pageSize: number;
  acceptedTrades: boolean;
  sortBy: string;
  sortOrder: string;
  totalRecords: number;
}

export class TradeExportList {
  acceptedTrades: boolean;
  sortBy: string;
  sortOrder: string;
  startDate: string;
  endDate: string;
  exportType: string;
  dateType: string;
}

export const tradesListDefaultState = {
  isLoading: false,
  loaded: false,
  listObject: {
    list: [],
    pageIndex: tradesListFirstPage,
    pageSize: maxRecordsPerPage,
    acceptedTrades: true,
    sortBy: tradesListSortBy,
    sortOrder: tradesListSortOrder,
    totalRecords: null
  },
  error: null
};

// TODO set state to TradesState type once action.payload is figured out
export function tradesReducer(state = tradesListDefaultState, action: actions.ActionsTypes) {
  switch (action.type) {
    case actions.LOAD:
      return {
        ...state,
        listObject: {...state.listObject, acceptedTrades: action.payload.acceptedTrades},
        isLoading: true,
        error: null
      };
    case actions.LOAD_SUCCESS:
      return {
        ...state,
        listObject: {...action.payload, acceptedTrades: state.listObject.acceptedTrades},
        isLoading: false,
        loaded: true,
        error: null
      };
    case actions.LOAD_FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.payload
      };
    case actions.EXPORT:
      return {
        ...state,
        isExporting: true,
        error: null
      };
    case actions.EXPORT_SUCCESS:
      return {
        ...state,
        isExporting: false,
        exportSuccess: true,
        error: null
      };
    case actions.EXPORT_FAILURE:
      return {
        ...state,
        isExporting: false,
        error: action.payload
      };
    default:
      return state;
  }
}
