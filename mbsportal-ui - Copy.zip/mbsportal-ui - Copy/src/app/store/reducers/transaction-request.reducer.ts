import { LENDER_ACCEPTED, LENDER_OPEN, TRADER_PRICED, TRADER_REPRICED, TransactionRequest } from '../models/transaction-request.model';
import * as actions from '../actions/transaction-request.actions';
import { StringBooleanArray } from '../../shared/interfaces/misc.interface';

export class TransactionRequestsState {
  isLoading: boolean;
  loaded: boolean;
  isCreating: boolean;
  isUpdating: StringBooleanArray;
  isPolling: boolean;
  shouldPoll: boolean;
  lastPollTimestamp: string;
  entities: TransactionRequest[];
  // TODO update type when error type is available
  error: any;
}

const transRequestsListDefaultState: TransactionRequestsState = {
  isLoading: false,
  loaded: false,
  isCreating: false,
  isUpdating: {},
  isPolling: false,
  shouldPoll: true,
  lastPollTimestamp: '',
  entities: [],
  error: null
};

export function transactionRequestReducer(
  state: TransactionRequestsState = transRequestsListDefaultState,
  action: actions.ActionsTypes
): TransactionRequestsState {
  switch (action.type) {
    case actions.LOAD:
    case actions.LOAD_ONE:
      return {
        ...state,
        isLoading: true,
        loaded: false,
        error: null
      };
    case actions.POLL:
      return {
        ...state,
        isPolling: true
      };
    case actions.POLL_SUCCESS:
      return {
        ...state,
        isPolling: false,
        lastPollTimestamp: action.payload.serverTime
      };
    case actions.POLL_FAILURE:
      return {
        ...state,
        isPolling: false,
        error: action.payload
      };
    case actions.LOAD_SUCCESS:
      return handleLoadSuccess(state, action);
    case actions.LOAD_ONE_SUCCESS:
      return {
        ...state,
        entities: [action.payload],
        isLoading: false,
        loaded: true,
        error: null
      };
    case actions.LOAD_FAILURE:
    case actions.LOAD_ONE_FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.payload
      };
    case actions.CREATE:
      return {
        ...state,
        isCreating: true,
        error: null
      };
    case actions.CREATE_SUCCESS:
      return {
        ...state,
        entities: [action.payload],
        isCreating: false,
        error: null
      };
    case actions.CREATE_FAILURE:
      return {
        ...state,
        isCreating: false,
        error: action.payload
      };
    case actions.UPDATE:
      state.isUpdating[action.payload.transReqId] = true;
      return {
        ...state,
        isUpdating: {...state.isUpdating},
        error: null
      };
    case actions.UPDATE_WS_SUCCESS:
      const index = state.entities.findIndex(x => x.transReqId === action.payload.transReqId);
      if (index === -1) {
        state.entities.push(action.payload);
      } else {
        if (versionUpdated(state.entities[index], action.payload)) {
          state.entities[index] = action.payload;
        } else {
          logToConsole({message: '[WARN] UI received outdated version update', payload: action.payload});
        }
      }

      return {
        ...state,
        entities: [...state.entities],
        error: null
      };
    case actions.UPDATE_SUCCESS:
      const updatedIndex = state.entities.findIndex(x => x.transReqId === action.payload.transReqId);
      if (updatedIndex !== -1) {
        if (versionUpdated(state.entities[updatedIndex], action.payload)) {
          state.entities[updatedIndex] = action.payload;
        } {
          logToConsole({message: '[WARN] UI received outdated version update', payload: action.payload});
        }
      }
      state.isUpdating[action.payload.transReqId] = false;

      return {
        ...state,
        entities: [...state.entities],
        isUpdating: {...state.isUpdating},
        error: null
      };
    case actions.UPDATE_FAILURE:
      state.isUpdating[action.payload.transReqId] = false;

      return {
        ...state,
        isUpdating: {...state.isUpdating},
        error: action.payload
      };
    case actions.DELETE_SUCCESS:
      return {
        ...state,
        entities: [...state.entities.filter(entity => entity.transReqId !== action.payload.transReqId)],
        error: null
      };
    case actions.START_POLLING:
      return {
        ...state,
        shouldPoll: true
      };
    case actions.STOP_POLLING:
      return {
        ...state,
        shouldPoll: false
      };
    case actions.UPDATE_PRICE:
      return handlePriceUpdate(state, action);
    default:
      return state;
  }
}

function handleLoadSuccess(state: TransactionRequestsState, action: actions.LoadSuccessAction): TransactionRequestsState {
  state.entities.forEach((transRequest: TransactionRequest, index) => {
    const foundInPayload = action.payload.find(entity => entity.transReqId === transRequest.transReqId);
    if (!foundInPayload) {
      action.payload.push({
        ...state.entities[index],
        updateNeeded: true
      });
    }
  });

  const compareFunc = (a, b): number => {
    if (a.submissionDate < b.submissionDate) {
      return -1;
    }
    if (a.submissionDate > b.submissionDate) {
      return 1;
    }
    return 0;
  };

  return {
    ...state,
    entities: action.payload.sort(compareFunc),
    isLoading: false,
    loaded: true,
    error: null
  };
}

function handlePriceUpdate(state: TransactionRequestsState, action: actions.UpdatePriceAction): TransactionRequestsState {
  const price = action.payload;
  state.entities.map((tr: TransactionRequest) => {
    if (isActiveTransaction(tr.stateType)
      && tr.product.nameCode === price.productNameCode
      && tr.tradeCouponRate === price.passThroughRate
      && tr.tradeSettlementDate === price.settlementDate) {
      if (tr.tradeBuySellType === 'BID') {
        tr.streamPricePercentHandleText = price.bidPrice.handle;
        tr.streamPricePercentTicksText = price.bidPrice.tick;
      } else {
        tr.streamPricePercentHandleText = price.askPrice.handle;
        tr.streamPricePercentTicksText = price.askPrice.tick;
      }
    }
    return tr;
  });

  return {
    ...state,
    entities: [...state.entities]
  };
}

function versionUpdated(current: TransactionRequest, incoming: TransactionRequest): boolean {
  return current.activeVersion < incoming.activeVersion;
}

export function isActiveTransaction(stateType: string): boolean {
  return [
    LENDER_OPEN,
    LENDER_ACCEPTED,
    TRADER_PRICED,
    TRADER_REPRICED
  ].includes(stateType);
}

function logToConsole(message: any) {
  localStorage.setItem('MBSP_LOG_KEY_' + Date.now(), JSON.stringify(message));
}
