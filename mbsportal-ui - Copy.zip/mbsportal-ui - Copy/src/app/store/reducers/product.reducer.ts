import { Product } from '../models/product.model';
import * as actions from '../actions/product.actions'

export class ProductsState {
  isLoading: boolean;
  loaded: boolean;
  entities: Product[];
  // TODO update type when error type is available
  error: any;
}

const productsListDefaultState = {
  isLoading: false,
  loaded: false,
  entities: [],
  error: null
};

export function productsReducer(state: ProductsState = productsListDefaultState, action: actions.ActionsTypes) {
  switch (action.type) {
    case actions.LOAD:
      return {
        ...state,
        isLoading: true,
        error: null
      };
    case actions.LOAD_SUCCESS:
      return {
        ...state,
        entities: action.payload,
        isLoading: false,
        loaded: true,
        error: null
      };
    case actions.LOAD_FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.payload
      };
    default:
      return state;
  }
}
