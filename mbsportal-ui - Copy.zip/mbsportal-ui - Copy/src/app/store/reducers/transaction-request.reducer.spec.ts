import * as actions from '../actions/transaction-request.actions';
import { transactionRequestReducer, TransactionRequestsState } from './transaction-request.reducer';
import { LENDER_OPEN, LENDER_REJECTED, TRADER_PRICED, TransactionRequest } from '../models/transaction-request.model';

describe('transactionRequestReducer', () => {
  let transaction: TransactionRequest;
  let initialState: TransactionRequestsState;
  const today = (new Date()).toISOString().slice(0, 10);

  beforeEach(() => {
    transaction = {
      'transReqId': '17H00001',
      'product': {
        'productId': {
          'identifier': 1,
          'sourceType': 'PU',
          'type': 'MBS'
        },
        'nameCode': 'FN30'
      },
      'tradeCouponRate': '4.00',
      'tradeBuySellType': 'BID',
      'stateType': 'LENDER_OPEN',
      'tradeSettlementDate': today,
      'activeVersion': 0
    };
    initialState = {
      isLoading: false,
      loaded: true,
      isCreating: false,
      isUpdating: {},
      isPolling: false,
      shouldPoll: false,
      lastPollTimestamp: '',
      entities: [],
      error: null
    };
  });

  it('should check LOAD action', () => {
    const action = new actions.LoadAction();
    const newState = transactionRequestReducer(initialState, action);

    expect(newState.isLoading).toEqual(true);
    expect(newState.error).toEqual(null);
  });

  it('should check LOAD_ONE action', () => {

    const action = new actions.LoadOneAction();
    const newState = transactionRequestReducer(initialState, action);

    expect(newState.isLoading).toEqual(true);
    expect(newState.error).toEqual(null);
  });

  it('should check POLL action', () => {
    const action = new actions.PollAction();
    const newState = transactionRequestReducer(initialState, action);

    expect(newState.isPolling).toEqual(true);
  });

  it('should check POLL SUCCESS action', () => {
    const action = new actions.PollSuccessAction({eventsAvailable: false, serverTime: '2018-01-1215:11:41'});
    const newState = transactionRequestReducer(initialState, action);

    expect(newState.isPolling).toEqual(false);
    expect(newState.lastPollTimestamp).toEqual('2018-01-1215:11:41');
  });

  it('should check POLL_FAILURE action', () => {
    const action = new actions.PollFailureAction({'error': 'some API error'});
    const newState = transactionRequestReducer(initialState, action);

    expect(newState.isPolling).toEqual(false);
    expect(newState.error).toEqual({error: 'some API error'});
  });

  it('should check LOAD_SUCCESS action', () => {
    const action = new actions.LoadSuccessAction([{...transaction}]);
    const newState = transactionRequestReducer(initialState, action);

    expect(newState.isLoading).toEqual(false);
    expect(newState.loaded).toEqual(true);
    expect(newState.entities).toEqual([transaction]);
  });

  it('should check LOAD_ONE_SUCCESS action', () => {
    const action = new actions.LoadOneSuccessAction({...transaction});
    const newState = transactionRequestReducer(initialState, action);

    expect(newState.isLoading).toEqual(false);
    expect(newState.loaded).toEqual(true);
    expect(newState.entities).toEqual([transaction]);
  });

  it('should check LOAD_FAILURE action', () => {
    const action = new actions.LoadFailureAction({'error': 'some API error'});
    const newState = transactionRequestReducer(initialState, action);

    expect(newState.isLoading).toEqual(false);
    expect(newState.error).toEqual({error: 'some API error'});
  });

  it('should check LOAD_ONE_FAILURE action', () => {
    const action = new actions.LoadOneFailureAction({'error': 'some API error'});
    const newState = transactionRequestReducer(initialState, action);

    expect(newState.isLoading).toEqual(false);
    expect(newState.error).toEqual({error: 'some API error'});
  });

  it('should check CREATE action', () => {
    const action = new actions.CreateAction({...transaction});
    const newState = transactionRequestReducer(initialState, action);

    expect(newState.isCreating).toEqual(true);
    expect(newState.error).toEqual(null);
  });

  it('should check CREATE_SUCCESS action', () => {
    const action = new actions.CreateSuccessAction({...transaction});
    const newState = transactionRequestReducer(initialState, action);

    expect(newState.isCreating).toEqual(false);
    expect(newState.error).toEqual(null);
    expect(newState.entities).toEqual([transaction]);
  });

  it('should check CREATE_FAILURE action', () => {
    const action = new actions.CreateFailureAction({'error': 'some API error'});
    const newState = transactionRequestReducer(initialState, action);

    expect(newState.isCreating).toEqual(false);
    expect(newState.error).toEqual({error: 'some API error'});
  });

  it('should check UPDATE action', () => {
    const action = new actions.UpdateAction({...transaction, stateType: TRADER_PRICED});
    const newState = transactionRequestReducer(initialState, action);

    expect(newState.isUpdating[transaction.transReqId]).toEqual(true);
    expect(newState.error).toEqual(null);
  });

  it('should check UPDATE_SUCCESS action where trans has same version', () => {
    const loadSuccessAction = new actions.LoadSuccessAction([transaction]);
    const stateAfterLoadSuccessAction = transactionRequestReducer(initialState, loadSuccessAction);

    const updateSuccessAction = new actions.UpdateSuccessAction({...transaction, stateType: TRADER_PRICED});
    const newState = transactionRequestReducer(stateAfterLoadSuccessAction, updateSuccessAction);

    expect(newState.isUpdating[transaction.transReqId]).toEqual(false);
    expect(newState.entities).toEqual([transaction]);
    expect(newState.entities[0].stateType).toEqual(LENDER_OPEN);
    expect(newState.entities[0] === transaction).toEqual(true); // object instances are the same - it didn't update the store version is old
  });

  it('should check UPDATE_SUCCESS action where trans has new version', () => {
    const loadSuccessAction = new actions.LoadSuccessAction([{...transaction}]);
    const stateAfterLoadSuccessAction = transactionRequestReducer(initialState, loadSuccessAction);

    const updateSuccessAction = new actions.UpdateSuccessAction({
      ...transaction,
      stateType: TRADER_PRICED,
      activeVersion: transaction.activeVersion + 1
    });
    const newState = transactionRequestReducer(stateAfterLoadSuccessAction, updateSuccessAction);

    expect(newState.isUpdating[transaction.transReqId]).toEqual(false);
    expect(newState.entities[0].stateType).toEqual(TRADER_PRICED);
    expect(newState.entities[0] === transaction).toEqual(false); // object instances are not the same, store is updated
  });

  it('should check UPDATE_WS_SUCCESS action for new object', () => {
    const updateSuccessAction = new actions.UpdateWSSuccessAction({...transaction});
    const newState = transactionRequestReducer(initialState, updateSuccessAction);

    expect(newState.entities).toEqual([transaction]);
    expect(newState.entities[0].stateType).toEqual(LENDER_OPEN);
    expect(newState.entities[0] === transaction).toEqual(false); // object instances are not the same, store is updated
  });

  it('should check UPDATE_WS_SUCCESS action where trans has same version', () => {
    const loadSuccessAction = new actions.LoadSuccessAction([transaction]);
    const stateAfterLoadSuccessAction = transactionRequestReducer(initialState, loadSuccessAction);

    const updateSuccessAction = new actions.UpdateWSSuccessAction({...transaction, stateType: TRADER_PRICED});
    const newState = transactionRequestReducer(stateAfterLoadSuccessAction, updateSuccessAction);

    expect(newState.entities).toEqual([transaction]);
    expect(newState.entities[0].stateType).toEqual(LENDER_OPEN);
    expect(newState.entities[0] === transaction).toEqual(true); // object instances are the same - it didn't update the store version is old
  });

  it('should check UPDATE_SUCCESS action where trans has new version', () => {
    const loadSuccessAction = new actions.LoadSuccessAction([transaction]);
    const stateAfterLoadSuccessAction = transactionRequestReducer(initialState, loadSuccessAction);

    const updateSuccessAction = new actions.UpdateWSSuccessAction({
      ...transaction,
      stateType: TRADER_PRICED,
      activeVersion: transaction.activeVersion + 1
    });
    const newState = transactionRequestReducer(stateAfterLoadSuccessAction, updateSuccessAction);

    expect(newState.entities[0].stateType).toEqual(TRADER_PRICED);
    expect(newState.entities[0] === transaction).toEqual(false); // object instances are not the same, store is updated
  });

  it('should check UPDATE_FAILURE action', () => {
    const failureResponse = {'error': 'some API error', transReqId: transaction.transReqId}
    const action = new actions.UpdateFailureAction(failureResponse);
    const newState = transactionRequestReducer(initialState, action);

    expect(newState.isUpdating[transaction.transReqId]).toEqual(false);
    expect(newState.error).toEqual(failureResponse);
  });

  it('should check UPDATE_SUCCESS action', () => {
    const loadSuccessAction = new actions.LoadSuccessAction([{...transaction}]);
    const stateAfterLoadSuccessAction = transactionRequestReducer(initialState, loadSuccessAction);

    const deleteSuccessAction = new actions.DeleteSuccessAction({...transaction});
    const newState = transactionRequestReducer(stateAfterLoadSuccessAction, deleteSuccessAction);

    expect(newState.entities).toEqual([]);
  });

  it('should check START_POLLING action', () => {
    const action = new actions.StartPollingAction();
    const newState = transactionRequestReducer(initialState, action);

    expect(newState.shouldPoll).toEqual(true);
  });

  it('should check STOP_POLLING action', () => {
    const action = new actions.StopPollingAction();
    const newState = transactionRequestReducer(initialState, action);

    expect(newState.shouldPoll).toEqual(false);
  });

  it('should check UPDATE_PRICE action', () => {
    const price = {
      'productNameCode': 'FN30',
      'settlementDate': today,
      'observationDateText': '2018-06-1310:09:00',
      'passThroughRate': '4.00',
      'bidPrice': {
        'handle': '102',
        'tick': '18+'
      },
      'askPrice': {
        'handle': '103',
        'tick': '21'
      }
    };
    const action = new actions.UpdatePriceAction(price);
    const newState = transactionRequestReducer({...initialState, entities: [{...transaction}]}, action);
    expect(newState.entities[0].streamPricePercentHandleText).toEqual('102');
    expect(newState.entities[0].streamPricePercentTicksText).toEqual('18+');

    const newState1 = transactionRequestReducer({...initialState, entities: [{...transaction, tradeBuySellType: 'OFFER'}]}, action);
    expect(newState1.entities[0].streamPricePercentHandleText).toEqual('103');
    expect(newState1.entities[0].streamPricePercentTicksText).toEqual('21');

    const newState2 = transactionRequestReducer({...initialState, entities: [{...transaction, stateType: LENDER_REJECTED}]}, action);
    expect(newState2.entities[0].streamPricePercentHandleText).toBeUndefined();
    expect(newState2.entities[0].streamPricePercentTicksText).toBeUndefined();
  });

});
