/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { NgModule, ErrorHandler, APP_INITIALIZER } from '@angular/core';
import { APP_BASE_HREF } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';

import './core/operators';

import { environment } from '../environments/environment';
import { AppComponent } from './app.component';
import { reducers } from './store';
import { AppRoutingModule } from './app-routing.module';
import { HomeModule } from './home/home.module';
import { HeaderModule } from './shared/components/header/header.module';
import { NavbarModule } from './shared/components/navbar/navbar.module';
import { FooterModule } from './shared/components/footer/footer.module';
import { SharedModule } from './shared/shared.module';

import { startupFactory, StartupService } from './shared/services/startup.service';
import { CustomErrorHandler } from './core/error-handler';
import { ModalComponent } from './shared/components/modal/modal.component';
import { AppEffects } from './store/effects/app.effects';
import { ProfileEffects } from './store/effects/profile.effects';
import { TransactionRequestEffects } from './store/effects/transaction-request.effects';
import { TradeEffects } from './store/effects/trade.effects';
import { ProductEffects } from './store/effects/product.effects';
import { PricingEffects } from './store/effects/pricing.effects';
import { StompRService } from '@stomp/ng2-stompjs';
import { HTTP_INTERCEPTORS, HttpClient, HttpClientModule } from '@angular/common/http';
import { MbspHttpInterceptor } from './core/http-interceptor';
import { SessionEffects } from './store/effects/session.effects';
import { NotificationsModule } from './shared/components/notifications/notifications.module';

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    AppRoutingModule,
    HomeModule,
    HeaderModule,
    NavbarModule,
    FooterModule,
    NotificationsModule,
    SharedModule.forRoot(),
    StoreModule.forRoot(reducers),
    EffectsModule.forRoot([
      AppEffects,
      ProfileEffects,
      TransactionRequestEffects,
      TradeEffects,
      ProductEffects,
      PricingEffects,
      SessionEffects
    ])
  ],
  declarations: [AppComponent, ModalComponent],
  providers: [
    HttpClient,
    StartupService,
    {
      provide: ErrorHandler,
      useClass: CustomErrorHandler
    },
    {
      provide: APP_BASE_HREF,
      useValue: environment.baseHref
    },
    {
      provide: APP_INITIALIZER,
      useFactory: startupFactory,
      deps: [StartupService],
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MbspHttpInterceptor,
      multi: true
    },
    StompRService
  ],
  bootstrap: [AppComponent],
  entryComponents: [ModalComponent]
})
export class AppModule { }
