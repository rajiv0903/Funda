import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'mbsp-home',
  templateUrl: 'home.component.html',
  styleUrls: ['home.component.scss']
})
export class HomeComponent {
  name = 'John';
}
