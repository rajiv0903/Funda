import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { HomeComponent } from './home.component';

describe('Home Component ', () => {

  let comp: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [HomeComponent]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);

    comp = fixture.componentInstance;

    de = fixture.debugElement.query(By.css('p'));
    el = de.nativeElement;
  });

  it('should display original text', () => {
    fixture.detectChanges();
    expect(el.textContent).toContain('Hello John. This is your landing page.');
  });

  it('should display a different text', () => {
    comp.name = 'Tester';
    fixture.detectChanges();
    expect(el.textContent).toContain('Hello Tester. This is your landing page.');
  });
});
