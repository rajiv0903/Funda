import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { TradesHistoryComponent } from './trades-history.component';
import { TradesLoadedGuard } from '../shared/guards/trades-loaded.guard';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: '',
        component: TradesHistoryComponent,
        canActivate: [
          TradesLoadedGuard
        ]
      }
    ])
  ],
  providers: [
    TradesLoadedGuard
  ],
  exports: [RouterModule]
})
export class TradesHistoryRoutingModule { }
