/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import {
  AfterViewChecked, AfterViewInit, Component, ElementRef, Input,
  OnChanges, OnInit, SimpleChanges, ViewChild, ViewEncapsulation
} from '@angular/core';

import { UserProfileService } from '../../shared/services/user-profile.service';
import { LoggerService } from '../../shared/services/logger.service';
import { Store } from '@ngrx/store';
import * as fromRoot from '../../store';
import * as trActions from '../../store/actions/trade.actions';
import { TradesList, tradesListDefaultState } from '../../store/reducers/trade.reducer';
import { Trade } from '../../store/models/trade.model';
import { UserType } from '../../shared/enums/user-type.enum';
import { TradesExportComponent } from '../trades-export/trades-export.component';
import { ModalService } from './../../shared/services/modal.service';
import {
  tradesListFirstPage,
  tradesListSortBy,
  tradesListSortOrder,
  tradesListDateType
} from '../../shared/constants/business.constant';
import * as moment from 'moment';

@Component({
  selector: 'mbsp-trades-list',
  templateUrl: './trades-list.component.html',
  styleUrls: ['./trades-list.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TradesListComponent implements OnChanges, OnInit, AfterViewInit, AfterViewChecked {

  @Input() listObject: TradesList;
  @Input() tradesIsLoading: boolean;

  public selectedRadioValue: string = 'CSV';
  public displayDialog: boolean = false;
  public isDateSelected: boolean = false;

  @ViewChild('entityCell') entityCell;
  @ViewChild(TradesExportComponent)
  private tradesExportComponent: TradesExportComponent;

  private headerElements: any[];

  public rows: Trade[];
  public overflow: boolean = false;
  public displayDate;
  public acceptedTrades: boolean;
  public sortBy: string;
  public sortOrder: string;
  public pageIndex: number;
  public pageSize: number;
  public totalRecords: number;
  public first: number;
  public recordMessageDisplayed: String;
  private firstRecordNumber: number;
  private lastRecordNumber: number;

  constructor(
    public userProfile: UserProfileService,
    private store: Store<fromRoot.AppStore>,
    private hostElement: ElementRef,
    private loggerService: LoggerService,
    private modalService: ModalService
  ) { }

  ngOnInit() {
    this.displayDate = Date.now();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.listObject) {
      this.rows = this.listObject.list;

      this.acceptedTrades = this.listObject.acceptedTrades;
      this.sortBy = tradesListDefaultState.listObject.sortBy;
      this.sortOrder = tradesListDefaultState.listObject.sortOrder;
      this.totalRecords = this.listObject.totalRecords;
      this.pageIndex = this.listObject.pageIndex;
      this.pageSize = this.listObject.pageSize;
      this.first = (this.pageIndex - 1) * this.pageSize;

      if (this.rows.length > 0) {
        this.sortBy = this.listObject.sortBy;
        this.sortOrder = this.listObject.sortOrder;
      }

      this.recordCountDisplay();
    }
  }

  ngAfterViewInit() {
    this.selectHeaderElements();
  }

  ngAfterViewChecked() {
    this.handleActiveSortStateStyling();
  }

  public showDialog() {
    this.loggerService.info('Export clicked');
    this.tradesExportComponent.setDefault();
    this.displayDialog = true;
  }

  public enableExportBtn($event) {
    this.isDateSelected = !$event;
  }

  private selectHeaderElements() {
    this.headerElements = this.hostElement.nativeElement.querySelectorAll('th');
  }

  private handleActiveSortStateStyling() {
    for (const header of this.headerElements) {
      const sortElement = header.querySelector('span.ui-sortable-column-icon');
      if (sortElement) {
        if (sortElement.classList.contains('fmi-sort-desc') || sortElement.classList.contains('fmi-sort-asc')) {
          header.classList.add('ui-state-active');
        } else {
          header.classList.remove('ui-state-active');
        }
      }
    }
  }

  public checkOverflow() {
    this.overflow = this.entityCell.nativeElement.innerText.length > 20;
  }

  public getSortIconClasses(fieldName: string) {
    return {
      'fmi-sort': this.sortBy !== fieldName,
      'fmi-sort-desc': this.sortBy === fieldName && this.sortOrder === 'desc',
      'fmi-sort-asc': this.sortBy === fieldName && this.sortOrder === 'asc'
    };
  }

  public toggleAcceptedTrades() {
    this.loggerService.info('Toggle display accepted trades');
    this.acceptedTrades = !this.acceptedTrades;
    this.pageIndex = tradesListFirstPage;
    this.sortOrder = tradesListSortOrder;
    this.sortBy = tradesListSortBy;
    setTimeout(() => this.dispatchAction(), 200);
  }

  public onExport(): void {
    this.loggerService.info('Export OK clicked');
    if (moment(this.tradesExportComponent.stDate).diff(moment(this.tradesExportComponent.edDate), 'days') < -365) {
      this.modalService.show({ status: 400 });
    } else {

      const payload = {
        acceptedTrades: false,
        sortBy: tradesListSortBy,
        sortOrder: tradesListSortOrder,
        startDate: this.tradesExportComponent.stDate,
        endDate: this.tradesExportComponent.edDate,
        exportType: this.selectedRadioValue,
        dateType: tradesListDateType
      };
      this.store.dispatch(new trActions.ExportAction(payload));

      this.displayDialog = false;
      this.tradesExportComponent.setDefault();
    }
  }

  public onCancel(): void {
    this.loggerService.info('Export Cancel clicked');
    this.displayDialog = false;
    this.tradesExportComponent.setDefault();
  }

  public toggleSort(fieldName: string) {
    this.loggerService.info('Toggle sort: ' + fieldName);
    this.sortOrder = this.sortBy === fieldName ? (this.sortOrder === 'asc' ? 'desc' : 'asc') : 'asc';
    this.sortBy = fieldName;
    this.pageIndex = tradesListFirstPage;

    this.dispatchAction();
  }

  public toggleRefresh(): void {
    this.loggerService.info('Refresh clicked');
    this.pageIndex = tradesListFirstPage;
    this.sortOrder = tradesListSortOrder;
    this.sortBy = tradesListSortBy;
    this.dispatchAction();
  }

  public dispatchAction() {
    this.displayDate = Date.now();
    this.store.dispatch(new trActions.LoadAction({
      acceptedTrades: this.acceptedTrades,
      sortBy: this.sortBy,
      sortOrder: this.sortOrder,
      pageIndex: this.pageIndex,
      pageSize: this.pageSize
    })
    );
  }

  public isInternalUserType() {
    return this.userProfile.userType === UserType.INTERNAL;
  }

  public pageChange(event: any): void {
    this.loggerService.info('Pagination changed');
    this.pageIndex = event.page + 1;
    this.dispatchAction();
  }

  public recordCountDisplay(): void {
    this.firstRecordNumber = (this.pageIndex - 1) * this.pageSize + 1;
    this.lastRecordNumber = this.firstRecordNumber + this.rows.length - 1;
    this.recordMessageDisplayed = this.firstRecordNumber + ' - ' + this.lastRecordNumber + ' of ' + this.totalRecords + ' Records';
  }
}
