import { async, ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { FmDataTableModule } from '@fm-ui-adk/components/dist/fm-datatable/fm-datatable.module';
import { FmDialogModule } from '@fm-ui-adk/components/dist/fm-dialog/fm-dialog.module';

import { TradesListComponent } from './trades-list.component';
import { NameFormat } from '../../shared/pipes/name-format.pipe';
import { TooltipModule } from 'ngx-tooltip';
import { UserProfileService } from '../../shared/services/user-profile.service';
import { LoggerService } from '../../shared/services/logger.service';
import { Store, StoreModule } from '@ngrx/store';
import { TRADER_TIMEOUT } from '../../store/models/transaction-request.model';
import { TradeResource } from '../trade.resource';
import { AppStore } from '../../store/index';
import { UiSwitchModule } from 'ngx-toggle-switch';
import { LocalStorageService } from '../../shared/services/local-storage.service';
import { DateTimezoneFormat } from '../../shared/pipes/date-format.pipe';
import { DatePipe } from '@angular/common';
import { Component, SimpleChange } from '@angular/core';
import { getProfileReducerMock } from '../../util/stubs/mock-profile-reducer';
import { RoleType } from '../../shared/enums/role-type.enum';
import { FmRadioModule } from '@fm-ui-adk/components/dist/fm-radio/fm-radio.module';
import { ModalService } from '../../shared/services/modal.service';
import { BsModalService, ComponentLoaderFactory, PositioningService } from 'ngx-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FmPaginatorModule } from '@fm-ui-adk/components/dist/fm-pagination/fm-pagination.module';
import { deepCopy } from '../../../test';
import {
  tradesListFirstPage,
  tradesListSortBy,
  tradesListSortOrder,
  tradesListDateType
} from '../../shared/constants/business.constant';

@Component({
  selector: 'mbsp-trades-export',
  template: 'no template for trades export child',
})
class MockTradesExportComponent {
}

describe('TradesListComponent', () => {
  let component: TradesListComponent;
  let fixture: ComponentFixture<TradesListComponent>;
  let store: Store<AppStore>;
  const mockTrades = deepCopy(require('../../../assets/data/trades.json'));
  const mockTraderProfile = deepCopy(require('../../../assets/data/trader-profile.json'));

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        TooltipModule,
        UiSwitchModule,
        StoreModule.forRoot({
          profile: getProfileReducerMock(RoleType.TRADER, mockTraderProfile)
        }),
        FmDataTableModule.forRoot(),
        FmDialogModule.forRoot(),
        FmRadioModule.forRoot(),
        FmPaginatorModule.forRoot(),
      ],
      declarations: [
        TradesListComponent,
        MockTradesExportComponent,
        NameFormat,
        DateTimezoneFormat
      ],
      providers: [
        UserProfileService,
        DatePipe,
        LocalStorageService,
        LoggerService,
        ModalService,
        BsModalService,
        ComponentLoaderFactory,
        PositioningService,
        {
          provide: TradeResource,
          useValue: jasmine.createSpyObj('tradeResource', ['query'])
        }
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TradesListComponent);
    component = fixture.componentInstance;
    component.rows = mockTrades.list;
    store = fixture.debugElement.injector.get(Store);
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should check initial values', () => {
    expect(component.rows).toEqual(mockTrades.list);
  });

  it('should render trades history table', () => {
    expect(fixture.debugElement.query(By.css('#trades-history'))).toBeTruthy();
  });

  it('should render port and inv_num td cell values', () => {
    expect(fixture.debugElement.query(By.css('.port'))).toBeTruthy();
    expect(fixture.debugElement.query(By.css('.inv_num'))).toBeTruthy();
  });

  it('should render tsp td cell values', () => {
    component.rows = mockTrades.list;
    expect(fixture.debugElement.query(By.css('.tsp'))).toBeTruthy();
    expect(fixture.debugElement.query(By.css('.tsp')).nativeElement.innerText).toEqual('TSSE');
  });

  it('should check port value to be equal to — when there is nothing to show', () => {
    component.rows[0].tradeSubPortfolioShortName = '';
    const handleElement = fixture.debugElement.query(By.css('.port'));
    fixture.detectChanges();

    expect(handleElement.nativeElement.innerText).toEqual('—');
  });

  it('should check inv# value to be equal to — when there is nothing to show', () => {
    component.rows[0].tradeSrcPrimaryId = '';
    const handleElement = fixture.debugElement.query(By.css('.inv_num'));
    fixture.detectChanges();

    expect(handleElement.nativeElement.innerText).toEqual('—');
  });

  it('should check for the status types for different stateTypes', () => {
    component.rows[0].stateType = 'EXECUTED';
    let label = fixture.debugElement.query(By.css('.status span'));
    fixture.detectChanges();

    expect(label.nativeElement.innerText).toEqual('Accepted');

    component.rows[0].stateType = 'LENDER_REJECTED';
    fixture.detectChanges();
    label = fixture.debugElement.query(By.css('.status span'));
    expect(label.nativeElement.innerText).toEqual('Cancelled');

    component.rows[0].stateType = 'TRADER_PASSED';
    fixture.detectChanges();
    label = fixture.debugElement.query(By.css('.status span'));
    expect(label.nativeElement.innerText).toEqual('FM Passed');

    component.rows[0].stateType = 'TRADER_REJECTED';
    fixture.detectChanges();
    label = fixture.debugElement.query(By.css('.status span'));
    expect(label.nativeElement.innerText).toEqual('FM Cancelled');

    component.rows[0].stateType = 'LENDER_TIMEOUT';
    fixture.detectChanges();
    label = fixture.debugElement.query(By.css('.status span'));
    expect(label.nativeElement.innerText).toEqual('Timed Out');

    component.rows[0].stateType = 'TRADER_TIMEOUT';
    fixture.detectChanges();
    label = fixture.debugElement.query(By.css('.status span'));
    expect(label.nativeElement.innerText).toEqual('FM Timed Out');
  });

  it('should check for the amount field formatting', () => {
    const amountField = fixture.debugElement.query(By.css('.amount'));
    fixture.detectChanges();

    expect(amountField.nativeElement.innerText).toEqual('4,747,000');
  });

  it('should render Tsp, Port and FM Trader td cell values for a trader', () => {
    const tsp = fixture.debugElement.query(By.css('.tsp'));
    const fmTrader = fixture.debugElement.query(By.css('.fm-trader'));
    const port = fixture.debugElement.query(By.css('.port'));

    expect(tsp.nativeElement).toBeTruthy();
    expect(fmTrader.nativeElement).toBeTruthy();
    expect(port.nativeElement).toBeTruthy();
  });

  it('should test pageChange', () => {
    const mockDropdownEvent = { page: 1};
    component.pageChange(mockDropdownEvent);
    expect(component.pageIndex ).toEqual(2);
  });

  it('should test recordCountDisplay', () => {
    component.rows = mockTrades.list;
    component.pageIndex = 1 ;
    component.pageSize = 20;
    component.totalRecords = component.rows.length;
    component.recordCountDisplay();
    expect(component.recordMessageDisplayed  ).toEqual('1 - 5 of ' + component.totalRecords + ' Records');
  });

  it('should test enableExportBtn', () => {
    const mockDropdownEvent = false;
    component.enableExportBtn(mockDropdownEvent);
    expect(component.isDateSelected  ).toEqual(true);
  });

  describe('setting lender role', () => {
    let profileRole: string;
    beforeAll(() => {
      profileRole = mockTraderProfile.roles[0].name;
      mockTraderProfile.roles[0].name = 'MBS Trade - Execute';
    });
    it('should not render Tsp, Port and FM Trader td cell values for a lender', () => {
      const tsp = fixture.debugElement.query(By.css('.tsp'));
      const fmTrader = fixture.debugElement.query(By.css('.fm-trader'));
      const port = fixture.debugElement.query(By.css('.port'));

      expect(tsp).toBeFalsy();
      expect(fmTrader).toBeFalsy();
      expect(port).toBeFalsy();
    });

    afterAll(() => {
      mockTraderProfile.roles[0].name = profileRole;
    });
  });


  it('should check for the "checkOverflow" method on hover', () => {
    const entityField = fixture.debugElement.query(By.css('div.checkEllipsis'));
    fixture.detectChanges();
    spyOn(component, 'checkOverflow');

    entityField.triggerEventHandler('mouseover', null);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.checkOverflow).toHaveBeenCalled();
    })
  });

  it('should check overflow when entity is long', () => {
    const entityField = fixture.debugElement.query(By.css('div.checkEllipsis'));
    fixture.detectChanges();

    entityField.triggerEventHandler('mouseover', null);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.overflow).toEqual(true);
    });
  });

  it('should check overflow when entity is short', () => {
    component.rows[0].lenderEntityName = 'Test-C';
    const entityField = fixture.debugElement.query(By.css('div.checkEllipsis'));
    fixture.detectChanges();

    entityField.triggerEventHandler('mouseover', null);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.overflow).toEqual(false);
    })
  });

  it('should check for toggleSort method on click', () => {
    const tradeDateField = fixture.debugElement.query(By.css('div.ui-state-default'));
    fixture.detectChanges();
    spyOn(component, 'toggleSort');

    tradeDateField.triggerEventHandler('click', null);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.toggleSort).toHaveBeenCalled();
    })

  });

  it('should check for toggleAcceptedTrades method on toggle button click', fakeAsync(() => {
    const acceptedToggleSwitch = fixture.debugElement.query(By.css('ui-switch'));
    spyOn(component, 'toggleAcceptedTrades');

    acceptedToggleSwitch.triggerEventHandler('click', null);
    expect(component.toggleAcceptedTrades).toHaveBeenCalled();
  }));

  it('should check for toggleRefresh method on refresh icon click', () => {
    const refreshIcon = fixture.debugElement.query(By.css('.fa-sync'));
    spyOn(component, 'toggleRefresh');
    refreshIcon.triggerEventHandler('click', null);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.toggleRefresh).toHaveBeenCalled();
      expect(component.pageIndex).toEqual(tradesListFirstPage);
      expect(component.sortOrder).toEqual(tradesListSortOrder);
      expect(component.sortBy).toEqual(tradesListSortBy);
    })
  });

  it('should check for ngOnChanges method', () => {
    component.listObject = mockTrades;

    component.ngOnChanges({
      listObject: new SimpleChange(null, component.listObject, true)
    });
    fixture.detectChanges();

    expect(component.sortBy).toEqual('tradeAmount');
    expect(component.sortOrder).toEqual('asc');
    expect(component.totalRecords).toEqual(5);
    expect(component.pageIndex).toEqual(1);
    expect(component.pageSize).toEqual(20);
    expect(component.first).toEqual(0);
    expect(component.rows).toEqual(mockTrades.list);
  });

  it('should check for sortOrder and sortBy for toggleSort method', () => {
    const fieldName = 'tradeSettlementDate';

    component.toggleSort(fieldName);
    fixture.detectChanges();
    expect(component.sortBy).toEqual('tradeSettlementDate');
    expect(component.sortOrder).toEqual('asc');

    component.toggleSort(fieldName);
    expect(component.sortBy).toEqual('tradeSettlementDate');
    expect(component.sortOrder).toEqual('desc');

    component.toggleSort('lenderEntityName');
    expect(component.sortBy).toEqual('lenderEntityName');
    expect(component.sortOrder).toEqual('asc');
  });

  it('should check for acceptedTrades on calling dispatchAction', () => {
    const fieldName = 'tradeSettlementDate';
    component.acceptedTrades = true;

    component.toggleSort(fieldName);
    expect(component.acceptedTrades).toEqual(true);

    component.toggleAcceptedTrades();
    expect(component.acceptedTrades).toEqual(false);
    expect(component.pageIndex).toEqual(tradesListFirstPage);
    expect(component.sortOrder).toEqual(tradesListSortOrder);
    expect(component.sortBy).toEqual(tradesListSortBy);


    component.dispatchAction();
    expect(component.acceptedTrades).toEqual(false);
  });

  it('should check for acceptedTrades,sortBy,sortOrder for multiple scenarios', () => {
    component.acceptedTrades = true;

    component.toggleSort('tradeAmount');
    expect(component.acceptedTrades).toEqual(true);
    expect(component.sortBy).toEqual('tradeAmount');
    expect(component.sortOrder).toEqual('asc');
    expect(component.pageIndex).toEqual(tradesListFirstPage);

    component.toggleAcceptedTrades();
    expect(component.acceptedTrades).toEqual(false);
    expect(component.sortBy).toEqual('submissionDate');
    expect(component.sortOrder).toEqual('desc');
    expect(component.pageIndex).toEqual(tradesListFirstPage);

    component.toggleSort('tradeDate');
    expect(component.acceptedTrades).toEqual(false);
    expect(component.sortBy).toEqual('tradeDate');
    expect(component.sortOrder).toEqual('asc');
    expect(component.pageIndex).toEqual(tradesListFirstPage);

    component.dispatchAction();
    expect(component.acceptedTrades).toEqual(false);
    expect(component.sortBy).toEqual('tradeDate');
    expect(component.sortOrder).toEqual('asc');
    expect(component.pageIndex).toEqual(tradesListFirstPage);
  });

    it('should check for recordCountDisplay method', () => {
    component.listObject = mockTrades;

    component.ngOnChanges({
      listObject: new SimpleChange(null, component.listObject, true)
    });
    fixture.detectChanges();

    expect(component.sortBy).toEqual('tradeAmount');
    expect(component.sortOrder).toEqual('asc');
    expect(component.totalRecords).toEqual(5);
    expect(component.pageIndex).toEqual(1);
    expect(component.pageSize).toEqual(20);
    expect(component.first).toEqual(0);
    expect(component.rows).toEqual(mockTrades.list);
    expect(component.recordMessageDisplayed).toEqual('1 - ' + component.rows.length + ' of ' +
      component.totalRecords + ' Records');
  });
});
