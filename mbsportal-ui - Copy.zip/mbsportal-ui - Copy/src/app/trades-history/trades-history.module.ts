import { NgModule } from '@angular/core';
import { UiSwitchModule } from 'ngx-toggle-switch';

import { TradesHistoryRoutingModule } from './trades-history-routing.module';
import { SharedModule } from '../shared/shared.module';
import { TradesHistoryComponent } from './trades-history.component';
import { TradesListComponent } from './trades-list/trades-list.component';
import { FmDataTableModule } from '@fm-ui-adk/components/dist/fm-datatable/fm-datatable.module';
import { TradesExportComponent } from './trades-export/trades-export.component';
import { FmDialogModule } from '@fm-ui-adk/components/dist/fm-dialog/fm-dialog.module';
import { FmRadioModule } from '@fm-ui-adk/components/dist/fm-radio/fm-radio.module';
import { FmSelectModule } from '@fm-ui-adk/components/adk';
import { NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';
import { FmPaginatorModule } from '@fm-ui-adk/components/dist/fm-pagination/fm-pagination.module';


@NgModule({
  imports: [
    SharedModule,
    TradesHistoryRoutingModule,
    FmDataTableModule,
    FmDialogModule,
    FmRadioModule,
    FmSelectModule,
    UiSwitchModule,
    FmPaginatorModule,
    NgbDatepickerModule.forRoot()
  ],
  declarations: [
    TradesHistoryComponent,
    TradesListComponent,
    TradesExportComponent
  ]
})
export class TradesHistoryModule { }
