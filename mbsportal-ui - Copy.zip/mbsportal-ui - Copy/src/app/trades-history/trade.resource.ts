import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';

import { environment } from '../../environments/environment';
import { TradesList } from '../store/reducers/trade.reducer';
import { catchError, map, retryWhen } from 'rxjs/operators';
import { unexpectedError} from '../shared/constants/error.constant';

@Injectable()
export class TradeResource {
  constructor(private httpClient: HttpClient) { }

  private getPath(params: {
    acceptedTrades: boolean;
    sortBy: string;
    sortOrder: string;
    pageIndex: number;
    pageSize: number;
  }): string {
    return (
      environment.apiBasePath +
      `/transactionshistory/${params.acceptedTrades}/${params.sortBy}/${
      params.sortOrder
      }/${params.pageIndex}/${params.pageSize}`
    );
  }

  private getExportPath(params: {
    acceptedTrades: boolean;
    sortBy: string;
    sortOrder: string;
    startDate: string;
    endDate: string;
    exportType: string;
    dateType: string;
  }): string {
    return (
      `/fmnapi/transactionshistory/export/${params.acceptedTrades}/${params.sortBy}/${
      params.sortOrder
      }/${params.startDate}/${params.endDate}/${params.exportType}/${
      params.dateType
      }`
    );
  }

  public query(queryParams: {
    acceptedTrades: boolean;
    sortBy: string;
    sortOrder: string;
    pageIndex: number;
    pageSize: number;
  }): Observable<TradesList> {
    return this.httpClient.get<TradesList>(this.getPath(queryParams));
  }

  public exportQuery(queryParams: {
    acceptedTrades: boolean;
    sortBy: string;
    sortOrder: string;
    startDate: string;
    endDate: string;
    exportType: string;
    dateType: string;
  }): Observable<any> {
    const body: Observable<any>  = this.getExportFileForReadyStatus(this.getExportPath(queryParams));
    return body;
  }

  public getExportFileForReadyStatus(url): Observable<any> {
    return this.httpClient.get(url).pipe(
      catchError((error: any) => {
        return Observable.throw(new Error(error.status));
      })
    );
  }

  public getExportFileForNotReadyStatus(url): Observable<any> {
    return this.httpClient.get(url).pipe(
      map((response: any) => {
        if (response.status === 'notready') {
          throw response;
        } else {
          return response;
        }
      }),
      catchError((error: any) => {
        return Observable.throw(new Error(error.status));
      })
    );
  }
}
