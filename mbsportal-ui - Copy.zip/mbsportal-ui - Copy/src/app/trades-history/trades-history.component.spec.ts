/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Response, ResponseOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { StoreModule, Store } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import {HttpClient, HttpHandler} from '@angular/common/http';

import { TradesHistoryComponent } from './trades-history.component';
import { AppStore } from '../store';
import { UserProfileService } from '../shared/services/user-profile.service';
import * as actions from '../store/actions/trade.actions';
import { TradeEffects } from '../store/effects/trade.effects';
import { NameFormat } from '../shared/pipes/name-format.pipe';
import { TradeResource } from './trade.resource';
import { TradeService } from '../shared/services/trade.service';
import { TooltipModule } from 'ngx-tooltip';
import { TradesList, tradesReducer } from '../store/reducers/trade.reducer';
import { Component, Input } from '@angular/core';
import { getProfileReducerMock } from '../util/stubs/mock-profile-reducer';
import { RoleType } from '../shared/enums/role-type.enum';
import { deepCopy } from '../../test';

@Component({
  selector: 'mbsp-trades-list',
  template: 'some html here',
})
class MockTradesListComponent {
  @Input() listObject: TradesList;
  @Input() tradesIsLoading: TradesList;
}

describe('TradesHistoryComponent', () => {
  let component: TradesHistoryComponent;
  let fixture: ComponentFixture<TradesHistoryComponent>;
  let store: Store<AppStore>;
  const mockTrades = deepCopy(require('../../assets/data/trades.json'));

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        EffectsModule.forRoot([TradeEffects]),
        StoreModule.forRoot({
          profile: getProfileReducerMock(RoleType.LENDER),
          trades: tradesReducer
        }),
        TooltipModule
      ],
      declarations: [
        TradesHistoryComponent,
        MockTradesListComponent,
        NameFormat
      ],
      providers: [
        UserProfileService,
        TradeService,
        HttpClient,
        HttpHandler,
        {
          provide: TradeResource,
          useValue: jasmine.createSpyObj('tradeResource', ['query'])
        }
      ]

    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TradesHistoryComponent);
    component = fixture.componentInstance;
    store = fixture.debugElement.injector.get(Store);
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should return observable', () => {
    expect(component.tradesList$ instanceof Observable).toEqual(true);
  });

  it('should load trade history rows', () => {
    const tradeResource = TestBed.get(TradeResource);
    const tradesHistoryGetResponse = new Response(
      new ResponseOptions(
        {
          body: mockTrades
        }
      )
    );

    tradeResource.query.and.returnValue(Observable.of(tradesHistoryGetResponse.json()));

    store.dispatch(new actions.LoadAction({acceptedTrades: true, sortBy: 'submissionDate', sortOrder: 'desc', pageIndex: 1, pageSize: 3}));

    component.tradesList$.subscribe(trades => {
      expect(trades).toEqual(mockTrades);
    })
  });

});
