import {Component, OnInit, Output, EventEmitter} from '@angular/core';
import {NgbDateStruct, NgbCalendar, NgbDateParserFormatter} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'mbsp-trades-export',
  templateUrl: 'trades-export.component.html',
  styleUrls: ['trades-export.component.scss']
})
export class TradesExportComponent implements OnInit {
  @Output() selectedDateEvent: EventEmitter<String> = new EventEmitter();
  public stDate: string;
  public edDate: string;
  public navigation = 'arrows';
  public hoveredDate: NgbDateStruct;
  public fromDate: NgbDateStruct;
  public toDate: NgbDateStruct;
  public maximumDate: NgbDateStruct;
  public showDate: NgbDateStruct;
  public currentDay: NgbDateStruct;
  public date: {year: number, month: number};

  constructor(
    private calendar: NgbCalendar,
    private ngbDateParserFormatter: NgbDateParserFormatter
  ) {}

  ngOnInit() {
    this.setDefault();
  }

  public setDefault(): void {
    const now = new Date();
    this.fromDate = null;
    this.toDate = null;
    this.currentDay = {
      year: now.getFullYear(),
      month: now.getMonth() + 1,
      day: now.getDate()
    };
    this.maximumDate = this.calendar.getToday();
    this.showDate = {
      year: now.getFullYear(),
      month: now.getMonth(),
      day: now.getDate()
    };
    this.onDateSelectionEmit();
  }

  public onDateSelection(date: NgbDateStruct): void {
    if (!this.fromDate && !this.toDate) {
      this.fromDate = date;
      this.toDate = date;
    } else if (this.fromDate === this.toDate && this.before(date, this.fromDate)) {
      this.fromDate = date;
    } else if (this.fromDate === this.toDate && this.after(date, this.fromDate) ) {
      this.toDate = date;
    } else if (this.fromDate && !this.toDate && this.before(date, this.fromDate)) {
      this.toDate = this.fromDate;
      this.fromDate = date;
    } else if (this.fromDate && !this.toDate && this.after(date, this.fromDate)) {
      this.toDate = date;
    } else if (this.fromDate && this.toDate && !this.isInside(date)) {
      this.toDate = date;
      this.fromDate = date;
    } else {
      this.toDate = date;
      this.fromDate = date;
    }
    if (this.fromDate && this.toDate) {
      this.onDateSelectionEmit();
    }
  }

  public onDateSelectionEmit(): void {
    this.stDate = this.ngbDateParserFormatter.format(this.fromDate);
    this.edDate = this.ngbDateParserFormatter.format(this.toDate);
    this.selectedDateEvent.emit(this.stDate);
  }

  public isHovered(date): boolean {
    return this.fromDate && !this.toDate && this.hoveredDate && this.after(date, this.fromDate) && this.before(date, this.hoveredDate);
  }

  public isInside(date): boolean {
    return this.after(date, this.fromDate) && this.before(date, this.toDate);
  }

  public isFrom(date): boolean {
    return this.equals(date, this.fromDate);
  }

  public isTo(date): boolean {
    return this.equals(date, this.toDate);
  }

  public isBefore(date): boolean {
    return this.fromDate && this.toDate && this.hoveredDate && this.fromDate === this.toDate
      && this.before(date, this.fromDate) && this.after(date, this.hoveredDate);
  }

  public isAfter(date): boolean {
    return this.fromDate && this.toDate && this.hoveredDate && this.fromDate === this.toDate
      && this.after(date, this.fromDate) && this.before(date, this.hoveredDate);
  }

  public equals(one: NgbDateStruct, two: NgbDateStruct): boolean {
    return one && two && (two.year === one.year) && (two.month === one.month) && (two.day === one.day);
  }

  public before(one: NgbDateStruct, two: NgbDateStruct): boolean {
    return !one || !two ? false : one.year === two.year
      ? one.month === two.month
        ? one.day === two.day
          ? false
          : one.day < two.day
        : one.month < two.month
      : one.year < two.year;
  }

  public after(one: NgbDateStruct, two: NgbDateStruct): boolean {
    return !one || !two ? false : one.year === two.year
      ? one.month === two.month
        ? one.day === two.day
          ? false
          : one.day > two.day
        : one.month > two.month
      : one.year > two.year;
  }

}
