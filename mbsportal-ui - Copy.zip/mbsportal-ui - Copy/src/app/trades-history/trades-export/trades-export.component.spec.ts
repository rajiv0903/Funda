/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';
import { TradesExportComponent } from './trades-export.component';

describe('TradesExportComponent', () => {
  let component: TradesExportComponent;
  let fixture: ComponentFixture<TradesExportComponent>;
  let insideSpy, hoveredSpy;
  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [NgbDatepickerModule.forRoot()],
        declarations: [TradesExportComponent],
        schemas: [NO_ERRORS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(TradesExportComponent);
    component = fixture.componentInstance;
    insideSpy = spyOn(component, 'isInside');
    hoveredSpy = spyOn(component, 'isHovered');
    fixture.detectChanges();
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });

  it('should return on date selection method', () => {

    let startDate = {year: 2018, month: 5, day: 21};
    let endDate = {year: 2018, month: 5, day: 22};
    let beforeDate = {year: 2018, month: 12, day: 31};
    let afterDate = {year: 2018, month: 12, day: 29};
    component.onDateSelection(startDate);
    component.onDateSelection(endDate);
    expect(component.fromDate).toEqual(startDate);
    expect(component.toDate).toEqual(endDate);

    startDate = {year: 2017, month: 1, day: 20};
    endDate = {year: 2018, month: 5, day: 22};
    component.onDateSelection(startDate);
    component.onDateSelection(endDate);
    expect(component.fromDate).toEqual(startDate);
    expect(component.toDate).toEqual(endDate);

    startDate = {year: 2017, month: 12, day: 30};
    endDate = {year: 2018, month: 5, day: 2};
    component.onDateSelection(startDate);
    component.onDateSelection(endDate);
    expect(component.fromDate).toEqual(startDate);
    expect(component.toDate).toEqual(endDate);
    startDate = {year: 2018, month: 12, day: 30};
    endDate = {year: 2018, month: 12, day: 30};
    beforeDate = {year: 2018, month: 12, day: 31};
    afterDate = {year: 2018, month: 29, day: 31};
    component.toDate = null;
    component.fromDate = startDate;
    component.toDate = endDate;
    component.onDateSelection(beforeDate);
    expect(component.fromDate).toEqual(beforeDate);

    component.onDateSelection(afterDate);
    expect(component.toDate).toEqual(afterDate);
    component.toDate = null;
    component.onDateSelection(beforeDate);
    expect(component.toDate).toEqual(beforeDate);

    component.toDate = null;
    component.onDateSelection(afterDate);
    expect(component.toDate).toEqual(afterDate);
  });

  it('should not check date is after', () => {
    const startDate = {year: 2018, month: 5, day: 21};
    const endDate = {year: 2018, month: 5, day: 26};
    component.toDate = endDate;
    expect(component.isTo(endDate)).toBeTruthy();
  });

  it('should be equal', () => {
    const startDate = {year: 2018, month: 5, day: 21};
    const endDate = {year: 2018, month: 5, day: 20};
    component.isTo(startDate);
    component.isTo(endDate);
    component.toDate = endDate;
    expect(component.isTo(endDate)).toBeTruthy();
  });

  it('should test end date is after ', () => {
    const startDate = {year: 2017, month: 4, day: 21};
    const endDate = {year: 2018, month: 5, day: 26};
    component.after(startDate, endDate);
    expect(component.after).toBeTruthy();
  });

  it('should test before ', () => {
    const startDate = {year: 2018, month: 5, day: 21};
    const endDate = {year: 2018, month: 5, day: 26};
    component.before(startDate, endDate);
    expect(component.before).toBeTruthy();
  });

  it('should test equals ', () => {
    const startDate = {year: 2018, month: 5, day: 21};
    const endDate = {year: 2018, month: 5, day: 21};
    component.equals(startDate, endDate);
    expect(component.equals).toBeTruthy();
  });

  it('should test before with null dates ', () => {
    const startDate = {year: 2018, month: 5, day: 21};
    const endDate = {year: 2017, month: 4, day: 20};
    component.before(startDate, endDate);
    expect(component.before).toBeTruthy();
  });

  it('should test onDateSelectionEmit', () => {
    const startDate = {year: 2018, month: 5, day: 21};
    const endDate = {year: 2018, month: 5, day: 26};
    component.fromDate = startDate;
    component.toDate = endDate;
    component.onDateSelectionEmit();
    expect(component.stDate).not.toBeNull();
    expect(component.edDate).not.toBeNull();
  });

  it('should test isHovered', () => {
    const fromDate = {year: 2018, month: 5, day: 20};
    const hoveredDate = {year: 2018, month: 5, day: 21};
    const endDate = {year: 2018, month: 5, day: 22};
    component.fromDate = fromDate;
    component.toDate = null;
    component.hoveredDate = hoveredDate;
    expect(component.isHovered(hoveredDate)).not.toBeTruthy();
  });

})
