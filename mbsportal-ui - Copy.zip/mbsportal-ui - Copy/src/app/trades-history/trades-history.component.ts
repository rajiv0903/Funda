/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

import { ChangeDetectionStrategy, Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Rx';

import * as fromRoot from '../store';
import { TradesList } from '../store/reducers/trade.reducer';

@Component({
  selector: 'mbsp-trades-history',
  templateUrl: './trades-history.component.html',
  styleUrls: ['./trades-history.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TradesHistoryComponent {

  constructor(private store: Store<fromRoot.AppStore>) { }

  get tradesList$(): Observable<TradesList> {
    return this.store.select(fromRoot.getTradesList);
  }

  get tradesIsLoading$(): Observable<any> {
    return this.store.select(fromRoot.getTradesIsLoading);
  }

}
