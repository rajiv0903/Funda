import { config } from '../app/core/config';

export const environment = {
  ...config,
  name: 'aws',
  production: true,
  apiBasePath: '/fmnapi',
  cdxApiBasePath: '/cdxapi',
  deployPath: '/fmnui/mbsportal/',
  websocketUrl: ''
};
