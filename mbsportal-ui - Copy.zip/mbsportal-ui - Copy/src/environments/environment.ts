// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.dev.ts`, but if you do
// `ng build --env={env_name}` then `environment.{env_name}.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

// THIS IS THE LOCAL ENVIRONMENT FILE

import { config } from '../app/core/config';

export const environment = {
  ...config,
  name: 'local',
  production: false,
  apiBasePath: 'http://mbsp01-devl-webapp.j22g6rr3zz.us-east-1.elasticbeanstalk.com',
  cdxApiBasePath: 'https://d2o5ku9ymibe1l.cloudfront.net/cdxapi',
  websocketUrl: 'http://localhost:9443/mbsp-websocket'
};
