# Instruction to build and run Angular 2 project with CDX common components

## Request access to CDXUI
- Request access for `SG-ATLASSIAN-PROD-CDXUI-BASIC-READ` from IAG
- Generate SSH key for GIT SSH access
	* run `git bash` and change the directory to your windows home directory
	* run `ssh-keygen -t rsa -C "your_fanniemae_email_here"`
	* Just accept all defaults when prompted, you should have public/private key pairs generated in `.ssh` directory of your home folder
	* Open `.ssh\id_rsa.pub` file in an editor, copy the whole content of the file
	* Login to your bitbucket account in a browser [here](http://bitbucket)
	* Click your account logo, then `manage account`
	* Select `SSH keys`, you should be [here](http://bitbucket/plugins/servlet/ssh/account/keys) now
	* Click `Add key`, then paste the content of `.ssh\id_rsa.pub` into the text box, then click `Add key`

## Nodejs version and setting

- Nodejs needs to be at least 6.9.x
- Fannie Mae Nexus repository does not support Angular 2 packages yet, so you will need to change .npmrc file to download node packages from internet:
```registry=https://registry.npmjs.org
strict-ssl=false
tmp=C:\Users\<your_ldap_id>\AppData\Roaming
proxy=http://<your_ldap_id>:<your_ldap_password>@zsproxy.fanniemae.com:10479/
https-proxy=http://<your_ldap_id>:<your_ldap_password>@zsproxy.fanniemae.com:10479
```
- Please beware that you can no longer use bcproxy.fanniemae.com as it is decomissioned

## Install latest angular cli to the global location
run `npm install -g @angular/cli@latest`

## Build and run
- `npm start` to start the client
- Open browser at http://localhost:4200

## Linting and Jasmine test
- Please make sure you run `ng lint` and `ng test` and fix any errors introduced by your changes.
- You should also generate a code coverage report (`ng test --browsers=Chrome --code-coverage`) to check and make sure you code changes are covered by the Jasmine unit test. The code coverage report is located at coverage directory.

=====================
# Mbsp - CLI generated content

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.0.0.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:8080/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive/pipe/service/class/module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
