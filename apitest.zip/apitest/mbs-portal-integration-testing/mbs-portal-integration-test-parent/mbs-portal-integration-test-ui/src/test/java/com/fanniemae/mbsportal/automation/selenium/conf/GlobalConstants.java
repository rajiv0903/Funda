/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.automation.selenium.conf;

import com.jayway.restassured.RestAssured;

/**
 * Created by g8us9b on 8/28/2017.
 */
public interface GlobalConstants {

    public static String LENDERQUERY = "Select * from TRADER_CONFIRMED where LenderID = ";
    public static String TRADERQUERY = "Select * from TRADER_CONFIRMED where TraderID = ";
    public static String PRODUCTLISTQUERY = "Select * from ProductList";
    public static String AMOUNTVALIDATEQUERY = "Select * from LenderAmountValidate";
    public static String TRADERHEADERQUERY = "Select TraderHeaderColumns from HeaderData";
    public static String TRADERPRICEQUERY = "Select * from TraderPriceValidate_1";
    public static String TRANSHISTORYQUERY = "Select TRANSHISTORYHEADER from TransHistoryHeader";
    public static String USERLOGINQUERY = "Select * from USER_DETAILS where USER_ID=";
    public static String USERDETAILSFROMCODEQUERY = "Select * from USER_DETAILS where USER_CODE=";
    public static String LENDERMULTIPLETRADES = "Select * from LenderMultipleTrades";
    public static String LENDERMULTIPLETRADES_PASSNO = "Select * from StreamPrice_Trades where PASS=";


    public static String LENDERQUERY_GREEN = "Select * from TRADER_CONFIRMED_GREEN where LenderID = ";
    public static String TRADERQUERY_GREEN = "Select * from TRADER_CONFIRMED_GREEN where TraderID = ";


    public static String TRANSACTIONSHISTORY = "/transactionshistory";


    //BLUE users
    public static String EXTERNAL_USER_ID = "p3hbrm1e";
    public static String INTERNAL_USER_ID = "admin12";
    public static String READONLY_TRADER = "tdread12";
    public static String EXTERNAL_TSP_ID = "p065hmnt";

    //GREEN users
    public static String EXTERNAL_USER_ID_GREEN = "a09h0mxt";
    public static String INTERNAL_USER_ID_GREEN = "admin45";
    public static String READONLY_TRADER_GREEN = "tdread45";
    public static String EXTERNAL_TSP_ID_GREEN = "p4hxnmnt";

    public static String PRODUCTDEFAULT = "Select Product";


    public static String LENDER = "LENDER";
    public static String TRADER = "TRADER";
    public static String READ_TRADER = "READ ONLY TRADER";

    public static String PENDINGSTATUS = "PENDING";
    public static String EXECUTEDSTATUS = "ACCEPTED";
    public static String CANCELLEDSTATUS = "CANCELLED";
    public static String TRADERPASSED = "FANNIE MAE PASSED";
    public static String TRADERCANCELLED = "FANNIE MAE CANCELLED";
    public static String NEWQUOTE = "NEW QUOTE";
    public static String QUOTED = "QUOTED";
    public static String LENDER_PASSED = "PASSED";
    public static String TRADER_TIMEOUT = "FANNIE MAE TIMED OUT";
    public static String LENDER_TIMEOUT = "TIMED OUT";

    public static String PRICE_UP = "UP";
    public static String PRICE_DOWN = "DOWN";

    public static String BID = "BID";
    public static String OFFER = "OFFER";

    public static String INCL_VALIDATION = "INCL_VALIDATION";
    public static String NO_VALIDATION = "NO_VALIDATION";

    public static String OFFER_COLOR = "rgba(218, 19, 15, 1)";
    public static String BID_COLOR = "rgba(20, 167, 57, 1)";
    public static String FONT_WEIGHT = "900";

    public static String SELL_BGCOLOR = "rgba(240, 43, 67, 1)";
    public static String SELL_HOVER_BGCOLOR = "rgba(255, 160, 172, 1)";

    public static String BUY_BGCOLOR = "rgba(5, 169, 11, 1)";
    public static String BUY_HOVER_BGCOLOR = "rgba(104, 255, 109, 1)";

    public static String DISABLED_DIAL_BGCOLOR = "rgba(158, 174, 203, 1)";
    public static String ACCEPTED_TRADE_BGCOLOR = "rgba(225, 239, 221, 1)";
    public static String OTHER_COMPLETED_TRADE_BGCOLOR = "rgba(174, 180, 191, 1)";


    public static int MAX_EIGHTS = 8;
    public static int MAX_TICK = 32;
    public static int MAX_HANDLE = 102;
    public static int MIN_EIGHTS = -1;
    public static int MIN_TICK = -1;
    public static int MIN_HANDLE = 100;


    public String TRADEACTIONBAR = "action-bar-";
    public int AMOUNT_VALUE = 10000;
    public int AMOUNT_VALUE_1 = 23500;
    public String MIN_LENDER_AMOUNT = "24999";
    public String MAX_LENDER_AMOUNT = "250000001";


    public static String PRODUCTPRICINGENDPOINT = "/mbsproductpricing/";
    public static String LENDERTRADEPOST = "/mbslendertransactions";
    public static String TRADERTRADEPOST = "/mbstradertransactions";
    public static String LOGINENDPOINT = "https://api.acptfanniemae.com/cdxapi/cdxlogin";


    public static String BLANKVALUE = "";
    public static String ATTRIBUTE_VALUE = "value";
    public static String CURRENCY_FORMAT_1 = "$ ###,###";
    public static String CURRENCY_FORMAT_2 = "###,###";

    public static String MonthShortName = "MMM";
    public static String DATEFORMAT_1 = "MM/dd/yyyy";
    public static String DATEFORMAT_2 = "yyyy-MM-dd";
    public static String DATEFORMAT_3 = "M/d/yy";
    public static String DATEFORMAT_4 = "MMM dd, yyyy";
    public static String DATEFORMAT_5 = "M/d/yy hh:mma";
    public static String DATEFORMAT_6 = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";


    public static String HYPHEN = "-";
    public static String Passes = "Passes";
    public static String Cancels = "Cancels";
    public static String RePrice = "Re-Prices";

    public static String ButtonBackgroundColor = "rgba(222, 240, 245, 1)";
    public static String OutlineBorder = "rgb(14, 195, 255) solid 4px";
    public static String BackgroundCSSValue = "background-color";

    public static String LenderSELLBackgroundColor = "rgba(210, 17, 17, 1)";
    public static String LenderBUYBackgroundColor = "rgba(0, 188, 6, 1)";


    public static String DRIVER_CONFIG_CHROME = "webdriver.chrome.driver";
   // public static String CHROME_PATH = "C:\\Program Files (x86)\\Selenium Client Drivers 3.4.3\\ChromeDriver\\chromedriver.exe";
    //public static String CHROME_PATH = "C:\\Users\\g8us9b\\chromedriver.exe";
    public static String CHROME_PATH = "C:\\Developers\\ChromeDriver\\chromedriver.exe";

    public static String DRIVER_CONFIG_IE = "webdriver.ie.driver";
    public static String IE_PATH = "C:\\Program Files (x86)\\Selenium Client Drivers 3.4.2\\IEDriver\\IEDriverServer.exe";
    public static String DRIVER_CONFIG_FIREFOX = "webdriver.gecko.driver";
//    public static String FIREFOX_PATH = "C:\\Program Files (x86)\\Selenium Client Drivers 3.4.2\\GeckoDriver\\geckodriver.exe";
    public static String FIREFOX_PATH = "C:\\Developers\\geckodriver.exe";

    public static String PROPERTYFILEPATH = "src/test/resources/conf/localConf.properties";

    public enum TradeConstans {
        TRADER_PRICED,
        TRADER_REPRICED,
        TRADER_CONFIRMED,
        TRADER_TIMEOUT
    }

    public enum LenderPriceAcceptState
    {
        HIT,
        LIFT
    }

    public enum PriceLabel
    {
        Price,
        Quote
    }

    public enum TradeActionType {
        SELL,
        BUY
    }

    public enum UserType {
        LENDER,
        READ_TRADER,
        TRADER
    }

    public enum BrowserModeType {
        INCOGONITO,
        NORMAL
    }

    public static String INCOGNITO_MODE = "--incognito";
    public static String BROWSER_MAXIMIZE = "--start-maximized";
    public static String PRIVATE_MODE = "-private";
    public static String PRIVATE_FIREFOX_MODE = "browser.private.browsing.autostart";
    public static String MARIONETTE = "marionette";

    public static final long TRADEWAIT = 3000;
    public static final int STATUS_SUCCESS = 200;
    public static final int STATUS_UNAUTHORISED = 401;
    public static final int BLACKROCKWAITTIME = 90000;

    public static void InitializeAPICall()
    {
        RestAssured.baseURI = ConfigConstants.APIBaseURL;
        RestAssured.useRelaxedHTTPSValidation();
    }

    public static String CHROME ="chrome";
    public static String FIREFOX ="firefox";
    public static String IE = "internet explorer";

    public static String LenderAmountErrorMessage = "Amount must be between 25,000 and 250,000,000";
    public static String TraderPriceErrorMessage = "Invalid Value";
    public static String LOGINERROR  = "Multiple Sessions found for this user.";

}