/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.automation.selenium.utils;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by g8us9b on 8/24/2017.
 */
public class ExcelLib {

    Fillo ExcelObj;
    Connection connection;
    Recordset recordset;

    private void CreateConnection() throws FilloException {
        ExcelObj = new Fillo();
        connection = ExcelObj.getConnection("src/test/resources/TestData/MBSTestData.xlsx");
    }

    public List<String> ExecuteQuery(String query) throws FilloException {
        List<String> data = new LinkedList<String>();

        try
       {
           CreateConnection();
           recordset = connection.executeQuery(query);
           //loop thru the records to fill in the list
           while (recordset.next())
           {
               data.add(recordset.getField(0).value());
           }
       }
       finally {
           recordset.close();
           connection.close();
           return data;
       }
    }

    public Recordset GetTestData(String query) throws FilloException {

        try {
            CreateConnection();
            return recordset = connection.executeQuery(query);
        }
        finally {
          //  recordset.close();
            connection.close();
        }
    }
}
