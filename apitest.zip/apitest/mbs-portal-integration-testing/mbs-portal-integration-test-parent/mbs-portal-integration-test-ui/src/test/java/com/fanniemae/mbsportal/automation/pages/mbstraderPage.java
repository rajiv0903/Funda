/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.automation.pages;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;
import com.fanniemae.mbsportal.automation.selenium.conf.ConfigConstants;
import com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants;
import com.fanniemae.mbsportal.automation.selenium.utils.AutoUtil;
import com.fanniemae.mbsportal.automation.selenium.utils.ExcelLib;
import com.fanniemae.mbsportal.automation.selenium.utils.PropertiesLib;
import org.apache.poi.ss.usermodel.Row;
import org.eclipse.jetty.util.DateCache;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.*;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.*;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.TradeActionType.BUY;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.TradeActionType.SELL;
import static com.fanniemae.mbsportal.automation.selenium.utils.AutoUtil.WaitForAngular2Finish;
import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementSelectionStateToBe;
import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOfElementLocated;

/**
 * Created by g8us9b on 8/10/2017.
 */
public class mbstraderPage {

    Recordset rsTrader, rsReadTrader;
    ExcelLib objExcelLib = new ExcelLib();
    int colRequestTime, colPrice, colTrans, colAmount, colProduct, colCoupon, colSettle, colSubmit,colTransID ,colEntity, colTrader,colTSPID;
    List<String> TransID = new ArrayList<String>();
    int iHandleRePrice = 98;
    int iTickRePrice = 111;
    private mbsloginPage mbsloginpage;
    private String traderId;
    private String transId;
    private mbstradertranshistoryPage mbstradertranshistoryPage;
    private WebDriver driver;

    @FindBy(css="#live-pricing-requests th") protected List<WebElement> TraderTHRow;
    @FindBy(css="#live-pricing-requests tbody tr") protected List<WebElement> TraderDataRows;
    @FindBy(tagName="td") protected List<WebElement> TraderDataCols;
    @FindBy(id="price-handle") protected WebElement HandlePrice;
    @FindBy(id="price-tick") protected WebElement TickPrice;
    @FindBy(id="price-submit") protected WebElement SubmitPrice;
    @FindBy(id="price-execute") protected WebElement ConfirmTrade;
    @FindBy(id="price-pass") protected WebElement PassTrade;
    @FindBy(id="price-cancel") protected WebElement CancelTrade;
    @FindBy(css=".inactive-status-label") protected WebElement TradeFinalStatus;
    @FindBy(css = ".inactive") protected WebElement CompletedTrade;
    @FindBy(css = ".tooltips-text") protected WebElement PriceErrorMessage;
    @FindBy(css = ".dial-up") protected WebElement PriceDialUP;
    @FindBy(css = ".dial-down") protected WebElement PriceDialDown;
    @FindBy(css = ".stream-pricing") protected WebElement StreamPricing;
    @FindBy(css = ".price-clickable") protected WebElement streamPriceColumn;
    @FindBy(css = ".fa-caret-right") protected WebElement arrowIcon;
    @FindBy(linkText = "TBA Trading") protected WebElement TBATradingPage;

    /**
     * Purpose: Constructor to initialize all the WebElements defined by the PageFactory annotation for the Trader Page
     * @param TraderDriver
     *        TraderDriver to trigger all the actions and perform asserts
     */
    public void mbsTraderPageInit(WebDriver TraderDriver) {

        PageFactory.initElements(TraderDriver,this);
        driver = TraderDriver;
    }

    public void goToTraderTBATrading()
            throws InterruptedException, FilloException, ParseException {
        Thread.sleep(ConfigConstants.MED_WAIT);
        TBATradingPage.click();
    }

    public void validateCompletedTrades(String Status)
            throws InterruptedException, FilloException, ParseException {
        List<WebElement> TDRow = TraderDataRows;
        rsTrader.moveFirst();
        Thread.sleep(ConfigConstants.MED_WAIT);
        assertNotNull(TraderDataRows.size());
        assertEquals(Status, TradeFinalStatus.getText().trim());
        if (Status.contentEquals("ACCEPTED")) {
            assertEquals(ACCEPTED_TRADE_BGCOLOR, CompletedTrade.getCssValue("background-color"));
        } else {
            assertEquals(OTHER_COMPLETED_TRADE_BGCOLOR, CompletedTrade.getCssValue("background-color"));
        }
        ValidateTraderData(TDRow.get(0), "COMPLETED");
    }

    public void LenderGetExpectedData(String ID) throws InterruptedException, FilloException, IOException {
        String query;

        String traderquery;
        PropertiesLib objProperties = new PropertiesLib();
        objProperties.InitPropertyFile();

        //set Blue/Green users
        if(objProperties.getBGEnv().contentEquals("BLUE"))
            traderquery = TRADERQUERY;
        else
            traderquery = TRADERQUERY_GREEN;

        Thread.sleep(ConfigConstants.MED_WAIT);

        query = traderquery + "'" + ID + "'";
        rsTrader = objExcelLib.GetTestData(query);
     }


    /**
     *
     * @throws FilloException
     * @throws InterruptedException
     */
    public void ValidateTraderInitialLoad() throws FilloException, InterruptedException {
        //validate the headers
        int i=0;
        Recordset rsTraderHeader = objExcelLib.GetTestData(TRADERHEADERQUERY);
        List<WebElement> THRow = TraderTHRow;

        //wait till the header is loaded on the page
        WebDriverWait wait = new WebDriverWait(driver,60);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("#live-pricing-requests")));

        while(rsTraderHeader.next())
        {
            assertTrue(THRow.get(i).getText().trim().contains(rsTraderHeader.getField("TraderHeaderColumns").trim()));

            switch (THRow.get(i).getText().trim())
            {
            case "REQUEST TIME":
                colRequestTime = i;
                break;
            case "PRICE":
                colPrice = i;
                break;
            case "ENTITY":
                colEntity = i;
                break;
            case "TRADER":
                 colTrader= i;
                 break;
            case "TRANS":
                colTrans = i;
                break;
            case "AMOUNT":
                colAmount =i;
                break;
            case "PROD":
                colProduct = i;
                break;
            case "CPN":
                colCoupon = i;
                break;
            case "SETT":
                colSettle = i;
                break;
            case "TRANS ID":
                colTransID = i;
                break;
            case "TSP":
                colTSPID = i;
            }
            i++;
        }
        rsTraderHeader.close();
    }

    //validate all rows and submit price
    public void TraderSubmitPrice(String PriceAction ) throws FilloException, InterruptedException {
        int i=0;
        
        List<WebElement> TDRow = TraderDataRows;
        Thread.sleep(ConfigConstants.MED_WAIT);

        //process trades only if the Trade arrives on the trader queue
       while(true) {
           if (TraderDataRows.size() > 0) {
               while (rsTrader.next()) {
                   ValidateTraderData(TDRow.get(i), "INCOMMING");
                   if (PriceAction.contentEquals("WITHOUT_DIALS"))
                       SubmitTraderPrice(TDRow.get(i));
                   else
                       ValidateTraderPriceDials(TDRow.get(i), PriceAction);
                   i++;
               }
               break;
           }
       }
    }
    
    public void TraderSubmitPriceNoValidation() throws FilloException, InterruptedException {
        int i=0;

        List<WebElement> TDRow = TraderDataRows;
        for(WebElement tdRow: TDRow){
            SubmitTraderPrice(tdRow);
        }
    }

    public void traderLockRow(String userCode) throws FilloException, InterruptedException {
        int i=0;
        List<WebElement> TDRow = TraderDataRows;

        while(true)
        {
            i =  TDRow.size() - 1;
            if(TraderDataRows.size()>0)
            {
                while (rsTrader.next())
                {
                    traderNamePopulation(TDRow.get(i), userCode);
                    i++;
                }
                break;
            }
        }
    }
    
    private void traderNamePopulation(WebElement Row, String userCode) throws FilloException, InterruptedException
    {
        Recordset rsUser = null;
        String Query = USERDETAILSFROMCODEQUERY + "'" + userCode + "'";
        rsUser = objExcelLib.GetTestData(Query);
        rsUser.moveFirst();
        HandlePrice = Row.findElement(By.id("price-handle-" + this.priceElementId(Row)));
        TickPrice = Row.findElement(By.id("price-tick-" + this.priceElementId(Row)));
        List<WebElement> ReleaseButton, streamPriceColumn;
        String streamPriceValue, streamHandleValue, streamTickValue ;

        HandlePrice.click();
        Thread.sleep(ConfigConstants.MED_WAIT);

        ReleaseButton = Row.findElements(By.className("fa-lock-alt"));

        //check trader name is displayed on the trader column and
        String traderName = Row.findElement(By.className("trader")).getText();
        assertEquals(traderName.toLowerCase(), (rsUser.getField("FULL_Name").toString().trim().toLowerCase()));

        //check if the Release Trade element is displyaed once the Trader locks the row
        assertTrue(ReleaseButton.get(0).isDisplayed());

        HandlePrice.clear();
        TickPrice.clear();

        HandlePrice.sendKeys("101");
        TickPrice.sendKeys("00+");

        //release the trade and the stream price should re-populate again on the trader queue
        ReleaseButton.get(0).click();

        Thread.sleep(ConfigConstants.SMALL_WAIT);

        assertFalse(ReleaseButton.get(0).isDisplayed());

        //valdiate the handle and tick price and the stream price
        streamPriceValue = Row.findElement(By.cssSelector(".stream-pricing")).getText();
        streamHandleValue = streamPriceValue.split("-")[0].trim();
        streamTickValue   = streamPriceValue.split("-")[1].trim();

        Thread.sleep(ConfigConstants.MED_WAIT);

        //Stream price should be displayed on handle and tick once the trade is released, Trader name should be blank
        traderName = Row.findElement(By.className("trader")).getText();
        assertEquals(HandlePrice.getAttribute("value"), streamHandleValue);
        assertEquals(TickPrice.getAttribute("value"), streamTickValue);
        assertEquals("", traderName);

        Thread.sleep(ConfigConstants.MED_WAIT);

        //check for Trader Name and Release icon when clicked on Stream Price column
        streamPriceColumn = Row.findElements(By.className("price-clickable"));
        streamPriceColumn.get(0).click();

        Thread.sleep(ConfigConstants.LONG_WAIT);

        traderName = Row.findElement(By.className("trader")).getText();
        assertEquals(traderName.toLowerCase(), (rsUser.getField("FULL_Name").toString().trim().toLowerCase()));
        assertTrue(ReleaseButton.size()>0);

        //check by changing handle and tick values and click copy and validate the values
        HandlePrice.clear();
        TickPrice.clear();

        Thread.sleep(ConfigConstants.MED_WAIT);

        HandlePrice.sendKeys("114");
        TickPrice.sendKeys("047");

        streamPriceColumn.get(0).click();

        traderName = Row.findElement(By.className("trader")).getText();
        assertEquals(traderName.toLowerCase(), (rsUser.getField("FULL_Name").toString().trim().toLowerCase()));
        assertTrue(ReleaseButton.size()>0);

        assertEquals(HandlePrice.getAttribute("value"), streamHandleValue);
        assertEquals(TickPrice.getAttribute("value"), streamTickValue);


        //submit the price as is and confirm that trader name is again displayed and release button is not displayed
        SubmitPrice.click();

        ReleaseButton = Row.findElements(By.className("fa-minus-square"));

        Thread.sleep(ConfigConstants.SMALL_WAIT);

        traderName = Row.findElement(By.className("trader")).getText();

        //the release button should not be displayed once the Trade Price has been submitted
        assertFalse(ReleaseButton.size()>0);
        assertEquals(traderName.toLowerCase(), (rsUser.getField("FULL_Name").toString().trim().toLowerCase()));

    }
    
    public void traderLockRowValidate(String userCode) throws FilloException, InterruptedException {
        int i=0;
        List<WebElement> TDRow = TraderDataRows;
        i =  TDRow.size() - 1;
        //enter the last row data only..TODO

        while (rsTrader.next())
        {
            traderEnterValues(TDRow.get(i),userCode );
            i++;
        }
    }
    
    private void traderEnterValues(WebElement Row,String userCode) throws FilloException, InterruptedException
    {
        String handleValue, tickValue;
        List<WebElement> ReleaseButton;
        String streamPriceValue, streamHandleValue, streamTickValue,traderName;
        String Query = USERDETAILSFROMCODEQUERY + "'" + userCode + "'";
        Recordset rsUser = objExcelLib.GetTestData(Query);
        rsUser.moveFirst();

        HandlePrice = Row.findElement(By.id("price-handle-" + this.priceElementId(Row)));
        TickPrice = Row.findElement(By.id("price-tick-" + this.priceElementId(Row)));

        ReleaseButton = Row.findElements(By.className(".fa-minus-square"));
        //assert that the Release button is not displayed for the trader who is only viewing the trade
        assertFalse(ReleaseButton.size()>0);

        //check trader name is displayed on the trader column and
        traderName = Row.findElement(By.className("trader")).getText();
        assertEquals(traderName.toLowerCase(), "a. test");

        handleValue = HandlePrice.getAttribute("value");
        tickValue = TickPrice.getAttribute("value");

        assertEquals(HandlePrice.isEnabled(), false);
        assertEquals(TickPrice.isEnabled(), false);

        assertEquals(DISABLED_DIAL_BGCOLOR, PriceDialUP.getCssValue("background-color"));
        assertEquals(DISABLED_DIAL_BGCOLOR, PriceDialDown.getCssValue("background-color"));

        assertNotNull(Row.findElement(By.className("trader")).getText());

        //validate that user is not able to use price dials and that the values do not change
        PriceDialUP.click();

        assertEquals(handleValue, HandlePrice.getAttribute("value"));
        assertEquals(tickValue, TickPrice.getAttribute("value"));

        Thread.sleep(ConfigConstants.MED_WAIT);

        PriceDialDown.click();

        assertEquals(handleValue, HandlePrice.getAttribute("value"));
        assertEquals(tickValue, TickPrice.getAttribute("value"));

        //also validate the stream price and handle tick are same since trade was submitted on the default stream price
        streamPriceValue = Row.findElement(By.cssSelector(".stream-pricing")).getText();
        streamHandleValue = streamPriceValue.split("-")[0].trim();
        streamTickValue   = streamPriceValue.split("-")[1].trim();

        Thread.sleep(ConfigConstants.MED_WAIT);

        //Stream price should be displayed on handle and tick once the trade is released, Trader name should be blank
        assertEquals(HandlePrice.getAttribute("value"), streamHandleValue);
        assertEquals(TickPrice.getAttribute("value"), streamTickValue);

    }

    
    //validate the Trader Rows of Data
    private void ValidateTraderData(WebElement Row, String TradePhase) throws FilloException, InterruptedException {
        //todo fetch only the columns of the selected row once multiple rows are displayed
        String RowClassName;
        List<WebElement> EntityNameToolTip;

        DecimalFormat myFormatter = new DecimalFormat(CURRENCY_FORMAT_2);
        String CurrentDate = new SimpleDateFormat(DATEFORMAT_3).format(new Date());
        String output="";

      //validate if the row is "RESERVED" if new trade and it has made the expected sound
        if (TradePhase.contentEquals("RESERVED") ) {
            //reserved
            RowClassName = "td_row transactionRequest_" + priceElementId(Row) + " reserved";
            assertEquals(RowClassName, Row.getAttribute("class").toString());
        }

        List<WebElement> Cols = TraderDataCols ;

        assertThat(Cols.get(colRequestTime).getText().trim(), containsString(CurrentDate.trim()));

        assertEquals(rsTrader.getField("TraderTradeType").trim(), Cols.get(colTrans).getText().trim());

        if(rsTrader.getField("TraderTradeType").trim().contentEquals(BID))
            assertEquals(BID_COLOR, Cols.get(colTrans).getCssValue("color"));
        else
            //assertEquals(OFFER_COLOR, Cols.get(colTrans).getAttribute("color"));
            assertEquals(OFFER_COLOR, Cols.get(colTrans).getCssValue("color"));


        output = myFormatter.format(Long.parseLong(String.valueOf(rsTrader.getField("LenderAmount").trim())));
        assertEquals(output, Cols.get(colAmount).getText().trim());
        assertEquals(FONT_WEIGHT, Cols.get(colAmount).getCssValue("font-weight"));

        assertEquals(rsTrader.getField("Product").trim(), Cols.get(colProduct).getText().trim());
        assertEquals(FONT_WEIGHT, Cols.get(colProduct).getCssValue("font-weight"));

        assertEquals(rsTrader.getField("CouponValue").trim(), Cols.get(colCoupon).getText().trim());
        assertEquals(FONT_WEIGHT, Cols.get(colCoupon).getCssValue("font-weight"));


        assertEquals(rsTrader.getField("SettlementMonth").trim().toUpperCase(), Cols.get(colSettle).getText().trim());
        assertEquals(FONT_WEIGHT, Cols.get(colSettle).getCssValue("font-weight"));


        assertEquals(rsTrader.getField("Lender_Name").trim().toUpperCase(), Cols.get(colEntity).getText().toUpperCase().trim());

        WebElement element = Cols.get(colEntity);

        EntityNameToolTip = element.findElements(By.tagName("tooltip-content"));

        //assert the tooltip only if there is a tool tip tag on the DOM
        if(EntityNameToolTip.size() > 0)
        {
            Actions builder = new Actions(driver);
            Action mouseOver = builder.clickAndHold().moveToElement(element).build();
            mouseOver.perform();

            String ActualEntityName = EntityNameToolTip.get(0).getText();
            Thread.sleep(ConfigConstants.MED_WAIT);
            assertThat(ActualEntityName, containsString(rsTrader.getField("Lender_Name").trim()));
        }


        if(rsTrader.getField("LenderID").trim().contains("TSP"))
            assertEquals(rsTrader.getField("TSP").trim().toUpperCase(), Cols.get(colTSPID).getText().toUpperCase().trim());


        //store the trans id for future validation
        TransID.add(Cols.get(colTransID).getText().trim());
    }

    private String priceElementId(WebElement Row) {
        String transReqId = Row.findElements(By.tagName("td")).get(colTransID).getText() ;
        return transReqId;
    }

    private void SubmitTraderPrice(WebElement Row) throws FilloException, InterruptedException
    {


        Recordset rsPrice = objExcelLib.GetTestData(TRADERPRICEQUERY);
        HandlePrice = Row.findElement(By.id("price-handle-" + this.priceElementId(Row)));
        TickPrice = Row.findElement(By.id("price-tick-" + this.priceElementId(Row)));

        //clear the stream price. TODO : Add a new assert that validates the streaming price if populated in Handle and Tick

        while (rsPrice.next())
        {

            Thread.sleep(ConfigConstants.MED_WAIT);

            HandlePrice.clear();
            TickPrice.clear();

            HandlePrice.sendKeys(rsPrice.getField("HANDLE").trim());
            TickPrice.sendKeys(rsPrice.getField("TICK").trim());

            System.out.println(rsPrice.getField("HANDLE").trim() + "," + rsPrice.getField("TICK").trim());

            Thread.sleep(ConfigConstants.SMALL_WAIT);
            //submit
            SubmitPrice.click();

            Thread.sleep(ConfigConstants.MED_WAIT);

            if (rsPrice.getField("ENABLED_AFTER_SUBMIT").trim().toLowerCase().contentEquals("t")) {
                   //validate the error message
                    assertThat(PriceErrorMessage.getText().toLowerCase(), containsString(TraderPriceErrorMessage.toLowerCase()));
        }
        else {
                //the price is valid price. The submit button should be disabled
                Thread.sleep(ConfigConstants.SMALL_WAIT);
                assertFalse(SubmitPrice.isEnabled());
            }

        }

        //validate if the row class name is class="td_row transactionRequest_18C00477 reserved"
        String RowClassName = "td_row transactionRequest_" + priceElementId(Row) + " reserved";
        assertEquals(RowClassName, Row.getAttribute("class").toString());


        //reenter the price from rs trader if different price
        if(!(rsTrader.getField("HandlePrice").contentEquals(HandlePrice.getAttribute("value"))
                && rsTrader.getField("TickPrice").trim().contentEquals(TickPrice.getAttribute("value"))))
        {
            HandlePrice.clear();
            TickPrice.clear();

            HandlePrice.sendKeys(rsTrader.getField("HandlePrice").trim());
            TickPrice.sendKeys(rsTrader.getField("TickPrice").trim());

            SubmitPrice.click();
        }
    }

    /**
     *
     * @param Row
     * @return
     */
    private Boolean isHandlePriceEnabled(WebElement Row)
    {
          return HandlePrice.isEnabled();
    }

    private Boolean isTickPriceEnabled(WebElement Row)
    {
         return TickPrice.isEnabled();
    }

    private Boolean isSubmitButtonPriceEnabled(WebElement Row) throws InterruptedException {
        return SubmitPrice.isEnabled();
    }


    public void ValidateTraderReceiveHit()
    {
        int i=0;
        try{
            List<WebElement> TDRow = TraderDataRows;
            rsTrader.moveFirst();
            ValidateTraderData(TDRow.get(i), "RESERVED");
            i++;

            while (rsTrader.next())
            {
                ValidateTraderData(TDRow.get(i),"RESERVED");
                i++;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void TraderConfirmTrade(String Validate) throws InterruptedException, FilloException {
        HandlePrice.click();

        if(Validate.contentEquals(INCL_VALIDATION))
        {
            Actions builder = new Actions(driver);

            Thread.sleep(ConfigConstants.MED_WAIT);

            //assert the text of the confirm button - BUY/SELL
            if (rsTrader.getField("TradeType").trim().toLowerCase().contentEquals(TradeActionType.SELL.toString().toLowerCase()))
            {
                //check text, background color and hover over background color
                assertEquals(TradeActionType.BUY.toString().toLowerCase(), ConfirmTrade.getText().trim().toLowerCase());
                // assertEquals(BUY_HOVER_BGCOLOR, ConfirmTrade.getCssValue("background-color"));


                //           Action mouseOver = builder.clickAndHold().moveToElement(ConfirmTrade).build();
                //           mouseOver.perform();
                //           Thread.sleep(ConfigConstants.SMALL_WAIT);
                //         assertEquals(BUY_BGCOLOR, ConfirmTrade.getCssValue("background-color"));

            }
            else
            {
                //check text, background color and hover over background color
                assertEquals(TradeActionType.SELL.toString().toLowerCase(), ConfirmTrade.getText().trim().toLowerCase());

                //assertEquals(SELL_HOVER_BGCOLOR, ConfirmTrade.getCssValue("background-color"));

                //           Action mouseOver = builder.clickAndHold().moveToElement(ConfirmTrade).build();
                //           mouseOver.perform();
                //           Thread.sleep(ConfigConstants.SMALL_WAIT);

                //           assertEquals(SELL_BGCOLOR, ConfirmTrade.getCssValue("background-color"));
            }

            List<WebElement> TDRow = TraderDataRows;

            String streamPriceValue,streamHandleValue,streamTickValue;

            streamPriceValue = TDRow.get(0).findElement(By.cssSelector(".stream-pricing")).getText();
            streamHandleValue = streamPriceValue.split("-")[0].trim();
            streamTickValue   = streamPriceValue.split("-")[1].trim();

            streamPriceColumn.click();

            assertEquals(HandlePrice.getAttribute("value"), streamHandleValue);
            assertEquals(TickPrice.getAttribute("value"), streamTickValue);

            HandlePrice.clear();
            TickPrice.clear();

            HandlePrice.sendKeys(rsTrader.getField("HandlePrice"));
            TickPrice.sendKeys(rsTrader.getField("TickPrice"));

        }

        ConfirmTrade.click();

        Thread.sleep(ConfigConstants.MED_WAIT);

        if(Validate.contentEquals(INCL_VALIDATION))
        {
            arrowIcon.click();
            assertEquals(rsTrader.getField("HandlePrice"),HandlePrice.getAttribute("value"));
            assertEquals(rsTrader.getField("TickPrice"),TickPrice.getAttribute("value"));
        }
        //assert the label
        assertEquals(EXECUTEDSTATUS.toLowerCase(),TradeFinalStatus.getText().trim().toLowerCase());
    }

    public void TraderAction(String TradeAction) throws InterruptedException, FilloException {

        switch (TradeAction)
        {
        case Passes:
            TraderPassTrade();
            break;
        case Cancels:
            TraderCancelTrade();
            break;
        case RePrice:
            TraderSubmitRePrice();
            break;
        }
       // Thread.sleep(GlobalConstants.TRADEWAIT);
    }

    private void TraderPassTrade() throws InterruptedException {

        PassTrade.click();
        Thread.sleep(ConfigConstants.MED_WAIT);
        assertEquals(LENDER_PASSED.toLowerCase(),TradeFinalStatus.getText().trim().toLowerCase());

        Thread.sleep(ConfigConstants.FINALSTATUS_WAIT);
        //TODO - Check if the row exists after the wait is over.
    }

    private void TraderCancelTrade() throws InterruptedException {
        CancelTrade.click();
        Thread.sleep(ConfigConstants.MED_WAIT);
        assertEquals(TRADERCANCELLED.toLowerCase(),TradeFinalStatus.getText().trim().toLowerCase());
        //TODO - use the close icon to clear the row and wait to check if the row exists
        Thread.sleep(ConfigConstants.FINALSTATUS_WAIT);
        //TODO - Check if the row exists after the wait is over.

    }


    public void TraderSubmitRePrice() throws InterruptedException {
        int i;
        List<WebElement> TDRow = TraderDataRows;

        i =  TDRow.size() - 1;

        //enter Handle and Price Data and check if Submit is enabled before and after

        if(isHandlePriceEnabled(TDRow.get(i)) && isTickPriceEnabled(TDRow.get(i)))
        {
            HandlePrice.clear();
            TickPrice.clear();
        }

        //reprice the trade
        iHandleRePrice += 1;
        iTickRePrice += 2;

        HandlePrice.sendKeys(String.valueOf(iHandleRePrice));
        TickPrice.sendKeys(String.valueOf(iTickRePrice));

        Thread.sleep(ConfigConstants.MED_WAIT);
       // WaitForAngular2Finish();
        assertTrue(isSubmitButtonPriceEnabled(TDRow.get(i)));

        SubmitPrice.click();
    }
    
    /**
     * @return the mbsloginpage
     */
    public mbsloginPage getMbsloginpage() {
            return mbsloginpage;
    }



    /**
     * @param mbsloginpage the mbsloginpage to set
     */
    public void setMbsloginpage(mbsloginPage mbsloginpage) {
            this.mbsloginpage = mbsloginpage;
    }



    /**
     * @return the traderId
     */
    public String getTraderId() {
            return traderId;
    }



    /**
     * @param traderId the traderId to set
     */
    public void setTraderId(String traderId) {
            this.traderId = traderId;
    }



    /**
     * @return the transId
     */
    public String getTransId() {
            return transId;
    }



    /**
     * @param transId the transId to set
     */
    public void setTransId(String transId) {
            this.transId = transId;
    }



    /**
     * @return the mbstradertranshistoryPage
     */
    public mbstradertranshistoryPage getMbstradertranshistoryPage() {
            return mbstradertranshistoryPage;
    }



    /**
     * @param mbstradertranshistoryPage the mbstradertranshistoryPage to set
     */
    public void setMbstradertranshistoryPage(mbstradertranshistoryPage mbstradertranshistoryPage) {
            this.mbstradertranshistoryPage = mbstradertranshistoryPage;
    }

    public void TraderTimeOut(String UserType) throws InterruptedException {

        WebElement element = (new WebDriverWait(driver,138 ))
                .until(ExpectedConditions.elementToBeClickable(By.cssSelector(".inactive-status-label")));

        System.out.println("Trader final status is: " + TradeFinalStatus.getText().toLowerCase());

        //validate the status to "FANNIE MAE Timeout" or Timed Out
        if (UserType.toLowerCase().contentEquals("trader"))
            assertEquals(TRADER_TIMEOUT.toLowerCase().trim(),TradeFinalStatus.getText().toLowerCase());
        else
            assertEquals(LENDER_TIMEOUT.toLowerCase().trim(),TradeFinalStatus.getText().toLowerCase());

    }

    private void ValidateTraderPriceDials(WebElement Row, String Dial_Type) throws FilloException, InterruptedException {
        //enter initial price and then validate the up and down dials then reset it to original value and submit

        rsTrader.moveFirst();

        HandlePrice = Row.findElement(By.id("price-handle-" + this.priceElementId(Row)));
        TickPrice = Row.findElement(By.id("price-tick-" + this.priceElementId(Row)));

        HandlePrice.clear();
        TickPrice.clear();

        if(Dial_Type.contentEquals("WITH_DIALS_UP")) {
            HandlePrice.sendKeys(rsTrader.getField("HandlePrice").trim());
            TickPrice.sendKeys(rsTrader.getField("TickPrice").trim());

            PriceDialAction(Row, PRICE_UP);
        }
        else if(Dial_Type.contentEquals("WITH_DIALS_DOWN"))
        {
            HandlePrice.sendKeys(rsTrader.getField("HandlePrice").trim());
            TickPrice.sendKeys("010");
            Thread.sleep(ConfigConstants.MED_WAIT);
            //check the down dial
            PriceDialAction(Row,PRICE_DOWN);
        }
    }

    private void PriceDialAction(WebElement Row, String DialAction) throws FilloException, InterruptedException {
        int iHandle,iTick,iEights,icount=0;
        String sTickValue, sEightsValue;

        iHandle = Integer.parseInt(HandlePrice.getAttribute("value").trim());
        iTick = Integer.parseInt(TickPrice.getAttribute("value").trim().substring(0,2));

        if (TickPrice.getAttribute("value").trim().substring(2,3).contentEquals("+"))
            iEights = 4;
        else
            iEights = Integer.parseInt(TickPrice.getAttribute("value").trim().substring(2,3));

        while (true)
        {
           Thread.sleep(ConfigConstants.MED_WAIT);

            icount++;
            if( DialAction.contentEquals(PRICE_UP)) {
                System.out.println("UP Dial");
                PriceDialUP.click();
                iEights++;

                if(iEights == MAX_EIGHTS)
                {
                    iTick+=1;
                    iEights = 0;
                }

                if(iTick == MAX_TICK)
                {
                    iHandle+=1;
                    iTick = 0;
                }

                if(iHandle == MAX_HANDLE)
                {
                    iHandle = 0;
                    iTick = 0;
                    iEights = 0;
                    break;
                }
            }
            else if(DialAction.contentEquals(PRICE_DOWN))
            {
                System.out.println("DOWN Dial");
                PriceDialDown.click();

                Thread.sleep(ConfigConstants.LONG_WAIT);
                iEights --;


                if(iEights == MIN_EIGHTS)
                {
                    iTick-=1;
                    iEights = 7;
                }

                if(iTick == MIN_TICK)
                {
                    iHandle-=1;
                    iTick = 0;
                }

                if(iHandle == MIN_HANDLE)
                {
                    iHandle = 0;
                    iTick = 0;
                    iEights = 0;
                    break;
                }
            }

            //assert the value after each increment
            if (iEights == 4)
                sEightsValue = "+";
            else
                sEightsValue = Integer.toString(iEights);


            sTickValue = Integer.toString(iTick) + sEightsValue;

            if(Integer.toString(iTick).length() == 1)
                sTickValue = "0" + sTickValue;

            HandlePrice = Row.findElement(By.id("price-handle-" + this.priceElementId(Row)));
            TickPrice = Row.findElement(By.id("price-tick-" + this.priceElementId(Row)));

            System.out.println("Handle value is : " + iHandle);
            System.out.println("Tick value is : " + sTickValue);

            assertEquals(Integer.toString(iHandle), HandlePrice.getAttribute("value"));
            assertEquals(sTickValue, TickPrice.getAttribute("value"));

            assertTrue(isSubmitButtonPriceEnabled(Row));

            if(icount==4) {
                SubmitPrice.click();
                icount=0;
            }

            Thread.sleep(ConfigConstants.SMALL_WAIT);
        }
    }

    public void ValidateSubmitConfirmEnabled(String ValidationType) throws FilloException, InterruptedException {

        String OriginalPrice, sHandleValue, sTick;
        rsTrader.moveFirst();

        int i=0;

        List<WebElement> TDRow = TraderDataRows;
        i =  TDRow.size() - 1;

        HandlePrice = TDRow.get(i).findElement(By.id("price-handle-" + this.priceElementId(TDRow.get(i))));
        TickPrice = TDRow.get(i).findElement(By.id("price-tick-" + this.priceElementId(TDRow.get(i))));

        if(ValidationType.contentEquals("PRE_CONFIRM")) {
            HandlePrice.clear();
            TickPrice.clear();
            sHandleValue = rsTrader.getField("HandlePrice").trim();
            sTick = rsTrader.getField("TickPrice").trim();
            HandlePrice.sendKeys(sHandleValue);
            TickPrice.sendKeys(sTick);
        }
        else {
            sHandleValue = HandlePrice.getAttribute("value");
            sTick = TickPrice.getAttribute("value");
        }

        OriginalPrice = sHandleValue + "-" + sTick;

        //first validate down with Submit Button Enabled/Disabled

        ValidateSubmit_Dial(OriginalPrice, sHandleValue, "DOWN",TDRow.get(i), ValidationType);

        if(ValidationType.contentEquals("PRE_CONFIRM")) {
            HandlePrice.clear();
            TickPrice.clear();

            Thread.sleep(ConfigConstants.MED_WAIT);

            sTick = "315";
            HandlePrice.sendKeys(sHandleValue);
            TickPrice.sendKeys(sTick);

            OriginalPrice = sHandleValue + "-" + sTick;

            ValidateSubmit_Dial(OriginalPrice, sHandleValue, "UP", TDRow.get(i), ValidationType);

            //once the validation are completed, send the original price to hit/confirm

            Thread.sleep(ConfigConstants.MED_WAIT);
            HandlePrice.clear();
            TickPrice.clear();

            HandlePrice.sendKeys(rsTrader.getField("HandlePrice").trim());
            TickPrice.sendKeys(rsTrader.getField("TickPrice").trim());

            SubmitPrice.click();
        }
//        else
//            ConfirmTrade.click();
    }


    private void ValidateSubmit_Dial(String OriginalPrice, String sHandleValue, String DialAction, WebElement Row, String ValidationType)
            throws InterruptedException {

        //send
        if (ValidationType.contentEquals("PRE_CONFIRM"))
            SubmitPrice.click();

        Thread.sleep(ConfigConstants.MED_WAIT);

        //click down till the handle value is changed and submit remains enabled
        while(sHandleValue.contentEquals(HandlePrice.getAttribute("value")))
        {
            if(DialAction.contentEquals("DOWN"))
                PriceDialDown.click();
            else
                PriceDialUP.click();


            Thread.sleep(ConfigConstants.MED_WAIT);
            assertTrue(isSubmitButtonPriceEnabled(Row));
        }

        Thread.sleep(ConfigConstants.MED_WAIT);

        //now bring the price to the original value and ensure that the submit button is disabled
        while (!OriginalPrice.contentEquals(HandlePrice.getAttribute("value") + "-" + TickPrice.getAttribute("value")))
        {
            assertTrue(isSubmitButtonPriceEnabled(Row));

            if(DialAction.contentEquals("DOWN"))
            PriceDialUP.click();
            else
                PriceDialDown.click();

            Thread.sleep(ConfigConstants.MED_WAIT);
        }

        //the submit button now should be disabled because it is the original price

        if (ValidationType.contentEquals("PRE_CONFIRM"))
            assertFalse(isSubmitButtonPriceEnabled(Row));
        else {
            assertTrue(ConfirmTrade.isDisplayed());
            assertTrue(ConfirmTrade.isEnabled());
        }
    }

    public void ValidateReadTraderPage(String TraderType,String TraderID, String ActionType)
            throws FilloException, ParseException {
        //validate all the rows of the read only trader that they are disabled
        int i=0;
        //todo fetch only the columns of the selected row once multiple rows are displayed
        String RowClassName;
        DecimalFormat myFormatter = new DecimalFormat(CURRENCY_FORMAT_2);
        SimpleDateFormat dateFormatter = new SimpleDateFormat(DATEFORMAT_2);
        String CurrentDate = new SimpleDateFormat(DATEFORMAT_3).format(new Date());
        String output="";
        WebElement SubmitButton,PassButton, CancelButton;
        List<WebElement> ReleaseButton;

        rsReadTrader = objExcelLib.GetTestData(GlobalConstants.LENDERMULTIPLETRADES);
        List<WebElement> TDRows = TraderDataRows;
        List<WebElement> Cols = TDRows.get(i).findElements(By.tagName("td")) ;

        //validate if the row count is same as expected
        assertEquals(rsReadTrader.getCount(), TDRows.size());

        assertThat(Cols.get(colRequestTime).getText().trim(), containsString(CurrentDate.trim()));

        while (rsReadTrader.next())
        {
            //the price, dials, submit and pass buttons should be disabled anyways
            HandlePrice = TDRows.get(i).findElement(By.id("price-handle-" + this.priceElementId(TDRows.get(i))));
            TickPrice = TDRows.get(i).findElement(By.id("price-tick-" + this.priceElementId(TDRows.get(i))));
            SubmitButton = TDRows.get(i).findElement(By.id("price-submit"));
            PassButton = TDRows.get(i).findElement(By.id("price-pass"));

            ReleaseButton = TDRows.get(i).findElements(By.className("fa-minus-square"));

            //assert that the Release button is not displayed for the trader who is only viewing the trade
            assertFalse(ReleaseButton.size()>0);

            //validate all the rows only first time i.e. PRE_PRICE_SUBMIT, else only validate if the trader name, and border line of the first selected row is valid
            if (ActionType.contentEquals("PRE_PRICE_SUBMIT") ) {

                Cols = TDRows.get(i).findElements(By.tagName("td")) ;

                assertEquals(rsReadTrader.getField("traderTransDisplay").toUpperCase().trim(), Cols.get(colTrans).getText().toUpperCase().trim());

                assertThat(Cols.get(colRequestTime).getText().trim(), containsString(CurrentDate.trim()));

                output = myFormatter.format(Long.parseLong(String.valueOf(rsReadTrader.getField("tradeAmount").trim())));
                assertEquals(output, Cols.get(colAmount).getText().trim());

                assertEquals(rsReadTrader.getField("product").trim(), Cols.get(colProduct).getText().trim());
                assertEquals(rsReadTrader.getField("tradeCouponRate").trim(), Cols.get(colCoupon).getText().trim());

                dateFormatter.applyPattern(DATEFORMAT_2);
                Date date = dateFormatter.parse(rsReadTrader.getField("tradeSettlementDate").trim().toUpperCase());
                dateFormatter.applyPattern(MonthShortName);
                assertEquals(dateFormatter.format(date).toUpperCase(), Cols.get(colSettle).getText().trim());
                assertEquals(rsReadTrader.getField("entity").trim().toUpperCase(), Cols.get(colEntity).getText().toUpperCase().trim());
                if(rsReadTrader.getField("lenderId").trim().contains("TSP"))
                    assertEquals(rsReadTrader.getField("tsp").trim().toUpperCase(), Cols.get(colTSPID).getText().toUpperCase().trim());

                 assertFalse(HandlePrice.isEnabled());
                 assertFalse(TickPrice.isEnabled());
                 assertFalse(SubmitButton.isEnabled());
                 assertFalse(PassButton.isEnabled());
            }
            else
            {
                //assert only if i is 0
                if (i==0)
                {
                    //reserved
                    RowClassName = "td_row transactionRequest_" + priceElementId(TDRows.get(i)) + " reserved";
                    assertEquals(RowClassName, TDRows.get(i).getAttribute("class").toString());
                    assertEquals(rsReadTrader.getField("Trader").toUpperCase().trim(), Cols.get(colTrader).getText().toUpperCase().trim());

                    CancelButton = TDRows.get(i).findElement(By.id("price-cancel"));

                    assertFalse(CancelButton.isEnabled());
                    assertFalse(SubmitButton.isEnabled());
                }

            }
            i++;
        }

    }

    //trades process multiple trades
    public void ProcessAllTrades()
    {

    }


    public void ValidateSreamPrice(String PassNo) throws FilloException {

        int i=0;
        Recordset rsValidatePrice = objExcelLib.GetTestData(LENDERMULTIPLETRADES_PASSNO + "'" + PassNo + "'" );
        WebElement SubmitButton,PassButton, CancelButton;
        String handleValue, tickValue, streamHandleValue,streamTickValue,streamPriceValue;

        List<WebElement> TDRows = TraderDataRows;


        while (rsValidatePrice.next()) {
            List<WebElement> Cols = TDRows.get(i).findElements(By.tagName("td"));

            //the price, dials, submit and pass buttons should be disabled anyways
            HandlePrice = TDRows.get(i).findElement(By.id("price-handle-" + this.priceElementId(TDRows.get(i))));
            TickPrice = TDRows.get(i).findElement(By.id("price-tick-" + this.priceElementId(TDRows.get(i))));
            SubmitButton = TDRows.get(i).findElement(By.id("price-submit"));
            PassButton = TDRows.get(i).findElement(By.id("price-pass"));

            //valdiate the handle and tick price and the stream price
            streamPriceValue = TDRows.get(i).findElement(By.cssSelector(".stream-pricing")).getText();
            streamHandleValue = streamPriceValue.split("-")[0].trim();
            streamTickValue   = streamPriceValue.split("-")[1].trim();

            //get the handle and tick values
            handleValue = HandlePrice.getAttribute("value");
            tickValue = TickPrice.getAttribute("value");

            assertEquals(streamHandleValue,handleValue);
            assertEquals(streamTickValue,tickValue);

        }
    }
}
