/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.automation.pages;

import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.CURRENCY_FORMAT_2;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.DATEFORMAT_1;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.DATEFORMAT_2;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.DATEFORMAT_3;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.DATEFORMAT_5;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.DATEFORMAT_6;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.InitializeAPICall;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.LENDERQUERY;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.MonthShortName;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.TRADERQUERY;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.TradeActionType.BUY;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.TradeActionType.SELL;
import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import com.fanniemae.mbsportal.automation.selenium.utils.PropertiesLib;
import org.json.JSONException;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;
import com.fanniemae.mbsportal.automation.selenium.conf.ConfigConstants;
import com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants;
import com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.UserType;
import com.fanniemae.mbsportal.automation.selenium.utils.ExcelLib;
import com.fanniemae.mbsportal.automation.selenium.utils.MBSTradingPortalUtil;
import com.fanniemae.mbsportal.automation.steps.mbsCommonSteps;
import com.fanniemae.mbsportal.util.StateType;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;

/**
 * Created by g8us9b on 10/13/2017.
 */
/**
 * @author FannieMae
 *
 */
public class mbstradertranshistoryPage {

	private static final String CHROME_BROWSER = "chrome";

	private static final String FIREFOX_BROWSER = "firefox";

	private ExcelLib objExcelLib = new ExcelLib();

	int colPrice, colTrans, colAmount, colProduct, colCoupon, colSettle, colSubmit, colTransID, colEntity, colUser,
			colFMTrader, colPort, colInv, colRqTime, colTradeDate, colStatus, colTSP;

	Recordset rsTrader;

	WebDriver driver;

	private Response response;

	Map<String, String> APIHeaderMap;
	
	private List endpointResponseData;

	@FindBy(linkText = "Transaction History")
	protected WebElement TransHistoryPage;
	@FindBy(css = "#trades-history tr th")
	protected List<WebElement> TransHistoryHeaderRow;
	@FindBy(css = "#trades-history tbody tr")
	protected List<WebElement> TransHistoryDataRows;
	// @FindBy(tagName="td") protected List<WebElement> TransHistoryDataCols;
	@FindBy(linkText = "TBA Trading")
	protected WebElement TBATradingPage;
	@FindBy(css = ".ui-chkbox-icon")
	protected WebElement CheckboxIcon;

	@FindBy(css = ".export-activity")
	protected WebElement popUpDialog;
	@FindBy(css = ".export-btn")
	protected WebElement exportButton;
	@FindBy(css = ".export-text")
	protected WebElement exportPopupHeader;

	// replace the following with ids when available in the html
	@FindBy(id = "csvRadioBtn")
	protected WebElement csvButton;
	@FindBy(id = "excelRadioBtn")
	protected WebElement xlsButton;

	@FindBy(css = ".btn-submit")
	protected WebElement submitButton;
	@FindBy(css = ".btn-cancel")
	protected WebElement cancelButton;

	@FindBy(css = ".paginator-row")
	protected WebElement paginatorRow;
	@FindBy(css = ".center-paginator")
	protected WebElement centerPaginator;
	@FindBy(id = "record-count-display")
	protected WebElement recordCountDisplay;
	@FindAll(@FindBy(xpath = "//fm-paginator/div/span/a"))
	protected List<WebElement> paginatorNumberElements;
	@FindBy(css = ".ui-paginator-prev")
	protected WebElement paginatorPrevElement;
	@FindBy(css = ".ui-paginator-next")
	protected WebElement paginatorNextElement;

	@FindAll(@FindBy(css = ".ngb-dp-month-name"))
	protected List<WebElement> monthNames;
	@FindAll(@FindBy(css = ".ngb-dp-month"))
	protected List<WebElement> months;
	@FindAll(@FindBy(css = ".ngb-dp-day"))
	protected List<WebElement> days;

	By TransHistoryDataCols = By.tagName("td");
	By EntityName = By.cssSelector(".entity");

	/**
	 * Purpose: Constructor to initialize all the WebElements defined by the
	 * PageFactory annotation for the Trader Transaction History Page
	 * 
	 * @param TraderDriver
	 *            TraderDriver to trigger all the actions and perform asserts on
	 *            the Trader Transaction History Page
	 */
	public void transhistoryPageInit(WebDriver TraderDriver) {
		PageFactory.initElements(TraderDriver, this);
		driver = TraderDriver;
	}

	public void goToTraderTransHistory(String ID, String TransID, String RoleName, UserType user)
		throws InterruptedException, FilloException, ParseException, IOException {
		int count = 0;
		String query = "";

		String lenderquery;
		PropertiesLib objProperties = new PropertiesLib();
		objProperties.InitPropertyFile();

		//set Blue/Green users
		if(objProperties.getBGEnv().contentEquals("BLUE")) {
			if (user.toString().contentEquals(UserType.LENDER.toString()))
					lenderquery = LENDERQUERY;
			else
				lenderquery = TRADERQUERY;
		}
		else {
			if (user.toString().contentEquals(UserType.LENDER.toString()))
				lenderquery = LENDERQUERY_GREEN;
			else
				lenderquery = TRADERQUERY_GREEN;
		}

		Thread.sleep(ConfigConstants.MED_WAIT);
		TransHistoryPage.click();
		Thread.sleep(ConfigConstants.MED_WAIT);
		ValidateTraderTransactionHistoryHeader(user);

		if (user.toString().contentEquals(UserType.LENDER.toString()))
			query = lenderquery + "'" + ID + "'";
		else
			query = lenderquery + "'" + ID + "'";

		rsTrader = objExcelLib.GetTestData(query);

		while (rsTrader.next()) {
			ValidateTraderTransHistoryData(ID, TransID, count, RoleName, user);
			count++;
		}

		// go back to TBA Trading page - move to ValidateTraderTransHistoryData
		// TBATradingPage.click();
	}

	public void sortTraderTransHistory(String ID, String TransID, String RoleName, UserType user)
			throws InterruptedException, FilloException, ParseException {
		int count = 0;
		String query = "";
		Thread.sleep(ConfigConstants.MED_WAIT);
		// WaitForAngular2Finish();
		TransHistoryPage.click();
		Thread.sleep(ConfigConstants.MED_WAIT);
		// WaitForAngular2Finish();
		ValidateTraderTransactionHistoryHeader(user);

		if (user.toString().contentEquals(UserType.LENDER.toString()))
			query = LENDERQUERY + "'" + ID + "'";
		else
			query = TRADERQUERY + "'" + ID + "'";

		rsTrader = objExcelLib.GetTestData(query);

		while (rsTrader.next()) {
			sortTraderTransHistoryData(ID, TransID, count, RoleName, user);
			count++;
		}

		// go back to TBA Trading page - move to ValidateTraderTransHistoryData
		TBATradingPage.click();
	}

	/**
	 *
	 * @param traderId
	 * @param TransID
	 * @param count
	 * @param roleName
	 * @param user
	 * @throws FilloException
	 * @throws InterruptedException
	 * @throws ParseException
	 */
	private void sortTraderTransHistoryData(String traderId, String TransID, int count, String roleName, UserType user)
			throws FilloException, InterruptedException, ParseException {

		DecimalFormat myFormatter = new DecimalFormat(CURRENCY_FORMAT_2);

		List<WebElement> TDROWS = TransHistoryDataRows;
		List<WebElement> THROWS = TransHistoryHeaderRow;
		// THROWS.get(colCoupon).click();
		Thread.sleep(ConfigConstants.POLLING_WAIT);

		/* Checking the sorting for status column */
		THROWS.get(colStatus).findElement(By.className("ui-sortable-column")).click();

		List<WebElement> Cols = TransHistoryDataRows.get(count).findElements(TransHistoryDataCols);
		assertEquals(rsTrader.getField("TraderConfirmedStatus").toLowerCase().trim(),
				Cols.get(colStatus).getText().toLowerCase().trim());

		/* Checking the Sorting for Coupon Column */
		THROWS.get(colCoupon).findElement(By.className("ui-sortable-column")).click();
		assertEquals(rsTrader.getField("CouponValue").toLowerCase().trim(),
				Cols.get(colCoupon).getText().toLowerCase().trim());

		/* Checking the Sorting for Product Column */
		THROWS.get(colProduct).findElement(By.className("ui-sortable-column")).click();
		assertEquals(rsTrader.getField("Product").toLowerCase().trim(),
				Cols.get(colProduct).getText().toLowerCase().trim());

		// Cols.get(colCoupon).findElement(By.className("fmi-sort")).click();
		// assertEquals(TransID.trim(), Cols.get(colTransID).getText().trim());
		// assertEquals(roleName.toLowerCase().trim(),
		// Cols.get(colUser).getText().toLowerCase().trim());
		// assertEquals(rsTrader.getField("TraderConfirmedStatus").toLowerCase().trim(),
		// Cols.get(colStatus).getText().toLowerCase().trim());
		// assertThat(Cols.get(colRqTime).getText().trim(),
		// containsString(CurrentDate.trim()));

		// String output =
		// myFormatter.format(Long.parseLong(String.valueOf(rsTrader.getField("LenderAmount").trim())));
		//
		// assertEquals(output, Cols.get(colAmount).getText().trim());
		//
		// assertEquals(rsTrader.getField("Product").trim(),
		// Cols.get(colProduct).getText().trim());
		// assertEquals(rsTrader.getField("CouponValue").trim(),
		// Cols.get(colCoupon).getText().trim());

		// TO DO = Compare latest values if the handle and price are re-priced
		// if(rsTrader.getField("HandlePrice").trim().length() > 0 &&
		// rsTrader.getField("TickPrice").trim().length() >0)
		// assertEquals(rsTrader.getField("HandlePrice").trim() +"-" +
		// rsTrader.getField("TickPrice").trim() ,
		// Cols.get(colPrice).getText().trim());

		// String MonthName = new SimpleDateFormat(MonthShortName).format(new
		// SimpleDateFormat(DATEFORMAT_1).parse(Cols.get(colSettle).getText().trim()));
		// assertEquals(rsTrader.getField("SettlementMonth").trim(),
		// MonthName.trim());

		// check if the tool tip text displays full Entity Name

		// WebElement element = Cols.get(colEntity);
		//
		// Actions builder = new Actions(driver);
		// Action mouseOver =
		// builder.clickAndHold().moveToElement(element).build();
		// mouseOver.perform();
		// String ActualEntityName =
		// element.findElement(EntityNameToolTip).getText();
		// System.out.println(ActualEntityName);
		// Thread.sleep(ConfigConstants.MED_WAIT);
		// assertThat(ActualEntityName,
		// containsString(rsTrader.getField("Lender_Name").trim()));

		// to do
		// Thread.sleep(BLACKROCKWAITTIME);
		Cols = TDROWS.get(count).findElements(TransHistoryDataCols);

		if (user.toString().contentEquals(UserType.TRADER.toString())) {
			if (rsTrader.getField("FM_TRADER").toLowerCase().trim().length() > 0)
				assertEquals(rsTrader.getField("FM_TRADER").toLowerCase().trim(),
						Cols.get(colFMTrader).getText().toLowerCase().trim());

			if (rsTrader.getField("TradeType").trim().contentEquals(SELL.toString().trim()))
				assertEquals(BUY.toString().toLowerCase().trim(), Cols.get(colTrans).getText().toLowerCase().trim());
			else
				assertEquals(SELL.toString().toLowerCase().trim(), Cols.get(colTrans).getText().toLowerCase().trim());

			// assertTrue(Cols.get(colPort).getText().trim().length()>2);
		} else if (user.toString().contentEquals(UserType.LENDER.toString())) {
			// if Lender Transaction histroy screen, match the trade type as is
			// assertEquals(rsTrader.getField("TradeType").toLowerCase().trim(),
			// Cols.get(colTrans).getText().toLowerCase().trim());
		}

		// assertTrue(Cols.get(colInv).getText().trim().length()>2);
		// assertEquals(CurrentDate.trim(),
		// Cols.get(colTradeDate).getText().trim());
	}

	private void ValidateTraderTransactionHistoryHeader(UserType user) throws InterruptedException, FilloException {
		List<WebElement> THROw = TransHistoryHeaderRow;
		Recordset rsTransHistoryHeader = null;
		int count = 0;

		Thread.sleep(ConfigConstants.LONG_WAIT);

		try {
			rsTransHistoryHeader = objExcelLib.GetTestData(GlobalConstants.TRANSHISTORYQUERY);
			while (rsTransHistoryHeader.next()) {
				// ignore matching Port and FM Trader if it is Lender screen
				if (user.toString().contentEquals(UserType.LENDER.toString())) {
					if (rsTransHistoryHeader.getField("TRANSHISTORYHEADER").trim().contentEquals("PORT")
							|| rsTransHistoryHeader.getField("TRANSHISTORYHEADER").trim().contentEquals("FM TRADER")
							|| rsTransHistoryHeader.getField("TRANSHISTORYHEADER").trim().contentEquals("TSP")) {
						count--;
					} else
						assertEquals(rsTransHistoryHeader.getField("TRANSHISTORYHEADER").trim(),
								THROw.get(count).getText().trim());

				} else {

					assertEquals(rsTransHistoryHeader.getField("TRANSHISTORYHEADER").trim(),
							THROw.get(count).getText().trim());
				}

				switch (THROw.get(count).getText().trim()) {
				case "PRICE":
					colPrice = count;
					break;
				case "B/S":
					colTrans = count;
					break;
				case "AMOUNT":
					colAmount = count;
					break;
				case "PROD":
					colProduct = count;
					break;
				case "CPN":
					colCoupon = count;
					break;
				case "SETTLE":
					colSettle = count;
					break;
				case "TRANS ID":
					colTransID = count;
					break;
				case "ENTITY":
					colEntity = count;
					break;
				case "USER":
					colUser = count;
					break;
				case "FM TRADER":
					colFMTrader = count;
					break;
				case "STATUS":
					colStatus = count;
					break;
				case "PORT":
					colPort = count;
					break;
				case "INV#":
					colInv = count;
					break;
				case "REQUEST TIME":
					colRqTime = count;
					break;
				case "TRADE DATE":
					colTradeDate = count;
					break;
				case "TSP":
					colTSP = count;
					break;
				}
				count++;

			}
			Thread.sleep(ConfigConstants.MED_WAIT);
			Thread.sleep(ConfigConstants.MED_WAIT);
		} finally {
			rsTransHistoryHeader.close();
		}

	}

	private void ValidateTraderTransHistoryData(String traderId, String TransID, int count, String roleName,
			UserType user) throws FilloException, InterruptedException, ParseException {

		List<WebElement> EntityNameToolTip;
		DecimalFormat myFormatter = new DecimalFormat(CURRENCY_FORMAT_2);
		String shortRoleName;

		List<WebElement> TDROWS = TransHistoryDataRows;
		String CurrentDate = new SimpleDateFormat(DATEFORMAT_3).format(new Date());

		// toggle to display all trades view
		CheckboxIcon.click();
		Thread.sleep(ConfigConstants.LONG_WAIT);

		List<WebElement> Cols = TransHistoryDataRows.get(count).findElements(TransHistoryDataCols);
		Thread.sleep(ConfigConstants.MED_WAIT);

		// assertEquals(TransID.trim(), Cols.get(colTransID).getText().trim());
		shortRoleName = roleName.substring(0, 1).concat(".").concat(" ")
				+ Arrays.stream(roleName.split(" ")).skip(1).collect(Collectors.joining(""));

		assertEquals(rsTrader.getField("TransHistoryStatus").toLowerCase().trim(),
				Cols.get(colStatus).getText().toLowerCase().trim());

		assertThat(Cols.get(colRqTime).getText().trim(), containsString(CurrentDate.trim()));

		String output = myFormatter.format(Long.parseLong(String.valueOf(rsTrader.getField("LenderAmount").trim())));

		assertEquals(output, Cols.get(colAmount).getText().trim());

		assertEquals(rsTrader.getField("Product").trim(), Cols.get(colProduct).getText().trim());
		assertEquals(rsTrader.getField("CouponValue").trim(), Cols.get(colCoupon).getText().trim());

		// TO DO = Compare latest values if the handle and price are re-priced
		// if(rsTrader.getField("HandlePrice").trim().length() > 0 &&
		// rsTrader.getField("TickPrice").trim().length() >0)
		// assertEquals(rsTrader.getField("HandlePrice").trim() +"-" +
		// rsTrader.getField("TickPrice").trim() ,
		// Cols.get(colPrice).getText().trim());

		String MonthName = new SimpleDateFormat(MonthShortName)
				.format(new SimpleDateFormat(DATEFORMAT_1).parse(Cols.get(colSettle).getText().trim()));
		assertEquals(rsTrader.getField("SettlementMonth").trim(), MonthName.trim());

		// check if the tool tip text displays full Entity Name

		WebElement element = Cols.get(colEntity);
		assertEquals(rsTrader.getField("Lender_Name").trim().toUpperCase(), Cols.get(colEntity).getText().toUpperCase().trim());

		EntityNameToolTip = element.findElements(By.tagName("tooltip-content"));

		// assert the tooltip only if there is a tool tip tag on the DOM
		if (EntityNameToolTip.size() > 0) {
			Actions builder = new Actions(driver);
			Action mouseOver = builder.clickAndHold().moveToElement(element).build();
			mouseOver.perform();

			String ActualEntityName = EntityNameToolTip.get(0).getText();
			Thread.sleep(ConfigConstants.MED_WAIT);
			assertThat(ActualEntityName, containsString(rsTrader.getField("Lender_Name").trim()));
		}

		// to do
		// Thread.sleep(BLACKROCKWAITTIME);
		Cols = TDROWS.get(count).findElements(TransHistoryDataCols);

		if (user.toString().contentEquals(UserType.TRADER.toString())) {
			if (rsTrader.getField("FM_TRADER").toLowerCase().trim().length() > 0)
				assertEquals(rsTrader.getField("FM_TRADER").toLowerCase().trim(),
						Cols.get(colFMTrader).getText().toLowerCase().trim());

			if (rsTrader.getField("LenderID").trim().contains("TSP"))
				assertEquals(rsTrader.getField("TSP").trim(), Cols.get(colTSP).getText().trim());
			else
				assertEquals("—", Cols.get(colTSP).getText().trim());

			if (rsTrader.getField("TradeType").trim().contentEquals(SELL.toString().trim()))
				assertEquals(BUY.toString().toLowerCase().trim(), Cols.get(colTrans).getText().toLowerCase().trim());
			else
				assertEquals(SELL.toString().toLowerCase().trim(), Cols.get(colTrans).getText().toLowerCase().trim());

			// assertTrue(Cols.get(colPort).getText().trim().length()>2);
		} else if (user.toString().contentEquals(UserType.LENDER.toString())) {
			// if Lender Transaction histroy screen, match the trade type as is
			// assertEquals(rsTrader.getField("TradeType").toLowerCase().trim(),
			// Cols.get(colTrans).getText().toLowerCase().trim());
		}

		// assertTrue(Cols.get(colInv).getText().trim().length()>2);
		// assertEquals(CurrentDate.trim(),
		// Cols.get(colTradeDate).getText().trim());
	}

	/**
	 * @throws InterruptedException
	 * @throws FilloException
	 * @throws ParseException
	 */
	public void goToTraderTransHistoryAndExport() throws InterruptedException, FilloException, ParseException {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(TransHistoryPage));
		TransHistoryPage.click();
		wait.until(ExpectedConditions.elementToBeClickable(exportButton));
		exportButton.click();
	}

	/**
	 * @param elementMap
	 */
	public void validateExportPopUp(Map<String, String> elementMap) {
		for (Entry<String, String> keyValue : elementMap.entrySet()) {
			switch (keyValue.getKey().toUpperCase()) {
			case "CSVRADIOBUTTON":
				WebElement box = csvButton.findElement(By.className("ui-radiobutton-box"));
				System.out.println(box.getTagName());
				assertNotNull(csvButton.findElement(By.className("ui-radiobutton-box")).getCssValue("ui-state-active"));
				System.out.println("assertTrue(csvButton.isSelected())");
				break;
			case "XLSRADIOBUTTON":
				assertFalse(xlsButton.isSelected());
				System.out.println("assertFalse(xlsButton.isSelected())");
				break;
			case "TITLE":
				assertEquals(keyValue.getValue(), exportPopupHeader.getText());
				System.out.println("assertTrue(keyValue.getValue().equals(exportPopupHeader.getText()))");
				break;
			case "EXPORTBUTTON":
				assertFalse(submitButton.isEnabled());
				System.out.println("assertTrue(submitButton.isEnabled())");
				break;
			case "CANCELBUTTON":
				assertTrue(cancelButton.isEnabled());
				System.out.println("assertTrue(cancelButton.isEnabled())");
				break;
			default:
				System.out.println("***********default case -  ********");
				System.out.println("***********  " + keyValue.getKey().toUpperCase() + "  *************");
				break;
			}

		}

		// validate the calendar months and year
		assertTrue(monthNames.size() == 2);
		String currMonth = LocalDateTime.now().getMonth().name();
		String prevMonth = LocalDateTime.now().minusMonths(1).getMonth().name();
		int currYear = LocalDateTime.now().getYear();
		int prevYear = LocalDateTime.now().minusMonths(1).getYear();

		String previousMonthAndYear = monthNames.get(0).getText().toUpperCase();
		String currentMonthAndYear = monthNames.get(1).getText().toUpperCase();

		assertEquals(currMonth + " " + currYear, currentMonthAndYear);
		assertEquals(prevMonth + " " + prevYear, previousMonthAndYear);
		System.out.println("*** current and previous months match ****");

	}

	/**
	 * 
	 */
	public void clickCancelButton() {
		assertTrue(popUpDialog.isDisplayed());
		cancelButton.click();
		assertFalse(popUpDialog.isDisplayed());
	}

	/**
	 * 
	 */
	public void clickSubmitButton() {
		assertTrue(popUpDialog.isDisplayed());
		submitButton.click();
		Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
		String browserName = cap.getBrowserName().toLowerCase();
		System.out.println(browserName);
		if (FIREFOX_BROWSER.equalsIgnoreCase(browserName)) {

		} else if (CHROME_BROWSER.equalsIgnoreCase(browserName)) {

		}
		assertFalse(popUpDialog.isDisplayed());
	}

	public void selectDate(String date) {
		DateFormat df = new SimpleDateFormat("EEEE, LLLL d, yyyy");
		Date day;
		switch (date) {
		case "TODAY":
			day = getDay(0);
			break;
		case "YESTERDAY":
			day = getDay(-1);
			break;
		case "DAYBEFORE":
			day = getDay(-2);
			break;
		default:
			Calendar c = Calendar.getInstance();
			c.set(Calendar.DATE, Integer.parseInt(date));
			day = c.getTime();
			break;
		}
		for (WebElement displayDay : days) {
			String fullDate = displayDay.getAttribute("aria-label");
			if (fullDate.trim().equals(df.format(day))) {
				displayDay.click();
			}
		}

	}

	public void validateSubmitButton(boolean enabled) {
		if (enabled) {
			assertTrue(submitButton.isEnabled());
			System.out.println("assertTrue(submitButton.isEnabled())");
		} else {
			assertFalse(submitButton.isEnabled());
			System.out.println("assertTrue(submitButton.isEnabled())");
		}
	}

	private Date getDay(int offset) {
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, offset);
		return c.getTime();
	}

	/**
	 * @param userEntity
	 * @throws JSONException
	 * 
	 */
	public void validatePagination(String userid, String userEntity) throws Exception {
		// System.out.println("*********** in validatePagination
		// ******************** " + userid + " --- " + userEntity);
		mbsCommonSteps.waitForElementToBeClickable(driver, TransHistoryPage);
		TransHistoryPage.click();
		mbsCommonSteps.waitForElementToBeVisible(driver, centerPaginator);
		if (GlobalConstants.TRADER.equalsIgnoreCase(userid)) {
			callAPIToPopulateTransactionHistoryPage(userid, GlobalConstants.INTERNAL_USER_ID);
		} else if (GlobalConstants.READ_TRADER.equalsIgnoreCase(userid)) {
			callAPIToPopulateTransactionHistoryPage(userid, GlobalConstants.READONLY_TRADER);
		} else if (GlobalConstants.LENDER.equalsIgnoreCase(userid)) {
			if (userEntity.contains("TSP")) {
				callAPIToPopulateTransactionHistoryPage(userid, GlobalConstants.EXTERNAL_TSP_ID);
			} else {
				callAPIToPopulateTransactionHistoryPage(userid, GlobalConstants.EXTERNAL_USER_ID);
			}
		}

	}

	/**
	 * 
	 */
	public void switchToTransactionHistoryPage() {
		mbsCommonSteps.waitForElementToBeClickableAndClick(driver, TransHistoryPage);
		try {
			Thread.sleep(ConfigConstants.LONG_WAIT);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 
	 */
	public void switchToTBATradingPage() {
		mbsCommonSteps.waitForElementToBeClickableAndClick(driver, TBATradingPage);
		try {
			Thread.sleep(ConfigConstants.LONG_WAIT);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 
	 */
	private void checkRecordCountDisplay() {
		if (paginatorNumberElements != null && paginatorNumberElements.size() > 1) {
			if (recordCountDisplay != null) {
				try {
					Thread.sleep(ConfigConstants.LONG_WAIT);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				recordCountDisplay = driver.findElement(By.id("record-count-display"));
				mbsCommonSteps.waitForElementToBeVisible(driver, recordCountDisplay);
			}
		}
	}

	/**
	 */
	public void traverseOnePage() {
		try {
			Thread.sleep(ConfigConstants.LONG_WAIT);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (paginatorNumberElements != null && paginatorNumberElements.size() > 1) {
			mbsCommonSteps.waitForElementToBeClickableAndClick(driver, paginatorNextElement);
			if (recordCountDisplay != null) {
				checkRecordCountDisplay();
				if (recordCountDisplay != null) {
					assertTrue(recordCountDisplay.getText().contains("26 - "));
				}
			}
		}

	}

	/**
	 * 
	 */
	public void clickColumnHeader() {
		if (paginatorNumberElements != null && paginatorNumberElements.size() >= 1) {
			List<WebElement> THROWS = TransHistoryHeaderRow;

			/* Checking the sorting for status column */
			THROWS.get(colAmount).findElement(By.className("ui-sortable-column")).click();
		}
	}
	
	/**
	 * 
	 */
	public void clickRefreshIcon() {
		if (paginatorNumberElements != null && paginatorNumberElements.size() >= 1) {
			WebElement elm = driver.findElement(By.className("fa-sync"));
			mbsCommonSteps.waitForElementToBeClickableAndClick(driver, elm);
		}
	}
	
	/**
	 * 
	 */
	public void clickAcceptedTradesToggle() {
//		WebElement elm = driver.findElement(By.id("accepted-toggle"));
		WebElement elm = driver.findElement(By.className("ui-chkbox"));
		System.out.println("element is " + elm.getCssValue("class") + " " + elm.getTagName());
		mbsCommonSteps.waitForElementToBeClickableAndClick(driver, elm);
	}	
	
	/**
	 * 
	 */
	public void checkIfOnPageOne() {
		try {
			Thread.sleep(ConfigConstants.LONG_WAIT);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		checkRecordCountDisplay();
		if (recordCountDisplay != null) {
			assertTrue(recordCountDisplay.getText().contains("1 - "));
		}
	}

	/**
	 * @param userid
	 * @throws JSONException
	 */
	public void callAPIToPopulateTransactionHistoryPage(String userType, String userid) throws Exception {

		// System.out.println("*********** in
		// callAPIToPopulateTransactionHistoryPage ******************** " +
		// userid);
		String url;
		APIHeaderMap = mbsCommonSteps.setAPIHeaderMap(userid);

		// set the API Get URL
		InitializeAPICall();
		RestAssured.baseURI += GlobalConstants.TRANSACTIONSHISTORY;
		url = RestAssured.baseURI + "/true/submissionDate/desc/1/25";

		System.out.println(url);
		int totalRecords, pageIndex = 1, pageSize = 0, totalPages;

		response = given().contentType(ContentType.JSON).headers(APIHeaderMap).when().get(url);
		System.out.println(response.getBody().asString());
		totalRecords = response.getBody().jsonPath().getInt("totalRecords");
		pageSize = response.getBody().jsonPath().getInt("pageSize");
		endpointResponseData = response.getBody().jsonPath().getJsonObject("list");
		compareUIWithBackendData(userType);
		if (totalRecords != 0) {
			totalPages = totalRecords / pageSize + 1;
			mbsCommonSteps.waitForElementToBeVisible(driver, recordCountDisplay);
			assertEquals(totalPages, paginatorNumberElements.size());
			// click forward through the pages
			for (WebElement we : paginatorNumberElements) {
				we.click();
				pageIndex = makeBackendCallAndCheckValues(pageIndex, userType);
				pageIndex++;
			}

			if (paginatorPrevElement.isEnabled()) {
				pageIndex--;
				// click backward through using the prev button
				for (int i = pageIndex; i >= 1; i--) {
					pageIndex = makeBackendCallAndCheckValues(pageIndex, userType);
					paginatorPrevElement.click();
					pageIndex--;
				}

				if (paginatorNextElement.isEnabled()) {
					pageIndex++;
					// click forward through using the next button
					for (int i = pageIndex; i <= paginatorNumberElements.size(); i++) {
						pageIndex = makeBackendCallAndCheckValues(pageIndex, userType);
						paginatorNextElement.click();
						pageIndex++;
					}

					// click backward through the pages
					WebElement we;
					pageIndex--;
					for (int j = paginatorNumberElements.size() - 2; j >= 0; j--) {
						we = paginatorNumberElements.get(j);
						we.click();
						pageIndex--;
						pageIndex = makeBackendCallAndCheckValues(pageIndex, userType);
					}
				}
			}

		} else {
			assertNull(paginatorRow);
			assertNull(recordCountDisplay);
		}
	}

	/**
	 * @param pageIndex
	 * @return
	 */
	private int makeBackendCallAndCheckValues(int pageIndex, String userType) throws Exception{
		String url;
		int totalRecords;
		int pageSize;
		int listLength;
		int firstRecordNumber;
		int lastRecordNumber;
		String recordCountToBeShown;
		url = RestAssured.baseURI + "/true/submissionDate/desc/" + pageIndex + "/25";

		response = given().contentType(ContentType.JSON).headers(APIHeaderMap).when().get(url);

		pageIndex = response.getBody().jsonPath().getInt("pageIndex");
		pageSize = response.getBody().jsonPath().getInt("pageSize");
		listLength = response.getBody().jsonPath().getList("list").size();
		totalRecords = response.getBody().jsonPath().getInt("totalRecords");

		firstRecordNumber = (pageIndex - 1) * pageSize + 1;
		lastRecordNumber = firstRecordNumber + listLength - 1;
		recordCountToBeShown = firstRecordNumber + " - " + lastRecordNumber + " of " + totalRecords + " Records";
		// System.out.println("*********** pageIndex is *********** " +
		// pageIndex);
		// System.out.println("*********** recordCountToBeShown is *********** "
		// + recordCountToBeShown);
		// System.out.println(
		// "*********** recordCountDisplay.getText() is *********** " +
		// recordCountDisplay.getText());
		try {
			Thread.sleep(ConfigConstants.LONG_WAIT);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mbsCommonSteps.waitForElementToBeClickable(driver, centerPaginator);
		recordCountDisplay = driver.findElement(By.id("record-count-display"));
		mbsCommonSteps.waitForElementToBeVisible(driver, recordCountDisplay);
		// System.out.println(
		// "*********** recordCountDisplay.getText() is *********** " +
		// recordCountDisplay.getText());
		assertTrue(recordCountToBeShown.equalsIgnoreCase(recordCountDisplay.getText()));
		endpointResponseData = response.getBody().jsonPath().getJsonObject("list");
		compareUIWithBackendData(userType);
		return pageIndex;
	}

	public void compareUIWithBackendData(String userType) throws Exception{
		boolean lender = userType.toUpperCase().trim().contentEquals(UserType.LENDER.toString().trim());
		for (int i = 0; i < TransHistoryDataRows.size(); i++) {
			WebElement row = TransHistoryDataRows.get(i);
			String rowData = row.getText();
			Map<String, Object> gfRowData = (Map<String, Object>) endpointResponseData.get(i);
			System.out.println("UI Data " + rowData);
			System.out.println("endpoint data " + gfRowData);
			compareSubmissionDate(gfRowData, rowData);
			compareEntityName(gfRowData, rowData);
			if (!lender) {
				compareTSP(gfRowData, rowData);
				comparePortfolio(gfRowData, rowData);
				compareTrader(gfRowData, rowData);
			}
			compareTradeDate(gfRowData, rowData);
			compareBuySellType(gfRowData, rowData);
			compareAmount(gfRowData, rowData);
			compareProduct(gfRowData, rowData);
			compareCoupon(gfRowData, rowData);
			compareSettlementDate(gfRowData, rowData);
			comparePrice(gfRowData, rowData);
			compareStatus(gfRowData, rowData);
			compareTransId(gfRowData, rowData);
			compareInventoryNum(gfRowData, rowData);
			compareLender(gfRowData, rowData);
		}
	}

	private void compareTrader(Map<String, Object> gfRowData, String rowData) {
		Object trader = gfRowData.get("traderName");
		if (trader == null) {
			return;
		}
		String traderName = trader + "";
		String[] names = traderName.split(",");
		traderName = names[1].charAt(0) + ". " + names[0];
		assertTrue(rowData.contains(traderName));
	}

	private void compareLender(Map<String, Object> gfRowData, String rowData) {
		Object lender = gfRowData.get("lenderName");
		if (lender == null) {
			return;
		}
		String lenderName = lender + "";
		String[] names = lenderName.split(",");
		lenderName = names[1].charAt(0) + ". " + names[0];
		assertTrue(rowData.contains(lenderName));
	}

	private void comparePortfolio(Map<String, Object> gfRowData, String rowData) {
		Object portObj = gfRowData.get("tradeSubPortfolioShortName");
		String portStr = (portObj == null)?"-":portObj + "";
		assertTrue(rowData.contains(portStr));
	}

	private void compareInventoryNum(Map<String, Object> gfRowData, String rowData) {
		Integer invObj = (Integer) gfRowData.get("tradeSrcPrimaryId");
		String invStr = (invObj.intValue() == 0)?"-":invObj + "";
		assertTrue(rowData.contains(invStr));
	}

	private void compareTransId(Map<String, Object> gfRowData, String rowData) {
		String transId = gfRowData.get("transReqId") + "";
		assertTrue(rowData.contains(transId));
	}

	private void compareStatus(Map<String, Object> gfRowData, String rowData) {
		String status = gfRowData.get("stateType") + "";
		assertTrue(rowData.contains(getStatus(status)));
	}
	
	private String getStatus(String stateType) {
		StateType state = StateType.getEnum(stateType);
		return state.getDisplayName();
	}

	private void comparePrice(Map<String, Object> gfRowData, String rowData) {
		Object priceHandle = gfRowData.get("pricePercentHandleText");
		if (priceHandle == null) {
			return;
		}
		String price = priceHandle + " - " + gfRowData.get("pricePercentTicksText");
		assertTrue(rowData.contains(price));
	}

	private void compareSettlementDate(Map<String, Object> gfRowData, String rowData) throws Exception {
		Object tradeSettlementDateObj = gfRowData.get("tradeSettlementDate");
		if (tradeSettlementDateObj == null) {
			return;
		}
		Date tradeSettlementDate = new Date(MBSTradingPortalUtil.getLocalDateCurrentTimeStampFromGivenDateTime(tradeSettlementDateObj + "", DATEFORMAT_2));
		String tradeSettlementDateStr = MBSTradingPortalUtil.getLocalZonedDateTimeFromEpochMilli(tradeSettlementDate.getTime(), DATEFORMAT_3);
		assertTrue("trade settlement date is '" + tradeSettlementDateStr + "' not found in " + rowData, rowData.contains(tradeSettlementDateStr));
	}
	
	private void compareCoupon(Map<String, Object> gfRowData, String rowData) {
		assertTrue(rowData.contains(gfRowData.get("tradeCouponRate") + ""));
	}

	private void compareProduct(Map<String, Object> gfRowData, String rowData) {
		Map<String, Object> productMap = (Map<String, Object>) gfRowData.get("product");
		String product = productMap.get("nameCode") + "";
		assertTrue(rowData.contains(product));
	}

	private void compareAmount(Map<String, Object> gfRowData, String rowData) {
		String amount = gfRowData.get("tradeAmount") + "";
		int intAmount = Integer.parseInt(amount);
		NumberFormat f = NumberFormat.getInstance();
		f.setGroupingUsed(true);
		amount = f.format(intAmount);
		assertTrue("amount is " + amount + " not found in " + rowData, rowData.contains(amount));
	}

	private void compareBuySellType(Map<String, Object> gfRowData, String rowData) {
		assertTrue(rowData.contains(gfRowData.get("tradeBuySellType") + ""));
	}

	private void compareTradeDate(Map<String, Object> gfRowData, String rowData) throws Exception {
		Object tradeDateObj = gfRowData.get("tradeDate");
		if (tradeDateObj == null) {
			return;
		}
		System.out.println("trade Data Obj " + tradeDateObj.getClass().getName());
		Date tradeDate = new Date(MBSTradingPortalUtil.getLocalDateCurrentTimeStampFromGivenDateTime(tradeDateObj + "", DATEFORMAT_2));
		String tradeDateStr = MBSTradingPortalUtil.getLocalZonedDateTimeFromEpochMilli(tradeDate.getTime(), DATEFORMAT_3);
		assertTrue("trade date is '" + tradeDateStr + "' not found in " + rowData, rowData.contains(tradeDateStr));
	}

	private void compareTSP(Map<String, Object> gfRowData, String rowData) {
		Object tspObj = gfRowData.get("tspShortName");
		String tspStr = (tspObj == null)?"-":tspObj + "";
		assertTrue(rowData.contains(tspStr));
	}

	private void compareEntityName(Map<String, Object> gfRowData, String rowData) {
		assertTrue(rowData.contains(gfRowData.get("lenderEntityName") + ""));
	}

	private void compareSubmissionDate(Map<String, Object> gfRowData, String rowData) throws Exception {
		Object submissionDateObj = gfRowData.get("submissionDate");
		if (submissionDateObj == null) {
			return;
		}
		Date submissionDate = new Date(MBSTradingPortalUtil.getLocalDateCurrentTimeStampFromGivenDateTime(submissionDateObj + "", DATEFORMAT_6));
		String submissionDateStr = MBSTradingPortalUtil.getLocalZonedDateTimeFromEpochMilli(submissionDate.getTime(), DATEFORMAT_5);
		assertTrue("submission date is '" + submissionDateStr + "' not found in " + rowData, rowData.toLowerCase().contains(submissionDateStr.toLowerCase()));
		
	}
}
