/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.automation.runners;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/**
 * Created by g8us9b on 7/24/2017.
 */
@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty", "json:target/cucumber-ui_5.json", "html:target/cucumber-ui" }, glue = {
		"com.fanniemae.mbsportal.automation.steps" },
		//tags = { "@paginationAcceptedToggleResetPageTest" },
//		tags = { "@paginationNavigateAwayAndBackTest" },
//		tags = { "@paginationRefreshResetPageTest" },
//		tags = { "@paginationSortPageResetTest" },
//		tags = { "@paginationTest" },
		tags = {"@regtest"},
		// tags = {"@regtest1234"},
		// tags = {"@rerun2"},
		// , glue = { "com.fm.qa.smoke.cucumber" },
		// features = {"."})

		// tags = {"@regtest123"},
		// tags = {"@rerun2"},
		// , glue = { "com.fm.qa.smoke.cucumber" },
		// *
//		 features =
//		 {"src/test/resources/feature/mbsLenderproductpricegrid.feature",
//		// "src/test/resources/feature/mbstraderconfirmed.feature",
//		 "src/test/resources/feature/mbslendercancelled.feature",
//		 "src/test/resources/feature/zmbstraderPassCancel.feature",
//		 "src/test/resources/feature/mbstraderRePricing.feature" ,
//		 "src/test/resources/feature/mbsusertimeout.feature" //,
//		//// "src/test/resources/feature/mbstradersoftlock.feature"
//		 })
		// features = {"src/test/resources/feature/test.feature"})
		// features = {"src/test/resources/feature/mbsLenderproductpricegrid.feature"})
		// features = {"src/test/resources/feature/mbstraderconfirmed.feature"})
		// features = {"src/test/resources/feature/mbslendercancelled.feature"})
		//features = {"src/test/resources/feature/zmbstraderPassCancel.feature"})
		// features = {"src/test/resources/feature/mbstraderRePricing.feature"})
		// features =
		// {"src/test/resources/feature/mbsTransactionsHistorySorting.feature"})
		// features = {"src/test/resources/feature/mbstradersoftlock.feature"})
		// features = {"src/test/resources/feature/mbsusertimeout.feature"})
	    //  features = {"src/test/resources/feature/mbstraderValidatePriceDials.feature"})
		//features = {"src/test/resources/feature/mbslenderReadonly.feature"})
		//features = {"src/test/resources/feature/mbstraderValidatePriceDials.feature"})
	    //features = {"src/test/resources/feature/mbstransactionhistoryexport.feature"})
      //   features = {"src/test/resources/feature/mbstransactionhistorypagination.feature"})
	features = { "src/test/resources/feature/" })
public class mbsTBATradesRunnerTest {

}