package com.fanniemae.mbsportal.automation.selenium.utils;

import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class MBSTradingPortalUtil {

	public static final String TIME_ZONE_NYC = "America/New_York";

    public static String getCurrentDate(int timeToRemove, String format) {
    	Date d = new Date(getLocalDateCurrentTimeStamp());
    	Calendar c = Calendar.getInstance();
//    	System.out.println(c.getTimeZone().getID() + " " + getLocalZonedDateTimeFromEpochMilli(d.getTime(), format));
    	if (!c.getTimeZone().equals(TimeZone.getTimeZone(ZoneId.of(TIME_ZONE_NYC)))) {
    		c.setTime(d);
    		c.add(Calendar.HOUR, 1);
    	} else {
    		c.setTime(d);
    	}
    	c.add(Calendar.DATE, timeToRemove);
    	return getLocalZonedDateTimeFromEpochMilli(c.getTimeInMillis(), format);
	}

	/**
	 * @param epochMilli
	 * @param formatter
	 * @return
	 */
	public static String getLocalZonedDateTimeFromEpochMilli(Long epochMilli, String formatter) {
		try {
			Instant instant = Instant.ofEpochMilli(epochMilli);
			ZoneId zoneId = ZoneId.of(TIME_ZONE_NYC);
			ZonedDateTime zdt = ZonedDateTime.ofInstant(instant, zoneId);
			return zdt.format(DateTimeFormatter.ofPattern(formatter));
		} finally {

		}
	}

	/**
	 * 
	 * @return
	 */
	public static long getLocalDateCurrentTimeStamp() {
		return LocalDateTime.now().atZone(ZoneId.of(TIME_ZONE_NYC)).toInstant().toEpochMilli();

	}

	/**
	 * 
	 * @param dateTime
	 * @param formatter
	 * @return
	 * @throws Exception
	 */
	public static long getLocalDateCurrentTimeStampFromGivenDateTime(String dateTime, String formatter)
			throws Exception {
		try {
			return LocalDateTime.parse(dateTime, DateTimeFormatter.ofPattern(formatter)).atZone(ZoneId.of(TIME_ZONE_NYC))
					.toInstant().toEpochMilli();
		} catch (DateTimeException e) {
			return new SimpleDateFormat(formatter).parse(dateTime).getTime();
		}

	}

	
}
