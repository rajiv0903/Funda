package com.fanniemae.mbsportal.automation.steps;

import org.json.JSONException;
import org.openqa.selenium.WebDriver;

import com.fanniemae.mbsportal.automation.pages.mbslenderPage;
import com.fanniemae.mbsportal.automation.pages.mbsloginPage;
import com.fanniemae.mbsportal.automation.pages.mbstraderPage;
import com.fanniemae.mbsportal.automation.pages.mbstradertranshistoryPage;
import com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.UserType;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class mbsPaginationSteps {

	static WebDriver lenderDriver, readTraderDriver, traderDriver;
	static String lenderWindowHandle, readTraderWindowHandle, traderWindowHandle, exportWindowHandle;
	static boolean blnNewTrade;
	mbsCommonSteps mbscommonSteps = new mbsCommonSteps();

	mbsloginPage objLogin =  new mbsloginPage();
	mbslenderPage objLender = new mbslenderPage();
	mbstraderPage objTrader = new mbstraderPage();
	mbstradertranshistoryPage objTransHistory = new mbstradertranshistoryPage();

	/**
	 * @param user
	 * @throws InterruptedException
	 * @throws JSONException 
	 */
	@Then("^\"([^\"]*)\" \"([^\"]*)\" should see the pagination widgets at the bottom of the page$")
	public void validatePaginationWidget(String user, String userEntity) throws Throwable {
		if (user.toUpperCase().trim().contentEquals(UserType.LENDER.toString().trim())) {
			lenderWindowHandle = mbsCommonSteps.LenderWindowHandle;
			lenderDriver = mbsCommonSteps.LenderDriver;
			objTransHistory.transhistoryPageInit(lenderDriver);
			objLogin.SwitchWindow(lenderWindowHandle, lenderDriver);
			objTransHistory.validatePagination(user, userEntity);
		} else if (user.toUpperCase().trim().contentEquals(UserType.READ_TRADER.toString().trim())) {
			readTraderWindowHandle = mbsCommonSteps.ReadTraderWindowHandle;
			readTraderDriver = mbsCommonSteps.ReadTraderDriver;
			objTransHistory.transhistoryPageInit(readTraderDriver);
			objLogin.SwitchWindow(readTraderWindowHandle, readTraderDriver);
			objTransHistory.validatePagination(user, userEntity);
		} else if (user.toUpperCase().trim().contentEquals(UserType.TRADER.toString().trim())) {
			traderWindowHandle = mbsCommonSteps.TraderWindowHandle;
			traderDriver = mbsCommonSteps.TraderDriver;
			objTransHistory.transhistoryPageInit(traderDriver);
			objLogin.SwitchWindow(traderWindowHandle, traderDriver);
			objTransHistory.validatePagination(user, userEntity);
		}
	}
	
    @Given("^\"([^\"]*)\" goes to the Transaction History page$")
	public void goToTransactionHistoryPage(String user) throws InterruptedException {
		if (user.toUpperCase().trim().contentEquals(UserType.LENDER.toString().trim())) {
			lenderWindowHandle = mbsCommonSteps.LenderWindowHandle;
			lenderDriver = mbsCommonSteps.LenderDriver;
			objTransHistory.transhistoryPageInit(lenderDriver);
			objLogin.SwitchWindow(lenderWindowHandle, lenderDriver);
			objTransHistory.switchToTransactionHistoryPage();
		} else if (user.toUpperCase().trim().contentEquals(UserType.READ_TRADER.toString().trim())) {
			readTraderWindowHandle = mbsCommonSteps.ReadTraderWindowHandle;
			readTraderDriver = mbsCommonSteps.ReadTraderDriver;
			objTransHistory.transhistoryPageInit(readTraderDriver);
			objLogin.SwitchWindow(readTraderWindowHandle, readTraderDriver);
			objTransHistory.switchToTransactionHistoryPage();
		} else if (user.toUpperCase().trim().contentEquals(UserType.TRADER.toString().trim())) {
			traderWindowHandle = mbsCommonSteps.TraderWindowHandle;
			traderDriver = mbsCommonSteps.TraderDriver;
			objTransHistory.transhistoryPageInit(traderDriver);
			objLogin.SwitchWindow(traderWindowHandle, traderDriver);
			objTransHistory.switchToTransactionHistoryPage();
		}    	
    }
    
    @Given("^\"([^\"]*)\" navigatesﾠto the TBA Trading page$")
	public void goToTBATradingPage(String user) throws InterruptedException {
		if (user.toUpperCase().trim().contentEquals(UserType.LENDER.toString().trim())) {
			lenderWindowHandle = mbsCommonSteps.LenderWindowHandle;
			lenderDriver = mbsCommonSteps.LenderDriver;
			objLender.LenderPageInit(lenderDriver);
			objLogin.SwitchWindow(lenderWindowHandle, lenderDriver);
			objTransHistory.switchToTBATradingPage();
		} else if (user.toUpperCase().trim().contentEquals(UserType.READ_TRADER.toString().trim())) {
			readTraderWindowHandle = mbsCommonSteps.ReadTraderWindowHandle;
			readTraderDriver = mbsCommonSteps.ReadTraderDriver;
			objTrader.mbsTraderPageInit(readTraderDriver);
			objLogin.SwitchWindow(readTraderWindowHandle, readTraderDriver);
			objTransHistory.switchToTBATradingPage();
		} else if (user.toUpperCase().trim().contentEquals(UserType.TRADER.toString().trim())) {
			traderWindowHandle = mbsCommonSteps.TraderWindowHandle;
			traderDriver = mbsCommonSteps.TraderDriver;
			objTrader.mbsTraderPageInit(traderDriver);
			objLogin.SwitchWindow(traderWindowHandle, traderDriver);
			objTransHistory.switchToTBATradingPage();
		}    	
    }
    
    @Given("^User traverses '1' page forward on the History page$")
	public void traverseHistoryPages() {
    	objTransHistory.traverseOnePage();
    }
    
    @When("^User clicks on any column header$")
	public void clickColumnHeader() throws InterruptedException, JSONException {
    	objTransHistory.clickColumnHeader();
    }
    
    @When("^User clicks on the refresh icon$")
	public void clickRefreshIcon() throws InterruptedException, JSONException {
    	objTransHistory.clickRefreshIcon();
    }
    
    @When("^User clicks on the accepted trades toggle$")
	public void clickAcceptedTradesToggle() throws InterruptedException, JSONException {
    	objTransHistory.clickAcceptedTradesToggle();
    }
    
    
    
    @Then("^User should be back on page '1'$")
	public void checkIfOnPageOne() {
    	objTransHistory.checkIfOnPageOne();
    }
    
    @Then("^Validate history data for \"([^\"]*)\"$")
    public void validateData(String userType) throws Throwable {
    	objTransHistory.compareUIWithBackendData(userType);
    }
}	
