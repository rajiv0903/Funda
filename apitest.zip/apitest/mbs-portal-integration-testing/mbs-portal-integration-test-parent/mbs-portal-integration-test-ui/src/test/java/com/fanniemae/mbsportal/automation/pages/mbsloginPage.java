/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.automation.pages;

import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.LOGINERROR;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.USERDETAILSFROMCODEQUERY;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.USERLOGINQUERY;
import static com.fanniemae.mbsportal.automation.selenium.utils.AutoUtil.WaitForAngular2Finish;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;
import com.fanniemae.mbsportal.automation.selenium.conf.ConfigConstants;
import com.fanniemae.mbsportal.automation.selenium.utils.ExcelLib;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

/**
 * Created by g8us9b on 9/28/2017.
 */
public class mbsloginPage {

    private ExcelLib objExcelObj = new ExcelLib();

    private String ExternalUser;
    private String RoleName;
    private String LenderName;
    private String InternalUser;
    private String TraderName;
    private String Pwd;

    private WebDriver webDriver;
    private String windowHandle;
    private boolean blnNewTrade;

    String url = ConfigConstants.baseUrl.toString().trim();

    @FindBy(id = "userName")
    protected WebElement UID;
    @FindBy(id = "password")
    protected WebElement Password;
    @FindBy(css = ".fm-primary-button")
    protected WebElement LoginSubmit;
    @FindBy(css = ".md-card")
    protected WebElement MBSPortalLink;
    @FindBy(linkText = "Logout")
    protected WebElement LogOutLink;
    @FindBy(css = ".user-dropdown")
    protected WebElement LogOutUser;
    @FindBy(css = ".err-msg-str")
    protected List<WebElement> ErrorMsg;
    @FindBy(css = ".scissors")
    protected WebElement TempPage;



    /**
     * Purpose: Init all the Login Page Elements using the PageFactory
     * 
     * @param driver
     *            pass the appropriate driver to init the page elements
     */
    public void LoginPageInit(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    /**
     * Purpose: Set the External User
     * 
     * @param UserID
     */
    public void setExternalUser(String UserID) {
        // if(ExternalUser == null)
        ExternalUser = UserID.trim();
    }

    /**
     * Purpose: Get the External User
     * 
     * @return
     */
    public String getExternalUser() {
        return ExternalUser.trim();
    }

    /**
     * Purpose: Set Role Name
     * 
     * @param RName
     */
    public void setRoleName(String RName) {
        if (RoleName == null)
            RoleName = RName.trim();
    }

    /**
     * Purpose: Get Role Name
     * 
     * @return
     */
    public String getRoleName() {
        return RoleName.trim();
    }

    /**
     * Purpose: Set Lender Name
     * 
     * @param LName
     */
    public void setLenderName(String LName) {
        if (LenderName == null)
            LenderName = LName.trim();
    }

    /**
     * Get Lender Name
     * 
     * @return
     */
    public String getLenderName() {
        return LenderName.trim();
    }

    /**
     * Set Internal User
     * 
     * @param IUser
     */
    public void setInternalUser(String IUser) {
        if (InternalUser == null)
            InternalUser = IUser.trim();
    }

    /**
     * Purpose: Get Internal User
     * 
     * @return
     */
    public String getInternalUser() {
        return InternalUser.trim();
    }

    /**
     * Purpose: Set Trader Name
     * 
     * @param TName
     */
    public void setTraderName(String TName) {
        if (TraderName == null)
            TraderName = TName.trim();
    }

    /**
     * Purpose: Get Trader Name
     * 
     * @return
     */
    public String getTraderName() {
        return TraderName.trim();
    }

    /**
     * Purpose: Set User Password
     * 
     * @param sPwd
     */
    public void setUserPassword(String sPwd) {
        // if(Pwd == null)
        Pwd = sPwd.trim();
    }

    /**
     * Purpose: Get User Password
     * 
     * @return
     */
    public String getUserPassword() {
        return Pwd.trim();
    }

    /**
     * Purpose: Switch the window i.e. Lender Browser or Trader Browser
     * 
     * @param WindowHandle
     * @param driver
     * @throws InterruptedException
     */
    public void SwitchWindow(String WindowHandle, WebDriver driver) throws InterruptedException {
        driver.switchTo().window(WindowHandle);
        Thread.sleep(ConfigConstants.MED_WAIT);
        Thread.sleep(ConfigConstants.POLLING_WAIT);
        //WaitForAngular2Finish();
    }

    /**
     * Purpose: Launch the Browser
     * 
     * @param driver
     * @return
     */
    // To be replaced by the bew method
    @Deprecated
    public String LaunchApplication(WebDriver driver) {
        driver.get(url);
        return driver.getWindowHandle().toString().trim();
    }

    /**
     * 
     * @param driver
     */
    public void LaunchApp(WebDriver driver) {
        driver.get(url);
        setWindowHandle(driver.getWindowHandle().toString().trim());
    }

    /**
     * Purpose: Navigate to Trader View or Lender View
     * 
     * @throws InterruptedException
     */
    public void NavigateToPage(WebDriver driver) throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver,120);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".md-card")));

        MBSPortalLink.click();
        Thread.sleep(ConfigConstants.LONG_WAIT);
    }

    /**
     * Purpose: Get the User Data depending on the User ID from the Test Data
     * Excel sheet
     * 
     * @param USERID
     * @throws FilloException
     */
    public void FetchUserData(String USERID) throws FilloException {
        Recordset rsUser = null;
        String Query = USERLOGINQUERY + "'" + USERID + "'";
        try {
            // get the user details
            rsUser = objExcelObj.GetTestData(Query);
            rsUser.moveFirst();

            setExternalUser(rsUser.getField("User_ID").toString().trim());
            setRoleName(rsUser.getField("RAM_Role_Name").toString().trim());
            setLenderName(rsUser.getField("Lender").toString().trim());
            setUserPassword(rsUser.getField("Password").toString().trim());
        } finally {
            rsUser.close();
        }

    }

    /**
     * Purpose: Get the User Data depending on the lender/trader input code from
     * the Test Data Excel sheet
     * 
     * @param USERID
     * @throws FilloException
     */
    public void FetchUserDataFromCode(String userCode) throws FilloException {
        Recordset rsUser = null;
        String Query = USERDETAILSFROMCODEQUERY + "'" + userCode + "'";
        try {
            // get the user details
            rsUser = objExcelObj.GetTestData(Query);
            rsUser.moveFirst();

            setExternalUser(rsUser.getField("User_ID").toString().trim());
            setRoleName(rsUser.getField("RAM_Role_Name").toString().trim());
            setLenderName(rsUser.getField("Lender").toString().trim());
            setUserPassword(rsUser.getField("Password").toString().trim());
        } finally {
            rsUser.close();
        }

    }

    /**
     * Purpose: Set the UserID and Password
     * 
     * @throws FilloException
     */
    public void UserLogin() throws FilloException, InterruptedException {
        // login using user id and password
        Thread.sleep(ConfigConstants.LONG_WAIT);
        UID.sendKeys(getExternalUser());
        Password.sendKeys(getUserPassword());
        LoginSubmit.click();
        Thread.sleep(ConfigConstants.MED_WAIT);

        //retry login if there are issues with multiple session of same user
        try {
            if(ErrorMsg.size() > 0)
            {
                System.out.println("error logging");
                Thread.sleep(ConfigConstants.MED_WAIT);
                Password.sendKeys(getUserPassword());
                LoginSubmit.click();
            }

        } catch (NoSuchElementException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Purpose: Log off from the app
     * 
     * @param driver
     * @throws InterruptedException
     */
    public void UserLogoff(WebDriver driver) throws InterruptedException {
        Thread.sleep(ConfigConstants.MED_WAIT);
       // WaitForAngular2Finish();
    //    LogOutUser.click();
        Thread.sleep(ConfigConstants.MED_WAIT);

      //  LogOutLink.click();
    }

    /**
     * @return the webDriver
     */
    public WebDriver getWebDriver() {
        return webDriver;
    }

    /**
     * @param webDriver
     *            the webDriver to set
     */
    public void setWebDriver(WebDriver webDriver) {
        this.webDriver = webDriver;
    }

    /**
     * @return the windowHandle
     */
    public String getWindowHandle() {
        return windowHandle;
    }

    /**
     * @param windowHandle
     *            the windowHandle to set
     */
    public void setWindowHandle(String windowHandle) {
        this.windowHandle = windowHandle;
    }

    /**
     * @return the blnNewTrade
     */
    public boolean isBlnNewTrade() {
        return blnNewTrade;
    }

    /**
     * @param blnNewTrade
     *            the blnNewTrade to set
     */
    public void setBlnNewTrade(boolean blnNewTrade) {
        this.blnNewTrade = blnNewTrade;
    }
}
