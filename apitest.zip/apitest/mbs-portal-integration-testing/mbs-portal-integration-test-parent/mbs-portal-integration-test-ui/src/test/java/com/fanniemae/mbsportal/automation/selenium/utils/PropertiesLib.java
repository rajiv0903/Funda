/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.automation.selenium.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.PROPERTYFILEPATH;

/**
 * Created by g8us9b on 11/30/2017.
 */
public class PropertiesLib {

        Properties prop = new Properties();
        InputStream input = null;

        public void InitPropertyFile() throws IOException {
            input = new FileInputStream(PROPERTYFILEPATH);
            prop.load(input);
        }

        public String getBrowserName()
        {
             return  prop.getProperty("browser");
        }

        public String getBrowserVersion()
        {
            return prop.getProperty("version");
        }

        public String getOSName()
        {
                return prop.getProperty("os");
        }

        public String getUsername()
        {
                return prop.getProperty("username");
        }


        public String getAccesskey()
        {
                return prop.getProperty("accesskey");
        }

        public String getparentTunnelId()
        {
                return prop.getProperty("parentTunnelId");
        }

        public String getTunnelId()
        {
                return prop.getProperty("tunnelId");
        }

        public String getProxyHost()
        {
                return prop.getProperty("proxyHost");
        }

        public String getproxyPort()
        {
                return prop.getProperty("proxyPort");
        }

        public String getbuildId()
        {
             return prop.getProperty("buildId");
        }

        public String getname()
        {
              return prop.getProperty("name");
        }

        public String getSeleniumVersion()
        {
                return prop.getProperty("selenium_version");
        }
        
        public String getDownloadPath()
        {
        		return prop.getProperty("download_path");
        }

        public String getEnv() {return prop.getProperty("env");}

        public String getBGEnv() {return prop.getProperty("B_G");}

}
