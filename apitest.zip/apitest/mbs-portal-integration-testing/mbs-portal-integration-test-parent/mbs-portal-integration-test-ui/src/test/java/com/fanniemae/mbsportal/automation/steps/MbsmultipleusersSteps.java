/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.automation.steps;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import com.codoid.products.exception.FilloException;
import com.fanniemae.mbsportal.automation.pages.mbslenderPage;
import com.fanniemae.mbsportal.automation.pages.mbsloginPage;
import com.fanniemae.mbsportal.automation.pages.mbstraderPage;
import com.fanniemae.mbsportal.automation.pages.mbstradertranshistoryPage;
import com.fanniemae.mbsportal.automation.selenium.conf.ConfigConstants;
import com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants;
import com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.BrowserModeType;
import com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.UserType;
import com.fanniemae.mbsportal.automation.selenium.utils.AutoUtil;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import static com.fanniemae.mbsportal.automation.selenium.utils.AutoUtil.WaitForAngular2Finish;

/**
 * @author g8upjv
 * @date 01/04/2018
 * Initial version
 */
public class MbsmultipleusersSteps {
	static Map<String, Object> userViews = new HashMap<>();
	// WebDriver webDriver; //, TraderDriver;
	// String windowHandle; //, TraderWindowHandle;
	// static boolean blnNewTrade;
	// String TransID;
	// String LenderID, TraderId="";

	mbsloginPage objLogin;// = new mbsloginPage();
	mbslenderPage objLender;// = new mbslenderPage();
	mbstraderPage objTrader;// = new mbstraderPage();
	mbstradertranshistoryPage objTransHistory;// = new
												// mbstradertranshistoryPage();

	@After
	public void teardown() {
		// objTraderConfirmed.teardown();
	}

	/**
	 * Method to retrieve details based on user code
	 *
	 * @param User
	 * @param userCode
	 * @throws FilloException
	 * @throws InterruptedException
	 * @throws IOException
	 */
	@Given("^\"([^\"]*)\" \"([^\"]*)\" Logs to MBS Trading Platform$")
	public void UsersLogin_ext(String userCode, String User) throws FilloException, InterruptedException, IOException {
		// mbsloginPage objLogin;
		// mbslenderPage objLender;
		// mbstraderPage objTrader;
		if (userViews.containsKey(userCode.toUpperCase())) {
			if (User.toUpperCase().trim().contentEquals(UserType.LENDER.toString().trim())) {
				objLender = (mbslenderPage) userViews.get(userCode.toUpperCase());
				objLogin = objLender.getMbsloginpage();
				objLogin.setBlnNewTrade(false);
			} else {
				objTrader = (mbstraderPage) userViews.get(userCode.toUpperCase());
				objLogin = objTrader.getMbsloginpage();
			}
			// objLogin = (mbsloginPage) userViews.get(userCode.toUpperCase());
			objLogin.FetchUserDataFromCode(userCode);
			objLogin.LoginPageInit(objLogin.getWebDriver());
			objLogin.SwitchWindow(objLogin.getWindowHandle(), objLogin.getWebDriver());
		} else {
		    if (User.toUpperCase().trim().contentEquals(UserType.LENDER.toString().trim())) {
		        AutoUtil.setUp(BrowserModeType.NORMAL);
		    } else {
		        AutoUtil.setUp(BrowserModeType.INCOGONITO);
		    }

			objLogin = new mbsloginPage();
			objLogin.setWebDriver(AutoUtil.getDriver());
			objLogin.LaunchApp(objLogin.getWebDriver());
			objLogin.LoginPageInit(objLogin.getWebDriver());
			objLogin.FetchUserDataFromCode(userCode);
			objLogin.UserLogin();
			objLogin.NavigateToPage(AutoUtil.getDriver());
			if (User.toUpperCase().trim().contentEquals(UserType.LENDER.toString().trim())) {
			        objLender = new mbslenderPage();
				objLogin.setBlnNewTrade(true);
				objLender.setMbsloginpage(objLogin);
				userViews.put(userCode.toUpperCase(), objLender);
			} else {
			        objTrader = new mbstraderPage();
				objTrader.setMbsloginpage(objLogin);
				userViews.put(userCode.toUpperCase(), objTrader);
			}
		}
	}

	@When("^\"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" is on TBA Trading Page$")
	public void NavigatetoPage_ext(String userCode, String Type, String ID)
		throws InterruptedException, FilloException, IOException {

		// go to the page
		Thread.sleep(ConfigConstants.MED_WAIT);

		if (Type.toUpperCase().contentEquals(UserType.LENDER.toString())) {
			// LenderID = ID;
			objLender = (mbslenderPage) userViews.get(userCode.toUpperCase());
			objLender.LenderPageInit(objLender.getMbsloginpage().getWebDriver());
			objLender.setLenderId(ID);
			objLender.LenderGetExpectedData(ID);
			objLender.ValidateLenderInitialLoad(objLender.getMbsloginpage().isBlnNewTrade());
		} else {
			// TraderId = ID;
			objTrader = (mbstraderPage) userViews.get(userCode.toUpperCase());
			objTrader.setTraderId(ID);
			objTrader.mbsTraderPageInit(objTrader.getMbsloginpage().getWebDriver());
			objTrader.LenderGetExpectedData(ID);
			objTrader.ValidateTraderInitialLoad();
		}
	}

	@Then("^\"([^\"]*)\" Lender submits a new Trade$")
	public void LenderSubmitAmount_ext(String userCode) throws InterruptedException, FilloException {
		objLender = (mbslenderPage) userViews.get(userCode.toUpperCase());
		objLender.setTransId(objLender.LenderSubmitAmount(objLender.getMbsloginpage().getLenderName(),
				objLender.getMbsloginpage().getRoleName(), objLender.getMbsloginpage().isBlnNewTrade()));
	}

	@Then("^\"([^\"]*)\" Trader submits Price for submitted Trade$")
	public void TraderSubmitPrice_ext(String userCode) throws FilloException, InterruptedException {
		// validate all data and enter price with validations
		objTrader = (mbstraderPage) userViews.get(userCode.toUpperCase());
		objTrader.TraderSubmitPriceNoValidation();
	}

	@Then("^\"([^\"]*)\" Trader locks the row for pricing$")
        public void TraderLockRow(String userCode) throws FilloException, InterruptedException {
                // validate all data and enter price with validations
                objTrader = (mbstraderPage) userViews.get(userCode.toUpperCase());
                objTrader.traderLockRow(userCode);
        }

	@Then("^\"([^\"]*)\" Trader validates the lock$")
        public void TraderValidateLockRow(String userCode) throws FilloException, InterruptedException {
                // validate all data and enter price with validations
                objTrader = (mbstraderPage) userViews.get(userCode.toUpperCase());
                objTrader.traderLockRowValidate(userCode.toUpperCase());
        }

	@When("^\"([^\"]*)\" Lender receives Trade \"([^\"]*)\"$")
	public void LenderReceivePrice_ext(String userCode, String PriceType) throws InterruptedException {
		objLender = (mbslenderPage) userViews.get(userCode.toUpperCase());
		objLogin = objLender.getMbsloginpage();
		objLogin.SwitchWindow(objLogin.getWindowHandle(), objLogin.getWebDriver());
		objLender.ValidateLenderReceivePrice(objLogin.getLenderName(), objLogin.getRoleName(), PriceType);
	}

	@Then("^\"([^\"]*)\" Lender Hits the trade$")
	public void LenderHitTrade_ext(String userCode) throws FilloException, InterruptedException {
		objLender = (mbslenderPage) userViews.get(userCode.toUpperCase());
		objLender.AcceptQuote(GlobalConstants.INCL_VALIDATION);
	}

	@When("^\"([^\"]*)\" Trader receives Lender confirmation$")
	public void TraderReceiveConfirmation_ext(String userCode) throws InterruptedException {
		Thread.sleep(ConfigConstants.MED_WAIT);
		//WaitForAngular2Finish();
		objTrader = (mbstraderPage) userViews.get(userCode.toUpperCase());
		objLogin = objTrader.getMbsloginpage();
		objLogin.SwitchWindow(objLogin.getWindowHandle(), objLogin.getWebDriver());
		objTrader.ValidateTraderReceiveHit();
	}

	@Then("^\"([^\"]*)\" Trader confirms the Trade$")
	public void TraderConfirmTrade_ext(String userCode) throws InterruptedException, FilloException {
		objTrader = (mbstraderPage) userViews.get(userCode.toUpperCase());
		objTrader.TraderConfirmTrade(GlobalConstants.INCL_VALIDATION);
	}

	@Then("^\"([^\"]*)\" ^\"([^\"]*)\" is able to verify Trade details on Transaction History Page$")
	public void TraderTransactionHistory_ext(String userCode, String User)
		throws InterruptedException, FilloException, ParseException, IOException {
		objTransHistory = new mbstradertranshistoryPage();
		if (User.toUpperCase().trim().contentEquals(UserType.LENDER.toString().trim())) {
			objLender = (mbslenderPage) userViews.get(userCode.toUpperCase());
			objLogin = objLender.getMbsloginpage();
			objTransHistory.transhistoryPageInit(objLogin.getWebDriver());
			objLogin.SwitchWindow(objLogin.getWindowHandle(), objLogin.getWebDriver());
			objTransHistory.goToTraderTransHistory(objLender.getLenderId(), objLender.getTransId(),
					objLogin.getRoleName(), UserType.LENDER);
		} else if (User.toUpperCase().trim().contentEquals(UserType.TRADER.toString().trim())) {
			objTrader = (mbstraderPage) userViews.get(userCode.toUpperCase());
			objLogin = objTrader.getMbsloginpage();
			objTransHistory.transhistoryPageInit(objLogin.getWebDriver());
			objLogin.SwitchWindow(objLogin.getWindowHandle(), objLogin.getWebDriver());
			objTransHistory.goToTraderTransHistory(objTrader.getTraderId(), objTrader.getTransId(),
					objLogin.getRoleName(), UserType.TRADER);
			objTrader.setMbstradertranshistoryPage(objTransHistory);
		}
	}

	@Then("^\"([^\"]*)\" ^\"([^\"]*)\" clicks on the export button on Transaction History Page$")
	public void TraderTransactionHistoryExport_ext(String userCode, String User)
			throws InterruptedException, FilloException, ParseException {
		objTransHistory = new mbstradertranshistoryPage();
		if (User.toUpperCase().trim().contentEquals(UserType.LENDER.toString().trim())) {
			objLender = (mbslenderPage) userViews.get(userCode.toUpperCase());
			objLogin = objLender.getMbsloginpage();
			objTransHistory.transhistoryPageInit(objLogin.getWebDriver());
			objLogin.SwitchWindow(objLogin.getWindowHandle(), objLogin.getWebDriver());
			objTransHistory.goToTraderTransHistoryAndExport();
		} else if (User.toUpperCase().trim().contentEquals(UserType.TRADER.toString().trim())) {
			objTrader = (mbstraderPage) userViews.get(userCode.toUpperCase());
			objLogin = objTrader.getMbsloginpage();
			objTransHistory.transhistoryPageInit(objLogin.getWebDriver());
			objLogin.SwitchWindow(objLogin.getWindowHandle(), objLogin.getWebDriver());
			objTransHistory.goToTraderTransHistoryAndExport();
			objTrader.setMbstradertranshistoryPage(objTransHistory);
		}
	}

	@Then("^\"([^\"]*)\" Lender receives Trade confirmation on Lender page$")
	public void LenderConfirmReceiveStatus_ext(String userCode)
			throws FilloException, InterruptedException, ParseException {
		objLender = (mbslenderPage) userViews.get(userCode.toUpperCase());
		objLogin = objLender.getMbsloginpage();
		objLogin.SwitchWindow(objLogin.getWindowHandle(), objLogin.getWebDriver());
		objLender.LenderReceiveConfirm(objLogin.getLenderName(), objLogin.getRoleName());
	}

	@Then("^\"([^\"]*)\" \"([^\"]*)\" User Logs Off from the MBS Trading Platform$")
	public void UserLogoff_ext(String userCode, String user) throws InterruptedException {
		if (user.toUpperCase().trim().contentEquals(UserType.LENDER.toString().trim())) {
			objLender = (mbslenderPage) userViews.get(userCode.toUpperCase());
			objLogin = objLender.getMbsloginpage();
			//timeout the trade to close the test properly
			Thread.sleep(ConfigConstants.TRADE_TIMEOUT);

		} else if (user.toUpperCase().trim().contentEquals(UserType.TRADER.toString().trim())) {
			objTrader = (mbstraderPage) userViews.get(userCode.toUpperCase());
			objLogin = objTrader.getMbsloginpage();
		}

		objLogin.LoginPageInit(objLogin.getWebDriver());
		objLogin.SwitchWindow(objLogin.getWindowHandle(), objLogin.getWebDriver());
		objLogin.UserLogoff(objLogin.getWebDriver());
		Thread.sleep(ConfigConstants.MED_WAIT);

		objLogin.getWebDriver().close();
	}

	@When("^\"([^\"]*)\" Lender Cancels the Submitted Trade$")
	public void CancelTrade_ext(String userCode) throws InterruptedException {
		objLender = (mbslenderPage) userViews.get(userCode.toUpperCase());
		objLender.CancelTrade();
	}

	@Then("^\"([^\"]*)\" ^\"([^\"]*)\" Status should be Displayed on the Lender Trade Info section$")
	public void ValidateCancelledStatus_ext(String userCode, String TradeStatus)
			throws InterruptedException, FilloException {
		objLender = (mbslenderPage) userViews.get(userCode.toUpperCase());
		objLogin = objLender.getMbsloginpage();
		objLogin.SwitchWindow(objLogin.getWindowHandle(), objLogin.getWebDriver());
		objLender.ValidateCancelStatus(objLogin.getLenderName(), objLogin.getRoleName(), TradeStatus);
	}

	@Then("^Trader \"([^\"]*)\" ^\"([^\"]*)\" the Trade$")
	public void TraderPassCancelTrade_ext(String userCode, String TraderAction)
			throws InterruptedException, FilloException {
		objTrader = (mbstraderPage) userViews.get(userCode.toUpperCase());
		objTrader.TraderAction(TraderAction);
	}

	@Then("^Clear the data$")
        public void clearData()
                        throws InterruptedException, FilloException {
                userViews.clear();
        }

}
