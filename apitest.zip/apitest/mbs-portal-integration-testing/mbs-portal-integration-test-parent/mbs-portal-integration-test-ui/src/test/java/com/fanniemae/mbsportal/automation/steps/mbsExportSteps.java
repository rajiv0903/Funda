package com.fanniemae.mbsportal.automation.steps;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import com.codoid.products.exception.FilloException;
import com.fanniemae.mbsportal.automation.pages.mbslenderPage;
import com.fanniemae.mbsportal.automation.pages.mbsloginPage;
import com.fanniemae.mbsportal.automation.pages.mbstraderPage;
import com.fanniemae.mbsportal.automation.pages.mbstradertranshistoryPage;
import com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.UserType;
import com.fanniemae.mbsportal.automation.selenium.utils.AutoUtil;
import com.fanniemae.mbsportal.automation.selenium.utils.MBSTradingPortalUtil;

import cucumber.api.java.en.Then;

public class mbsExportSteps {

	static WebDriver lenderDriver, traderDriver;
	static String lenderWindowHandle, traderWindowHandle, exportWindowHandle;
	static boolean blnNewTrade;
	mbsCommonSteps mbscommonSteps = new mbsCommonSteps();

	mbsloginPage objLogin =  new mbsloginPage();
	mbslenderPage objLender = new mbslenderPage();
	mbstraderPage objTrader = new mbstraderPage();
	mbstradertranshistoryPage objTransHistory = new mbstradertranshistoryPage();

	/**
	 * @param user
	 * @throws InterruptedException
	 * @throws FilloException
	 * @throws ParseException
	 */
	@Then("^\"([^\"]*)\" clicks on the export button on Transaction History Page$")
	public void traderTransactionHistoryExport(String user)
			throws InterruptedException, FilloException, ParseException {
		if (user.toUpperCase().trim().contentEquals(UserType.LENDER.toString().trim())) {
			lenderWindowHandle = mbsCommonSteps.LenderWindowHandle;
			lenderDriver = mbsCommonSteps.LenderDriver;
			objTransHistory.transhistoryPageInit(lenderDriver);
			objLogin.SwitchWindow(lenderWindowHandle, lenderDriver);
			objTransHistory.goToTraderTransHistoryAndExport();
		} else if (user.toUpperCase().trim().contentEquals(UserType.TRADER.toString().trim())) {
			traderWindowHandle = mbsCommonSteps.TraderWindowHandle;
			traderDriver = mbsCommonSteps.TraderDriver;
			objTransHistory.transhistoryPageInit(traderDriver);
			objLogin.SwitchWindow(traderWindowHandle, traderDriver);
			objTransHistory.goToTraderTransHistoryAndExport();
		}
	}

	/**
	 * @param user
	 * @throws InterruptedException
	 */
	@Then("^\"([^\"]*)\" should see the export popup with the below elements$")
	public void validateExportPopUp(String user, Map<String, String> elementMap) throws InterruptedException {
		if (user.toUpperCase().trim().contentEquals(UserType.LENDER.toString().trim())) {
			lenderWindowHandle = mbsCommonSteps.LenderWindowHandle;
			lenderDriver = mbsCommonSteps.LenderDriver;
			objTransHistory.transhistoryPageInit(lenderDriver);
			objLogin.SwitchWindow(lenderWindowHandle, lenderDriver);
			objTransHistory.validateExportPopUp(elementMap);
		} else if (user.toUpperCase().trim().contentEquals(UserType.TRADER.toString().trim())) {
			traderWindowHandle = mbsCommonSteps.TraderWindowHandle;
			traderDriver = mbsCommonSteps.TraderDriver;
			objTransHistory.transhistoryPageInit(traderDriver);
			objLogin.SwitchWindow(traderWindowHandle, traderDriver);
			objTransHistory.validateExportPopUp(elementMap);
		}

	}

	@Then("^User clicks the cancel button$")
	public void clickCancelButton() {
		objTransHistory.clickCancelButton();
	}

	@Then("^User clicks the export button$")
	public void clickSubmitButton() {
		objTransHistory.clickSubmitButton();
	}
	
	@Then("^\"([^\"]*)\" should see the export button on the export popup as \"([^\"]*)\"$")
	public void validateExportButtonOnPopUp(String user, String enabled) {
		if (enabled.equals("enabled")) {
			objTransHistory.validateSubmitButton(true);
		} else {
			objTransHistory.validateSubmitButton(false);
		}
	}

	@Then("^^\"([^\"]*)\" sees the File is in download directory$")
	public void findDownloadFile(String user) throws Exception {
		Thread.sleep(10000);
		if (user.toUpperCase().trim().contentEquals(UserType.LENDER.toString().trim())) { // Lender
		} else if (user.toUpperCase().trim().contentEquals(UserType.TRADER.toString().trim())) { // Trader
			String filename = getFileName(user);
			System.out.println(filename);
			File directory = new File(AutoUtil.objProperties.getDownloadPath());
			String[] files = directory.list();
			System.out.println(Arrays.toString(files));
			for (String diskFileName : files) {
				if (diskFileName.contains(filename)) {
					File f = new File(directory.getPath() + File.separator + diskFileName);
					try {
						InputStream fis = new FileInputStream(f);
						assertNotEquals("file " + f + " is empty", -1, fis.read());
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						fail("File error in file " + f);
					}
					assertNotEquals("file " + f + " is 0 length ", 0, f.length());
					return;
				}
			}
			fail("No file found matching " + filename);
		}
	}
	
	@Then("^User selects date \"([^\"]*)\"$")
	public void selectDate(String date) {
		objTransHistory.selectDate(date);
	}

	private String getFileName(String user) {
		String filename = "";
		filename += "_" + MBSTradingPortalUtil.getCurrentDate(0, "MMddYYYY_HHmm");
		return filename;
	}
}
