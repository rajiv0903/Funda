/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.automation.selenium.conf;

/**
 * Created by g8uaxt on 7/20/2017.
 */

/**
 *
 *         Constants file for configuration info
 */
public interface ConfigConstants {
        //TODO: it can be moved to environment specific prop loading as part of CI(jenkin) jobs

        //fannie mae single sign on portal dev
//            public static String baseUrl = "https://d2o5ku9ymibe1l.cloudfront.net/portal#/signin";

        //fannie mae single sign on portal accept
       // public static String baseUrl = "https://glass.acptfanniemae.com/portal#/signin";
         //public static String baseUrl = "https://d2cwxh19afvdx5.cloudfront.net";

        //TEST url
        public static String baseUrl = "https://d1w8e25d2cx6jp.cloudfront.net/portal#/signin";

        public static final long SMALL_WAIT = 10;
        public static final long MED_WAIT = 2000;
        public static final long LONG_WAIT = 5000;
        public static final long POLLING_WAIT = 5000;
        public static final long KEYPRESSWAIT = 1000;
        public static final long TRADE_TIMEOUT = 135000;
        //final status wait
        public static final long FINALSTATUS_WAIT = 8000;

        public static final String SELENIUM_VERESION = "3.4.2";

        public static final boolean enableRemote = false;

        public static final String HUB_URL = "http://ondemand.saucelabs.com:80/wd/hub";
        public static final String phontomjsLocation ="/export/appl/o7prod/phantomjs/bin/phantomjs"; //"C:\\Program Files (x86)\\Selenium Client Drivers 3.4.0\\PhantomjsDriver\\phantomjs.exe";//

        //DEV API URL
        //public static final String APIBaseURL = "https://mbsp01-devl-webapp.j22g6rr3zz.us-east-1.elasticbeanstalk.com";

        //TEST API URL
      public static final String APIBaseURL = "https://mbsp-test-eb-01-webapp.e003.fanniemae.com";

        //ACPT API URL
        public static final String APIBaseURL_Alt = "https://mbsp-test-eb-01-webapp.e003.fanniemae.com";
      //  public static final String APIBaseURL_Alt = "https://glass.acptfanniemae.com/fmnapi";
       // public static final String APIBaseURL = "https://api.acptfanniemae.com/fmnapi";
       // public static final String APIBaseURL_Alt = "https://mbsp-acpt-eb-01-webapp.bcisxifmst.us-east-1.elasticbeanstalk.com";

}