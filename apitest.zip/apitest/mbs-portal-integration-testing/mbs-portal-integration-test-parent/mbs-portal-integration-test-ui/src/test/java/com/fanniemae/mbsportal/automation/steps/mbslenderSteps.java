/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.automation.steps;

import com.codoid.products.exception.FilloException;
import com.fanniemae.mbsportal.automation.pages.mbslenderPage;
import com.fanniemae.mbsportal.automation.pages.mbsloginPage;
import com.fanniemae.mbsportal.automation.selenium.conf.ConfigConstants;
import com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants;
import com.fanniemae.mbsportal.automation.selenium.utils.AutoUtil;
import com.fanniemae.mbsportal.automation.selenium.utils.PropertiesLib;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.json.JSONException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;

import java.io.IOException;
import java.text.ParseException;

import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.*;
import static com.fanniemae.mbsportal.automation.selenium.utils.AutoUtil.WaitForAngular2Finish;
import static junit.framework.TestCase.assertNotSame;

public class mbslenderSteps  {


    @After
    public void teardown()
    {
       // AutoUtil.getDriver().close();
    }

    mbslenderPage objLenderPage = new mbslenderPage();
    mbsloginPage objLoginPage = new mbsloginPage();
    String LenderWindowHandle = "";

    WebDriver LenderDriver;

    @Given("^Lender is on TBA Trading Page$")
    public void LaunchTBATradingPage() throws InterruptedException, FilloException, IOException {

        String UserID;
        PropertiesLib objProperties = new PropertiesLib();
        objProperties.InitPropertyFile();

        //set Blue/Green users
        if(objProperties.getBGEnv().contentEquals("BLUE"))
            UserID = EXTERNAL_USER_ID;
        else
            UserID = EXTERNAL_USER_ID_GREEN;

        if (LenderDriver == null) {
            AutoUtil.setUp(GlobalConstants.BrowserModeType.NORMAL);

            LenderDriver = AutoUtil.getDriver();
            LenderWindowHandle = objLoginPage.LaunchApplication(LenderDriver);
            objLoginPage.LoginPageInit(LenderDriver);
            objLoginPage.FetchUserData(UserID);
            objLoginPage.UserLogin();
            objLoginPage.NavigateToPage(LenderDriver);
        }
        else {
            objLoginPage.FetchUserData(UserID);
            objLoginPage.LoginPageInit(LenderDriver);
            objLoginPage.SwitchWindow(LenderWindowHandle, LenderDriver);
        }
       Thread.sleep(ConfigConstants.SMALL_WAIT);
        //WaitForAngular2Finish();
    }

    //part of story CMMBSSTA01-38 to test the product pricing grid for all the products

    @Then("^Validate Product Pricing Grid for all the products$")
    public void ValidateProductPricing()
            throws InterruptedException, FilloException, JSONException, ParseException, IOException {
        //the init will change and will be more generic.
        SessionId session;
        objLenderPage.LenderPageInit(LenderDriver);

        //get the session id
       if(ConfigConstants.enableRemote)
           session = ((RemoteWebDriver)LenderDriver).getSessionId();
        else
           session = ((ChromeDriver)LenderDriver).getSessionId();
          //session = ((FirefoxDriver)LenderDriver).getSessionId();

        objLenderPage.selectProducts(objLoginPage.getLenderName(),objLoginPage.getRoleName(), session.toString());
    }

    @Then("Lender Logs Off from MBS Trading Platform$")
    public void UserLogsOff() throws InterruptedException {
        objLoginPage.SwitchWindow(LenderWindowHandle,LenderDriver);
        objLoginPage.UserLogoff(LenderDriver);
        Thread.sleep(ConfigConstants.MED_WAIT);

       // WaitForAngular2Finish();

        LenderDriver.close();
        LenderDriver = null;
    }
}
