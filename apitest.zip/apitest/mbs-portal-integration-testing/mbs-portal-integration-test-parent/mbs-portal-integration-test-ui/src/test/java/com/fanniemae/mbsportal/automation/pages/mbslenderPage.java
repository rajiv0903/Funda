/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.automation.pages;

import static com.fanniemae.mbsportal.automation.selenium.conf.ConfigConstants.KEYPRESSWAIT;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.*;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.TradeActionType.BUY;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.TradeActionType.SELL;
import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

import com.fanniemae.mbsportal.automation.selenium.utils.PropertiesLib;
import com.jayway.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by g8us9b on 7/26/2017.
 */

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;
import com.fanniemae.mbsportal.automation.selenium.conf.ConfigConstants;
import com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants;
import com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.LenderPriceAcceptState;
import com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.PriceLabel;
import com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.TradeActionType;
import com.fanniemae.mbsportal.automation.selenium.utils.ExcelLib;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.ValidatableResponse;
import org.springframework.util.Base64Utils;

public class mbslenderPage {
    private Recordset rsProductList,rsLender,rsMultipleLenders;
    private ExcelLib objExcelLib = new ExcelLib();
    private ValidatableResponse response;
    private String ProductPricingURL = "";
    private String TradeActionId = "";
    private String TradeActionBar = TRADEACTIONBAR;
    private WebDriver driver;
    private mbsloginPage mbsloginpage;
    private String lenderId;
    private String transId;

    private List<String> TradesTransIDs = new ArrayList<String>();
    private mbstradertranshistoryPage mbstradertranshistoryPage;

    By CouponCol = By.cssSelector(".coupon");
    @FindBy(css = ".mbsp-dropdown ul li") protected List<WebElement> ProductListOptions;
    @FindBy(css = ".mbsp-dropdown") protected WebElement ProductList;
    @FindBy(css = "#product-pricing-grid th") protected List<WebElement> ProductPricingTHRow;
    @FindBy(css = "#product-pricing-grid tbody tr") protected List<WebElement> ProductPricingCoupons;
    @FindBy(css = ".sell-type") protected WebElement SelectedTradeTypeSELL;
    @FindBy(css = ".buy-type") protected WebElement SelectedTradeTypeBUY;
    @FindBy(css = ".product-pricing-details") protected WebElement ProductPricingDetails;
    @FindBy(css = ".trade-info") protected WebElement TradeInfoDetails;
    @FindBy(css = ".name") protected WebElement RoleNameInfo;
    @FindBy(css = ".lender-info") protected WebElement LenderInfo;
    @FindBy(id = "transaction-amount") protected WebElement AmountFieldID;
    @FindBy(id = "transaction-submit") protected WebElement SubmitButtonID;
    @FindBy(css = ".price-block") protected WebElement LenderPriceBlock;
    @FindBy(id = "settlement-date") protected WebElement SettlementMonthID;
    @FindBy(id = "price-accept") protected List<WebElement> PriceAccept;
    @FindBy(id = "transaction-price") protected WebElement TransactionPrice;
    @FindBy(id = "product-pricing-grid") protected WebElement ProductPricingGrid;
    @FindBy(id = "new-trade") protected List<WebElement> NewTradeButton;
    @FindBy(id = "cancel-button") protected WebElement CancelButton;
    @FindBy(name = "transReqId") protected WebElement TransID;
    @FindBy(name = "tradeSettlementDate") protected WebElement SettlementDate;
    @FindBy(css = ".ticket-header") protected WebElement CurrentTradeStatus;
    @FindBy(css = ".tooltips-text") protected WebElement AmountErrorMessage;
    @FindBy(css = ".tsp-dropdown") protected WebElement TspDropDown;
    @FindBy(css = ".ui-select-match-text") protected WebElement TspSelectedValue;
    @FindBy(css = ".ui-select-search") protected WebElement TspEnterValue;

    /**
     * Purpose: Method to initialize all the WebElements defined by the
     * PageFactory annotation for the Lender Page
     * 
     * @param LenderDriver
     *            LenderDriver to trigger all the actions and perform asserts
     */
    public void LenderPageInit(WebDriver LenderDriver) {
        PageFactory.initElements(LenderDriver, this);
        driver = LenderDriver;

    }

    /**
     * Purpose: Get Lender Expected Data from Test Data Excel sheet
     * 
     * @param ID
     *            - Lender ID
     * @param sessionID
     *            - Session ID, in case we need to call any API call
     * @throws InterruptedException
     *             - Thread Sleep method may throw InterruptedException
     * @throws FilloException
     *             - Fillo API call to make queries to Excel sheet
     */
    public void LenderGetExpectedData(String ID) throws InterruptedException, FilloException, IOException {

        String query;
        String lenderquery;
        PropertiesLib objProperties = new PropertiesLib();
        objProperties.InitPropertyFile();

        //set Blue/Green users
        if(objProperties.getBGEnv().contentEquals("BLUE"))
            lenderquery = LENDERQUERY;
        else
            lenderquery = LENDERQUERY_GREEN;


        Thread.sleep(ConfigConstants.MED_WAIT);
        // Fetch the expected data from the data sheet
        query = lenderquery + "'" + ID + "'";
        // fetch test data related to lender id
        rsLender = objExcelLib.GetTestData(query);
    }

    /**
     * Purpose: To Select the Product from the Product List Drop Down on Lender
     * Page
     * 
     * @param Option
     *            - Option to be selected from Dropdown
     * @throws InterruptedException
     *             Thread Sleep method may throw InterruptedException
     */
    public void SelectOption(String Option) throws InterruptedException {

        ProductList.click();
        ProductList.findElement(By.id(Option)).click();
    }

    /**
     * Purpose: To Select the trade action from the product pricing grid. The id
     * is dynamic based on Product, Coupon and Settlement month
     * 
     * @param TradeAction
     *            - id to be selected from the Product Pricing grid
     */
    public void SelectTradeAction(String TradeAction) {

        driver.findElement(By.id(TradeAction)).click();
    }

    /**
     * Purpose: Get the trade action depending on the trade type - Buy/Sell
     * 
     * @param TradeType
     *            - Trade type - Buy/Sell
     * @return
     */
    public String getTradeAction(String TradeType) {

        String Trade;
        if (TradeType.contentEquals(TradeActionType.SELL.toString()))
            Trade = SelectedTradeTypeSELL.getText();
        else
            Trade = SelectedTradeTypeBUY.getText();

        return Trade.trim();
    }

    /**
     * Purpose: validate trade info details on the Lender screen once the trade
     * type is selected
     * 
     * @param tradeDetails
     *            - trade details of the trade selected
     * @return
     */
    public boolean hasTradeInfo(String tradeDetails) {
        return TradeInfoDetails.getText().contains(tradeDetails);
    }

    /**
     * Purpose: Check if the amount field is displayed
     * 
     * @return - boolean true or false depending on the condition
     */
    public boolean isAmountFieldDisplayed() {
        return AmountFieldID.isDisplayed();
    }

    /**
     * Purpose: check if Submit Button is displayed
     * 
     * @return true or false depending on the condition
     */
    public boolean isSubmitButtonDisplayed() {
        return SubmitButtonID.isDisplayed();
    }

    /**
     * Purpose: check if the Amount field is enabled
     * 
     * @return true or false depending on the condition
     */
    public boolean isAmountFieldEnabled() {
        return AmountFieldID.isEnabled();
    }

    /**
     * Purpose: check if Submit Button on Lender Page is enabled
     * 
     * @return true/false depending on the condition
     */
    public boolean isSubmitButtonEnabled() {
        return SubmitButtonID.isEnabled();
    }

    /**
     * Purpose: Enter the Amount in the Amount field
     * 
     * @param Amount
     *            to be entered
     */
    public void SubmitLenderAmount(String Amount) {
        AmountFieldID.sendKeys(Amount);
    }

    /**
     * Purpose: Click on the Submit button
     */
    public void SubmitTrade() {
        SubmitButtonID.click();
    }

    /**
     * Purpose: Clear the Amount field
     */
    public void ClearAmountField() {
        AmountFieldID.clear();
    }

    /**
     * Purpose: to check if the desired Element is displayed on the Lender Page
     * 
     * @param ElementName
     *            web element
     * @return
     */
    public boolean isElementDisplayed(String ElementName) {
        return SubmitButtonID.isDisplayed();
    }

    /**
     * Purpose: check if the Hit/Lift button is displayed on the Lender Page
     * 
     * @return true/false depending on the condition
     */
    public boolean CheckHitButtonDisplayed() {
        try {
            return PriceAccept.get(0).isEnabled();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    /**
     * Purpose: Validate PRoduct Pricing grid. The Expected values are taken
     * from the PRoduct Pricing API call and the Actual values are from the
     * Lender Page. VAlidates each Product all Product Pricing
     * 
     * @param lenderName
     *            - need to check if the Trade Info section displays expected
     *            Lender NAme
     * @param roleName
     *            - need to check if the Trade Info section displays expected
     *            Lender NAme
     * @param sessionID
     *            - needed to make the API Call
     * @throws FilloException
     *             - Exception to check Excel sheet data query
     * @throws JSONException
     *             - API returns JSON string
     * @throws ParseException
     *             Parsing Json string to object
     * @throws InterruptedException
     *             - Thread sleep exception
     */
    public void selectProducts(String lenderName, String roleName, String sessionID)
            throws FilloException, JSONException, ParseException, InterruptedException, IOException {
        int count = 0;
        int i = 0;
        String json = "";
        SortedMap<Date,String> SettlementMonths = new TreeMap<Date,String>();

        SortedSet<String> Coupons = new TreeSet<String>();
        int AmountValue = AMOUNT_VALUE;
        boolean isSellFlag = false;
        Map<String, String> APIHeaderMap = new HashMap<String, String>();
        PropertiesLib objProperties = new PropertiesLib();
        objProperties.InitPropertyFile();
        String productIdentifier;

        APIHeaderMap.put("x-fnma-channel", "web");
        APIHeaderMap.put("x-fnma-sub-channel", "MBSP");

      if (objProperties.getEnv().contentEquals("ACPT"))
        APIHeaderMap.put("x-fnma-sessionid", sessionID);

        // get the product List from the product list to select each product in
        // a loop and validating the UI
        rsProductList = objExcelLib.GetTestData(GlobalConstants.PRODUCTLISTQUERY);

        // set the API Get URL
        RestAssured.baseURI = ConfigConstants.APIBaseURL_Alt;
        RestAssured.useRelaxedHTTPSValidation();
        RestAssured.baseURI += GlobalConstants.PRODUCTPRICINGENDPOINT;

        if (objProperties.getEnv().contentEquals("ACPT")) {
            RestAssured.sessionId = sessionID.trim();
            RestAssured.proxy("zsproxy.fanniemae.com",10479);
        }
        // start testing each product
        while (rsProductList.next()) {
            // ignore the 1st row that we get from the recordset of Product List
            if (count != 0) {
                // select the product from the dropdown first
                SelectOption(rsProductList.getField("Products").trim());

                Thread.sleep(ConfigConstants.MED_WAIT);

                if (objProperties.getEnv().contentEquals("ACPT"))
                    productIdentifier = rsProductList.getField("PricingProductIdentifier").trim();
                else
                    productIdentifier = rsProductList.getField("PricingProductIdentifier").trim();

                ProductPricingURL = RestAssured.baseURI + productIdentifier
                        + "/" + rsProductList.getField("PricingProductSourceType").trim() + "/"
                        + rsProductList.getField("PricingProductType").trim();
                // get the data from the API service
                response = given().headers(APIHeaderMap).when().get(ProductPricingURL).then()
                        .statusCode(STATUS_SUCCESS);
                json = response.contentType(ContentType.JSON).extract().response().asString();
                JSONArray values = new JSONArray(json);

                // reset the collections for every product
                SettlementMonths.clear();
                Coupons.removeAll(Coupons);

                // collect the Settlement Date and Coupon to compare against the
                // UI product pricing grid
                for (i = 0; i < values.length(); i++) {
                    SettlementMonths.put(new SimpleDateFormat(DATEFORMAT_2)
                            .parse(values.getJSONObject(i).get("settlementDate").toString().trim()),values.getJSONObject(i).get("settlementDate").toString().trim());

                    Coupons.add(values.getJSONObject(i).get("passThroughRate").toString().trim());
                }

                // validate the UI against the collection
                // 1. Validate the month names against the TH collection

                List<WebElement> THRows = ProductPricingTHRow;

                i = 1;
                for(Map.Entry<Date,String> entry : SettlementMonths.entrySet() )
                {
                    assertEquals(new SimpleDateFormat(MonthShortName).format(entry.getKey()).toUpperCase(),
                            THRows.get(i).getText().trim());
                    i++;
                }


                // 2. validate the coupon rate against the UI TD rows
                i = 0;
                List<WebElement> TDCoupons = ProductPricingCoupons;

                for (String s1 : Coupons) {
                    assertEquals(s1.trim(), TDCoupons.get(i).findElement(CouponCol).getText().trim());
                    i++;
                }

                // 3. select all Sell options
                for(Map.Entry<Date,String> entry : SettlementMonths.entrySet() )
                {
                    for (String s1 : Coupons) {
                        // perform action for each Trade Action i.e. BUY/SELL
                        for (GlobalConstants.TradeActionType TradeAction : GlobalConstants.TradeActionType.values()) {
                            String TradeToClick = TradeAction.toString() + HYPHEN + s1 + HYPHEN
                                    + new SimpleDateFormat(MonthShortName).format(entry.getKey());

                            // hover over the trade type and assert if the
                            // background changes
                            WebElement element = driver.findElement(By.id(TradeToClick));
                            Actions builder = new Actions(driver);
                            Action mouseOver = builder.moveToElement(element).build();
                            mouseOver.perform();
                            String buttonColor = element.getCssValue(BackgroundCSSValue);
                            Thread.sleep(ConfigConstants.MED_WAIT);

                            assertEquals(ButtonBackgroundColor, buttonColor.trim());

                            SelectTradeAction(TradeToClick);

                            Thread.sleep(ConfigConstants.SMALL_WAIT);

                            //assert the background color
                            if(element.getText().toUpperCase().contentEquals(SELL.toString()))
                                assertEquals(GlobalConstants.LenderSELLBackgroundColor, element.getCssValue(BackgroundCSSValue));
                            else
                                assertEquals(LenderBUYBackgroundColor, element.getCssValue(BackgroundCSSValue));

                            // assert Trade Type and Trade Info
                            assertEquals(TradeAction.toString().trim(), getTradeAction(TradeAction.toString()).trim());

                            assertTrue(hasTradeInfo(rsProductList.getField("Products").trim() + " " + s1 + " "
                                    + new SimpleDateFormat(MonthShortName).format(entry.getKey()).toUpperCase()));

                            //assert the settlement month
                            assertEquals(entry.getValue(),SettlementDate.getAttribute("value"));

                            // assert Amount and Submit fields
                            assertTrue(isAmountFieldDisplayed());
                            assertTrue(isAmountFieldEnabled());
                            assertTrue(isSubmitButtonDisplayed());
                            assertTrue(isSubmitButtonEnabled());
                            // clear the amount
                            ClearAmountField();
                            // Enter Trade Amount, validate trade amount for format and min and max values
                            SubmitLenderAmount();
                            //SubmitLenderAmount(String.valueOf(AmountValue += AMOUNT_VALUE_1));
                        }

                     //   break;
                    }
                    Thread.sleep(ConfigConstants.MED_WAIT);
                   // break;
                }
            }
            count++;

            Thread.sleep(ConfigConstants.MED_WAIT);

            if (count == 3)
                rsProductList.moveFirst();
            else if (count > 3)
                break;
        }
    }

    /**
     * Purpose: To validate if the PRoduct List drop down has the expected
     * products
     * 
     * @throws FilloException
     *             - Call to query the Test Data Excel sheet
     */
    public void ValidateProductList() throws FilloException {
        Recordset ExpectedProductList = null;
        int count = 0;

        if(ProductList.isEnabled())
        {
            // get the expected product list
            try {
                ExcelLib objExcelObj = new ExcelLib();
                ExpectedProductList = objExcelObj.GetTestData(PRODUCTLISTQUERY);
                assertEquals(ExpectedProductList.getCount() - 1, ProductListOptions.size());

                // assert that the actual products are as expected in the Product
                // List
                while (ExpectedProductList.next()) {
                    if (count == 0) {
                        // assert the first element to the first visible only if the first product is default and the previous test case has not in-flight
                        if(ProductList.getText().contentEquals(PRODUCTDEFAULT))
                            assertEquals(ExpectedProductList.getField("Products").trim(),ProductList.getText());
                    }
                    else {
                        //  assertEquals(ExpectedProductList.getField(0).value(), ProductListOptions.get(count).getText().trim());
                    }
                    count++;
                }
            } finally {
                ExpectedProductList.close();
            }

        }
    }

    /**
     * Purpose: Validate the Lender initial load
     * 
     * @param blnNewTrade
     * @throws FilloException
     * @throws InterruptedException
     */
    public void ValidateLenderInitialLoad(boolean blnNewTrade) throws FilloException, InterruptedException {
        if (blnNewTrade)
            ValidateProductList();

    }

    /**
     * Purpose: check if the Product Pricing grid on the Lender Page is enabled
     * 
     * @return true/false depending on the condition
     */
    private boolean isProductPricingGridEnabled() {
        return ProductPricingGrid.isEnabled();
    }

    /**
     * Purpose: Check if the Clear Ticket is displayed
     * 
     * @return true/false depending on the condition
     */
    private boolean isClearTicketDisplayed() {
        try {
            return NewTradeButton.size() > 0;
        } catch (NoSuchElementException e) {
            return false;
        }

    }

    /**
     * Purpose: To check if the Clear Ticket button is enabled
     * 
     * @return true/false depending on the condition
     */
    private boolean isClearTicketEnabled() {
        return NewTradeButton.get(0).isEnabled();
    }

    /**
     * Purpose: Select the Product, Trade Action and Submit the Amount on the
     * Lender page
     * 
     * @param LenderName
     *            - Check if Lender name is displayed on the Trade Info page
     * @param RoleName
     *            - Check if the Role Name is displayed on the Trade Info Page
     * @param blnNewTrade
     *            - Check if the action is new trade
     * @return TransID once the submit is successfull. TransID is used further
     *         for validation
     * @throws FilloException
     *             - Excel sheet query
     * @throws InterruptedException
     *             - Thread sleep exception
     */
    public String LenderSubmitAmount(String LenderName, String RoleName, boolean blnNewTrade)
            throws FilloException, InterruptedException {

        // loop thru all the trades for the lender that need to be submitted
        while (rsLender.next()) {

            // select the product
            if (!blnNewTrade) {
                CreateNewTrade();
            }


            System.out.println("product name is:" + ProductList.getText());
            //recover scenario in case the previous scenario failed and the trade is in mid flight
            if(!ProductList.getText().contentEquals(PRODUCTDEFAULT))
            {
               //a. if not Default that means the previous trade is in flight and wait till the new trade button is enabled
                WebDriverWait wait = new WebDriverWait(driver, 140);
                WebElement element = wait.until(
                        ExpectedConditions.visibilityOfElementLocated(By.id("new-trade")));

                if(isClearTicketDisplayed())
                    CreateNewTrade();
            }

            //if TSP user, then first select the TSP name
            if (rsLender.getField("LenderID").contains("TSP"))
            {
                assertTrue(TspDropDown.isDisplayed());
                assertTrue(TspDropDown.isEnabled());
                TspDropDown.click();
                Thread.sleep(ConfigConstants.SMALL_WAIT);
                TspEnterValue.sendKeys(rsLender.getField("LenderSearchName"));
                TspEnterValue.sendKeys(Keys.ENTER);
                Thread.sleep(ConfigConstants.SMALL_WAIT);
                assertEquals(rsLender.getField("Lender_Name").toLowerCase().trim(), TspSelectedValue.getText().toLowerCase().trim());
                assertTrue(ProductList.isEnabled());
            }

            SelectOption(rsLender.getField("Product").trim());

            assertTrue(isClearTicketDisplayed());
            // select Trade Action
            SelectTradeAction();
            // validate Trade Details info and if submit button is selected
            ValidateTradeInfoDetails(LenderName, RoleName);

            // Submit Trade Amount

            SubmitLenderAmount(rsLender.getField("LenderAmount").toString());
            SubmitTrade();
            Thread.sleep(ConfigConstants.MED_WAIT);
            // get the transid and settlement date
            SettlementDate.getText().trim();

        }
        return TransID.getText().trim();
    }

    /**
     * Purpose: Select the trade action on the Product Pricing grid
     * 
     * @throws FilloException
     *             - Excel sheet query
     */
    private void SelectTradeAction() throws FilloException, InterruptedException {
        // form the trade action id dynamically
        TradeActionId = rsLender.getField("TradeType").trim() + "-" + rsLender.getField("CouponValue").trim() + "-"
                + rsLender.getField("SettlementMonth").trim();
        Thread.sleep(ConfigConstants.MED_WAIT);
        driver.findElement(By.id(TradeActionId)).click();
    }

    /**
     * Purpose: Validate trade info details once the trade is selected on the
     * Lender Page
     * 
     * @param LenderName
     *            - Validate if Lender Name is displayed in the Trade info
     *            section once the trade type is selected
     * @param RoleName
     *            - Validate if Role Name is displayed in the Trade info section
     *            once the trade type is selected
     * @throws FilloException
     *             - Excel sheet query exception
     */
    private void ValidateTradeInfoDetails(String LenderName, String RoleName)
            throws FilloException, InterruptedException {
        String TradeInfo = rsLender.getField("Product").trim() + " " + rsLender.getField("CouponValue").trim() + " "
                + rsLender.getField("SettlementMonth").trim().toUpperCase();

        // validate User name and Lender Name
        assertTrue(LenderInfo.getText().contains(LenderName.trim()));

        assertTrue(RoleNameInfo.getText().contains(RoleName.trim()));

        if (rsLender.getField("TradeType").trim().contentEquals(SELL.toString()))
            assertTrue(SelectedTradeTypeSELL.getText().toUpperCase().contains(SELL.toString().toUpperCase()));
        else
            assertTrue(SelectedTradeTypeBUY.getText().contains(BUY.toString()));

        assertTrue(TradeInfoDetails.getText().contains(TradeInfo));
        assertTrue(isAmountFieldDisplayed());
    }

    /**
     * Purpose: Validate on each key press if the Amount is valid and confrims
     * to the Currency format
     * 
     * @throws FilloException
     *             - Excel sheet query exception
     * @throws InterruptedException
     *             - Thread sleep exception
     */
    private void SubmitLenderAmount() throws FilloException, InterruptedException {

        Recordset rsAmount = objExcelLib.GetTestData(AMOUNTVALIDATEQUERY);

        NumberFormat format = NumberFormat.getCurrencyInstance();

        while (rsAmount.next()) {
            // if value is not numeric, amount field should be blank
            if (!Boolean.valueOf(rsAmount.getField("IS_VALID"))) {
                AmountFieldID.sendKeys(rsAmount.getField("AMOUNT").trim());
                assertEquals(BLANKVALUE, AmountFieldID.getText().trim());
                System.out.println(rsAmount.getField("AMOUNT").trim());
            }
            // else enter numeric value 1 char at a time and check if format is
            // as per $ currency
            else {
                DecimalFormat myFormatter = new DecimalFormat(CURRENCY_FORMAT_2);
                AmountFieldID.clear();
                String value = rsAmount.getField("AMOUNT").trim();
                StringBuilder s = new StringBuilder();
                for (int i = 0; i < value.length(); i++) {
                    char c = value.charAt(i);
                    s.append(c).toString();
                    String output = myFormatter.format(Long.parseLong(String.valueOf(s)));
                    Thread.sleep(KEYPRESSWAIT);
                    AmountFieldID.sendKeys(String.valueOf(c));
                    String test = AmountFieldID.getAttribute(ATTRIBUTE_VALUE);
                    assertEquals(output, test);
                }

            }
        }

        //Lender amount validations
        AmountFieldID.clear();
        AmountFieldID.sendKeys(MIN_LENDER_AMOUNT);
        //Validate the Return key
        AmountFieldID.sendKeys(Keys.RETURN);
        assertThat(AmountErrorMessage.getText().toLowerCase(), containsString(LenderAmountErrorMessage.toLowerCase()));
        Thread.sleep(ConfigConstants.MED_WAIT);

        AmountFieldID.clear();
        AmountFieldID.sendKeys(MAX_LENDER_AMOUNT);
        AmountFieldID.sendKeys(Keys.RETURN);
        assertThat(AmountErrorMessage.getText().toLowerCase(), containsString(LenderAmountErrorMessage.toLowerCase()));

        Thread.sleep(ConfigConstants.MED_WAIT);

        AmountFieldID.clear();
    }

    /**
     * Purpose: Validate if the data persists on Lender Page once the Trade
     * prices the trade and Lender receives the updated status
     * 
     * @param lenderName
     *            - Validate if the Lender Name is displayed on the Trade Info
     *            section
     * @param roleName
     *            - Validate if the Role Name is displayed on the Trade Info
     *            section
     * @throws InterruptedException
     */
    public void ValidateLenderReceivePrice(String lenderName, String roleName, String PriceType)
            throws InterruptedException {
        try {

            rsLender.moveFirst();
            ValidateLenderSelectedValues(PriceType, lenderName, roleName, PriceType);

            while (rsLender.next()) {
                // ValidateLenderSelectedValues(TradeConstans.TRADER_PRICED,
                // lenderName, roleName,PriceType);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Purpose: Validate if the Lender values as selected persist during each
     * pass of the trade flow
     * 
     * @param traderPriced
     *            - Constant Trader Priced
     * @param lenderName
     *            - Validate if the Lender Name is displayed on the Trade Info
     *            section
     * @param roleName
     *            - Validate if the Role Name is displayed on the Trade Info
     *            section
     * @throws FilloException
     * @throws InterruptedException
     * @throws ParseException
     */
    private void ValidateLenderSelectedValues(String CurrentTradeStatus, String lenderName, String roleName,
            String PriceType) throws FilloException, InterruptedException, ParseException {
        CheckProductSelected(rsLender.getField("Product").trim());
        ValidateTradeInfoDetails(lenderName, roleName);
        assertFalse(isAmountFieldEnabled());

        if(!(CurrentTradeStatus.contentEquals(TRADER_TIMEOUT) || CurrentTradeStatus.contentEquals(LENDER_TIMEOUT))) {
            assertFalse(isClearTicketDisplayed());
            isHitButtonDisplayed(true);
        }

        ValidateQoute(CurrentTradeStatus);
        ValidateStatusDisplay(CurrentTradeStatus);

    }

    /**
     * Purpose: Check if the expected PRoduct is selected option in the PRoduct
     * List drop down
     * 
     * @param ProductName
     *            - Expected Product Name
     */
    private void CheckProductSelected(String ProductName) {
        // Select Prodlist = new Select(ProductList);
        // assertEquals(Prodlist.getFirstSelectedOption().getText().trim(),ProductName.trim());
        // assertFalse(ProductList.isEnabled());
    }

    /**
     * Purpose: chefk if the Hit/Lift button is displayed and text is either HIT
     * or LIFT depending on the trade type if check display is true/false
     * 
     * @param CheckDisplay
     *            - true/false to check if display needs to be checked
     * @throws FilloException
     */
    private void isHitButtonDisplayed(Boolean CheckDisplay) throws FilloException {
        assertEquals(CheckDisplay, CheckHitButtonDisplayed());
        // check the text of the button as well only when the display is true
        if (CheckDisplay) {
            if (rsLender.getField("TradeType").trim().contentEquals(SELL.toString()))
                assertEquals(LenderPriceAcceptState.HIT.toString(), PriceAccept.get(0).getText().trim());
            else
                assertEquals(LenderPriceAcceptState.LIFT.toString(), PriceAccept.get(0).getText().trim());
        }
    }

    /**
     * Purpose: Validate the label to be Quote/Price depending on the current
     * status of the Trade. Also validate the settlement month name if the Trade
     * is c confirmed by the Trader
     * 
     * @param traderPriced
     * @throws FilloException
     * @throws ParseException
     */
    private void ValidateQoute(String CurrentTradeStatus) throws FilloException, ParseException {
        String Qoute = rsLender.getField("HandlePrice").trim() + "-" + rsLender.getField("TickPrice").trim();

        // to do-- depending on the price or re-price , validate the value -
        // Sumanth
        // assertEquals(Qoute.trim(),TransactionPrice.getText().trim());

        // check the label and settlement date as per the trade status
      if (Qoute.length() > 0) {
          switch (CurrentTradeStatus) {
           case QUOTED:
           case NEWQUOTE:
              assertThat(LenderPriceBlock.getText(), containsString(PriceLabel.Quote.toString()));
                  break;
          case EXECUTEDSTATUS:
              assertThat(LenderPriceBlock.getText(), containsString(PriceLabel.Price.toString()));
              String MonthName = new SimpleDateFormat(MonthShortName)
                      .format(new SimpleDateFormat(DATEFORMAT_4).parse(SettlementMonthID.getText().trim()));
              assertEquals(rsLender.getField("SettlementMonth").trim(), MonthName.trim());
              break;
          }
      }
    }

    /**
     * Purpose: Accept the quote that is Trader Priced and validate the status
     * once the Lender accepts the quote
     * 
     * @throws InterruptedException
     * @throws FilloException
     */
    public void AcceptQuote(String Validate) throws InterruptedException, FilloException {
        PriceAccept.get(0).click();
        ValidateStatusDisplay(rsLender.getField("TraderPricedStatus").trim());
        isHitButtonDisplayed(false);

        if (Validate.contentEquals(INCL_VALIDATION)) {
            Thread.sleep(15000);
            //validate if the Cancel button is enabled after 10 seconds
            assertTrue(CancelButton.isEnabled());
        }
    }

    /**
     * Purpose Validate the Trade status depending on the current status of the
     * Trade
     * 
     * @param ElementName
     * @throws InterruptedException
     */
    private void ValidateStatusDisplay(String ElementName) throws InterruptedException {

        Thread.sleep(ConfigConstants.MED_WAIT);
        assertTrue(CurrentTradeStatus.getText().trim().contains(ElementName.trim()));
    }

    /**
     * Purpose: Validate the Trade details once the Lender receives the Trader
     * Quote
     * 
     * @param lenderName
     * @param roleName
     * @throws InterruptedException
     * @throws FilloException
     * @throws ParseException
     */
    public void LenderReceiveConfirm(String lenderName, String roleName)
            throws InterruptedException, FilloException, ParseException {
        try {
            rsLender.moveFirst();
            CheckProductSelected(rsLender.getField("Product").trim());
            ValidateTradeInfoDetails(lenderName, roleName);
            assertFalse(isAmountFieldEnabled());
          //  isHitButtonDisplayed(false);
            ValidateQoute(EXECUTEDSTATUS);
            ValidateStatusDisplay(rsLender.getField("TraderConfirmedStatus").trim());

            assertTrue(isClearTicketDisplayed());

            while (rsLender.next()) {
                // to do
            }
        } finally {
            // close all the browsers after the flow ends...eventually should
            // move to @after annotation
            Thread.sleep(ConfigConstants.MED_WAIT);
            rsLender.close();
        }
    }

    /**
     * Purpose: Create a new Trade by using the New Trade button
     * 
     * @throws InterruptedException
     * @throws FilloException
     */
    public void CreateNewTrade() throws InterruptedException, FilloException {
        assertTrue(isClearTicketDisplayed());
        NewTradeButton.get(0).click();
        Thread.sleep(ConfigConstants.MED_WAIT);
        ValidateLenderInitialLoad(false);
    }

    /**
     * Purpose: Cancel the Trade
     * 
     * @throws InterruptedException
     */
    public void CancelTrade() throws InterruptedException {
        Thread.sleep(ConfigConstants.MED_WAIT);
      //  WaitForAngular2Finish();
        CancelButton.click();
    }

    /**
     * Purpose: Validate the Cancel status in the Trade info status section
     * 
     * @param lenderName
     * @param roleName
     * @param tradeStatus
     * @throws FilloException
     * @throws InterruptedException
     */
    public void ValidateCancelStatus(String lenderName, String roleName, String tradeStatus)
            throws FilloException, InterruptedException {
        CheckProductSelected(rsLender.getField("Product").trim());
        ValidateTradeInfoDetails(lenderName, roleName);

        switch (tradeStatus)
        {
        case "LENDER_CANCELLED":
            tradeStatus = CANCELLEDSTATUS;
            break;
        case "TRADER_PASSED":
            tradeStatus = TRADERPASSED;
            break;
        case "TRADER_CANCELLED":
            tradeStatus = TRADERCANCELLED;
            break;
        }

        ValidateStatusDisplay(tradeStatus);
    }

    /**
     * @return the mbsloginpage
     */
    public mbsloginPage getMbsloginpage() {
        return mbsloginpage;
    }

    /**
     * @param mbsloginpage
     *            the mbsloginpage to set
     */
    public void setMbsloginpage(mbsloginPage mbsloginpage) {
        this.mbsloginpage = mbsloginpage;
    }

    /**
     * @return the lenderId
     */
    public String getLenderId() {
        return lenderId;
    }

    /**
     * @param lenderId
     *            the lenderId to set
     */
    public void setLenderId(String lenderId) {
        this.lenderId = lenderId;
    }

    /**
     * @return the transId
     */
    public String getTransId() {
        return transId;
    }

    /**
     * @param transId
     *            the transId to set
     */
    public void setTransId(String transId) {
        this.transId = transId;
    }

    /**
     * @return the mbstradertranshistoryPage
     */
    public mbstradertranshistoryPage getMbstradertranshistoryPage() {
        return mbstradertranshistoryPage;
    }

    /**
     * @param mbstradertranshistoryPage
     *            the mbstradertranshistoryPage to set
     */
    public void setMbstradertranshistoryPage(mbstradertranshistoryPage mbstradertranshistoryPage) {
        this.mbstradertranshistoryPage = mbstradertranshistoryPage;
    }


    public void LenderTimeOut() throws InterruptedException {
        Thread.sleep(ConfigConstants.TRADE_TIMEOUT);

        Thread.sleep(ConfigConstants.MED_WAIT);

        //validate the status to "FANNIE MAE Timeout
        assertEquals(TRADER_TIMEOUT.toLowerCase().trim(),CurrentTradeStatus.getText().toLowerCase());
    }


    /**
     * Purpose: Simulate multiple lenders can submit trades using /mbslendertransactions API calls
     *
     * @throws InterruptedException
     */
    public void LenderMultipleTrades() throws FilloException, JSONException, IOException {

        String json = "",url;
        Response res;
        Map<String, String> APIHeaderMap = new LinkedHashMap<>();
        Map<String, Object> TradeMap = new LinkedHashMap<String,Object>();
        Map<String, Object> ProductMap = new LinkedHashMap<String,Object>();
        Map<String, Object> ProductSubMap = new LinkedHashMap<String,Object>();
        Map<String, String> SessionIdsMap = new LinkedHashMap<>();


        PropertiesLib objProperties = new PropertiesLib();
        String sessionId;

        objProperties.InitPropertyFile();

        if (objProperties.getEnv().contentEquals("ACPT"))
            SessionIdsMap = getSessionID();


            // get the Trades List from the test data sheet
        rsMultipleLenders = objExcelLib.GetTestData(GlobalConstants.LENDERMULTIPLETRADES);

        //POST trades
        while (rsMultipleLenders.next())
        {

            APIHeaderMap.put("x-fnma-channel", "web");
            APIHeaderMap.put("x-fnma-sub-channel", "MBSP");

            if (objProperties.getEnv().contentEquals("ACPT"))
            {
                //get the sesion id for each of the user id that are available
                sessionId =  SessionIdsMap.get(rsMultipleLenders.getField("lenderId"));
                APIHeaderMap.put("x-fnma-sessionid", sessionId);
            }
            else
                APIHeaderMap.put("username", rsMultipleLenders.getField("lenderId"));


            //create the json object for the post
            TradeMap.put("lenderId",rsMultipleLenders.getField("lenderId"));

            //product sub map

            if(objProperties.getEnv().contentEquals("ACPT"))
                ProductSubMap.put("identifier", rsMultipleLenders.getField("identifier"));
            else
                ProductSubMap.put("identifier", rsMultipleLenders.getField("identifier_TESTENV"));


            ProductSubMap.put("sourceType", rsMultipleLenders.getField("sourceType"));
            ProductSubMap.put("type", rsMultipleLenders.getField("type"));

            ProductMap.put("productId", ProductSubMap);

            //append the product to the Trade map
            TradeMap.put("product",ProductMap);

            TradeMap.put("stateType",rsMultipleLenders.getField("stateType"));
            TradeMap.put("tradeAmount",rsMultipleLenders.getField("tradeAmount"));
            TradeMap.put("tradeBuySellType",rsMultipleLenders.getField("tradeBuySellType"));
            TradeMap.put("tradeCouponRate",rsMultipleLenders.getField("tradeCouponRate"));
            TradeMap.put("tradeSettlementDate",rsMultipleLenders.getField("tradeSettlementDate"));

            if(rsMultipleLenders.getField("oboLenderSellerServicerNumber").trim().length() > 0)
                TradeMap.put("oboLenderSellerServicerNumber",rsMultipleLenders.getField("oboLenderSellerServicerNumber").trim());


            // set the API Get URL
            InitializeAPICall();
            RestAssured.baseURI += GlobalConstants.LENDERTRADEPOST;
            url = RestAssured.baseURI;

            if(objProperties.getEnv().contentEquals("ACPT"))
                RestAssured.proxy("zsproxy.fanniemae.com",10479);


//            response = given().contentType(ContentType.JSON).headers(APIHeaderMap).
//                    body(TradeMap).
//                    when().
//                    post(url).
//                    then().
//                    statusCode(STATUS_SUCCESS);

            while (true)
            {
                res = given().contentType(ContentType.JSON).headers(APIHeaderMap).
                        body(TradeMap).
                        when().
                        post(url);

                if (res.getStatusCode() == STATUS_SUCCESS)
                    break;
            }

            //json = response.contentType(ContentType.JSON).extract().response().asString();
            json = res.body().asString() ;

            JSONObject objJson = new JSONObject(json);
            TradesTransIDs.add(objJson.get("transReqId").toString());
        }
    }


    private LinkedHashMap<String,String> getSessionID() throws FilloException {
        String sessionID,authKey;
        Map<String, String> APIHeaderMap = new LinkedHashMap<>();
        Map<String, String> SessionIdsMap = new LinkedHashMap<>();

        Response res;

        RestAssured.baseURI = GlobalConstants.LOGINENDPOINT;
        RestAssured.useRelaxedHTTPSValidation();
        RestAssured.proxy("zsproxy.fanniemae.com",10479);
        String url = RestAssured.baseURI;

        rsMultipleLenders = objExcelLib.GetTestData(GlobalConstants.LENDERMULTIPLETRADES);

        //POST trades
        while (rsMultipleLenders.next()) {

            authKey = Base64Utils.encodeToString((rsMultipleLenders.getField("lenderId") + ":" + rsMultipleLenders.getField("pwd")).getBytes());

            APIHeaderMap.put("x-fnma-channel", "web");
            APIHeaderMap.put("Authorization", String.format("Basic %s", authKey));
            APIHeaderMap.put("x-fnma-sub-channel", "MBSP");

            while (true)
            {
                res = given().contentType(ContentType.JSON).headers(APIHeaderMap).
                        when().
                        post(url);

                if (res.getStatusCode() == STATUS_SUCCESS)
                    break;
            }

            sessionID = res.header("x-fnma-sessionid");

            SessionIdsMap.put(rsMultipleLenders.getField("lenderId"), sessionID);

        }
        return (LinkedHashMap<String, String>) SessionIdsMap;
    }


    /**
     * Purpose: Simulate multiple lenders can submit trades using /mbslendertransactions API calls
     *
     * @throws InterruptedException
     */
    public void LenderMultipleTrades_ext(String PassNo) throws FilloException, JSONException, JsonProcessingException {

        String json = "",url;
        Map<String, String> APIHeaderMap = new LinkedHashMap<>();
        Map<String, Object> TradeMap = new LinkedHashMap<String,Object>();
        Map<String, Object> ProductMap = new LinkedHashMap<String,Object>();
        Map<String, Object> ProductSubMap = new LinkedHashMap<String,Object>();

        // get the Trades List from the test data sheet
        rsMultipleLenders = objExcelLib.GetTestData(GlobalConstants.LENDERMULTIPLETRADES_PASSNO + "'" + PassNo + "'");

        // set the API Get URL
        InitializeAPICall();
        RestAssured.baseURI += GlobalConstants.LENDERTRADEPOST;
        url = RestAssured.baseURI;

        //POST trades
        while (rsMultipleLenders.next())
        {

            APIHeaderMap.put("x-fnma-channel", "web");
            APIHeaderMap.put("x-fnma-sub-channel", "MBSP");
            APIHeaderMap.put("username", rsMultipleLenders.getField("lenderId"));

            //create the json object for the post
            TradeMap.put("lenderId",rsMultipleLenders.getField("lenderId"));

            //product sub map
            ProductSubMap.put("identifier", rsMultipleLenders.getField("identifier"));
            ProductSubMap.put("sourceType", rsMultipleLenders.getField("sourceType"));
            ProductSubMap.put("type", rsMultipleLenders.getField("type"));

            ProductMap.put("productId", ProductSubMap);

            //append the product to the Trade map
            TradeMap.put("product",ProductMap);

            TradeMap.put("stateType",rsMultipleLenders.getField("stateType"));
            TradeMap.put("tradeAmount",rsMultipleLenders.getField("tradeAmount"));
            TradeMap.put("tradeBuySellType",rsMultipleLenders.getField("tradeBuySellType"));
            TradeMap.put("tradeCouponRate",rsMultipleLenders.getField("tradeCouponRate"));
            TradeMap.put("tradeSettlementDate",rsMultipleLenders.getField("tradeSettlementDate"));

            response = given().contentType(ContentType.JSON).headers(APIHeaderMap).
                    body(TradeMap).
                    when().
                    post(url).
                    then().
                    statusCode(STATUS_SUCCESS);

            json = response.contentType(ContentType.JSON).extract().response().asString();
            JSONObject objJson = new JSONObject(json);
            TradesTransIDs.add(objJson.get("transReqId").toString());
        }
    }


}
