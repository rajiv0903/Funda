/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.automation.steps;

import com.fanniemae.mbsportal.automation.pages.mbstraderPage;
import com.fanniemae.mbsportal.automation.selenium.conf.ConfigConstants;
import com.fanniemae.mbsportal.automation.selenium.utils.AutoUtil;
import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.LinkedList;
import java.util.List;

import static com.fanniemae.mbsportal.automation.selenium.utils.AutoUtil.WaitForAngular2Finish;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;


/**
 * Created by g8us9b on 8/2/2017.
 */
public class mbstraderSteps {
    int colPrice = 0;
    int colHandle;
    int colTick;
    String TransID;

    @After
    public void teardown() {
      //  AutoUtil.getDriver().quit();
    }

    mbstraderPage traderPage = new mbstraderPage();

    @Then("^Trader is able to view the submitted Trade on the Trade Request Grid with Lender accepted Price$")
    public void ValidateTradeRequestWithPrice(DataTable table)
    {
        List<List<String>> data = table.raw();
        List<WebElement> cols = AutoUtil.getDriver().findElements(By.cssSelector("#live-pricing-requests tr td"));
        int i=0;

        for(int row=1;row<data.size();row++)
        {
            if(data.get(row).get(i).trim().contentEquals("getTransId"))
            {
                TransID = cols.get(i).getText();
            }
            else
                assertEquals(cols.get(i).getText(),data.get(row).get(i));
        }
    }

//    @When("^Trader Confirms the Trade$")
//    public void TraderConfirmTrade() throws InterruptedException {
//        Thread.sleep(ConfigConstants.MED_WAIT);
//        AutoUtil.getDriver().findElement(By.id("price-execute")).click();
//    }

}




