/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.automation.steps;

import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.EXTERNAL_TSP_ID;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.EXTERNAL_USER_ID;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.INTERNAL_USER_ID;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.LENDER;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.READONLY_TRADER;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.READ_TRADER;
import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.TRADER;

import java.io.IOException;
import java.text.ParseException;
import java.util.LinkedHashMap;
import java.util.Map;

import com.fanniemae.mbsportal.automation.selenium.utils.PropertiesLib;
import org.json.JSONException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.codoid.products.exception.FilloException;
import com.fanniemae.mbsportal.automation.pages.mbslenderPage;
import com.fanniemae.mbsportal.automation.pages.mbsloginPage;
import com.fanniemae.mbsportal.automation.pages.mbstraderPage;
import com.fanniemae.mbsportal.automation.pages.mbstradertranshistoryPage;
import com.fanniemae.mbsportal.automation.selenium.conf.ConfigConstants;
import com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.BrowserModeType;
import com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.UserType;
import com.fanniemae.mbsportal.automation.selenium.utils.AutoUtil;
import com.fasterxml.jackson.core.JsonProcessingException;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import gherkin.formatter.model.Examples;
import gherkin.formatter.model.ExamplesTableRow;
import gherkin.formatter.model.ScenarioOutline;
import org.json.JSONException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;

import java.io.IOException;
import java.text.ParseException;

import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.*;
import static com.fanniemae.mbsportal.automation.selenium.utils.AutoUtil.WaitForAngular2Finish;

/**
 * Created by g8us9b on 8/28/2017.
 */
public class mbsCommonSteps
{
    static WebDriver LenderDriver, TraderDriver, ReadTraderDriver;
    static String LenderWindowHandle, TraderWindowHandle, ReadTraderWindowHandle, ExportWindowHandle;
    static boolean blnNewTrade;
    String TransID;
    String LenderID, TraderId="";
    
    static Map<String, String> APIHeaderMap = new LinkedHashMap<>();



    mbsloginPage objLogin = new mbsloginPage();
    mbslenderPage objLender = new mbslenderPage();
    mbstraderPage objTrader = new mbstraderPage();
    mbstradertranshistoryPage objTransHistory = new mbstradertranshistoryPage();

    @After
    public void teardown()
    {
        //objTraderConfirmed.teardown();
    }

    /**
     * @param driver
     * @param element
     */
    public static void waitForElementToBeClickable(WebDriver driver, WebElement element){
    	WebDriverWait wait = new WebDriverWait(driver, 15);
    	wait.until(ExpectedConditions.elementToBeClickable(element));
    }
    
    /**
     * @param driver
     * @param element
     */
    public static void waitForElementToBeClickableAndClick(WebDriver driver, WebElement element){
    	WebDriverWait wait = new WebDriverWait(driver, 15);
    	wait.until(ExpectedConditions.elementToBeClickable(element));
    	element.click();
    }
    
    /**
     * wait to be displayed
     * @param driver
     * @param element
     */
    public static void waitForElementToBeVisible(WebDriver driver, WebElement element){
    	WebDriverWait wait = new WebDriverWait(driver, 15);
    	wait.until(ExpectedConditions.visibilityOf(element));
    }


    /**
     * wait to be displayed
     * @param driver
     * @param by
     */
    public static void waitForElementToBeVisible(WebDriver driver, By by){
    	WebDriverWait wait = new WebDriverWait(driver, 15);
    	wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
    }
    
    
	/**
	 * @param userid
	 * @return
	 */
	public static Map<String, String> setAPIHeaderMap(String userid) {

		APIHeaderMap.put("x-fnma-channel", "web");
		APIHeaderMap.put("x-fnma-sub-channel", "MBSP");
		APIHeaderMap.put("userName", userid);
		return APIHeaderMap;
	}

    @Given("^\"([^\"]*)\" \"([^\"]*)\" Logs-in to MBS Trading Platform$")
    public void UserLogin(String User, String UserEntity) throws FilloException, InterruptedException, IOException {


            switch (User.toUpperCase().trim())
            {
            case LENDER:
                    LenderLogin(UserEntity);
                    break;
            case TRADER:
                    TraderLogin();
                    break;
            case READ_TRADER:
                    ReadTraderLogin();
                    break;
            }

    }


    @When("^\"([^\"]*)\" \"([^\"]*)\" is on TBA Trading Page$")
    public void NavigatetoPage(String Type, String ID) throws InterruptedException, FilloException, IOException {

        //go to the page
        Thread.sleep(ConfigConstants.MED_WAIT);

        switch (Type.toUpperCase().trim())
        {
                case LENDER:
                        objLogin.SwitchWindow(LenderWindowHandle, LenderDriver);
                        LenderID = ID;
                        objLender.LenderPageInit(LenderDriver);
                        objLender.LenderGetExpectedData(ID);
                        objLender.ValidateLenderInitialLoad(blnNewTrade);
                        break;
                case TRADER:
                case READ_TRADER:
                        TraderId = ID;

                        if (Type.toUpperCase().trim().contentEquals(TRADER)) {
                                objLogin.SwitchWindow(TraderWindowHandle, TraderDriver);
                                objTrader.mbsTraderPageInit(TraderDriver);
                        }
                        else {
                                objLogin.SwitchWindow(ReadTraderWindowHandle, ReadTraderDriver);
                                objTrader.mbsTraderPageInit(ReadTraderDriver);
                        }

                        Thread.sleep(ConfigConstants.MED_WAIT);
                        objTrader.LenderGetExpectedData(ID);
                        objTrader.ValidateTraderInitialLoad();
                        break;
        }
    }

    @Then("^Lender submits a new Trade$")
    public void LenderSubmitAmount() throws InterruptedException, FilloException {
            objLogin.SwitchWindow(LenderWindowHandle,LenderDriver);
            TransID = objLender.LenderSubmitAmount(objLogin.getLenderName(),objLogin.getRoleName(),blnNewTrade);
    }


    @When("^Lender submits multiple trades$")
    public void LenderMultipleTrades() throws InterruptedException, FilloException, JSONException, IOException {
            //Lender trades are submitted by using API calls to simulate multiple trades on trader queue
            objLender.LenderMultipleTrades();

    }

        @When("^Lender submits multiple trades in \"([^\"]*)\" pass$")
        public void LenderMultipleTrades_1(String PassNo) throws InterruptedException, FilloException, JSONException, JsonProcessingException {
                //Lender trades are submitted by using API calls to simulate multiple trades on trader queue
                objLender.LenderMultipleTrades_ext(PassNo);

        }

        @Then("^Validate Stream Trade Prices for \"([^\"]*)\" pass$")
        public void ValidateSreamPrice(String PassNo) throws InterruptedException, FilloException {
                //Lender trades are submitted by using API calls to simulate multiple trades on trader queue
                objTrader.ValidateSreamPrice(PassNo);

        }


        @Then("^Trader submits Price for submitted Trade$")
    public void TraderSubmitPrice() throws FilloException, InterruptedException {
        //validate all data and enter price with validations
        objTrader.TraderSubmitPrice("WITHOUT_DIALS");
    }


    @When("^Lender receives Trade \"([^\"]*)\"$")
    public void LenderReceivePrice(String PriceType) throws InterruptedException {
            objLogin.SwitchWindow(LenderWindowHandle,LenderDriver);
            objLender.ValidateLenderReceivePrice(objLogin.getLenderName(),objLogin.getRoleName(), PriceType);
    }

    @Then("^Lender Hits the trade$")
    public void LenderHitTrade() throws FilloException, InterruptedException {
        objLender.AcceptQuote(INCL_VALIDATION);
    }

    @Then("^Lender Accepts the trade$")
    public void LenderAcceptTrade() throws FilloException, InterruptedException {
               objLender.AcceptQuote(NO_VALIDATION);
        }




    @When("^Trader receives Lender confirmation$")
    public void TraderReceiveConfirmation() throws InterruptedException {
            objLogin.SwitchWindow(TraderWindowHandle,TraderDriver);
            objTrader.ValidateTraderReceiveHit();
    }

    @Then("^Trader confirms the Trade \"([^\"]*)\"$")
    public void TraderConfirmTrade(String Validate) throws InterruptedException, FilloException {
        objTrader.TraderConfirmTrade(Validate);
    }

    @Then("^\"([^\"]*)\" is able to verify Trade details on Transaction History Page$")
    public void TraderTransactionHistory(String User)
            throws InterruptedException, FilloException, ParseException, IOException {

            if(User.toUpperCase().trim().contentEquals(UserType.LENDER.toString().trim()))
            {
               objTransHistory.transhistoryPageInit(LenderDriver);
               objLogin.SwitchWindow(LenderWindowHandle,LenderDriver);
               objTransHistory.goToTraderTransHistory(LenderID, TransID,objLogin.getRoleName(),UserType.LENDER);
            }
            else if(User.toUpperCase().trim().contentEquals(UserType.TRADER.toString().trim()))
            {
                objTransHistory.transhistoryPageInit(TraderDriver);
                objLogin.SwitchWindow(TraderWindowHandle,TraderDriver);
                objTransHistory.goToTraderTransHistory(TraderId, TransID,objLogin.getRoleName(),UserType.TRADER);
            }
    }

    @Then("^Trader is able to verify completed trades on TBA Trading Page \"([^\"]*)\"$")
    public void KeepCompletedTrades(String status) throws InterruptedException, FilloException, ParseException {
            objTrader.mbsTraderPageInit(TraderDriver);
            objLogin.SwitchWindow(TraderWindowHandle, TraderDriver);
            objTrader.goToTraderTBATrading();
            objTrader.validateCompletedTrades(status);
    }

    @Then("^Lender receives Trade confirmation on Lender page$")
    public void LenderConfirmReceiveStatus() throws FilloException, InterruptedException, ParseException {
            objLogin.SwitchWindow(LenderWindowHandle,LenderDriver);
            objLender.LenderReceiveConfirm(objLogin.getLenderName(),objLogin.getRoleName());
    }

    @Then("^User Logs Off from the MBS Trading Platform$")
    public void UserLogoff() throws InterruptedException {

           if(LenderDriver != null) {
                   objLogin.LoginPageInit(LenderDriver);
                   objLogin.SwitchWindow(LenderWindowHandle, LenderDriver);
                   objLogin.UserLogoff(LenderDriver);
                   Thread.sleep(ConfigConstants.MED_WAIT);
                   // WaitForAngular2Finish();
                   LenderDriver.close();
                   LenderDriver = null;
                   LenderWindowHandle = null;

           }

           if(TraderDriver!=null) {
                   objLogin.LoginPageInit(TraderDriver);
                   objLogin.SwitchWindow(TraderWindowHandle, TraderDriver);
                   objLogin.UserLogoff(TraderDriver);

                   Thread.sleep(ConfigConstants.MED_WAIT);
                   TraderDriver.close();
                   TraderDriver = null;
                   TraderWindowHandle = null;
           }

            if(ReadTraderDriver!=null) {
                    objLogin.LoginPageInit(ReadTraderDriver);
                    objLogin.SwitchWindow(ReadTraderWindowHandle, ReadTraderDriver);
                    objLogin.UserLogoff(ReadTraderDriver);

                    Thread.sleep(ConfigConstants.MED_WAIT);
                    ReadTraderDriver.close();
                    ReadTraderDriver = null;
                    ReadTraderWindowHandle = null;
            }

            blnNewTrade = false;
    }


    @When("^Lender Cancels the Submitted Trade$")
    public void CancelTrade() throws InterruptedException {
        objLender.CancelTrade();
    }

    @Then("^\"([^\"]*)\" Status should be Displayed on the Lender Trade Info section$")
    public void ValidateCancelledStatus(String TradeStatus) throws InterruptedException, FilloException {
         objLogin.SwitchWindow(LenderWindowHandle,LenderDriver);
         objLender.ValidateCancelStatus(objLogin.getLenderName(),objLogin.getRoleName(),TradeStatus);
    }

    @Then("^Trader \"([^\"]*)\" the Trade$")
    public void TraderPassCancelTrade(String TraderAction) throws InterruptedException, FilloException {
            objLogin.SwitchWindow(TraderWindowHandle,TraderDriver);
            objTrader.TraderAction(TraderAction);
    }

    @Given("^Given Lender creates New Trade$")
    public void LenderClearTicket() throws InterruptedException, FilloException {
            objLogin.SwitchWindow(LenderWindowHandle,LenderDriver);
            objLender.CreateNewTrade();
        }

    @Then("^\"([^\"]*)\" is able to sort on Transaction History Page$")
    public void TraderSortTransactionHistory(String User) throws InterruptedException, FilloException, ParseException {
                if(User.toUpperCase().trim().contentEquals(UserType.LENDER.toString().trim()))
                {
                        objTransHistory.transhistoryPageInit(LenderDriver);
                        objLogin.SwitchWindow(LenderWindowHandle,LenderDriver);
                        objTransHistory.sortTraderTransHistory(LenderID, TransID,objLogin.getRoleName(),UserType.LENDER);
                }
                else if(User.toUpperCase().trim().contentEquals(UserType.TRADER.toString().trim()))
                {
                        objTransHistory.transhistoryPageInit(TraderDriver);
                        objLogin.SwitchWindow(TraderWindowHandle,TraderDriver);
                        objTransHistory.sortTraderTransHistory(TraderId, TransID,objLogin.getRoleName(),UserType.TRADER);
                }
        }


    @Then("^\"([^\"]*)\" times out the current trade$")
    public void Timeout(String UserType) throws InterruptedException {
           objLogin.SwitchWindow(TraderWindowHandle,TraderDriver);
           objTrader.TraderTimeOut(UserType);
    }

    @Then("^Trader submits Price using \"([^\"]*)\" Dials$")
     public void ValidateTraderPriceDials(String Dial_Type) throws InterruptedException, FilloException
    {

            objLogin.SwitchWindow(TraderWindowHandle,TraderDriver);
            if (Dial_Type.contentEquals("UP"))
                    objTrader.TraderSubmitPrice("WITH_DIALS_UP");
            else
                    objTrader.TraderSubmitPrice("WITH_DIALS_DOWN");
     }


     //validate the submit/confirm button is enabled when handle price is changed defect - CMMBSSTA01-1216
     @When("^Trader RePrices using Price Dials \"([^\"]*)\"$")
     public void ValidateSubmitConfirmEnabled(String ValidationType) throws InterruptedException, FilloException
     {
             objLogin.SwitchWindow(TraderWindowHandle,TraderDriver);
             objTrader.ValidateSubmitConfirmEnabled(ValidationType);
     }

    @Then("^\"([^\"]*)\" \"([^\"]*)\" is only view trades \"([^\"]*)\"$")
    public void ValidateReadOnlyTrader(String TraderType, String TraderID, String ActionType)
            throws InterruptedException, FilloException, ParseException {
            //valdiate if all the rows are disabled and the data is comming correctly
            objLogin.SwitchWindow(ReadTraderWindowHandle,ReadTraderDriver);
            objTrader.ValidateReadTraderPage(TraderType,TraderID, ActionType);

    }

        @Then("^Then Trader Processes Trades$")
        public void TraderProcessTrades() throws InterruptedException {
                objLogin.SwitchWindow(TraderWindowHandle,TraderDriver);
                objTrader.ProcessAllTrades();
        }


        private void LenderLogin(String UserEntity) throws InterruptedException, IOException, FilloException {
                     Thread.sleep(ConfigConstants.LONG_WAIT);

             String UserID;
             PropertiesLib objProperties = new PropertiesLib();
             objProperties.InitPropertyFile();

             //set Blue/Green users
             if(objProperties.getBGEnv().contentEquals("BLUE"))
             {
                     if (UserEntity.contains("TSP"))
                         UserID = EXTERNAL_TSP_ID;
                     else
                         UserID = EXTERNAL_USER_ID;
             }
             else
             {
                     //green
                     if (UserEntity.contains("TSP"))
                             UserID = EXTERNAL_TSP_ID_GREEN;
                     else
                             UserID = EXTERNAL_USER_ID_GREEN;
             }

             if (LenderDriver == null) {
                     AutoUtil.setUp(BrowserModeType.NORMAL);

                     LenderDriver = AutoUtil.getDriver();
                     LenderWindowHandle = objLogin.LaunchApplication(LenderDriver);
                     objLogin.LoginPageInit(LenderDriver);

                     objLogin.FetchUserData(UserID);

                     objLogin.UserLogin();
                     objLogin.NavigateToPage(LenderDriver);

                     //this is the first time load
                     blnNewTrade = true;
             } else {

                     if (UserEntity.contains("TSP")) {
                             objLogin.FetchUserData(UserID);
                             objLogin.UserLogin();
                             objLogin.NavigateToPage(LenderDriver);

                             //this is the first time load
                             blnNewTrade = true;
                     } else {
                             objLogin.FetchUserData(UserID);
                             objLogin.LoginPageInit(LenderDriver);
                             objLogin.SwitchWindow(LenderWindowHandle, LenderDriver);
                             blnNewTrade = false;
                     }
             }
     }


     private void TraderLogin() throws IOException, InterruptedException, FilloException {

             String UserID;
             PropertiesLib objProperties = new PropertiesLib();
             objProperties.InitPropertyFile();

             //set Blue/Green users
             if(objProperties.getBGEnv().contentEquals("BLUE"))
                 UserID = INTERNAL_USER_ID;
             else
                 UserID = INTERNAL_USER_ID_GREEN;

	        if (TraderDriver == null)
             {
                     AutoUtil.setUp(BrowserModeType.INCOGONITO);
                     TraderDriver = AutoUtil.getDriver();
                     TraderWindowHandle = objLogin.LaunchApplication(TraderDriver);
                     objLogin.LoginPageInit(TraderDriver);
                     objLogin.FetchUserData(UserID);
                     objLogin.UserLogin();
                     objLogin.NavigateToPage(TraderDriver);
             }
             else
             {
                     objLogin.FetchUserData(UserID);
                     objLogin.LoginPageInit(TraderDriver);
                     objLogin.SwitchWindow(TraderWindowHandle, TraderDriver);
             }
     }

     private void ReadTraderLogin() throws IOException, InterruptedException, FilloException {

             String UserID;
             PropertiesLib objProperties = new PropertiesLib();
             objProperties.InitPropertyFile();

             //set Blue/Green users
             if(objProperties.getBGEnv().contentEquals("BLUE"))
                     UserID = READONLY_TRADER;
             else
                     UserID = READONLY_TRADER_GREEN;


             if (ReadTraderDriver == null)
             {
                   AutoUtil.setUp(BrowserModeType.NORMAL);
                   ReadTraderDriver = AutoUtil.getDriver();
                   ReadTraderWindowHandle = objLogin.LaunchApplication(ReadTraderDriver);
                   objLogin.LoginPageInit(ReadTraderDriver);
                   objLogin.FetchUserData(UserID);
                   objLogin.UserLogin();
                   objLogin.NavigateToPage(ReadTraderDriver);
             }
             else
             {
                   objLogin.FetchUserData(UserID);
                   objLogin.LoginPageInit(ReadTraderDriver);
                   objLogin.SwitchWindow(ReadTraderWindowHandle, ReadTraderDriver);
             }
     }
}
