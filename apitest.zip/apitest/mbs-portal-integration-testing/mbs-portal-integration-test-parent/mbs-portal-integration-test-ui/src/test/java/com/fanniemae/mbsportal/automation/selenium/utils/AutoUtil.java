/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.automation.selenium.utils;

/**
 * Created by g8uaxt on 7/20/2017.
 */

import com.fanniemae.mbsportal.automation.selenium.conf.ConfigConstants;
import com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants;
import com.paulhammant.ngwebdriver.NgWebDriver;
import cucumber.api.Scenario;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.Properties;
import java.util.concurrent.TimeUnit;


import static com.fanniemae.mbsportal.automation.selenium.conf.GlobalConstants.*;
import static org.junit.Assert.fail;
import static org.openqa.selenium.remote.BrowserType.FIREFOX;

/**
 * @author ANBU This is selenium util class responsible for all UI test cases
 */
public class AutoUtil {
    private static WebDriver driver;
    private static NgWebDriver ngWebDriver;
    private static String browserName;
    public static PropertiesLib objProperties = new PropertiesLib();
    
    private static String MIME_TYPES = "binary/octet-stream;"
    		+ "application/vnd.hzn-3d-crossword;"
    		+ "video/3gpp;video/3gpp2;"
    		+ "application/vnd.mseq;"
    		+ "application/vnd.3m.post-it-notes;"
    		+ "application/vnd.3gpp.pic-bw-large;"
    		+ "application/vnd.3gpp.pic-bw-small;"
    		+ "application/vnd.3gpp.pic-bw-var;"
    		+ "application/vnd.3gp2.tcap;"
    		+ "application/x-7z-compressed;"
    		+ "application/x-abiword;"
    		+ "application/x-ace-compressed;"
    		+ "application/vnd.americandynamics.acc;"
    		+ "application/vnd.acucobol;"
    		+ "application/vnd.acucorp;"
    		+ "audio/adpcm;"
    		+ "application/x-authorware-bin;"
    		+ "application/x-athorware-map;"
    		+ "application/x-authorware-seg;"
    		+ "application/vnd.adobe.air-application-installer-package+zip;"
    		+ "application/x-shockwave-flash;"
    		+ "application/vnd.adobe.fxp;"
    		+ "application/pdf;"
    		+ "application/vnd.cups-ppd;"
    		+ "application/x-director;"
    		+ "applicaion/vnd.adobe.xdp+xml;"
    		+ "application/vnd.adobe.xfdf;"
    		+ "audio/x-aac;"
    		+ "application/vnd.ahead.space;"
    		+ "application/vnd.airzip.filesecure.azf;"
    		+ "application/vnd.airzip.filesecure.azs;"
    		+ "application/vnd.amazon.ebook;"
    		+ "application/vnd.amiga.ami;"
    		+ "applicatin/andrew-inset;"
    		+ "application/vnd.android.package-archive;"
    		+ "application/vnd.anser-web-certificate-issue-initiation;"
    		+ "application/vnd.anser-web-funds-transfer-initiation;"
    		+ "application/vnd.antix.game-component;"
    		+ "application/vnd.apple.installe+xml;"
    		+ "application/applixware;"
    		+ "application/vnd.hhe.lesson-player;"
    		+ "application/vnd.aristanetworks.swi;"
    		+ "text/x-asm;"
    		+ "application/atomcat+xml;"
    		+ "application/atomsvc+xml;"
    		+ "application/atom+xml;"
    		+ "application/pkix-attr-cert;"
    		+ "audio/x-aiff;video/x-msvieo;"
    		+ "application/vnd.audiograph;"
    		+ "image/vnd.dxf;"
    		+ "model/vnd.dwf;"
    		+ "text/plain-bas;"
    		+ "application/x-bcpio;"
    		+ "application/octet-stream;"
    		+ "image/bmp;"
    		+ "application/x-bittorrent;"
    		+ "application/vnd.rim.cod;"
    		+ "application/vnd.blueice.multipass;"
    		+ "application/vnd.bm;"
    		+ "application/x-sh;"
    		+ "image/prs.btif;"
    		+ "application/vnd.businessobjects;"
    		+ "application/x-bzip;"
    		+ "application/x-bzip2;"
    		+ "application/x-csh;"
    		+ "text/x-c;"
    		+ "application/vnd.chemdraw+xml;"
    		+ "text/css;"
    		+ "chemical/x-cdx;"
    		+ "chemical/x-cml;"
    		+ "chemical/x-csml;"
    		+ "application/vn.contact.cmsg;"
    		+ "application/vnd.claymore;"
    		+ "application/vnd.clonk.c4group;"
    		+ "image/vnd.dvb.subtitle;"
    		+ "application/cdmi-capability;"
    		+ "application/cdmi-container;"
    		+ "application/cdmi-domain;"
    		+ "application/cdmi-object;"
    		+ "application/cdmi-queue;"
    		+ "applicationvnd.cluetrust.cartomobile-config;"
    		+ "application/vnd.cluetrust.cartomobile-config-pkg;"
    		+ "image/x-cmu-raster;"
    		+ "model/vnd.collada+xml;"
    		+ "text/csv;"
    		+ "application/mac-compactpro;"
    		+ "application/vnd.wap.wmlc;"
    		+ "image/cgm;"
    		+ "x-conference/x-cooltalk;"
    		+ "image/x-cmx;"
    		+ "application/vnd.xara;"
    		+ "application/vnd.cosmocaller;"
    		+ "application/x-cpio;"
    		+ "application/vnd.crick.clicker;"
    		+ "application/vnd.crick.clicker.keyboard;"
    		+ "application/vnd.crick.clicker.palette;"
    		+ "application/vnd.crick.clicker.template;"
    		+ "application/vn.crick.clicker.wordbank;"
    		+ "application/vnd.criticaltools.wbs+xml;"
    		+ "application/vnd.rig.cryptonote;"
    		+ "chemical/x-cif;"
    		+ "chemical/x-cmdf;"
    		+ "application/cu-seeme;"
    		+ "application/prs.cww;"
    		+ "text/vnd.curl;"
    		+ "text/vnd.curl.dcurl;"
    		+ "text/vnd.curl.mcurl;"
    		+ "text/vnd.crl.scurl;"
    		+ "application/vnd.curl.car;"
    		+ "application/vnd.curl.pcurl;"
    		+ "application/vnd.yellowriver-custom-menu;"
    		+ "application/dssc+der;"
    		+ "application/dssc+xml;"
    		+ "application/x-debian-package;"
    		+ "audio/vnd.dece.audio;"
    		+ "image/vnd.dece.graphic;"
    		+ "video/vnd.dec.hd;"
    		+ "video/vnd.dece.mobile;"
    		+ "video/vnd.uvvu.mp4;"
    		+ "video/vnd.dece.pd;"
    		+ "video/vnd.dece.sd;"
    		+ "video/vnd.dece.video;"
    		+ "application/x-dvi;"
    		+ "application/vnd.fdsn.seed;"
    		+ "application/x-dtbook+xml;"
    		+ "application/x-dtbresource+xml;"
    		+ "application/vnd.dvb.ait;"
    		+ "applcation/vnd.dvb.service;"
    		+ "audio/vnd.digital-winds;"
    		+ "image/vnd.djvu;"
    		+ "application/xml-dtd;"
    		+ "application/vnd.dolby.mlp;"
    		+ "application/x-doom;"
    		+ "application/vnd.dpgraph;"
    		+ "audio/vnd.dra;"
    		+ "application/vnd.dreamfactory;"
    		+ "audio/vnd.dts;"
    		+ "audio/vnd.dts.hd;"
    		+ "imag/vnd.dwg;"
    		+ "application/vnd.dynageo;"
    		+ "application/ecmascript;"
    		+ "application/vnd.ecowin.chart;"
    		+ "image/vnd.fujixerox.edmics-mmr;"
    		+ "image/vnd.fujixerox.edmics-rlc;"
    		+ "application/exi;"
    		+ "application/vnd.proteus.magazine;"
    		+ "application/epub+zip;"
    		+ "message/rfc82;"
    		+ "application/vnd.enliven;"
    		+ "application/vnd.is-xpr;"
    		+ "image/vnd.xiff;"
    		+ "application/vnd.xfdl;"
    		+ "application/emma+xml;"
    		+ "application/vnd.ezpix-album;"
    		+ "application/vnd.ezpix-package;"
    		+ "image/vnd.fst;"
    		+ "video/vnd.fvt;"
    		+ "image/vnd.fastbidsheet;"
    		+ "application/vn.denovo.fcselayout-link;"
    		+ "video/x-f4v;"
    		+ "video/x-flv;"
    		+ "image/vnd.fpx;"
    		+ "image/vnd.net-fpx;"
    		+ "text/vnd.fmi.flexstor;"
    		+ "video/x-fli;"
    		+ "application/vnd.fluxtime.clip;"
    		+ "application/vnd.fdf;"
    		+ "text/x-fortran;"
    		+ "application/vnd.mif;"
    		+ "application/vnd.framemaker;imae/x-freehand;"
    		+ "application/vnd.fsc.weblaunch;"
    		+ "application/vnd.frogans.fnc;"
    		+ "application/vnd.frogans.ltf;"
    		+ "application/vnd.fujixerox.ddd;"
    		+ "application/vnd.fujixerox.docuworks;"
    		+ "application/vnd.fujixerox.docuworks.binder;"
    		+ "application/vnd.fujitu.oasys;"
    		+ "application/vnd.fujitsu.oasys2;"
    		+ "application/vnd.fujitsu.oasys3;"
    		+ "application/vnd.fujitsu.oasysgp;"
    		+ "application/vnd.fujitsu.oasysprs;"
    		+ "application/x-futuresplash;"
    		+ "application/vnd.fuzzysheet;"
    		+ "image/g3fax;"
    		+ "application/vnd.gmx;"
    		+ "model/vn.gtw;"
    		+ "application/vnd.genomatix.tuxedo;"
    		+ "application/vnd.geogebra.file;"
    		+ "application/vnd.geogebra.tool;"
    		+ "model/vnd.gdl;"
    		+ "application/vnd.geometry-explorer;"
    		+ "application/vnd.geonext;"
    		+ "application/vnd.geoplan;"
    		+ "application/vnd.geospace;"
    		+ "applicatio/x-font-ghostscript;"
    		+ "application/x-font-bdf;"
    		+ "application/x-gtar;"
    		+ "application/x-texinfo;"
    		+ "application/x-gnumeric;"
    		+ "application/vnd.google-earth.kml+xml;"
    		+ "application/vnd.google-earth.kmz;"
    		+ "application/vnd.grafeq;"
    		+ "image/gif;text/vnd.graphviz;"
    		+ "aplication/vnd.groove-account;"
    		+ "application/vnd.groove-help;"
    		+ "application/vnd.groove-identity-message;"
    		+ "application/vnd.groove-injector;"
    		+ "application/vnd.groove-tool-message;"
    		+ "application/vnd.groove-tool-template;"
    		+ "application/vnd.groove-vcar;"
    		+ "video/h261;"
    		+ "video/h263;"
    		+ "video/h264;"
    		+ "application/vnd.hp-hpid;"
    		+ "application/vnd.hp-hps;"
    		+ "application/x-hdf;"
    		+ "audio/vnd.rip;"
    		+ "application/vnd.hbci;"
    		+ "application/vnd.hp-jlyt;"
    		+ "application/vnd.hp-pcl;"
    		+ "application/vnd.hp-hpgl;"
    		+ "application/vnd.yamaha.h-script;"
    		+ "application/vnd.yamaha.hv-dic;"
    		+ "application/vnd.yamaha.hv-voice;"
    		+ "application/vnd.hydrostatix.sof-data;"
    		+ "application/hyperstudio;"
    		+ "application/vnd.hal+xml;"
    		+ "text/html;"
    		+ "application/vnd.ibm.rights-management;"
    		+ "application/vnd.ibm.securecontainer;"
    		+ "text/calendar;"
    		+ "application/vnd.iccprofile;"
    		+ "image/x-icon;"
    		+ "application/vnd.igloader;"
    		+ "image/ief;"
    		+ "application/vnd.immervision-ivp;"
    		+ "application/vnd.immervision-ivu;"
    		+ "application/reginfo+xml;"
    		+ "text/vnd.in3d.3dml;"
    		+ "text/vnd.in3d.spot;"
    		+ "mode/iges;"
    		+ "application/vnd.intergeo;"
    		+ "application/vnd.cinderella;"
    		+ "application/vnd.intercon.formnet;"
    		+ "application/vnd.isac.fcs;"
    		+ "application/ipfix;"
    		+ "application/pkix-cert;"
    		+ "application/pkixcmp;"
    		+ "application/pkix-crl;"
    		+ "application/pkix-pkipath;"
    		+ "applicaion/vnd.insors.igm;"
    		+ "application/vnd.ipunplugged.rcprofile;"
    		+ "application/vnd.irepository.package+xml;"
    		+ "text/vnd.sun.j2me.app-descriptor;"
    		+ "application/java-archive;"
    		+ "application/java-vm;"
    		+ "application/x-java-jnlp-file;"
    		+ "application/java-serializd-object;"
    		+ "text/x-java-source,java;"
    		+ "application/javascript;"
    		+ "application/json;"
    		+ "application/vnd.joost.joda-archive;"
    		+ "video/jpm;"
    		+ "image/jpeg;"
    		+ "video/jpeg;"
    		+ "application/vnd.kahootz;"
    		+ "application/vnd.chipnuts.karaoke-mmd;"
    		+ "application/vnd.kde.karbon;"
    		+ "application/vnd.kde.kchart;"
    		+ "application/vnd.kde.kformula;"
    		+ "application/vnd.kde.kivio;"
    		+ "application/vnd.kde.kontour;"
    		+ "application/vnd.kde.kpresenter;"
    		+ "application/vnd.kde.kspread;"
    		+ "application/vnd.kde.kword;"
    		+ "application/vnd.kenameaapp;"
    		+ "application/vnd.kidspiration;"
    		+ "application/vnd.kinar;"
    		+ "application/vnd.kodak-descriptor;"
    		+ "application/vnd.las.las+xml;"
    		+ "application/x-latex;"
    		+ "application/vnd.llamagraphics.life-balance.desktop;"
    		+ "application/vnd.llamagraphics.life-balance.exchange+xml;"
    		+ "application/vnd.jam;"
    		+ "application/vnd.lotus-1-2-3;"
    		+ "application/vnd.lotus-approach;"
    		+ "application/vnd.lotus-freelance;"
    		+ "application/vnd.lotus-notes;"
    		+ "application/vnd.lotus-organizer;"
    		+ "application/vnd.lotus-screencam;"
    		+ "application/vnd.lotus-wordro;"
    		+ "audio/vnd.lucent.voice;"
    		+ "audio/x-mpegurl;"
    		+ "video/x-m4v;"
    		+ "application/mac-binhex40;"
    		+ "application/vnd.macports.portpkg;"
    		+ "application/vnd.osgeo.mapguide.package;"
    		+ "application/marc;"
    		+ "application/marcxml+xml;"
    		+ "application/mxf;"
    		+ "application/vnd.wolfrm.player;"
    		+ "application/mathematica;"
    		+ "application/mathml+xml;"
    		+ "application/mbox;"
    		+ "application/vnd.medcalcdata;"
    		+ "application/mediaservercontrol+xml;"
    		+ "application/vnd.mediastation.cdkey;"
    		+ "application/vnd.mfer;"
    		+ "application/vnd.mfmp;"
    		+ "model/mesh;"
    		+ "appliation/mads+xml;"
    		+ "application/mets+xml;"
    		+ "application/mods+xml;"
    		+ "application/metalink4+xml;"
    		+ "application/vnd.ms-powerpoint.template.macroenabled.12;"
    		+ "application/vnd.ms-word.document.macroenabled.12;"
    		+ "application/vnd.ms-word.template.macroenabed.12;"
    		+ "application/vnd.mcd;"
    		+ "application/vnd.micrografx.flo;"
    		+ "application/vnd.micrografx.igx;"
    		+ "application/vnd.eszigno3+xml;"
    		+ "application/x-msaccess;"
    		+ "video/x-ms-asf;"
    		+ "application/x-msdownload;"
    		+ "application/vnd.ms-artgalry;"
    		+ "application/vnd.ms-ca-compressed;"
    		+ "application/vnd.ms-ims;"
    		+ "application/x-ms-application;"
    		+ "application/x-msclip;"
    		+ "image/vnd.ms-modi;"
    		+ "application/vnd.ms-fontobject;"
    		+ "application/vnd.ms-excel;"
    		+ "application/vnd.ms-excel.addin.macroenabled.12;"
    		+ "application/vnd.ms-excelsheet.binary.macroenabled.12;"
    		+ "application/vnd.ms-excel.template.macroenabled.12;"
    		+ "application/vnd.ms-excel.sheet.macroenabled.12;"
    		+ "application/vnd.ms-htmlhelp;"
    		+ "application/x-mscardfile;"
    		+ "application/vnd.ms-lrm;"
    		+ "application/x-msmediaview;"
    		+ "aplication/x-msmoney;"
    		+ "application/vnd.openxmlformats-officedocument.presentationml.presentation;"
    		+ "application/vnd.openxmlformats-officedocument.presentationml.slide;"
    		+ "application/vnd.openxmlformats-officedocument.presentationml.slideshw;"
    		+ "application/vnd.openxmlformats-officedocument.presentationml.template;"
    		+ "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;"
    		+ "application/vnd.openxmlformats-officedocument.spreadsheetml.template;"
    		+ "application/vnd.openxmlformats-officedocument.wordprocessingml.document;"
    		+ "application/vnd.openxmlformats-officedocument.wordprocessingml.template;"
    		+ "application/x-msbinder;application/vnd.ms-officetheme;"
    		+ "application/onenote;"
    		+ "audio/vnd.ms-playready.media.pya;"
    		+ "video/vnd.ms-playready.media.pyv;"
    		+ "application/vnd.ms-powerpoint;"
    		+ "application/vnd.ms-powerpoint.addin.macroenabled.12;"
    		+ "application/vnd.ms-powerpoint.slide.macroenabled.12;"
    		+ "application/vnd.ms-powerpoint.presentation.macroenabled.12;"
    		+ "application/vnd.ms-powerpoint.slideshow.macroenabled.12;"
    		+ "application/vnd.ms-project;"
    		+ "application/x-mspublisher;"
    		+ "application/x-msschedule;"
    		+ "application/x-silverlight-app;"
    		+ "application/vnd.ms-pki.stl;"
    		+ "application/vnd.ms-pki.seccat;"
    		+ "application/vn.visio;"
    		+ "video/x-ms-wm;"
    		+ "audio/x-ms-wma;"
    		+ "audio/x-ms-wax;"
    		+ "video/x-ms-wmx;"
    		+ "application/x-ms-wmd;"
    		+ "application/vnd.ms-wpl;"
    		+ "application/x-ms-wmz;"
    		+ "video/x-ms-wmv;"
    		+ "video/x-ms-wvx;"
    		+ "application/x-msmetafile;"
    		+ "application/x-msterminal;"
    		+ "application/msword;"
    		+ "application/x-mswrite;"
    		+ "application/vnd.ms-works;"
    		+ "application/x-ms-xbap;"
    		+ "application/vnd.ms-xpsdocument;"
    		+ "audio/midi;"
    		+ "application/vnd.ibm.minipay;"
    		+ "application/vnd.ibm.modcap;"
    		+ "application/vnd.jcp.javame.midlet-rms;"
    		+ "application/vnd.tmobile-ivetv;"
    		+ "application/x-mobipocket-ebook;"
    		+ "application/vnd.mobius.mbk;"
    		+ "application/vnd.mobius.dis;"
    		+ "application/vnd.mobius.plc;"
    		+ "application/vnd.mobius.mqy;"
    		+ "application/vnd.mobius.msl;"
    		+ "application/vnd.mobius.txf;"
    		+ "application/vnd.mobius.daf;"
    		+ "tex/vnd.fly;"
    		+ "application/vnd.mophun.certificate;"
    		+ "application/vnd.mophun.application;"
    		+ "video/mj2;"
    		+ "audio/mpeg;"
    		+ "video/vnd.mpegurl;"
    		+ "video/mpeg;"
    		+ "application/mp21;"
    		+ "audio/mp4;"
    		+ "video/mp4;"
    		+ "application/mp4;"
    		+ "application/vnd.apple.mpegurl;"
    		+ "application/vnd.msician;"
    		+ "application/vnd.muvee.style;"
    		+ "application/xv+xml;"
    		+ "application/vnd.nokia.n-gage.data;"
    		+ "application/vnd.nokia.n-gage.symbian.install;"
    		+ "application/x-dtbncx+xml;";
    

    public static void setUp(BrowserModeType BrowserMode)
            throws InterruptedException, IOException {

        objProperties.InitPropertyFile();
        driver = initializeDriver(BrowserMode);
        Thread.sleep(ConfigConstants.MED_WAIT);
    }

    private static WebDriver initializeDriver(BrowserModeType BrowserMode) throws IOException {

        browserName = objProperties.getBrowserName();

        WebDriver driver1 = null;
        if (ConfigConstants.enableRemote) {
            System.out.println("Running in Remote Mode");
            WebDriver driverRemote = null;
            try {
                driverRemote = new RemoteWebDriver(new URL(ConfigConstants.HUB_URL), initializeDesiredCapability(BrowserMode));
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }


            // Initialize browser
          //  DesiredCapabilities caps = new DesiredCapabilities();
           // caps.setCapability(PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY,ConfigConstants.phontomjsLocation);
           // WebDriver driver = new PhantomJSDriver(caps);


            // Instantiate ngWebdriver
              ngWebDriver = new NgWebDriver((JavascriptExecutor) driverRemote);

            // ngWebDriver = new NgWebDriver(driverRemote);
            ngWebDriver.waitForAngular2RequestsToFinish();
            driver1 = driverRemote;
        } else {

            switch (browserName)
            {
                case CHROME:
                    System.setProperty(DRIVER_CONFIG_CHROME, CHROME_PATH);
                    DesiredCapabilities capabilities = DesiredCapabilities.chrome();
                    ChromeOptions options = new ChromeOptions();

                    if(BrowserMode.name().contentEquals(BrowserModeType.INCOGONITO.toString()))
                    {
                        options.addArguments(INCOGNITO_MODE);
                    }

                    options.addArguments(BROWSER_MAXIMIZE);

                    capabilities.setCapability(ChromeOptions.CAPABILITY, options);
                    //capabilities.setAcceptInsecureCerts(true);
                    //capabilities.setCapability (CapabilityType.ACCEPT_SSL_CERTS, true);

                    ChromeDriver chromeDriver = new ChromeDriver(capabilities);
                    chromeDriver.manage().timeouts().setScriptTimeout(25, TimeUnit.SECONDS);
                    // Instantiate ngWebdriver
                    ngWebDriver = new NgWebDriver(chromeDriver);
                    driver1 = chromeDriver;
                    break;
                case IE:
                    System.setProperty(DRIVER_CONFIG_IE,IE_PATH);
                    DesiredCapabilities capabilities_ie = DesiredCapabilities.internetExplorer();
                    InternetExplorerOptions IEOptions = new InternetExplorerOptions();
                    capabilities_ie.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, Boolean.TRUE);
                    capabilities_ie.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, Boolean.TRUE);
                  //  capabilities_ie.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
                  //  capabilities_ie.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, Configuration.getConfig("My URL"));


                    InternetExplorerDriver IEDriver = new InternetExplorerDriver(capabilities_ie);
                    IEDriver.manage().timeouts().setScriptTimeout(10, TimeUnit.SECONDS);
                    // Instantiate ngWebdriver
                    ngWebDriver = new NgWebDriver(IEDriver);
                    driver1 = IEDriver;
                    break;
                case FIREFOX:
                    System.setProperty(DRIVER_CONFIG_FIREFOX,FIREFOX_PATH);
                    DesiredCapabilities capabilities_firefox = DesiredCapabilities.firefox();
                    capabilities_firefox.setCapability(MARIONETTE, false);

                    if(BrowserMode.name().contentEquals(BrowserModeType.INCOGONITO.toString()))
                    {

                        ProfilesIni profile = new ProfilesIni();
                        FirefoxProfile ffProfile = profile.getProfile("default");
                        ffProfile.setPreference(PRIVATE_FIREFOX_MODE,true);
                        ffProfile.setAcceptUntrustedCertificates(true);
                        ffProfile.setAssumeUntrustedCertificateIssuer(false);
                        
                        ffProfile.setPreference("browser.download.dir", objProperties.getDownloadPath());
                		ffProfile.setPreference("browser.download.folderList", 2);
                		ffProfile.setPreference("browser.helperApps.neverAsk.saveToDisk",MIME_TYPES);
                		ffProfile.setPreference("browser.helperApps.neverAsk.openFile",MIME_TYPES);

                        capabilities_firefox.setCapability(FirefoxDriver.PROFILE,ffProfile);
                        System.out.println("In private mode");
                    } else {
                	    //Create FireFox Profile object
                		FirefoxProfile ffProfile = new FirefoxProfile();

                		//Set Location to store files after downloading.
                        ffProfile.setPreference("browser.download.dir", objProperties.getDownloadPath());
                		ffProfile.setPreference("browser.download.folderList", 2);
                		ffProfile.setPreference("browser.helperApps.neverAsk.saveToDisk",MIME_TYPES);
                		ffProfile.setPreference("browser.helperApps.neverAsk.openFile",MIME_TYPES);
                		
                		capabilities_firefox.setCapability(FirefoxDriver.PROFILE, ffProfile);
                    	
                    }


                    WebDriver fxDriver = new FirefoxDriver(capabilities_firefox);
                    fxDriver.manage().timeouts().setScriptTimeout(10,TimeUnit.SECONDS);
                    // Instantiate ngWebdriver
                    ngWebDriver = new NgWebDriver((JavascriptExecutor) fxDriver);
                    driver1 = fxDriver;
                    break;
            }
        }
        return driver1;
    }

    public static void tearDown() {
        driver.quit();
    }

    public static WebDriver getDriver() {
        return driver;
    }

    public static NgWebDriver getNGWebDriver() {
        return ngWebDriver;
    }

    public static void WaitForAngular2Finish()
    {
        ngWebDriver.waitForAngular2RequestsToFinish();
    }

    private static DesiredCapabilities initializeDesiredCapability(BrowserModeType browserMode) {
        DesiredCapabilities capabilities = new DesiredCapabilities();

        switch (browserName)
        {
            case CHROME:
                if(browserMode.toString().contentEquals(BrowserModeType.INCOGONITO.toString()))
                    capabilities.setCapability("chrome.switches", Arrays.asList(INCOGNITO_MODE));

                capabilities.setAcceptInsecureCerts(true);
                capabilities.setCapability (CapabilityType.ACCEPT_SSL_CERTS, true);
                break;
            case FIREFOX:
                if(browserMode.name().contentEquals(BrowserModeType.INCOGONITO.toString()))
                {
                    FirefoxProfile fp = new FirefoxProfile();
                    fp.setPreference(PRIVATE_FIREFOX_MODE, true);
                }
                break;
        }

        capabilities.setCapability(CapabilityType.BROWSER_NAME, browserName);
        capabilities.setCapability(CapabilityType.VERSION, objProperties.getBrowserVersion());
        capabilities.setCapability(CapabilityType.PLATFORM, objProperties.getOSName());

        capabilities.setCapability("name", objProperties.getname());//scenarioName
        capabilities.setCapability("username", objProperties.getUsername());
        capabilities.setCapability("access-key", objProperties.getAccesskey());
        capabilities.setCapability("tunnel-identifier", objProperties.getTunnelId());
        capabilities.setCapability("parent-tunnel", objProperties.getparentTunnelId());
        capabilities.setCapability("build", objProperties.getbuildId());
        // capabilities.setCapability("javascriptEnabled", true);

        capabilities.setCapability("seleniumVersion", objProperties.getSeleniumVersion());//Desired Selenium Version
        capabilities.setJavascriptEnabled(true);

        capabilities.setCapability("command-timeout", 600);
        capabilities.setCapability("idle-timeout", 1000);

        // Additional settings to help debugging and improve job perf
        capabilities.setCapability("public", "share");
        capabilities.setCapability("webdriver.remote.quietExceptions", false);
        capabilities.setCapability("capture-html", true);
        capabilities.setCapability("video-upload-on-pass", false);

        System.setProperty("http.proxyHost", objProperties.getProxyHost());
        System.setProperty("http.proxyPort", objProperties.getproxyPort());
        
        if (FIREFOX.equalsIgnoreCase(browserName)) {
			FirefoxProfile ffProfile = new FirefoxProfile();
			ffProfile.setPreference("browser.download.dir", "C:\\\\temp");
			ffProfile.setPreference("browser.download.folderList", 2);
			ffProfile.setPreference("browser.download.manager.alertOnEXEOpen", false);
			ffProfile.setPreference("browser.helperApps.alwaysAsk.force", false);
			ffProfile.setPreference("browser.download.manager.showWhenStarting", false);
			ffProfile.setPreference("browser.download.manager.focusWhenStarting", false);
			ffProfile.setPreference("browser.download.useDownloadDir", true);
			ffProfile.setPreference("browser.download.manager.closeWhenDone", true);
			ffProfile.setPreference("browser.download.manager.showAlertOnComplete", false);
			ffProfile.setPreference("browser.download.manager.useWindow", false);
			ffProfile.setPreference("services.sync.prefs.sync.browser.download.manager.showWhenStarting", false);
    		ffProfile.setPreference("browser.download.panel.shown", false );
    		ffProfile.setPreference("browser.download.manager.alertOnEXEOpen", false );
			// Set Preference to not show file download confirmation dialogue
			// using MIME types Of different file extension types.
			ffProfile.setPreference("browser.helperApps.neverAsk.saveToDisk",
					"text/csv");
			capabilities.setCapability(FirefoxDriver.PROFILE, ffProfile);
        }


        return capabilities;
    }
}