package com.fanniemae.mbsportal.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

import com.fanniemae.mbsportal.utils.epv.EpvConnector;
import com.fanniemae.mbsportal.utils.exception.MBSBaseException;

@ImportResource(value = { "classpath*:*-client-gf-context.xml" })
public class DataAccessConfig {

    /**
     * 
     * appcode application code
     */
    @Value("${mbsp.appCd}")
    String appCode;
    
    /**
     * 
     * env identifies environment
     */
    @Value("${mbsp.envCd}")
    String env;
    
    /**
     * 
     * tsObjRefId identifies the trade service object reference id
     */
    @Value("${mbsp.epvRefId}")
    String tsObjRefId;

    /**
     * 
     * hold application wide variables to share
     * 
     * @return AppVault
     */
    @Bean
    public AppVault appVault() {
        AppVault appVault = new AppVault();
        System.out.println("Initializing appVault" + appVault.getTsAdminToken());
        return appVault;
    }

    /**
     * 
     * Returning the EpvConnector with initialization params
     * 
     * @return EpvConnector
     */
    @Bean
    @Profile({ "DEFAULT", "DEV1", "DEV2", "ACPT1", "ACPT2", "TEST1", "PROD1", "PROD2" })
    @Primary
    public EpvConnector epvConnector() {
        System.out.println(String.format("epvConnector initializing with appCode=%s env=%s tsObjRefId=%s", appCode, env,
                tsObjRefId));
        EpvConnector epvConnector = new EpvConnector();
        try {
            epvConnector.initialize(appCode, env, tsObjRefId);
        } catch (MBSBaseException e) {
        	System.out.println("epvConnector bean initialization failed " + e.getRootException());
        }

        System.out.println("epvConnector bean initialized");
        return epvConnector;
    }
	
}
