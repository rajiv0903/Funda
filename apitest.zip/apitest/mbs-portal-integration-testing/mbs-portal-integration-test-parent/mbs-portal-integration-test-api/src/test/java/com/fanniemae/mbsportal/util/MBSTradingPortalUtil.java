package com.fanniemae.mbsportal.util;

import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;
import java.util.TimeZone;

import org.json.JSONObject;

import com.fanniemae.mbsportal.framework.ExcelSheetData;
import com.fanniemae.mbsportal.framework.ExcelSheetParamEnum;

/**
 * 
 * @author Rajiv Chaudhuri
 * @Date Dec 8, 2017
 * @Time 3:14:56 PM com.fanniemae.mbsportal.util MBSTradingPortalUtil.java
 */
public class MBSTradingPortalUtil {

    public static final String TIME_ZONE_NYC = "America/New_York";
    public static final String DATE_TIME_FORMAT_UUUU_MM_DD_HH_MM_SS = "uuuu-MM-ddHH:mm:ss";
    public static final String DATE_FORMAT_NO_TIMESTAMP = "yyyy-MM-dd";

    static volatile Properties prop = null;

    public static String getDateFromServer(String date) throws Exception {
        SimpleDateFormat sdfDate = new SimpleDateFormat(MBSTradingPortalConstants.DATE_FORMAT_1);// dd/MM/yyyy
        Date startDate = sdfDate.parse(date);
        String currentDate = new SimpleDateFormat(MBSTradingPortalConstants.DATE_FORMAT_2).format(startDate);
        return currentDate;
    }

    public static String convertDateFormat(String date, String inFormat, String outFormat) throws Exception {
        return getLocalZonedDateTimeFromEpochMilli(getLocalDateCurrentTimeStampFromGivenDateTime(date, inFormat),
                outFormat);
    }

    public static String getCurrentDate() {
        return new SimpleDateFormat(MBSTradingPortalConstants.DATE_FORMAT_2).format(new Date());
    }

    public static synchronized void loadProps() throws Exception {
        if (prop == null) {
            prop = new Properties();
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            InputStream stream = loader.getResourceAsStream("config/config.properties");
            prop.load(stream);
        }
    }

    public static synchronized String getPropKey(String key) {
        return prop.getProperty(key);
    }

    /**
     * 
     * @param dateTime
     * @param formatter
     * @return
     * @throws Exception
     */
    public static long getLocalDateCurrentTimeStampFromGivenDateTime(String dateTime, String formatter)
            throws Exception {
        try {
            return LocalDateTime.parse(dateTime, DateTimeFormatter.ofPattern(formatter))
                    .atZone(ZoneId.of(TIME_ZONE_NYC)).toInstant().toEpochMilli();
        } catch (DateTimeException e) {
            return new SimpleDateFormat(formatter).parse(dateTime).getTime();
        }

    }

    /**
     * 
     * @return
     */
    public static long getLocalDateCurrentTimeStamp() {
        return LocalDateTime.now().atZone(ZoneId.of(TIME_ZONE_NYC)).toInstant().toEpochMilli();

    }

    /**
     * @param epochMilli
     * @param formatter
     * @return
     */
    public static String getLocalZonedDateTimeFromEpochMilli(Long epochMilli, String formatter) {
        try {
            Instant instant = Instant.ofEpochMilli(epochMilli);
            ZoneId zoneId = ZoneId.of(TIME_ZONE_NYC);
            ZonedDateTime zdt = ZonedDateTime.ofInstant(instant, zoneId);
            return zdt.format(DateTimeFormatter.ofPattern(formatter));
        } finally {

        }
    }

    public static String getCurrentDate(int timeToRemove, String format) {
        Date d = new Date(getLocalDateCurrentTimeStamp());
        Calendar c = Calendar.getInstance();
        // System.out.println(c.getTimeZone().getID() + " " +
        // getLocalZonedDateTimeFromEpochMilli(d.getTime(), format));
        if (!c.getTimeZone().equals(TimeZone.getTimeZone(ZoneId.of(TIME_ZONE_NYC)))) {
            c.setTime(d);
            c.add(Calendar.HOUR, 1);
        } else {
            c.setTime(d);
        }
        c.add(Calendar.DATE, timeToRemove);
        return getLocalZonedDateTimeFromEpochMilli(c.getTimeInMillis(), format);
    }

    /**
     * Validates two dates passed as formatted strings (assuming the dates have
     * the same format). Validates the date based on some spread (in seconds)
     * 
     * @param date1
     * @param date2
     * @param format
     * @param spread
     * @return
     * @throws Exception
     */
    public static boolean validateDate(String date1, String date2, String format, int spread) throws Exception {
        Long l = dateDiff(date1, date2, format);
        if (l > 3599L) { // remove an hour if there is an hour difference due to
                         // differing time zones. need to fix this properly
            l -= 3600L;
        }
        return l < spread;
    }

    /**
     * returns the number of seconds between the two dates.
     * 
     * @param date1
     * @param date2
     * @param format
     * @return
     * @throws Exception
     */
    public static long dateDiff(String date1, String date2, String format) throws Exception {
        DateFormat df = new SimpleDateFormat(format);
        Date d1 = df.parse(date1);
        Date d2 = df.parse(date2);
        return (Math.abs(d1.getTime() - d2.getTime()) / 1000L);
    }

    public static Object mapStateType(String stateType) {
        if (stateType == null)
            return "-";
        if (stateType.equals("LENDER_OPEN"))
            return "-"; // Trader submits the request for pricing
        if (stateType.equals("TRADER_PRICED"))
            return "-"; // Trader priced for lender request
        if (stateType.equals("TRADER_PASSED"))
            return "FM Passed"; // Trader passes the trade
        if (stateType.equals("TRADER_REPRICED"))
            return "-"; // Trader submits the request for re-pricing
        if (stateType.equals("LENDER_ACCEPTED"))
            return "-"; // Lender accepts the trade (hit/lift)
        if (stateType.equals("LENDER_REJECTED"))
            return "Cancelled"; // Lender rejects the trade (reject/cxl)
        if (stateType.equals("TRADER_CONFIRMED"))
            return "Accepted"; // Trader final acknowledgement after trader
                               // confirms
        if (stateType.equals("TRADER_REJECTED"))
            return "FM Cancelled"; // Rejected by Trader
        if (stateType.equals("EXECUTION_IN_PROGRESS"))
            return "Accepted"; // Intermediate state of trading
        if (stateType.equals("PENDING_EXECUTION"))
            return "Accepted"; // Send Successfully to Aladdin/TradeService
        if (stateType.equals("EXECUTED"))
            return "Accepted"; // Status after receiving acknowledgement from
                               // Aladdin/TradeService
        if (stateType.equals("LENDER_TIMEOUT"))
            return "Timed Out"; // The trade expires before the trader action
        if (stateType.equals("TRADER_TIMEOUT"))
            return "FM Timed Out"; // The trade expires before lender action
        if (stateType.equals("ERROR"))
            return "-";// Any error or exception scenario
        return null;
    }

    public static Date addDays(Date date, int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, days); // minus number would decrement the days
        return cal.getTime();
    }

    
    @SuppressWarnings("unchecked")
    public static JSONObject setProperty(String lookupKey, String valueNew, JSONObject jsonObj) throws Exception {
        if (jsonObj == null) {
            return jsonObj;
        }

        Iterator<String> keys = jsonObj.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            if (lookupKey.equalsIgnoreCase(key)) {
                jsonObj.put(lookupKey, valueNew);
                return jsonObj;
            }
            if (jsonObj.get(key) instanceof JSONObject) {
                if (jsonObj.get(key) != null) {
                    JSONObject xx = new JSONObject(jsonObj.get(key).toString());
                    jsonObj.put(key, setProperty(lookupKey, valueNew, xx)) ;
                }
            }
        }
        return jsonObj;
    }
    
    /**
     * It will replace the Excel Output value with value from config
     * @param excelData
     * @param jsonObj
     * @return
     * @throws Exception
     */
    public static JSONObject replaceExcelInputValueFromConfig(ExcelSheetData excelData, JSONObject jsonObj) throws Exception {
        if(excelData.getInputPropMap().containsValue(MBSTradingPortalConstants.REPLACE_PRODUCT_SOURCE_TYPE)){
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.sourceType.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_SOURCE_TYPE),jsonObj);
        }
        if(excelData.getInputPropMap().containsValue(MBSTradingPortalConstants.REPLACE_PRODUCT_TYPE)){
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.type.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_TYPE),jsonObj);
        }  
        if(excelData.getInputPropMap().containsValue(MBSTradingPortalConstants.REPLACE_PRODUCT_ID_0)){
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.identifier.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_ID_0),jsonObj);
        } 
        if(excelData.getInputPropMap().containsValue(MBSTradingPortalConstants.REPLACE_PRODUCT_COUPON_0)){
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.tradeCouponRate.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_COUPON_0),jsonObj);
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.passThroughRate.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_COUPON_0),jsonObj);
        } 
        if(excelData.getInputPropMap().containsValue(MBSTradingPortalConstants.REPLACE_PRODUCT_SETTLEMNET_DATE_0)){
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.tradeSettlementDate.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_SETTLEMNET_DATE_0),jsonObj);
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.settlementDate.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_SETTLEMNET_DATE_0),jsonObj);
        } 
        if(excelData.getInputPropMap().containsValue(MBSTradingPortalConstants.REPLACE_PRODUCT_ID_1)){
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.identifier.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_ID_1),jsonObj);
        } 
        if(excelData.getInputPropMap().containsValue(MBSTradingPortalConstants.REPLACE_PRODUCT_COUPON_1)){
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.tradeCouponRate.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_COUPON_1),jsonObj);
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.passThroughRate.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_COUPON_1),jsonObj);
        } 
        if(excelData.getInputPropMap().containsValue(MBSTradingPortalConstants.REPLACE_PRODUCT_SETTLEMNET_DATE_1)){
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.tradeSettlementDate.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_SETTLEMNET_DATE_1),jsonObj);
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.settlementDate.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_SETTLEMNET_DATE_1),jsonObj);
        } 
        if(excelData.getInputPropMap().containsValue(MBSTradingPortalConstants.REPLACE_PRODUCT_ID_2)){
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.identifier.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_ID_2),jsonObj);
        } 
        if(excelData.getInputPropMap().containsValue(MBSTradingPortalConstants.REPLACE_PRODUCT_COUPON_2)){
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.tradeCouponRate.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_COUPON_2),jsonObj);
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.passThroughRate.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_COUPON_2),jsonObj);
        } 
        if(excelData.getInputPropMap().containsValue(MBSTradingPortalConstants.REPLACE_PRODUCT_SETTLEMNET_DATE_2)){
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.tradeSettlementDate.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_SETTLEMNET_DATE_2),jsonObj);
            jsonObj = MBSTradingPortalUtil.
                    setProperty(ExcelSheetParamEnum.settlementDate.name(),  MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_SETTLEMNET_DATE_2),jsonObj);
        }
        return jsonObj;
    }
    
    /**
     * It will replace the Excel Output value with value from config
     * @param valueExcl
     * @return
     */
    public static String replaceExcelOutputValueFromConfig(String valueExcl) {
        
        if (valueExcl.contains(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_WITH_WRONG_FORMAT)) {
            valueExcl = valueExcl.replace(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_WITH_WRONG_FORMAT,
                        MBSTradingPortalUtil.getCurrentDate(0, MBSTradingPortalConstants.DATE_FORMAT_5));
        }
        if (valueExcl.contains(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_MINUS_400_WITH_WRONG_FORMAT)) {
            valueExcl = valueExcl.replace(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_MINUS_400_WITH_WRONG_FORMAT,
                    MBSTradingPortalUtil.getCurrentDate(-400, MBSTradingPortalConstants.DATE_FORMAT_5));
        } 
         
        if (valueExcl.contains(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_MINUS_30)) {
            valueExcl = valueExcl.replace(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_MINUS_30,
                    MBSTradingPortalUtil.getCurrentDate(-30, MBSTradingPortalConstants.DATE_FORMAT_2));
        }
        if (valueExcl.contains(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_PLUS_1)) {
            valueExcl = valueExcl.replace(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_PLUS_1,
                        MBSTradingPortalUtil.getCurrentDate(1, MBSTradingPortalConstants.DATE_FORMAT_2));               
        }
        if (valueExcl.contains(MBSTradingPortalConstants.REPLACE_CURRENT_DATE)) {
            valueExcl = valueExcl.replace(MBSTradingPortalConstants.REPLACE_CURRENT_DATE,
                    MBSTradingPortalUtil.getCurrentDate(0, MBSTradingPortalConstants.DATE_FORMAT_2));
        }
        if (valueExcl.contains(MBSTradingPortalConstants.REPLACE_PRODUCT_SOURCE_TYPE)) {
            valueExcl = valueExcl.replace(MBSTradingPortalConstants.REPLACE_PRODUCT_SOURCE_TYPE, MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_SOURCE_TYPE));
        }
        if (valueExcl.contains(MBSTradingPortalConstants.REPLACE_PRODUCT_TYPE)) {
            valueExcl = valueExcl.replace(MBSTradingPortalConstants.REPLACE_PRODUCT_TYPE, MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_TYPE));
        } 
        if (valueExcl.contains(MBSTradingPortalConstants.REPLACE_PRODUCT_ID_0)) {
            valueExcl = valueExcl.replace(MBSTradingPortalConstants.REPLACE_PRODUCT_ID_0, MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_ID_0));
        }
        if (valueExcl.contains(MBSTradingPortalConstants.REPLACE_PRODUCT_COUPON_0)) {
            valueExcl = valueExcl.replace(MBSTradingPortalConstants.REPLACE_PRODUCT_COUPON_0, MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_COUPON_0));
        }
        if (valueExcl.contains(MBSTradingPortalConstants.REPLACE_PRODUCT_SETTLEMNET_DATE_0)) {
            valueExcl = valueExcl.replace(MBSTradingPortalConstants.REPLACE_PRODUCT_SETTLEMNET_DATE_0, MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_SETTLEMNET_DATE_0));
        }
        if (valueExcl.contains(MBSTradingPortalConstants.REPLACE_PRODUCT_ID_1)) {
            valueExcl = valueExcl.replace(MBSTradingPortalConstants.REPLACE_PRODUCT_ID_1, MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_ID_1));
        }
        if (valueExcl.contains(MBSTradingPortalConstants.REPLACE_PRODUCT_COUPON_1)) {
            valueExcl = valueExcl.replace(MBSTradingPortalConstants.REPLACE_PRODUCT_COUPON_1, MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_COUPON_1));
        }
        if (valueExcl.contains(MBSTradingPortalConstants.REPLACE_PRODUCT_SETTLEMNET_DATE_1)) {
            valueExcl = valueExcl.replace(MBSTradingPortalConstants.REPLACE_PRODUCT_SETTLEMNET_DATE_1, MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_SETTLEMNET_DATE_1));
        }
        if (valueExcl.contains(MBSTradingPortalConstants.REPLACE_PRODUCT_ID_2)) {
            valueExcl = valueExcl.replace(MBSTradingPortalConstants.REPLACE_PRODUCT_ID_2, MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_ID_2));
        }
        if (valueExcl.contains(MBSTradingPortalConstants.REPLACE_PRODUCT_COUPON_2)) {
            valueExcl = valueExcl.replace(MBSTradingPortalConstants.REPLACE_PRODUCT_COUPON_2, MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_COUPON_2));
        }
        if (valueExcl.contains(MBSTradingPortalConstants.REPLACE_PRODUCT_SETTLEMNET_DATE_2)) {
            valueExcl = valueExcl.replace(MBSTradingPortalConstants.REPLACE_PRODUCT_SETTLEMNET_DATE_2, MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.MBSP_PRODUCT_SETTLEMNET_DATE_2));
        }
        return valueExcl;
    }


}
