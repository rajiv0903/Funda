package com.fanniemae.mbsportal.steps;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;

import com.fanniemae.mbsportal.model.MBSTrade;
import com.fanniemae.mbsportal.model.MBSTradingPortalBuilder;
import com.fanniemae.mbsportal.model.MBSTransactionRequest;
import com.fanniemae.mbsportal.util.MBSTradingPortalConstants;
import com.fanniemae.mbsportal.util.MBSTradingPortalUtil;
import com.fanniemae.mbsportal.util.StateType;

public class MBSTradingPortalHistoryValidator {

    public void compareTransactionHistoryWithDataFromGF(MBSTradingPortalBuilder builder) throws Throwable {
		Map<String, String> searchParams = builder.getModel().getExcelData().getInputPropMap();
		String mbsRoleType = searchParams.get("name");
    	JSONArray endpointData = builder.getModel().getResObjects();
    	List<?> gfData = builder.getModel().getGfObjects();
    	JSONObject response = builder.getModel().getLookUpObj();
//    	System.out.println("Endpoint Response: " + response);
    	System.out.println("Endpoint Data: " + endpointData);
    	System.out.println("GF Data: " + gfData);
     	Assert.assertEquals(endpointData.length(), gfData.size());
    	for (int i = 0; i < gfData.size(); i++) {
    		MBSTrade gfTrade = (MBSTrade) gfData.get(i);
    		MBSTransactionRequest gfObj = gfTrade.getTransReq();
    		JSONObject endpointObj = endpointData.getJSONObject(i);
//    		System.out.println("gemfire object " + gfTrade);
//    		System.out.println("endpoint object " + endpointObj);
    		Assert.assertEquals(gfObj.getTransReqNumber(), getJSONString(endpointObj,"transReqId"));
    		Assert.assertEquals(MBSTradingPortalUtil.getLocalZonedDateTimeFromEpochMilli(gfObj.getSubmissionDate().getTime(),MBSTradingPortalConstants.DATE_FORMAT_1), endpointObj.getString("submissionDate"));
    		Assert.assertEquals(gfObj.getDealerOrgName(), getJSONString(endpointObj,"lenderEntityName"));
    		Assert.assertEquals(gfObj.getTspShortName(), getJSONString(endpointObj,"tspShortName"));
    		Assert.assertEquals(gfTrade.getTradeDate() == null ? null : MBSTradingPortalUtil.getLocalZonedDateTimeFromEpochMilli(gfTrade.getTradeDate().getTime(),MBSTradingPortalConstants.DATE_FORMAT_2), getJSONString(endpointObj,"tradeDate"));
//    		Trade Date
    		Assert.assertEquals(getBuySell(mbsRoleType,gfObj), getJSONString(endpointObj,"tradeBuySellType"));
    		Assert.assertTrue(gfObj.getTradeAmount().compareTo(new BigDecimal(getJSONString(endpointObj,"tradeAmount") + "")) == 0);
    		if (gfObj.getProductNameCode() != null) {
    			Assert.assertEquals(gfObj.getProductNameCode(), getJSONString(endpointObj.getJSONObject("product"),"nameCode"));
    		}
    		Assert.assertTrue(gfObj.getTradeCouponRate().compareTo(new BigDecimal(getJSONString(endpointObj,"tradeCouponRate") + "")) == 0);
    		Assert.assertEquals(MBSTradingPortalUtil.getLocalZonedDateTimeFromEpochMilli(gfObj.getTradeSettlementDate().getTime(),MBSTradingPortalConstants.DATE_FORMAT_2), getJSONString(endpointObj,"tradeSettlementDate"));
    		Assert.assertEquals(gfObj.getPricePercentTicksText(), getPriceText(getJSONString(endpointObj,"pricePercentTicksText"), getJSONString(endpointObj,"pricePercentHandleText")));
    		Assert.assertEquals(getStatus(gfObj.getStateType()), getStatus(getJSONString(endpointObj,"stateType")));
    		Assert.assertEquals(gfTrade.getSourcePrimaryTradeId() + "", getJSONString(endpointObj,"tradeSrcPrimaryId"));
    		Assert.assertEquals(gfTrade.getSubPortfolioShortName(),  getJSONString(endpointObj,"tradeSubPortfolioShortName"));
    		Assert.assertEquals(gfObj.getCounterpartyTraderName(),invertName(getJSONString(endpointObj,"lenderName")));
    		Assert.assertEquals(gfObj.getTraderName(), invertName(getJSONString(endpointObj,"traderName")));
    	}
    }
	private String getPriceText(String ticks, String handle) {
		if (ticks == null || handle == null) {
			return null;
		}
		return ticks + "-" + handle;
	}

	private String getBuySell(String mbsRoleType, MBSTransactionRequest gfObj) {
		String buySell = "";
		if (!mbsRoleType.equals("TRADER")) {
			buySell = gfObj.getCounterPartyBuySellType();
		} else {
			buySell = gfObj.getTradeBuySellType();
		}
		return buySell;
	}

	private String getJSONString(JSONObject endpointObj, String key) {
		try {
			return endpointObj.getString(key);
		} catch (JSONException e) {
			return null;
		}
	}

	private String getStatus(String stateType) {
		StateType state = StateType.getEnum(stateType);
		return state.getDisplayName();
	}
	
	private String invertName(String name) {
		if (name == null) {
			return null;
		}
		if (StringUtils.isEmpty(name)) {
			return "";
		}
		String[] names = name.split(",");
		return names[1] + "," + names[0];
	}
	
}
