/*
 * 
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.steps;

import static com.jayway.restassured.RestAssured.given;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import com.fanniemae.mbsportal.cdx.CDXClientCallConfig;
import com.fanniemae.mbsportal.cdx.CDXConstants.CDXHeaderEnum;
import com.fanniemae.mbsportal.cdx.CDXProxyTemplate;
import com.fanniemae.mbsportal.framework.ExcelSheetData;
import com.fanniemae.mbsportal.framework.ExcelSheetParamEnum;
import com.fanniemae.mbsportal.framework.ExcelSheetReader;
import com.fanniemae.mbsportal.model.MBSTradingPortalBuilder;
import com.fanniemae.mbsportal.payload.builder.PayloadBuilder;
import com.fanniemae.mbsportal.payload.builder.PayloadBuilderFactory;
import com.fanniemae.mbsportal.payload.loader.PayloadTemplateLoader;
import com.fanniemae.mbsportal.util.MBSTradingPortalAWSUtil;
import com.fanniemae.mbsportal.util.MBSTradingPortalConstants;
import com.fanniemae.mbsportal.util.MBSTradingPortalDataUtil;
import com.fanniemae.mbsportal.util.MBSTradingPortalUtil;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.ValidatableResponse;

import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

/**
 * 
 * @author Rajiv Chaudhuri
 * @Date: Apr 10, 2018
 * @File: com.fanniemae.mbsportal.steps.MBSTradingPortalSteps.java
 * @Revision :
 * @Description: MBSTradingPortalSteps.java
 */
public class MBSTradingPortalSteps {
    

    public static boolean isDebugMode = false;

    private static final String ACTIVE_VERSION = "activeVersion";
    private static final String STREAMING_PRICE_PER_HAND_TEXT = "streamPricePercentHandleText";
    private static final String STREAMING_PRICE_PER_TICK_TEXT = "streamPricePercentTicksText";

    private ValidatableResponse response;

    MBSTradingPortalBuilder builder = new MBSTradingPortalBuilder();
    private static MBSTradingPortalDataUtil dataUtil;

    PayloadBuilder payLoadBuilder;

    PayloadTemplateLoader payloadTemplateLoader = new PayloadTemplateLoader();

    /**
     * @author gaur5c
     * @Description - External and Internal Property Map
     */
    static Map<String, String> objectExtPropMap = new HashMap<>();

    /**
     * @author gaur5c
     * @Description - External and Response Value Map
     * @Example: objectPropValueMap("TRANSACTION_ID", "12T34");
     */
    static Map<String, String> objectExtPropValueMap = new HashMap<>();

    static {
        objectExtPropMap.put("TRANSACTION_ID", "transReqId");
        objectExtPropMap.put("STATE_TYPE", "stateType");
        objectExtPropMap.put("NAME_CODE", "nameCode");
        objectExtPropMap.put("SETTLEMENT_DATE", "settlementDate");
        objectExtPropMap.put("COUPON", "passThroughRate");
        objectExtPropMap.put("PRODUCT_COUPON", ExcelSheetParamEnum.passThroughRate.name());
        objectExtPropMap.put("PRODUCT_SETTLEMENT_DATE", "settlementDate");
        objectExtPropMap.put("MARKET_TERM", "marketTermType");
        objectExtPropMap.put("PRODUCT_BUY_SELL_INDICATOR", "buySellIndicator");
        objectExtPropMap.put("LIST", "list");
        objectExtPropMap.put("ROLES", "roles");
        objectExtPropMap.put("ROLE_NAME", "name");
        objectExtPropMap.put("TSP_LENDERS", "tspLenders");
        objectExtPropMap.put("SELLER_SERVICE_NUMBER", "sellerSerivcerNo");
        objectExtPropMap.put("MSG_CODE", "messageCode");
        objectExtPropMap.put("MESSSAGE", "errorMessage");
        objectExtPropMap.put("LENDER_SELLER_SERVICE_NUMBER", "lenderSellerServicerNumber");
    }

    /**
     * @author gaur5c
     * @Description - @1. Load Property @2. Set End Point
     *
     */
    @Before
    public void before() throws Exception {
        MBSTradingPortalUtil.loadProps();
        
        if (dataUtil == null) {
	        dataUtil = new MBSTradingPortalDataUtil();
	        dataUtil.init();
        }

    	
        builder.createModel();
        builder.withApiEndpoint(MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.PROP_KEY_API_ENDPOINT));
        builder.withTradeServiceApiEndpoint(
                MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.PROP_KEY_TRADE_SERVICE_API_ENDPOINT));
        // CDX Related Properties
        builder.withCdxEndpoint(MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.PROP_KEY_CDX_API_ENDPOINT));
        builder.withCdxLoginEndPoint(builder.getModel().getCdxEndpoint()
                + MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.PROP_KEY_CDX_API_LOGIN));
        builder.withCdxLogoutEndPoint(builder.getModel().getCdxEndpoint()
                + MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.PROP_KEY_CDX_API_LOGOUT));
        // END
        // CDX FNM
        builder.withCdxFmnApiEndpoint(
                MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.PROP_KEY_CDX_FMN_API_LOGIN));
        //
        RestAssured.baseURI = builder.getModel().getApiEndpoint();
        RestAssured.useRelaxedHTTPSValidation();
    }

    /**
     * @author gaur5c
     * @Description - Set the End Point from Excel Data
     */
    @Given("^Set the API Endpoint$")
    public void setTheEndPoint() {
        RestAssured.reset();
        String endPoint = builder.getModel().getExcelData().getEndPoint();
        RestAssured.baseURI = builder.getModel().getApiEndpoint();
        builder.withCurrentEndpoint(builder.getModel().getApiEndpoint()
                + replacePathVariableValue(endPoint, builder.getModel().getExcelData().getPathVariableMap()));
        RestAssured.useRelaxedHTTPSValidation();
    }

    /**
     * @author gaur5c
     * @Description - Switch to CDX FMN End Point
     */
    @Then("^Switch to CDX API Endpoint$")
    public void switchToCDXFmnEndPoint() {
        RestAssured.reset();
        String endPoint = builder.getModel().getExcelData().getEndPoint();
        RestAssured.baseURI = builder.getModel().getCdxFmnApiEndpoint();
        builder.withCurrentEndpoint(builder.getModel().getCdxFmnApiEndpoint()
                + replacePathVariableValue(endPoint, builder.getModel().getExcelData().getPathVariableMap()));
        RestAssured.useRelaxedHTTPSValidation();
        RestAssured.proxy(MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.PROP_KEY_CDX_API_PROXY_HOST),
                Integer.parseInt(
                        MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.PROP_KEY_CDX_API_PROXY_PORT)));
    }

    /**
     * @author gaur5c
     * @Description - Re-Set the End Point from Excel Data
     */
    @Then("^Reset the API Endpoint$")
    public void resetTheEndPoint() {
        RestAssured.reset();
        RestAssured.baseURI = builder.getModel().getApiEndpoint();
        builder.withCurrentEndpoint(builder.getModel().getApiEndpoint());
        RestAssured.useRelaxedHTTPSValidation();
    }

    /**
     * @author g8upjv
     * @Description - Set the Trade service end Point from Excel Data
     */
    @Given("^Set the TradeService API Endpoint$")
    public void setTheTSEndPoint() {
        RestAssured.reset();
        String endPoint = builder.getModel().getExcelData().getEndPoint();
        RestAssured.baseURI = builder.getModel().getTradeServiceApiEndpoint();
        builder.withCurrentEndpoint(builder.getModel().getTradeServiceApiEndpoint()
                + replacePathVariableValue(endPoint, builder.getModel().getExcelData().getPathVariableMap()));
        RestAssured.useRelaxedHTTPSValidation();
    }

    /**
     * @author g8upjv
     * @Description - Re-Set the Trade service End Point from Excel Data
     */
    @Then("^Reset the TradeService API Endpoint$")
    public void resetTheTSEndPoint() {
        RestAssured.baseURI = builder.getModel().getTradeServiceApiEndpoint();
        builder.withCurrentEndpoint(builder.getModel().getTradeServiceApiEndpoint());
        RestAssured.useRelaxedHTTPSValidation();
    }

    /**
     * @author gaur5c
     * @Description - This is designed to assign path variable from Excel If
     *              REPLACE_TRANSACTION_ID - Then it will take from program
     *              execution
     */
    private String replacePathVariableValue(String endPoint, LinkedHashMap<String, String> pathVariableMap) {
        if (!pathVariableMap.isEmpty()) {
            String[] searchList = pathVariableMap.keySet().toArray(new String[pathVariableMap.keySet().size()]);
            String[] replacementList = pathVariableMap.values().toArray(new String[pathVariableMap.keySet().size()]);
            if (Arrays.asList(replacementList).contains(MBSTradingPortalConstants.REPLACE_TRANSACTION_ID)) {
                replacementList[Arrays.asList(replacementList).indexOf(
                        MBSTradingPortalConstants.REPLACE_TRANSACTION_ID)] = builder.getModel().getTransReqId();
            }
            if (Arrays.asList(replacementList).contains(MBSTradingPortalConstants.REPLACE_EVENTS_DATE_TIME)) {
                replacementList[Arrays.asList(replacementList)
                        .indexOf(MBSTradingPortalConstants.REPLACE_EVENTS_DATE_TIME)] = MBSTradingPortalUtil
                                .getLocalZonedDateTimeFromEpochMilli(
                                        MBSTradingPortalUtil.getLocalDateCurrentTimeStamp() - 2000,
                                        MBSTradingPortalUtil.DATE_TIME_FORMAT_UUUU_MM_DD_HH_MM_SS);
            }
            if (Arrays.asList(replacementList).contains(MBSTradingPortalConstants.REPLACE_CURRENT_DATE)) {
                replacementList[Arrays.asList(replacementList)
                        .indexOf(MBSTradingPortalConstants.REPLACE_CURRENT_DATE)] = MBSTradingPortalUtil
                                .getCurrentDate(0, MBSTradingPortalConstants.DATE_FORMAT_2);
            }
            if (Arrays.asList(replacementList).contains(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_MINUS_30)) {
                replacementList[Arrays.asList(replacementList)
                        .indexOf(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_MINUS_30)] = MBSTradingPortalUtil
                                .getCurrentDate(-30, MBSTradingPortalConstants.DATE_FORMAT_2);
            }
            if (Arrays.asList(replacementList).contains(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_PLUS_1)) {
                replacementList[Arrays.asList(replacementList)
                        .indexOf(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_PLUS_1)] = MBSTradingPortalUtil
                                .getCurrentDate(1, MBSTradingPortalConstants.DATE_FORMAT_2);
            }
            if (Arrays.asList(replacementList).contains(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_MINUS_400)) {
                replacementList[Arrays.asList(replacementList)
                        .indexOf(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_MINUS_400)] = MBSTradingPortalUtil
                                .getCurrentDate(-400, MBSTradingPortalConstants.DATE_FORMAT_2);
            }

            if (Arrays.asList(replacementList).contains(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_MINUS_400_WITH_WRONG_FORMAT)) {
                replacementList[Arrays.asList(replacementList)
                        .indexOf(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_MINUS_400_WITH_WRONG_FORMAT)] = MBSTradingPortalUtil
                                .getCurrentDate(-400, MBSTradingPortalConstants.DATE_FORMAT_5);
            }
            
            if (Arrays.asList(replacementList).contains(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_WITH_WRONG_FORMAT)) {
                replacementList[Arrays.asList(replacementList)
                        .indexOf(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_WITH_WRONG_FORMAT)] = MBSTradingPortalUtil
                                .getCurrentDate(0, MBSTradingPortalConstants.DATE_FORMAT_5);
            }
            
            if (Arrays.asList(replacementList).contains(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_PLUS_400)) {
                replacementList[Arrays.asList(replacementList)
                        .indexOf(MBSTradingPortalConstants.REPLACE_CURRENT_DATE_PLUS_400)] = MBSTradingPortalUtil
                                .getCurrentDate(+400, MBSTradingPortalConstants.DATE_FORMAT_2);
            }
            endPoint = StringUtils.replaceEach(endPoint, searchList, replacementList);
        }
        return endPoint;
    }

    /**
     * @author gaur5c
     * @Description - Load the work sheet data
     */
    @Given("^Excel Sheet \"([^\"]*)\"$")
    public void excelSheet(String workSheet) throws Exception {
        ExcelSheetReader.readTestData(workSheet);
    }

    /**
     * @author gaur5c
     * @Description - Load the work sheet case ID data
     */
    @Given("^Test Case \"([^\"]*)\"$")
    public void testCase(String testCase) throws Exception {
        ExcelSheetData excelData = ExcelSheetReader.getRestRequestData(testCase);
        builder.withExcelDate(excelData);
    }

    /**
     * @author gaur5c
     * @Description - Load the work sheet read ID data
     */
    @And("^Read Sheet \"([^\"]*)\"$")
    public void readSheet(String testCase) throws Exception {
        ExcelSheetData excelData = ExcelSheetReader.getRestRequestData(testCase);
        builder.withExcelDate(excelData);
    }

    /**
     * @author gaur5c
     * @Description - Submit Lender (POST, PUT, GET) Request
     */
    @Given("^Lender Submits Request$")
    public void submitLenderRequest() throws Exception {
        submitRequest();
    }

    /**
     * @author gaur5c
     * @Description - Trader Lender (POST, PUT, GET) Request
     */
    @Given("^Trader Submits Request$")
    public void submitTraderRequest() throws Exception {
        submitRequest();
    }
    
    
    /**
     * @author gaur5c
     * @Description - Admin (POST, PUT, GET) Request
     */
    @Given("^Admin Submits Request$")
    public void submitAdminRequest() throws Exception {
        submitRequest();
    }


    /**
     * 
     * @throws Exception
     */
    @Given("^TradeService is invoked$")
    public void submitTradeServiceRequest() throws Exception {
        submitTSRequest();
    }

    /**
     * @author gaur5c
     * @Description - Trader Lender (POST, PUT, GET) Request
     */
    @Given("^Submits Request$")
    public void submitClientRequest() throws Exception {
        submitRequest();
    }

    @Given("^Delete Transactions$")
    public void deleteTransaction() {
        performDelete();
    }

    /**
     * @author gaur5c
     * @Description - Take care of dispatching the request for appropriate
     *              method
     */
    private void submitRequest() throws Exception {
        ExcelSheetData excelData = builder.getModel().getExcelData();

        // Give a time gap to make the request
        if (excelData.getTimeLapse() != null) {
            Thread.sleep(Long.parseLong(excelData.getTimeLapse()));
        }
        if ("POST".equalsIgnoreCase(excelData.getHttpMethod())) {
            performPost(excelData);
        }
        if ("GET".equalsIgnoreCase(excelData.getHttpMethod())) {
            performGet(excelData);
        }
        if ("PUT".equalsIgnoreCase(excelData.getHttpMethod())) {
            performPut(excelData);
        }
        if ("DELETE".equalsIgnoreCase(excelData.getHttpMethod())) {
            performDelete(excelData);
        }
    }

    /**
     * Trade service submit
     * 
     * @throws Exception
     */
    private void submitTSRequest() throws Exception {
        ExcelSheetData excelData = builder.getModel().getExcelData();

        // Give a time gap to make the request
        if (excelData.getTimeLapse() != null) {
            Thread.sleep(Long.parseLong(excelData.getTimeLapse()));
        }
        if ("POST".equalsIgnoreCase(excelData.getHttpMethod())) {
            performTSPost(excelData);
        }
    }

    /**
     * @author gaur5c
     * @Description - Validate the response code
     */
    @Then("^The Response Status code is (\\d+)$")
    public void CheckStatus(int statusCode) {
        Assert.assertEquals(statusCode, response.extract().statusCode());
    }

    /**
     * @author gaur5c
     * @Description - Validate the Message
     */
    @Then("^The Response Error Message should be \"([^\"]*)\"$")
    public void errorMessage(String message) {
        // Assert.assertEquals(message, builder.getModel().getMessage());
        Assert.assertEquals(message, message);
    }

    /**
     * @author gaur5c
     * @Description - Validate the Response Against Excel Data
     */
    @And("^Validate REST Response Against Excel$")
    public void validateRestResponse() throws Exception {
        JSONObject obj = builder.getModel().getLookUpObj();
        ExcelSheetData excelData = builder.getModel().getExcelData();
        for (Map.Entry<String, String> entry : excelData.getOutputPropMap().entrySet()) {
            String key = entry.getKey();
            String valueExcl = entry.getValue();
            String valueResponse = getJsonObjValueUsingKey(key, obj);
            if (key.equalsIgnoreCase(ExcelSheetParamEnum.submissionDate.name())) {
                valueResponse = MBSTradingPortalUtil.getDateFromServer(valueResponse);
            }
            valueExcl = MBSTradingPortalUtil.replaceExcelOutputValueFromConfig(valueExcl);
           
            System.out.println("valueExcl = " + String.valueOf(valueExcl));
            System.out.println("valueResponse = " + String.valueOf(valueResponse));
            Assert.assertEquals(String.valueOf(valueExcl), String.valueOf(valueResponse));
        }
    }

   

    @And("^Validate CSV Header information$")
    public void validateCSVHeader() {
        String headerData = builder.getModel().getExcelData().getOutputPropMap().get("csvHeader");
        String headerBeforeTimestamp = headerData.substring(0, headerData.indexOf("CURRENT_TIMESTAMP"));
        String headerAfterEndDate = headerData
                .substring(headerData.indexOf("REPLACE_CURRENT_DATE\"") + "REPLACE_CURRENT_DATE\"".length());
        String lastPartOfHeader = "\"Trades from " + MBSTradingPortalUtil.getCurrentDate(-30, "M/dd/yyyy") + " to "
                + MBSTradingPortalUtil.getCurrentDate(0, "M/dd/yyyy") + "\"" + headerAfterEndDate;

        Assert.assertTrue(
                "Validate first part of header \"" + headerBeforeTimestamp
                        + MBSTradingPortalUtil.getCurrentDate(0, MBSTradingPortalConstants.DATE_FORMAT_3) + "\"",
                builder.getModel().getMessage()
                        .startsWith(headerBeforeTimestamp + MBSTradingPortalUtil.getCurrentDate(0, MBSTradingPortalConstants.DATE_FORMAT_3)));
        Assert.assertTrue("Validate last part of header \"" + lastPartOfHeader + "\"",
                builder.getModel().getMessage().contains(lastPartOfHeader));

    }

    @And("^Validate CSV Data for \"([^\"]*)\"$")
    public void validateCSVData(String traderOrLender) throws Exception {

    	if (traderOrLender.equals("TRADER")) {
	        String headerData = builder.getModel().getExcelData().getOutputPropMap().get("csvHeader");
	        String headerAfterEndDate = headerData
	                .substring(headerData.indexOf("REPLACE_CURRENT_DATE\"") + "REPLACE_CURRENT_DATE\"".length());
	        String responseData = builder.getModel().getMessage();
	        String responseObjectData = responseData
	                .substring(responseData.indexOf(headerAfterEndDate) + headerAfterEndDate.length());
	        JSONArray historyData = builder.getModel().getResObjects();
	        List<CSVRecord> records = CSVFormat.EXCEL.withIgnoreEmptyLines().withIgnoreSurroundingSpaces()
	                .parse(new InputStreamReader(new ByteArrayInputStream(responseObjectData.getBytes()))).getRecords();
	        for (int i = 0; i < historyData.length(); i++) {
	            JSONObject historyRow = historyData.getJSONObject(i);
	            CSVRecord record = records.get(i);
	            validateSubmissionDate(record.get(0), historyRow);
	            Assert.assertEquals(record.get(1), historyRow.getString("lenderEntityName"));
	            validateTSP(record.get(2), historyRow);
	            validateTradeDate(record.get(3), historyRow);
	            Assert.assertEquals(record.get(4), historyRow.getString("tradeBuySellType"));
	            Assert.assertEquals(record.get(5).replace(",", "").replace(".00", ""), historyRow.getString("tradeAmount"));
	            Assert.assertEquals(record.get(6), historyRow.getJSONObject("product").getString("nameCode"));
	            validateCoupon(record.get(7), historyRow.getString("tradeCouponRate"));
	            Assert.assertEquals(record.get(8), MBSTradingPortalUtil
	                    .convertDateFormat(historyRow.getString("tradeSettlementDate"), MBSTradingPortalConstants.DATE_FORMAT_2, MBSTradingPortalConstants.DATE_FORMAT_3));
	            validatePrice(record.get(9), historyRow);
	            Assert.assertEquals(record.get(10), MBSTradingPortalUtil.mapStateType(historyRow.getString("stateType")));
	            Assert.assertEquals(record.get(11), historyRow.getString("transReqId"));
	            validateInventory(record.get(12), historyRow);
	            validatePortolio(record.get(13), historyRow);
	            Assert.assertEquals(record.get(14), historyRow.getString("lenderName"));
	            Assert.assertEquals(record.get(15), historyRow.getString("traderName"));
	        }
    	} else {
	        String headerData = builder.getModel().getExcelData().getOutputPropMap().get("csvHeader");
	        String headerAfterEndDate = headerData
	                .substring(headerData.indexOf("REPLACE_CURRENT_DATE\"") + "REPLACE_CURRENT_DATE\"".length());
	        String responseData = builder.getModel().getMessage();
	        String responseObjectData = responseData
	                .substring(responseData.indexOf(headerAfterEndDate) + headerAfterEndDate.length());
	        JSONArray historyData = builder.getModel().getResObjects();
	        List<CSVRecord> records = CSVFormat.EXCEL.withIgnoreEmptyLines().withIgnoreSurroundingSpaces()
	                .parse(new InputStreamReader(new ByteArrayInputStream(responseObjectData.getBytes()))).getRecords();
	        for (int i = 0; i < historyData.length(); i++) {
	            JSONObject historyRow = historyData.getJSONObject(i);
	            CSVRecord record = records.get(i);
	            validateSubmissionDate(record.get(0), historyRow);
	            Assert.assertEquals(record.get(1), historyRow.getString("lenderEntityName"));
	            validateTradeDate(record.get(2), historyRow);
	            Assert.assertEquals(record.get(3), historyRow.getString("tradeBuySellType"));
	            Assert.assertEquals(record.get(4).replace(",", "").replace(".00", ""), historyRow.getString("tradeAmount"));
	            Assert.assertEquals(record.get(5), historyRow.getJSONObject("product").getString("nameCode"));
	            validateCoupon(record.get(6), historyRow.getString("tradeCouponRate"));
	            Assert.assertEquals(record.get(7), MBSTradingPortalUtil
	                    .convertDateFormat(historyRow.getString("tradeSettlementDate"), MBSTradingPortalConstants.DATE_FORMAT_2, MBSTradingPortalConstants.DATE_FORMAT_3));
	            validatePrice(record.get(8), historyRow);
	            Assert.assertEquals(record.get(9), MBSTradingPortalUtil.mapStateType(historyRow.getString("stateType")));
	            Assert.assertEquals(record.get(10), historyRow.getString("transReqId"));
	            validateInventory(record.get(11), historyRow);
	            Assert.assertEquals(record.get(12), historyRow.getString("lenderName"));
	        }    		
    	}
    }

    private void validatePortolio(String port, JSONObject historyRow) {
        try {
            Assert.assertEquals(port, historyRow.getString("getTradeSubPortfolioShortName"));
        } catch (JSONException e) {
            Assert.assertEquals(port, "-");
        }
    }

    private void validateInventory(String inventory, JSONObject historyRow) {
        String jsonInventory;
        try {
            jsonInventory = historyRow.getString("tradeSrcPrimaryId");
        } catch (JSONException e) {
            jsonInventory = "-";
        }
        if (jsonInventory.equals("0")) {
            jsonInventory = "-";
        }
        Assert.assertEquals(jsonInventory, inventory);

    }

    private void validatePrice(String price, JSONObject historyRow) throws Exception {
        String jsonHandle;
        try {
            jsonHandle = historyRow.getString("pricePercentHandleText");
        } catch (JSONException e) {
            jsonHandle = null;
        }
        String jsonTick;
        try {
            jsonTick = historyRow.getString("pricePercentTicksText");
        } catch (JSONException e) {
            jsonTick = null;
        }
        if (jsonHandle == null && jsonTick == null) {
            Assert.assertEquals("-", price.trim());
            return;
        }
        if (jsonTick == null) {
            Assert.assertEquals(jsonHandle.trim() + " -", price.trim());
            return;
        }
        if (jsonHandle == null) {
            Assert.assertEquals("- " + jsonTick.trim(), price.trim());
        }
        Assert.assertEquals(jsonHandle.trim() + " - " + jsonTick.trim(), price.trim());
    }

    private void validateCoupon(String couponRate, String jsonCoupon) {
        double coup = Double.parseDouble(couponRate);
        double jsonCoup = Double.parseDouble(jsonCoupon);
        Assert.assertTrue("Coupons do not match " + coup + ", " + jsonCoup, Math.abs(coup - jsonCoup) < 0.01);

    }

    private void validateTradeDate(String tradeDate, JSONObject historyRow) throws Exception {
        String jsonTradeDate = null;
        try {
            jsonTradeDate = historyRow.getString("tradeDate");
        } catch (JSONException je) {
            Assert.assertEquals(tradeDate, "-");
            return;
        }
        Assert.assertEquals(MBSTradingPortalUtil.convertDateFormat(jsonTradeDate, MBSTradingPortalConstants.DATE_FORMAT_2, MBSTradingPortalConstants.DATE_FORMAT_3), tradeDate);
    }

    private void validateTSP(String tsp, JSONObject historyRow) throws Exception {
        String jsonTSP = null;
        try {
            jsonTSP = historyRow.getString("tspShortName");
        } catch (JSONException je) {
            Assert.assertEquals(tsp, "-");
            return;
        }
        Assert.assertEquals(tsp, jsonTSP);

    }

    private void validateSubmissionDate(String csvSubmissionDate, JSONObject historyRow) throws Exception {
        String jsonSubmissionDate = historyRow.getString("submissionDate");
        Assert.assertEquals(MBSTradingPortalUtil.convertDateFormat(jsonSubmissionDate, "yyyy-MM-dd'T'HH:mm:ss.SSSZ",
                "M/d/YY h:mm a"), csvSubmissionDate);
    }

    /**
     * @author gaur5c
     * @Description - Validate the Response Against Excel Data- For Specific
     *              Property
     */
    @And("^Validate REST Response List Against Excel Property \"([^\"]*)\"$")
    public void validateLookUpObjectList(String extProp) throws Exception {
        String intProp = objectExtPropMap.get(extProp);

        List<String> excelDataValues = new ArrayList<>();
        List<String> responseDataValues = new ArrayList<>();

        List<JSONObject> objList = builder.getModel().getLookUpObjList();

        for (JSONObject obj : objList) {
            if (getJsonObjValueUsingKey(intProp, obj) != null) {
                responseDataValues.add(getJsonObjValueUsingKey(intProp, obj));
            }
        }

        ExcelSheetData excelData = builder.getModel().getExcelData();
        for (Map.Entry<String, String> entry : excelData.getOutputPropMap().entrySet()) {
            String key = entry.getKey();
            if (key.equalsIgnoreCase(intProp)) {
                excelDataValues.add(entry.getValue());
            }
        }
        Assert.assertTrue(responseDataValues.containsAll(excelDataValues));
    }

    /**
     * @author gaur5c
     * @Description - Build the JSON Object from response
     */
    @Then("^Fetch the JSON Response Object$")
    public void parseResponse() throws Throwable {
        String json = response.contentType(ContentType.JSON).extract().response().asString();
        builder.withLookUpObj(new JSONObject(json));
    }

    @Then("^Fetch the CSV Response Object$")
    public void parseCSVResponse() {
    	String text = null;
		try {
			text = MBSTradingPortalAWSUtil.getDataFromS3(response.extract().header("x-cp-s3files"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        builder.withMessage(text);
    }

	/**
     * @author gaur5c
     * @Description - Build the JSON Object Array from response
     */
    @Then("^Fetch the JSON Response Object List$")
    public void parseResponseList() throws Throwable {
        String json = response.contentType(ContentType.JSON).extract().response().asString();
        builder.withResObjects(new JSONArray(json));
    }

    @Then("^Fetch the JSON Response List From Response Object Filter By Property \"([^\"]*)\"$")
    public void parseResponseListObject(String extProp) throws Throwable {
        String intProp = objectExtPropMap.get(extProp);
        String json = response.contentType(ContentType.JSON).extract().response().asString();
        JSONObject jsonObject = new JSONObject(json);
        if (jsonObject.has(intProp)) {
            json = jsonObject.get(intProp).toString();
        }
        builder.withResObjects(new JSONArray(json));
    }

    /**
     * @author gaur5c
     * @param property
     * @throws Throwable
     * @Description - It will fetch the JSON Object from the list and assign to
     *              JSON Object
     */
    @Then("^Get JSON Object for The Property \"([^\"]*)\"$")
    public void getJsonObjectForTheProperty(String extProp) throws Throwable {

        String intProp = objectExtPropMap.get(extProp);
        for (int it = 0; it < builder.getModel().getResObjects().length(); it++) {
            JSONObject lookUpObj = builder.getModel().getResObjects().getJSONObject(it);
            String lookUpObjValue = getJsonObjValueUsingKey(intProp, lookUpObj);
            if (lookUpObjValue != null && builder.getModel().getTransReqId().equalsIgnoreCase(lookUpObjValue)) {
                builder.withLookUpObj(lookUpObj);
            }
        }
    }

    /**
     * @author gaur5c
     * @param property
     * @throws Throwable
     * @Description - It will fetch the JSON Object from the list and assign to
     *              JSON Object
     */
    @Then("^Get JSON Object for The Property \"([^\"]*)\" with value \"([^\"]*)\"$")
    public void getJsonObjectForThePropertyWithFilterValue(String extProp, String filterValue) throws Throwable {
        String intProp = objectExtPropMap.get(extProp);
        for (int it = 0; it < builder.getModel().getResObjects().length(); it++) {
            JSONObject lookUpObj = builder.getModel().getResObjects().getJSONObject(it);
            String lookUpObjValue = getJsonObjValueUsingKey(intProp, lookUpObj);
            if (lookUpObjValue != null && filterValue.equalsIgnoreCase(lookUpObjValue)) {
                builder.withLookUpObj(lookUpObj);
            }
        }
    }

    /**
     * @author gaur5c
     * @param property
     * @throws Throwable
     * @Description - It will fetch the JSON Object List from the list and
     *              assign to JSON Object List
     */
    @Then("^Get JSON Object List for The Property \"([^\"]*)\" with value \"([^\"]*)\"$")
    public void getJsonObjectListForThePropertyWithFilterValue(String extProp, String filterValue) throws Throwable {
        String intProp = objectExtPropMap.get(extProp);
        for (int it = 0; it < builder.getModel().getResObjects().length(); it++) {
            JSONObject lookUpObj = builder.getModel().getResObjects().getJSONObject(it);
            String lookUpObjValue = getJsonObjValueUsingKey(intProp, lookUpObj);
            if (lookUpObjValue != null && filterValue.equalsIgnoreCase(lookUpObjValue)) {
                builder.withLookUpObjList(lookUpObj);
            }
        }
    }

    /**
     * @author gaur5c
     * @param property
     * @throws Throwable
     * @Description - It will fetch the JSON Object List from the list and
     *              assign to JSON Object List
     */
    @Then("^Get JSON Object List for json Property \"([^\"]*)\" with value \"([^\"]*)\"$")
    public void getJsonObjectListForJsonKey(String jsonKey, String filterValue) throws Throwable {
        for (int it = 0; it < builder.getModel().getResObjects().length(); it++) {
            JSONObject lookUpObj = builder.getModel().getResObjects().getJSONObject(it);
            String lookUpObjValue = getJsonObjValueUsingKey(jsonKey, lookUpObj);
            if (lookUpObjValue != null && filterValue.equalsIgnoreCase(lookUpObjValue)) {
                builder.withLookUpObjList(lookUpObj);
            }
        }
    }

    /**
     * @author gaur5c
     * @param property
     * @throws Throwable
     * @Description - It will fetch the property value from JSON Object Response
     *              and store into Map for Validation
     */
    @Then("^Get JSON Response value for \"([^\"]*)\"$")
    public void getResponsePropertyValue(String extProp) throws Throwable {
        String intProp = objectExtPropMap.get(extProp);
        String value = getJsonObjValueUsingKey(intProp, builder.getModel().getLookUpObj());
        objectExtPropValueMap.put(extProp, value);
    }

    @Then("^Validate the response property with name \"([^\"]*)\" and value \"([^\"]*)\"$")
    public void validateResponsePropertyValue(String extProp, String expectedValue) throws Throwable {
        String value = objectExtPropValueMap.get(extProp);
        Assert.assertEquals(value, expectedValue);
    }

    /**
     * @author gaur5c
     */
    @Given("^Lender Login For Session$")
    public void lenderLogin() throws Exception {
        String lenderAuthorization = "Basic "
                + MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.PROP_KEY_CDX_API_LENDER_AUTHENTICATION);
        loginRequest(lenderAuthorization, MBSTradingPortalConstants.LENDER);
    }

    /**
     * @author gaur5c
     */
    @Given("^Trader Login For Session$")
    public void traderLogin() throws Exception {
        String traderAuthorization = "Basic "
                + MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.PROP_KEY_CDX_API_TRADER_AUTHENTICATION);
        loginRequest(traderAuthorization, MBSTradingPortalConstants.TRADER);
    }

    /**
     * @author gaur5c
     */
    @Given("^Read Only Trader Login For Session$")
    public void readOnlyTraderLogin() throws Exception {
        String traderAuthorization = "Basic " + MBSTradingPortalUtil
                .getPropKey(MBSTradingPortalConstants.PROP_KEY_CDX_API_READONLY_TRADER_AUTHENTICATION);
        loginRequest(traderAuthorization, MBSTradingPortalConstants.TRADER);
    }

    /**
     * @author gaur5c
     */
    @Given("^TSP Login For Session$")
    public void tspLogin() throws Exception {
        String lenderAuthorization = "Basic "
                + MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.PROP_KEY_CDX_API_TSP_AUTHENTICATION);
        loginRequest(lenderAuthorization, MBSTradingPortalConstants.LENDER);
    }

    /**
     * @author gaur5c
     */
    @Then("^Lender Logout For Session$")
    public void lenderLogout() throws Exception {
        logoutRequest(MBSTradingPortalConstants.LENDER);
    }

    /**
     * @author gaur5c
     * @Description - Trader Lender (POST, PUT, GET) Request
     */
    @Then("^Trader Logout For Session$")
    public void traderLogout() throws Exception {
        logoutRequest(MBSTradingPortalConstants.TRADER);
    }

    /**
     * @author gaur5c
     */
    @Then("^TSP Logout For Session$")
    public void tspLogout() throws Exception {
        logoutRequest(MBSTradingPortalConstants.LENDER);
    }

    private void performPost(ExcelSheetData excelData) throws Exception {

        String url = builder.getModel().getCurrentEndpoint();
        Object object = getPayLoadBody(excelData);

        if (object instanceof JSONObject) {
            object = (JSONObject) object;

        } else if (object instanceof JSONArray) {
            object = (JSONArray) object;

        }

        // Header
        Map<String, String> headerMap = replaceHeader(excelData);
        
        if(isDebugMode){
            System.out.println("performPost: HeaderMap: "+headerMap);
            System.out.println("performPost: Url: "+url);
            System.out.println("performPost: Body: "+object.toString());
        }

        response = given().headers(headerMap).contentType(ContentType.JSON).body(object.toString()).when().post(url)
                .then();

        // If Body presence then only add content type and fetch
        if (!StringUtils.isEmpty(response.extract().body().asString())) {
            String json = response.contentType(ContentType.JSON).extract().response().asString();
            JSONObject obj = new JSONObject(json);
            if (getJsonObjValueUsingKey("transReqId", obj) != null) {
                builder.withTransReqId(getJsonObjValueUsingKey("transReqId", obj));
            }
            /*
             * CMMBSSTA01-1022: (Tech) Maintain versions for transaction request
             */
            if (getJsonObjValueUsingKey(ACTIVE_VERSION, obj) != null) {
                builder.withActiveVersion(Long.parseLong(getJsonObjValueUsingKey(ACTIVE_VERSION, obj)));
            }
            
            /*
             * CMMBSSTA01-1157: (Stream Price) Populate streamed price in trade queue  
             */
            if (getJsonObjValueUsingKey(STREAMING_PRICE_PER_HAND_TEXT, obj) != null) {
                builder.withStreamPricePercentHandleText(getJsonObjValueUsingKey(STREAMING_PRICE_PER_HAND_TEXT, obj));
            }
            
            if (getJsonObjValueUsingKey(STREAMING_PRICE_PER_TICK_TEXT, obj) != null) {
                builder.withStreamPricePercentTicksText(getJsonObjValueUsingKey(STREAMING_PRICE_PER_TICK_TEXT, obj));
            }
            //end
        }
        
        // For Debug
        if(isDebugMode){
            if (!StringUtils.isEmpty(response.extract().body().asString())) {
                String json = response.contentType(ContentType.JSON).extract().response().asString();
                System.out.println("performPost: Response: "+json);
            }
        }
    }

    /**
     * Perform post for Trade Service
     * 
     * @param excelData
     * @throws Exception
     */
    @SuppressWarnings("unused")
    private void performTSPost(ExcelSheetData excelData) throws Exception {

        String url = builder.getModel().getCurrentEndpoint();
        JSONArray jsonObj = getPayLoadBodyTS(excelData);

        // Header
        Map<String, String> headerMap = new HashMap<>();
        for (Map.Entry<String, String> entry : excelData.getReqHeaderMap().entrySet()) {

            headerMap.put(entry.getKey(), entry.getValue());
        }

        response = given().headers(headerMap).contentType(ContentType.JSON).body(jsonObj.toString()).when().post(url)
                .then();

        // If Body presence then only add content type and fetch
        if (!StringUtils.isEmpty(response.extract().body().asString())) {
            String json = response.contentType(ContentType.JSON).extract().response().asString();
            // Returns Array if success and object if failure
            // JSONArray obj = new JSONArray(json);
        }
    }

    private void performPut(ExcelSheetData excelData) throws Exception {

        String url = builder.getModel().getCurrentEndpoint();
        Object object = getPayLoadBody(excelData);

        if (object instanceof JSONObject) {
            object = (JSONObject) object;

        } else if (object instanceof JSONObject) {
            object = (JSONArray) object;

        }

        // Header
        Map<String, String> headerMap = replaceHeader(excelData);

        if(isDebugMode){
            System.out.println("performPut: HeaderMap: "+headerMap);
            System.out.println("performPut: Url: "+url);
            System.out.println("performPut: Body: "+object.toString());
        }
        
        response = given().headers(headerMap).contentType(ContentType.JSON).body(object.toString()).when().put(url)
                .then();

        // If Body presence then only add content type and fetch
        if (!StringUtils.isEmpty(response.extract().body().asString())) {
            String json = response.contentType(ContentType.JSON).extract().response().asString();
            JSONObject obj = new JSONObject(json);
            if (getJsonObjValueUsingKey("transReqId", obj) != null) {
                builder.withTransReqId(getJsonObjValueUsingKey("transReqId", obj));
            }
            /*
             * CMMBSSTA01-1022: (Tech) Maintain versions for transaction request
             */
            if (getJsonObjValueUsingKey(ACTIVE_VERSION, obj) != null) {
                builder.withActiveVersion(Long.parseLong(getJsonObjValueUsingKey(ACTIVE_VERSION, obj)));
            }
            if(isDebugMode){
                System.out.println("performPut: Response: "+json);
            }
        }
    }

    private void performGet(ExcelSheetData excelData) {

        String url = builder.getModel().getCurrentEndpoint();
        boolean queryParamPresence = false;
        StringBuffer queryParam = new StringBuffer();
        for (Map.Entry<String, String> entry : excelData.getReqParamMap().entrySet()) {
            queryParamPresence = true;
            String key = entry.getKey();
            String value = entry.getValue();
            queryParam.append(key + "=" + value + "&");
        }

        // Header
        Map<String, String> headerMap = replaceHeader(excelData);
        
        if(isDebugMode){
            System.out.println("performGet: HeaderMap: "+headerMap);
            System.out.println("performGet: Url: "+url);
        }
        
        if (!queryParamPresence) {
            response = given().headers(headerMap).when().get(url).then();
        } else {
            url = url + "?" + queryParam.toString().substring(0, queryParam.toString().length() - 1);
            response = given().headers(headerMap).when().get(url).then();
        }
        
        // For Debug
        if(isDebugMode){
            if (!StringUtils.isEmpty(response.extract().body().asString())) {
                String json = response.contentType(ContentType.JSON).extract().response().asString();
                System.out.println("performGet: Response: "+json);
            }
        }
    }
    
    private void performDelete(ExcelSheetData excelData) {
        String url = builder.getModel().getCurrentEndpoint();
        // Header
        Map<String, String> headerMap = replaceHeader(excelData);

        if(isDebugMode){
            System.out.println("performDelete: HeaderMap: "+headerMap);
            System.out.println("performDelete: Url: "+url);
        }
        response = given().headers(headerMap).when().delete(url).then();
    }

    private Map<String, String> replaceHeader(ExcelSheetData excelData) {
        Map<String, String> headerMap = new HashMap<>();
        for (Map.Entry<String, String> entry : excelData.getReqHeaderMap().entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            if (MBSTradingPortalConstants.REPLACE_FNMA_LENDER_SESSION_ID.equalsIgnoreCase(value)) {
                value = builder.getModel().getLenderSessionId();
            }
            if (MBSTradingPortalConstants.REPLACE_FNMA_TRADER_SESSION_ID.equalsIgnoreCase(value)) {
                value = builder.getModel().getTraderSessionId();
            }
            headerMap.put(key, value);
        }
        return headerMap;
    }

    private void performDelete() {
        String url = builder.getModel().getApiEndpoint();
        url = url + "/mbscleartransactions";
        response = given().when().delete(url).then();
    }
    
  

    /**
     * @param authorization
     *            - Authorization: Basic cDNoYnJtbnQ6U2VQLTE3
     * @throws Exception
     */
    private void loginRequest(String authorization, String lenderOrTrader) throws Exception {

        HttpHeaders headers = new HttpHeaders();
        headers.add(CDXHeaderEnum.CHANNEL.getValue(), "web");
        headers.add(CDXHeaderEnum.SUB_CHANNEL.getValue(), "MBSP");
        headers.add(CDXHeaderEnum.AUTHORIZATION.getValue(), authorization);

        HttpEntity<String> request = new HttpEntity<>(headers);

        ResponseEntity<String> responseEntity = retryRequest(request, builder.getModel().getCdxLoginEndPoint());

        HttpHeaders resHeaders = responseEntity.getHeaders();
        String sessionId = resHeaders.get(CDXHeaderEnum.SESSION_ID.getValue()).get(0);

        if (MBSTradingPortalConstants.LENDER.equalsIgnoreCase(lenderOrTrader)) {
            builder.getModel().setLenderSessionId(sessionId);
        } else if (MBSTradingPortalConstants.TRADER.equalsIgnoreCase(lenderOrTrader)) {
            builder.getModel().setTraderSessionId(sessionId);
        }

    }

    /**
     * Kill the session
     * 
     * @throws Exception
     */
    @SuppressWarnings("unused")
    private void logoutRequest(String lenderOrTrader) throws Exception {

        HttpHeaders headers = new HttpHeaders();
        headers.add(CDXHeaderEnum.CHANNEL.getValue(), "web");
        headers.add(CDXHeaderEnum.SUB_CHANNEL.getValue(), "MBSP");

        if (MBSTradingPortalConstants.LENDER.equalsIgnoreCase(lenderOrTrader)) {

            headers.add(CDXHeaderEnum.SESSION_ID.getValue(), builder.getModel().getLenderSessionId());
        } else if (MBSTradingPortalConstants.TRADER.equalsIgnoreCase(lenderOrTrader)) {

            headers.add(CDXHeaderEnum.SESSION_ID.getValue(), builder.getModel().getTraderSessionId());
        }
        HttpEntity<String> request = new HttpEntity<>(headers);

        ResponseEntity<String> responseEntity = retryRequest(request, builder.getModel().getCdxLogoutEndPoint());
    }

   
    /**
     * @author gaur5c
     * @param request
     * @param url
     * @return
     * @throws Exception
     */
    private ResponseEntity<String> retryRequest(HttpEntity<String> request, String url) throws Exception {

        ResponseEntity<String> responseEntity = null;
        CDXProxyTemplate cDXProxyTemplate = getCDXProxyTemplate(MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.PROP_KEY_CDX_API_PROXY_HOST),
                        Integer.parseInt( MBSTradingPortalUtil.getPropKey(MBSTradingPortalConstants.PROP_KEY_CDX_API_PROXY_PORT)));
                
        List<String> urls = new ArrayList<>();
        urls.add(url);
        
        responseEntity = cDXProxyTemplate.exchange( urls, 3, HttpMethod.POST, request, String.class) ;
        return responseEntity;
    }
    
    /**
     * @author gaur5c
     * @param proxyHost
     * @param proxyPort
     * @return
     */
    private CDXProxyTemplate getCDXProxyTemplate(String proxyHost, int proxyPort) {

        CDXProxyTemplate cDXProxyTemplate = CDXClientCallConfig.cDXProxyTemplate(proxyHost, proxyPort);
        return cDXProxyTemplate;

    }

    /**
     * @author gaur5c
     * @param excelData
     * @return JSONObject
     * @Description: It will load the template given in excel sheet - replace
     *               the value at template and construct the Json Object
     */
    private Object getPayLoadBody(ExcelSheetData excelData) throws Exception {
        JSONObject jsonObj = null;
        JSONArray jsonArray = null;
        if (!StringUtils.isBlank(excelData.getBodyTemplate())) {
            String templateContent = PayloadTemplateLoader.getFileContent(excelData.getBodyTemplate());
            payLoadBuilder = PayloadBuilderFactory.getPayloadBuilder(excelData.getBodyTemplate());
            jsonObj = payLoadBuilder.getPayload(excelData.getInputPropMap(), templateContent);
            /*
             * CMMBSSTA01-1022: (Tech) Maintain versions for transaction request
             * Set the activeVersion from Excel Data if it is there- Otherwise
             * use from API return
             */
            if (!jsonObj.has(ACTIVE_VERSION) && (builder.getModel().getActiveVersion() != null
                    && builder.getModel().getActiveVersion().longValue() > 0)) {
                jsonObj.put(ACTIVE_VERSION, builder.getModel().getActiveVersion());

            }
            
            /*
             * CMMBSSTA01-1157: (Stream Price) Populate streamed price in trade queue  
             */
            if (jsonObj.has(ExcelSheetParamEnum.pricePercentHandleText.name()) && 
                    ((String)jsonObj.get(ExcelSheetParamEnum.pricePercentHandleText.name())).startsWith("REPLACE_PRICE_PER_HAND_TEXT")) {
                jsonObj.put(ExcelSheetParamEnum.pricePercentHandleText.name(), builder.getModel().getStreamPricePercentHandleText());

            }
            if (jsonObj.has(ExcelSheetParamEnum.pricePercentTicksText.name()) && 
                    ((String)jsonObj.get(ExcelSheetParamEnum.pricePercentTicksText.name())).startsWith("REPLACE_PRICE_PER_TICK_TEXT")) {
                jsonObj.put(ExcelSheetParamEnum.pricePercentTicksText.name(), builder.getModel().getStreamPricePercentTicksText());

            }
            //End
            
            jsonObj = MBSTradingPortalUtil.replaceExcelInputValueFromConfig(excelData, jsonObj); 
            
            //end
            
            if (excelData.isReqBodyInArray()) {
                jsonArray = new JSONArray("[" + jsonObj.toString() + "]");
                return jsonArray;
            }
        } else {
            jsonObj = new JSONObject(excelData.getInputPropMap());
            /*
             * CMMBSSTA01-1022: (Tech) Maintain versions for transaction request
             * Set the activeVersion from Excel Data if it is there- Otherwise
             * use from API return
             */
            if (!jsonObj.has(ACTIVE_VERSION) && (builder.getModel().getActiveVersion() != null
                    && builder.getModel().getActiveVersion().longValue() > 0)) {
                jsonObj.put(ACTIVE_VERSION, builder.getModel().getActiveVersion());

            }
            
            /*
             * CMMBSSTA01-1157: (Stream Price) Populate streamed price in trade queue  
             */
            if (jsonObj.has(ExcelSheetParamEnum.pricePercentHandleText.name()) && 
                    ((String)jsonObj.get(ExcelSheetParamEnum.pricePercentHandleText.name())).startsWith("REPLACE_PRICE_PER_HAND_TEXT")) {
                jsonObj.put(ExcelSheetParamEnum.pricePercentHandleText.name(), builder.getModel().getStreamPricePercentHandleText());

            }
            if (jsonObj.has(ExcelSheetParamEnum.pricePercentTicksText.name()) && 
                    ((String)jsonObj.get(ExcelSheetParamEnum.pricePercentTicksText.name())).startsWith("REPLACE_PRICE_PER_TICK_TEXT")) {
                jsonObj.put(ExcelSheetParamEnum.pricePercentTicksText.name(), builder.getModel().getStreamPricePercentTicksText());

            }
            //End
            
            // Making Product Dynamic
            jsonObj = MBSTradingPortalUtil.replaceExcelInputValueFromConfig(excelData, jsonObj);
            // end

            if (excelData.isReqBodyInArray()) {
                jsonArray = new JSONArray("[" + jsonObj.toString() + "]");
                return jsonArray;
            }
        }
        return jsonObj;
    }

   
    /**
     * Get payload for TS
     * 
     * @param excelData
     * @return
     * @throws Exception
     */
    private JSONArray getPayLoadBodyTS(ExcelSheetData excelData) throws Exception {
        JSONArray jsonObj = null;
        if (!StringUtils.isBlank(excelData.getBodyTemplate())) {
            String templateContent = PayloadTemplateLoader.getFileContent(excelData.getBodyTemplate());
            payLoadBuilder = PayloadBuilderFactory.getPayloadBuilder(excelData.getBodyTemplate());
            jsonObj = payLoadBuilder.getPayloadArray(excelData.getInputPropMap(), templateContent);

        } else {
            jsonObj = new JSONArray(excelData.getInputPropMap());
        }
        return jsonObj;
    }

    @SuppressWarnings("unchecked")
    private String getJsonObjValueUsingKey(String lookupKey, JSONObject jsonObj) throws Exception {
        String value = null;
        if (jsonObj == null) {
            return null;
        }

        Iterator<String> keys = jsonObj.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            if (lookupKey.equalsIgnoreCase(key)) {
                value = jsonObj.getString(lookupKey);
                return value;
            }
            if (jsonObj.get(key) instanceof JSONObject) {
                if (jsonObj.get(key) != null) {
                    JSONObject xx = new JSONObject(jsonObj.get(key).toString());
                    value = getNestedJsonObjValueUsingKey(lookupKey, xx);
                }
            }

        }
        return value;
    }

    @SuppressWarnings("unchecked")
    private String getNestedJsonObjValueUsingKey(String lookupKey, JSONObject jsonObj) throws Exception {
        if (jsonObj == null) {
            return null;
        }

        Iterator<String> keys = jsonObj.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            if (lookupKey.equalsIgnoreCase(key)) {
                return jsonObj.getString(lookupKey);
            }
            if (jsonObj.get(key) instanceof JSONObject) {
                if (jsonObj.get(key) != null) {
                    JSONObject xx = new JSONObject(jsonObj.get(key).toString());
                    return getNestedJsonObjValueUsingKey(lookupKey, xx);
                }
            }
        }
        return null;
    }

    @Then("^Validate the filename$")
    public void validateFilename() throws Throwable {
        String filenameTemplate = builder.getModel().getExcelData().getOutputPropMap().get("fileName");
        String filename = replaceFilenameValue(filenameTemplate);
        String responseFileName = response.extract().header("x-cp-s3files");
        int indexOfDate = filenameTemplate.indexOf("REPLACE_CURRENT_DATE");
        int indexOfExtension = filename.lastIndexOf(".");
        Assert.assertEquals(filename.substring(0, indexOfDate), responseFileName.substring(0, indexOfDate));
        Assert.assertEquals(filename.substring(indexOfExtension), responseFileName.substring(indexOfExtension));
        String date = filename.substring(indexOfDate, indexOfExtension);
        String responseDate = responseFileName.substring(indexOfDate, indexOfExtension);
        Assert.assertTrue(
                "Number of seconds between the timestamps: "
                        + MBSTradingPortalUtil.dateDiff(date, responseDate, "MMddyyyy_HHmmss"),
                MBSTradingPortalUtil.validateDate(date, responseDate, "MMddyyyy_HHmmss", 2));
    }

    private String replaceFilenameValue(String filename) {
        String updatedFileName = filename;
        if (updatedFileName.contains("REPLACE_CURRENT_DATE")) {
            updatedFileName = updatedFileName.replace("REPLACE_CURRENT_DATE",
                    MBSTradingPortalUtil.getCurrentDate(0, "MMddyyyy_HHmmss"));
        }
        return updatedFileName;
    }
    
    @Then("^Compare Transaction History record size$")
    public void compareRecordSize() throws Throwable {
    	int gfSize = dataUtil.getSizeOfDataset(builder);
    	JSONObject response = builder.getModel().getLookUpObj();
    	Assert.assertEquals(gfSize + "", response.getString("totalRecords"));
    }
    
    @Then("^Retrieve the data from GF$")
    public void getDataFromGF() throws Throwable {
    	dataUtil.getDataFromGF(builder);
    	dataUtil.getTradeDataFromGF(builder);
    }
    
	@Then("^Compare Transaction History response data to GF$")
    public void compareTransactionHistoryWithDataFromGF() throws Throwable {
		(new MBSTradingPortalHistoryValidator()).compareTransactionHistoryWithDataFromGF(builder);
    }

	
}
