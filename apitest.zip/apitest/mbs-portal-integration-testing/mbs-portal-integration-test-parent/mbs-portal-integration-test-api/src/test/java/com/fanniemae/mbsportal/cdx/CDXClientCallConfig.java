/**
 * 
 */
package com.fanniemae.mbsportal.cdx;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;

/**
 * @author: Rajiv Chaudhuri
 * @Date: Jun 1, 2018
 * @File: com.fanniemae.mbsportal.cdx.CDXClientCallConfig.java
 * @Revision:
 * @Description: CDXClientCallConfig.java
 */
public class CDXClientCallConfig {

    private static String proxyHost;
    private static Integer proxyPort;

    public static CDXProxyTemplate cDXProxyTemplate(String proxyHost, Integer proxyPort) {

        CDXProxyTemplate cDXProxyTemplate = null;

        try {

            CDXClientCallConfig.proxyHost = proxyHost;
            CDXClientCallConfig.proxyPort = proxyPort;

            cDXProxyTemplate = new CDXProxyTemplate(httpComponentsClientHttpRequestFactory());

        } catch (KeyStoreException exe) {
            System.err.println("KeyStoreException:"+ exe);

        } catch (NoSuchAlgorithmException exe) {
            System.err.println("NoSuchAlgorithmException:"+ exe);

        } catch (KeyManagementException exe) {
            System.err.println("KeyManagementException:"+ exe);
        }
        return cDXProxyTemplate;
    }

    /**
     * 
     * DMZ HTTP Client Factory with SSL Ignore and CDX Proxy
     * 
     * @return HttpComponentsClientHttpRequestFactory
     * @throws KeyStoreException
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     */
    @SuppressWarnings({ "deprecation" })
    private static HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory()
            throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
        // To ignore SSL for DMZ and CDX Proxy
        HttpClientBuilder b = HttpClientBuilder.create()
                .setProxy(new HttpHost(CDXClientCallConfig.proxyHost, CDXClientCallConfig.proxyPort, "http"));

        SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
            public boolean isTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
                return true;
            }
        }).build();
        b.setSslcontext(sslContext);
        HostnameVerifier hostnameVerifier = SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER;
        SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(sslContext, hostnameVerifier);
        Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory> create()
                .register("http", PlainConnectionSocketFactory.getSocketFactory()).register("https", sslSocketFactory)
                .build();
        // Allows Multi-Thread use
        PoolingHttpClientConnectionManager connMgr = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
        connMgr.setMaxTotal(20);
        b.setConnectionManager(connMgr);
        CloseableHttpClient httpClient = b.setDefaultRequestConfig(requestConfig()).build();
        HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
        httpComponentsClientHttpRequestFactory.setHttpClient(httpClient);
        return httpComponentsClientHttpRequestFactory;
    }

    /**
     * requestConfig
     * 
     * @return RequestConfig
     */
    private static RequestConfig requestConfig() {
        RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(5000).setConnectTimeout(5000)
                .setSocketTimeout(5000).build();
        return requestConfig;
    }

}
