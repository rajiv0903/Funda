package com.fanniemae.mbsportal.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Import;

import com.fanniemae.mbsportal.config.DataAccessConfig;
import com.fanniemae.mbsportal.dao.BaseDaoWrapper;
import com.fanniemae.mbsportal.dao.MBSBaseDao;
import com.fanniemae.mbsportal.model.MBSTrade;
import com.fanniemae.mbsportal.model.MBSTradingPortalBuilder;
import com.fanniemae.mbsportal.model.MBSTransactionRequest;
import com.fanniemae.mbsportal.steps.MBSTradingPortalHistoryQueryBuilder;

@Import(DataAccessConfig.class)
public class MBSTradingPortalDataUtil {
	MBSBaseDao<MBSTransactionRequest> mbsTransactionBaseDao;
	MBSBaseDao<MBSTrade> mbsTradeBaseDao;

	public void init() {
        mbsTransactionBaseDao = new MBSBaseDao<MBSTransactionRequest>();
        mbsTradeBaseDao = new MBSBaseDao<MBSTrade>();
    	ApplicationContext ctx = new AnnotationConfigApplicationContext(MBSBaseDao.class);
    	BaseDaoWrapper transWrapper = ctx.getBean("transBaseDaoWrapper",BaseDaoWrapper.class);
    	BaseDaoWrapper tradeWrapper = ctx.getBean("tradeBaseDaoWrapper",BaseDaoWrapper.class);
		mbsTransactionBaseDao.setBaseDaoWrapper(transWrapper);
		mbsTransactionBaseDao.getBaseDaoWrapper().setRegionName("MBSTransaction");
		mbsTradeBaseDao.setBaseDaoWrapper(tradeWrapper);
		mbsTradeBaseDao.getBaseDaoWrapper().setRegionName("MBSTrade");
		
	}
	
	public int getSizeOfDataset(MBSTradingPortalBuilder builder) throws Throwable {
		

		Map<String, String> searchParams = builder.getModel().getExcelData().getInputPropMap();
    	List<Object> queryArgsLst = new ArrayList<>();
        String query = createQueryFromParamsNoLimit(searchParams, queryArgsLst);
        System.out.println("query is " + query);
        System.out.println("args are " + queryArgsLst);
        Collection<MBSTransactionRequest> results = mbsTransactionBaseDao.query(query, queryArgsLst);
        return results.size();
	}

    public void getDataFromGF(MBSTradingPortalBuilder builder) throws Throwable {

		Map<String, String> searchParams = builder.getModel().getExcelData().getInputPropMap();
    	List<Object> queryArgsLst = new ArrayList<>();
        String query = createQueryFromParams(searchParams, queryArgsLst);
        System.out.println("query is " + query);
        System.out.println("args are " + queryArgsLst);
        Collection<MBSTransactionRequest> results = mbsTransactionBaseDao.query(query, queryArgsLst);
        List<MBSTransactionRequest> thisResults = new ArrayList<>();
        filterResults(thisResults, results, searchParams);
//        List<?> thisResults = mbsTransactionBaseDao.getAll();
    	builder.withGFObjList((List<?>) thisResults);
    }
    
    private void filterResults(List<MBSTransactionRequest> thisResults, Collection<MBSTransactionRequest> results, Map<String, String> searchParams) {
		List<Integer> indexAndSize = getIndexAndSize(searchParams);
		int index = indexAndSize.get(0);
		int size = indexAndSize.get(1);
		int offset = size * (index - 1);
		List<MBSTransactionRequest> inResults = new ArrayList<>();
		inResults.addAll(results);
		for (int i = offset; i < inResults.size(); i++) {
			thisResults.add(inResults.get(i));
		}
	}

	public void getTradeDataFromGF(MBSTradingPortalBuilder builder) throws Throwable {
    	List<Object> queryArgsLst = new ArrayList<>();
    	List<?> gfObjects = builder.getModel().getGfObjects();
    	List<String> transactionIds = new ArrayList<>();
    	for (Object gfObject : gfObjects) {
    		MBSTransactionRequest gfTrans = (MBSTransactionRequest) gfObject;
    		String reqId = gfTrans.getTransReqNumber();
    		if (!transactionIds.contains(reqId)) {
    			transactionIds.add(reqId);
    		}
    	}
    	String query = MBSTradingPortalHistoryQueryBuilder.getMBSTradeQuery(transactionIds, queryArgsLst);
    	Collection<MBSTrade> results = mbsTradeBaseDao.query(query, queryArgsLst);
    	List<MBSTrade> newResults = new ArrayList<>(); 
    	for (Object gfObject : gfObjects) {
    		MBSTransactionRequest gfTrans = (MBSTransactionRequest) gfObject;
    		String reqId = gfTrans.getTransReqNumber();
    		boolean found = false;
    		for (MBSTrade trade : results) {
    			if (!found && trade.getTransReqNumber().equals(reqId)) {
    				found = true;
    				trade.setTransReq(gfTrans);
    				newResults.add(trade);
    			}
    		}
    		if (!found) {
    			MBSTrade trade = new MBSTrade();
    			trade.setTransReq(gfTrans);
    			trade.setTransReqNumber(reqId);
    			newResults.add(trade);
    		}
    	}
    	builder.withGFObjList(newResults);
    }
    
    private String getIds(List<MBSTrade> asList) {
		StringBuilder ids = new StringBuilder();
		for (MBSTrade trade : asList) {
			ids.append(", " + trade.getTransReqNumber());
		}
		return ids.toString();
	}

	private String createQueryFromParamsNoLimit(Map<String, String> searchParams, List<Object> queryArgsLst) {
    	StringBuilder query = new StringBuilder();
    	String mbsRoleType = "";
    	String sellerServicerNumber = "";
    	String orderByClause = "order by ";
    	String sortParam = "";
    	boolean acceptedTrades = false;
//    	query.append("SELECT * FROM /MBSTransaction WHERE ");
    	for (String param : searchParams.keySet()) {
    		switch(param) {
    		case "acceptedTrades":
    			acceptedTrades = searchParams.get(param).equalsIgnoreCase("TRUE");
    			break;
    		case "orderField":
    			sortParam = searchParams.get(param);
    			orderByClause += searchParams.get(param) + " ";
    			break;
    		case "orderBy":
    			orderByClause += searchParams.get(param) + " ";
    			if (!sortParam.equalsIgnoreCase("transReqNumber") && !sortParam.equalsIgnoreCase("submissionDate") ) {
    				orderByClause += ", transReqNumber desc ";
    			}
    			break;
    		case "name":
    			mbsRoleType = searchParams.get(param);
    			break;
    		case "sellerServicerNumber":
    			sellerServicerNumber = searchParams.get(param);
    			break;
    		}
    	}
    	query.append(MBSTradingPortalHistoryQueryBuilder.getMBSTransReqHistoryQuery(mbsRoleType, acceptedTrades, sellerServicerNumber, queryArgsLst));
    	query.append(orderByClause);
		return query.toString();
	}

    private String createQueryFromParams(Map<String, String> searchParams, List<Object> queryArgsLst) {
    	StringBuilder query = new StringBuilder();
    	query.append(createQueryFromParamsNoLimit(searchParams, queryArgsLst));
    	List<Integer> indexAndSize = getIndexAndSize(searchParams);
       	query.append(getLimitClause(indexAndSize.get(0), indexAndSize.get(1)));
		return query.toString();
    }
    
    private List<Integer> getIndexAndSize(Map<String, String> searchParams) {
    	int pageIndex = 1;
    	int pageSize = 0;
    	for (String param : searchParams.keySet()) {
    		switch(param) {
    		case "pageIndex":
    			pageIndex = Integer.parseInt(searchParams.get(param));
    			break;
    		case "pageSize":
    			pageSize = Integer.parseInt(searchParams.get(param));
    			break;
    		}
    	}
    	return Arrays.asList(pageIndex, pageSize);
    }

	private String getLimitClause(int pageIndex, int pageSize) {
		if (pageIndex < 1 || pageSize < 0) {
			return "";
		}
		StringBuilder limitQuery = new StringBuilder();
		limitQuery.append("limit ");
    	long offsetLimit = pageSize * pageIndex;
    	limitQuery.append(offsetLimit).append(" ");
		return limitQuery.toString();
	}

}
