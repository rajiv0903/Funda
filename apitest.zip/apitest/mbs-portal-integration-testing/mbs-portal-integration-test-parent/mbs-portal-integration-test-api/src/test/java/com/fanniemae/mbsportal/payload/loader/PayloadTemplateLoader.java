/*
 * 
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.payload.loader;

import java.io.File;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 
 * @author Rajiv Chaudhuri
 * @Date: Mar 22, 2018
 * @File: com.fanniemae.mbsportal.payload.loader.PayloadTemplateLoader.java
 * @Revision : 
 * @Description: PayloadTemplateLoader.java
 */
public class PayloadTemplateLoader {

    static String extension = "dat";
    static Map<String, String> fileContentMap = new LinkedHashMap<>();

    static {
        try {
            URL resource = PayloadTemplateLoader.class.getResource("/payload");
            File fileDir = Paths.get(resource.toURI()).toFile();
            // String dirPath = fileDir.getCanonicalPath();
            File[] fileList = null;
            if (fileDir.isDirectory()) {
                fileList = fileDir.listFiles(file -> file.isFile()
                        && file.getName().substring(file.getName().lastIndexOf(".") + 1).equalsIgnoreCase(extension));
            }
            for (File jsonFile : fileList) {
                String content = new String(Files.readAllBytes(Paths.get(jsonFile.getAbsolutePath())));
                fileContentMap.put(jsonFile.getName().substring(0, jsonFile.getName().lastIndexOf(".")), content);
            }

        } catch (Exception exe) {
            exe.printStackTrace();
            System.err.println(exe.getMessage());
        }
    }

    public static String getFileContent(String keyCommand) throws Exception {
        if (!fileContentMap.containsKey(keyCommand)) {
            throw new Exception(String.format("The Payload File {%s} does not exists", keyCommand));
        }
        return fileContentMap.get(keyCommand);
    }

}
