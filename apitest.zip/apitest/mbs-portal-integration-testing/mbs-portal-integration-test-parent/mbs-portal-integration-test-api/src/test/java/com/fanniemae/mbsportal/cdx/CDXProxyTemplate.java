/*
 * 
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.cdx;

import java.util.List;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: Jun 1, 2018
 * @File: com.fanniemae.mbsportal.cdx.CDXProxyTemplate.java
 * @Revision:
 * @Description: CDXProxyTemplate.java
 */
public class CDXProxyTemplate extends RestTemplate {

    /**
     *
     * @param requestFactory
     */
    public CDXProxyTemplate(ClientHttpRequestFactory requestFactory) {
        super(requestFactory);
    }

    public <T> ResponseEntity<T> exchange(List<String> urls, int retryCount, HttpMethod method,
            HttpEntity<?> requestEntity, Class<T> responseType, Object... uriVariables) throws RestClientException {

        ResponseEntity<T> responseEntity = null;
        RequestCallback requestCallback = httpEntityCallback(requestEntity, responseType);
        ResponseExtractor<ResponseEntity<T>> responseExtractor = responseEntityExtractor(responseType);
        int retryCounter = 0;

        retryCount = retryCount * urls.size();

        while (retryCounter < (retryCount + 1)) {
            for (String url : urls) {
                try {
                    responseEntity = execute(url, method, requestCallback, responseExtractor, uriVariables);
                    return responseEntity;
                } catch (RestClientException clientExe) {
                    retryCounter++;
                    if (retryCounter == retryCount) {
                        System.err.println("CDXProxyTemplate: RestClientException:" + clientExe.getMessage());
                        throw clientExe;
                    }
                }
            }
        }

        return responseEntity;
    }

}
