/*
 * 
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.framework;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 
 * @author Rajiv Chaudhuri
 * @Date: Mar 22, 2018
 * @File: com.fanniemae.mbsportal.framework.ExcelSheetParamEnum.java
 * @Revision : 
 * @Description: ExcelSheetParamEnum.java
 */
public enum ExcelSheetParamEnum {
        // ENUM - name - json prop, const variable - excel sheet prop
        // productIdentifier("PRODUCT_ID"),
        identifier("PRODUCT_IDENTIFIER"), sourceType("PRODUCT_SOURCE_TYPE"), type("PRODUCT_TYPE"),
        productName("PRODUCT_NAME"), tradeAmount("TRADE_AMOUNT"), tradeBuySellType("BUY_SELL_TYPE"),
        tradeCouponRate("COUPON"), tradeSettlementDate("SETTLEMENT_DATE"), lenderId("LENDER_ID"),
        stateType("STATE_TYPE"), transReqId("TRANSACTION_ID"), pricePercentTicksText("PRICE_PER_TICK_TEXT"),
        pricePercentHandleText("PRICE_PER_HAND_TEXT"), submissionDate("SUBMISSION_DATE"),
        buySellIndicator("PRODUCT_BUY_SELL_INDICATOR"), passThroughRate("PRODUCT_COUPON"),
        oboLenderSellerServiceNumber("OBO_LENDER_SSN"), tspShortName("TSP_SHORT_NAME"),
        streamPricePercentHandleText("STREAM_PRICE_HANDLE_TEXT"),streamPricePercentTicksText("STREAM_PRICE_TICKS_TEXT"),
        
        traderId("TRADER_ID"),
        
        // Response mapping manage product
        nameCode("PRODUCT_NAME_CODE"), nameCodeSortOrder("PRODUCT_NAME_CODE_SORT_ORDER"),
        securityTerm("PRODUCT_SECURITY_TERM"), description("PRODUCT_DESCRIPTION"),
        settlementDate("PRODUCT_SETTLEMENT_DATE"), marketTermType("MARKET_TERM"),
        
        //Profile Related 
        userName("USER_NAME"), firstName("FIRST_NAME"), lastName("LAST_NAME"), emailAddress("EMAIL_ADDRESS"),
        eventsAvailable("EVENTS_AVAILABLE"), partyShortName("PARTY_SHORT_NAME"), sellerServicerNumber("SELLER_SERVICE_NUMBER"),
        dealerOrgId("DEALER_ORG_ID"), lenderEntityName("DEALER_ORG_NAME"), name("ROLE_NAME"), 
        shortName("TSP_LENDER_SHORT_NAME"),
	
	//UI Logging Related 
        code("HTTP_CODE"), module("MODULE"), page("PAGE"), functionality("FUNCTIONALITY"), message("MESSAGE"),
        
        //Versioning
        activeVersion("ACTIVE_VERSION"),
    
        //export data
        fileName("FILENAME"),csvHeader("CSVHEADER"),
        
        // history data
        acceptedTrades("ACCEPTED_TRADES"),
        orderField("ORDER_FIELD"),
        orderBy("ORDER_BY"),
        pageIndex("PAGE_INDEX"),
        pageSize("PAGE_SIZE"),
        
        //Exception data
        messageCode("MSG_CODE"), messages("messages"),
    
        //For Trade Service
        //RE-USED TRADE SETTLEMENT DATE, 
        commentGeneral("COMMENTS_GENERAL"), counterPartyName("COUNTER_PARTY_NAME"), portfolioName("PORTFOLIO_NAME"),
        pricePercent("PRICE_PERCENT"), purpose("PURPOSE"), quantity("QUANTITY"), sourceSystem("SOURCE_SYSTEM"),
        sourceTransactionId("SOURCE_TRANSACTION_ID"), tbaCoupon("TBA_COUPON"), tbaSettlementDate("TBA_SETTLEMENT_DATE"),
        tbaTicker("TBA_TICKER"), tbaType("TBA_TYPE"), tradeConfirmedBy("TRADE_CONFIRMED_BY"), tradeConfirmedWith("TRADE_CONFIRMED_WITH"),
        tradeDate("TRADE_DATE"), tradeType("TRADE_TYPE"), tradeVariance("TRADE_VARIANCE"), traderName("TRADER_NAME");
        
        
        
        
        
	
        
        static Map<String, String> excelData = new LinkedHashMap<>();
        private final String value;
        
        private ExcelSheetParamEnum(String value) {
                this.value = value;
        }
        
        public static String getIntProp(String extProp) {
                for(ExcelSheetParamEnum status : ExcelSheetParamEnum.values()) {
                        if(status.getValue().equalsIgnoreCase(extProp)) {
                                return status.toString();
                        }
                }
                return "DUMMY";
        }
        
        public String getValue() {
                return value;
        }
        
}
