/*
 * 
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.model;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fanniemae.mbsportal.framework.ExcelSheetData;

/**
 * 
 * @author Rajiv Chaudhuri
 * @Date: Mar 22, 2018
 * @File: com.fanniemae.mbsportal.model.MBSTradingPortalBuilderModel.java
 * @Revision :
 * @Description: MBSTradingPortalBuilderModel.java
 */
public class MBSTradingPortalBuilderModel {

    /**
     * @author gaur5c
     * @Description - All properties; some properties are kept for future use
     */
    private String transReqId;
    private String tradeAmount;
    private String productIdentifier;
    private String tradeSettlementDate;
    private String tradeCouponRate;
    private String tradeBuySellType;
    private String stateType;

    private String pricePercent;
    private String pricePercentHandleText;
    private String pricePercentTicksText;
    private String submissionDate;

    private String traderId;
    private String lenderId;

    private String message;

    private String tradeSubmissionDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

    private String apiEndpoint;
    private String currentEndpoint;

    private String tradeServiceApiEndpoint;

    private ExcelSheetData excelData;

    private String lenderSessionId;
    private String traderSessionId;

    private Long activeVersion;

    /**
     * @author gaur5c
     * @Description - Parse the JSON Response and assign to Object Or Array
     *              Object
     */
    JSONObject lookUpObj;
    JSONArray resObjects;
    List<?> gfObjects;

    /**
     * @author gaur5c CDX Related Properties
     */
    private String cdxEndpoint;
    private String cdxLoginEndPoint;
    private String cdxLogoutEndPoint;

    List<JSONObject> lookUpObjList = new ArrayList<>();

    private String streamPricePercentHandleText;
    private String streamPricePercentTicksText;
    
    /**
     * @author gaur5c CDX FMN API Endpoint
     */
    private String cdxFmnApiEndpoint;

    public String getTransReqId() {
        return transReqId;
    }

    public void setTransReqId(String transReqId) {
        this.transReqId = transReqId;
    }

    public String getTradeAmount() {
        return tradeAmount;
    }

    public void setTradeAmount(String tradeAmount) {
        this.tradeAmount = tradeAmount;
    }

    public String getProductIdentifier() {
        return productIdentifier;
    }

    public void setProductIdentifier(String productIdentifier) {
        this.productIdentifier = productIdentifier;
    }

    public String getTradeSettlementDate() {
        return tradeSettlementDate;
    }

    public void setTradeSettlementDate(String tradeSettlementDate) {
        this.tradeSettlementDate = tradeSettlementDate;
    }

    public String getTradeCouponRate() {
        return tradeCouponRate;
    }

    public void setTradeCouponRate(String tradeCouponRate) {
        this.tradeCouponRate = tradeCouponRate;
    }

    public String getTradeBuySellType() {
        return tradeBuySellType;
    }

    public void setTradeBuySellType(String tradeBuySellType) {
        this.tradeBuySellType = tradeBuySellType;
    }

    public String getStateType() {
        return stateType;
    }

    public void setStateType(String stateType) {
        this.stateType = stateType;
    }

    public String getPricePercent() {
        return pricePercent;
    }

    public void setPricePercent(String pricePercent) {
        this.pricePercent = pricePercent;
    }

    public String getPricePercentHandleText() {
        return pricePercentHandleText;
    }

    public void setPricePercentHandleText(String pricePercentHandleText) {
        this.pricePercentHandleText = pricePercentHandleText;
    }

    public String getPricePercentTicksText() {
        return pricePercentTicksText;
    }

    public void setPricePercentTicksText(String pricePercentTicksText) {
        this.pricePercentTicksText = pricePercentTicksText;
    }

    public String getSubmissionDate() {
        return submissionDate;
    }

    public void setSubmissionDate(String submissionDate) {
        this.submissionDate = submissionDate;
    }

    public String getTraderId() {
        return traderId;
    }

    public void setTraderId(String traderId) {
        this.traderId = traderId;
    }

    public String getLenderId() {
        return lenderId;
    }

    public void setLenderId(String lenderId) {
        this.lenderId = lenderId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public JSONObject getLookUpObj() {
        return lookUpObj;
    }

    public void setLookUpObj(JSONObject lookUpObj) {
        this.lookUpObj = lookUpObj;
    }

    public JSONArray getResObjects() {
        return resObjects;
    }

    public void setResObjects(JSONArray resObjects) {
        this.resObjects = resObjects;
    }

    public String getTradeSubmissionDate() {
        return tradeSubmissionDate;
    }

    public void setTradeSubmissionDate(String tradeSubmissionDate) {
        this.tradeSubmissionDate = tradeSubmissionDate;
    }

    public String getApiEndpoint() {
        return apiEndpoint;
    }

    public void setApiEndpoint(String apiEndpoint) {
        this.apiEndpoint = apiEndpoint;
    }

    public String getCurrentEndpoint() {
        return currentEndpoint;
    }

    public void setCurrentEndpoint(String currentEndpoint) {
        this.currentEndpoint = currentEndpoint;
    }

    public ExcelSheetData getExcelData() {
        return excelData;
    }

    public void setExcelData(ExcelSheetData excelData) {
        this.excelData = excelData;
    }

    public List<JSONObject> getLookUpObjList() {
        return lookUpObjList;
    }

    public void setLookUpObjList(List<JSONObject> lookUpObjList) {
        this.lookUpObjList = lookUpObjList;
    }

    public String getCdxEndpoint() {
        return cdxEndpoint;
    }

    public void setCdxEndpoint(String cdxEndpoint) {
        this.cdxEndpoint = cdxEndpoint;
    }

    public String getCdxLoginEndPoint() {
        return cdxLoginEndPoint;
    }

    public void setCdxLoginEndPoint(String cdxLoginEndPoint) {
        this.cdxLoginEndPoint = cdxLoginEndPoint;
    }

    public String getCdxLogoutEndPoint() {
        return cdxLogoutEndPoint;
    }

    public void setCdxLogoutEndPoint(String cdxLogoutEndPoint) {
        this.cdxLogoutEndPoint = cdxLogoutEndPoint;
    }

    public String getLenderSessionId() {
        return lenderSessionId;
    }

    public void setLenderSessionId(String lenderSessionId) {
        this.lenderSessionId = lenderSessionId;
    }

    public String getTraderSessionId() {
        return traderSessionId;
    }

    public void setTraderSessionId(String traderSessionId) {
        this.traderSessionId = traderSessionId;
    }

    /**
     * @return the tradeServiceApiEndpoint
     */
    public String getTradeServiceApiEndpoint() {
        return tradeServiceApiEndpoint;
    }

    /**
     * @param tradeServiceApiEndpoint
     *            the tradeServiceApiEndpoint to set
     */
    public void setTradeServiceApiEndpoint(String tradeServiceApiEndpoint) {
        this.tradeServiceApiEndpoint = tradeServiceApiEndpoint;
    }

    public Long getActiveVersion() {
        return activeVersion;
    }

    public void setActiveVersion(Long activeVersion) {
        this.activeVersion = activeVersion;
    }

    public String getCdxFmnApiEndpoint() {
        return cdxFmnApiEndpoint;
    }

    public void setCdxFmnApiEndpoint(String cdxFmnApiEndpoint) {
        this.cdxFmnApiEndpoint = cdxFmnApiEndpoint;
    }

    public String getStreamPricePercentHandleText() {
        return streamPricePercentHandleText;
    }

    public void setStreamPricePercentHandleText(String streamPricePercentHandleText) {
        this.streamPricePercentHandleText = streamPricePercentHandleText;
    }

    public String getStreamPricePercentTicksText() {
        return streamPricePercentTicksText;
    }

    public void setStreamPricePercentTicksText(String streamPricePercentTicksText) {
        this.streamPricePercentTicksText = streamPricePercentTicksText;
    }

	public List<?> getGfObjects() {
		return gfObjects;
	}

	public void setGfObjects(List<?> gfObjects) {
		this.gfObjects = gfObjects;
	}

    

}
