/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.util;

import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.util.Properties;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.ssl.SSLContexts;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicSessionCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.fanniemae.access.sts.AWSFederationAccess;

public class MBSTradingPortalAWSUtil {
	
    public static String getDataFromS3(String filename) throws IOException, Exception {
    	Properties config = loadProps();
    	AmazonS3 s3 = initS3(config);
       	String txt = s3.getObjectAsString(config.getProperty("mbsp.aws.bucketName"), config.getProperty("mbsp.aws.bucketLocation") + "/" + filename);
		return txt;
	}

	public static Properties loadProps() throws IOException {
		Properties config = new Properties();
		String configFile = "config/application.properties";
		InputStream propInputStream = AWSFederationAccess.class.getClassLoader().getResourceAsStream(configFile);
		config.load(propInputStream);
		return config;
	}
	
	
	public static AmazonS3 initS3(Properties config) throws Exception {
			
		String pwd = config.getProperty("mbsp.aws.trustStorePassword");
		String trustStoreAPassword = new String(org.apache.commons.codec.binary.Base64.decodeBase64(pwd));
		String store = config.getProperty("mbsp.aws.trustStore");
		KeyStore trustKeyStore = KeyStore.getInstance("JKS");
        String userName = config.getProperty("mbsp.aws.userName");
        String passwd = config.getProperty("mbsp.aws.password");
        
		trustKeyStore.load(				
				AWSFederationAccess.class.getClassLoader().getResourceAsStream(store),
				trustStoreAPassword.toCharArray());
		SSLContext sslcontext = SSLContexts.custom().loadTrustMaterial(trustKeyStore, new TrustSelfSignedStrategy())
				.build();
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, new String[] { "TLSv1.2" }, null,
				SSLConnectionSocketFactory.getDefaultHostnameVerifier());
		
		AWSFederationAccess fedAccess = new AWSFederationAccess();
		BasicSessionCredentials sessionCredentials = fedAccess.getBasicSessionCredentials(userName, passwd, "DEVL-MBSP01-DEVELOPER");
		
		ClientConfiguration clientConf = new ClientConfiguration();
		clientConf.getApacheHttpClientConfig().setSslSocketFactory(sslsf);
		clientConf.setProtocol(Protocol.HTTPS);
		clientConf.setProxyHost("zsproxy.fanniemae.com");
		clientConf.setProxyPort(10479);
		BasicSessionCredentials basicSessionCredentials = new BasicSessionCredentials(
				sessionCredentials.getAWSAccessKeyId(), sessionCredentials.getAWSSecretKey(),
				sessionCredentials.getSessionToken());
		
		
		AmazonS3 s3Client = AmazonS3ClientBuilder.standard().
				withCredentials(new AWSStaticCredentialsProvider(basicSessionCredentials)).
				withClientConfiguration(clientConf).
				withRegion(Regions.US_EAST_1).
				build();
		return s3Client;
	}
	
}
