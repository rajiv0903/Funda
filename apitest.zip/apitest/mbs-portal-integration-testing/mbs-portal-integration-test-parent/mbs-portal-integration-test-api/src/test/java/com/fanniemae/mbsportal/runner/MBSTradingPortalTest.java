/*
 * 
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/**
 * 
 * @author Rajiv Chaudhuri
 * @Date: Mar 22, 2018
 * @File: com.fanniemae.mbsportal.runner.MBSTradingPortalTest.java
 * @Revision :
 * @Description: MBSTradingPortalTest.java
 */
@RunWith(Cucumber.class)

@CucumberOptions(plugin = { "pretty", "json:target/cucumber-api.json", "html:target/cucumber-api" }, glue = {
        "com.fanniemae.mbsportal.steps" },
        features = { 
                "src/test/resources/feature/MBSManageProduct.feature",
                "src/test/resources/feature/MBSValidateProductSettlement.feature",
                "src/test/resources/feature/MBSProductCoupon.feature",
                "src/test/resources/feature/MBSTraderViewExecutedTrade.feature",
                "src/test/resources/feature/MBSTradeRequestBuyFlow.feature",
                "src/test/resources/feature/MBSTradingPortal.feature",
                "src/test/resources/feature/MBSTradeCancelFlow.feature",
                "src/test/resources/feature/MBSTraderPassedRejectFlow.feature",
                "src/test/resources/feature/MBSTraderRepricedFlow.feature",
                "src/test/resources/feature/MBSTradingEventsPolling.feature",
                "src/test/resources/feature/MBSTraderLenderOpenFlow.feature",
                "src/test/resources/feature/MBSTraderLenderUILogging.feature",
                "src/test/resources/feature/MBSTradingTradeAmountValidation.feature",
                "src/test/resources/feature/MBSTradePricingValidation.feature",
                "src/test/resources/feature/MBSTradingVersioning.feature",
                "src/test/resources/feature/MBSTradeSymbolicEightValidation.feature",
                "src/test/resources/feature/TradeServiceFlow.feature",
                // "src/test/resources/feature/MBSProfileEntitlement.feature",
                "src/test/resources/feature/MBSTraderBypassGateway.feature",
                "src/test/resources/feature/MBSTradeActiveDirectoryRole.feature",
                "src/test/resources/feature/MBSTradingTradeTimeOut.feature",
                "src/test/resources/feature/MBSTspFlow.feature",
                "src/test/resources/feature/MBSTSPProfileEntitlement.feature",
                "src/test/resources/feature/MBSTradeReadOnlyFlow.feature",
                "src/test/resources/feature/MBSLenderReactivateCancel.feature",
                "src/test/resources/feature/MBSExportTraderTransactions.feature",
                "src/test/resources/feature/MBSExportLenderTransactions.feature",
                "src/test/resources/feature/MBSParty.feature",
                "src/test/resources/feature/MBSTradingWithStreamPrice.feature",
                "src/test/resources/feature/MBSTransactionHistory.feature",
                "src/test/resources/feature/MBSProductPricingDisable.feature"
                })
public class MBSTradingPortalTest {

}
