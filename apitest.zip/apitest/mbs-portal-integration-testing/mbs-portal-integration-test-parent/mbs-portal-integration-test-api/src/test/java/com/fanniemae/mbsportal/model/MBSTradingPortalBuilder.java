/*
 * 
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.model;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fanniemae.mbsportal.framework.ExcelSheetData;

/**
 * 
 * @author Rajiv Chaudhuri
 * @Date: Mar 22, 2018
 * @File: com.fanniemae.mbsportal.model.MBSTradingPortalBuilder.java
 * @Revision : 
 * @Description: MBSTradingPortalBuilder.java
 */
public class MBSTradingPortalBuilder {

    MBSTradingPortalBuilderModel model;

    public void createModel() {
        model = new MBSTradingPortalBuilderModel();
    }

    public MBSTradingPortalBuilderModel getModel() {
        return this.model;
    }

    public MBSTradingPortalBuilder withTransReqId(String transReqId) {
        model.setTransReqId(transReqId);
        return this;
    }

    public MBSTradingPortalBuilder withLenderId(String lenderId) {
        model.setLenderId(lenderId);
        return this;
    }

    public MBSTradingPortalBuilder withMessage(String message) {
        model.setMessage(message);
        return this;
    }

    public MBSTradingPortalBuilder withLookUpObj(JSONObject lookUpObj) {
        model.setLookUpObj(lookUpObj);
        return this;
    }

    public MBSTradingPortalBuilder withResObjects(JSONArray resObjects) {
        model.setResObjects(resObjects);
        return this;
    }

    public MBSTradingPortalBuilder withApiEndpoint(String apiEndpoint) {
        model.setApiEndpoint(apiEndpoint);
        return this;
    }
    
    public MBSTradingPortalBuilder withTradeServiceApiEndpoint(String tradeServiceApiEndpoint) {
        model.setTradeServiceApiEndpoint(tradeServiceApiEndpoint);
        return this;
    }

    public MBSTradingPortalBuilder withCurrentEndpoint(String currentEndpoint) {
        model.setCurrentEndpoint(currentEndpoint);
        return this;
    }

    public MBSTradingPortalBuilder withExcelDate(ExcelSheetData excelData) {
        model.setExcelData(excelData);
        return this;
    }

    public MBSTradingPortalBuilder withLookUpObjList(JSONObject lookUpObj) {
        model.getLookUpObjList().add(lookUpObj);
        return this;
    }

    public MBSTradingPortalBuilder withLookUpObjList(List<JSONObject> lookUpObjList) {
        model.getLookUpObjList().addAll(lookUpObjList);
        return this;
    }
    
    public MBSTradingPortalBuilder withCdxEndpoint(String cdxEndpoint) {
        model.setCdxEndpoint(cdxEndpoint);
        return this;
    }
    
    public MBSTradingPortalBuilder withCdxLoginEndPoint(String cdxLoginEndPoint) {
        model.setCdxLoginEndPoint(cdxLoginEndPoint);
        return this;
    }
    
    public MBSTradingPortalBuilder withCdxLogoutEndPoint(String cdxLogoutEndPoint) {
        model.setCdxLogoutEndPoint(cdxLogoutEndPoint);
        return this;
    }
    
    public MBSTradingPortalBuilder withActiveVersion(Long activeVersion) {
        model.setActiveVersion(activeVersion);
        return this;
    }
    
    public MBSTradingPortalBuilder withCdxFmnApiEndpoint(String cdxFmnApiEndpoint) {
        model.setCdxFmnApiEndpoint(cdxFmnApiEndpoint);
        return this;
    }
    
    public MBSTradingPortalBuilder withStreamPricePercentHandleText(String streamPricePercentHandleText) {
        model.setStreamPricePercentHandleText(streamPricePercentHandleText);
        return this;
    }
    
    public MBSTradingPortalBuilder withStreamPricePercentTicksText(String streamPricePercentTicksText) {
        model.setStreamPricePercentTicksText(streamPricePercentTicksText);
        return this;
    }
    
    public MBSTradingPortalBuilder withGFObjList(List<?> gfObjects) {
    	model.setGfObjects(gfObjects);
    	return this;
    }
}
