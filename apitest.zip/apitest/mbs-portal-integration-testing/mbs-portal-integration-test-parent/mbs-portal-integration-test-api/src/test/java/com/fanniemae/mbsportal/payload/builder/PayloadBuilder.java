/*
 * 
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.payload.builder;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * 
 * @author Rajiv Chaudhuri
 * @Date: Mar 22, 2018
 * @File: com.fanniemae.mbsportal.payload.builder.PayloadBuilder.java
 * @Revision : 
 * @Description: PayloadBuilder.java
 */
public abstract class PayloadBuilder {

    public JSONObject getPayload(LinkedHashMap<String, String> mapData, String content) throws Exception {
        // To Maintain the order
        LinkedHashSet<String> keyset = new LinkedHashSet<>();

        for (String key : mapData.keySet()) {
            keyset.add("#" + key);
        }
        String[] searchList = keyset.toArray(new String[keyset.size()]);
        String[] replacementList = mapData.values().toArray(new String[mapData.keySet().size()]);

        String json = StringUtils.replaceEachRepeatedly(content, searchList, replacementList);

        JSONObject jsonObj = new JSONObject(json);

        return jsonObj;
    }
    
    public JSONArray getPayloadArray(LinkedHashMap<String, String> mapData, String content) throws Exception {
        // To Maintain the order
        LinkedHashSet<String> keyset = new LinkedHashSet<>();

        for (String key : mapData.keySet()) {
            keyset.add("#" + key);
        }
        String[] searchList = keyset.toArray(new String[keyset.size()]);
        String[] replacementList = mapData.values().toArray(new String[mapData.keySet().size()]);
        //Making it an array intead of in the JSON template, as having JSON array template is causing issue in cucumber plugin
        String newContentArray = "["+content+"]";
        String json = StringUtils.replaceEachRepeatedly(newContentArray, searchList, replacementList);

        JSONArray jsonObj = new JSONArray(json);

        return jsonObj;
    }

}
