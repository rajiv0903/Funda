/*
 * 
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.payload.builder;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author Rajiv Chaudhuri
 * @Date: Mar 22, 2018
 * @File: com.fanniemae.mbsportal.payload.builder.PayloadBuilderFactory.java
 * @Revision : 
 * @Description: PayloadBuilderFactory.java
 */
public class PayloadBuilderFactory {

    static Map<String, Object> builders = new HashMap<>();

    static {
        try {
            builders.put("INPUT_LENDER_TRADING_POST",
                    Class.forName("com.fanniemae.mbsportal.payload.builder.LenderTradingPostPayload").newInstance());
            builders.put("INPUT_TRADE_SERVICE_POST",
                    Class.forName("com.fanniemae.mbsportal.payload.builder.LenderTradingPostPayload").newInstance());
            builders.put("INPUT_LENDER_PARTY_POST",
                    Class.forName("com.fanniemae.mbsportal.payload.builder.LenderPartyPostPayload").newInstance());
            builders.put("INPUT_PRODUCT_PRICING_DISABLE",
                    Class.forName("com.fanniemae.mbsportal.payload.builder.ProductPricingCouponEnableDisable").newInstance());
            builders.put("INPUT_PRODUCT_PRICING_ENABLE",
                    Class.forName("com.fanniemae.mbsportal.payload.builder.ProductPricingCouponEnableDisable").newInstance());
        } catch (Exception exe) {
            exe.printStackTrace();
            System.err.println("Failed to initialized the builder class");
        }
    }

    public static PayloadBuilder getPayloadBuilder(String teamplate) throws Exception {
        if (!builders.containsKey(teamplate)) {
            throw new Exception(String.format("No class found for the Key {%s}", teamplate));
        }
        return (PayloadBuilder) builders.get(teamplate);
    }

}
