package com.fanniemae.mbsportal.util;

public class MBSTradingPortalConstants {
	
	public static final String YES = "YES";

    public static final String DATE_FORMAT_1 = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
    public static final String DATE_FORMAT_2 = "yyyy-MM-dd";
    public static final String DATE_FORMAT_3 = "M/d/YY";
    public static final String DATE_FORMAT_4 = "EEE MMM d HH:mm:ss zzz yyyy";
    public static final String DATE_FORMAT_5 = "yyyy:MM:dd";
    public static final String TRADE_SUBMISSION_DATE = "TRADE_SUBMISSION_DATE";

    public static final String CURRENT_DATE_MONTH = "CURRENT_DATE_MONTH";

    public static final String PROP_KEY_API_ENDPOINT = "api.endpoint";
    public static final String PROP_KEY_TRADE_SERVICE_API_ENDPOINT = "tradeservice.api.endpoint";
    public static final String PROP_KEY_CDX_FMN_API_LOGIN = "cdx.fmn.api.endpoint";
    
    //CDX Related Properties
    public static final String PROP_KEY_CDX_API_ENDPOINT = "cdx.api.endpoint";
    public static final String PROP_KEY_CDX_API_LOGIN = "cdx.api.endpoint.cdxlogin";
    public static final String PROP_KEY_CDX_API_LOGOUT = "cdx.api.endpoint.cdxlogout";
    public static final String PROP_KEY_CDX_API_LENDER_AUTHENTICATION = "cdx.api.authentication.lender";
    public static final String PROP_KEY_CDX_API_TRADER_AUTHENTICATION = "cdx.api.authentication.trader";
    public static final String PROP_KEY_CDX_API_TSP_AUTHENTICATION = "cdx.api.authentication.tsp";
    public static final String PROP_KEY_CDX_API_READONLY_TRADER_AUTHENTICATION = "cdx.api.authentication.readonly.trader";
    public static final String PROP_KEY_CDX_API_PROXY_HOST="cdx.api.proxy.host";
    public static final String PROP_KEY_CDX_API_PROXY_PORT="cdx.api.proxy.port";
    
    public static final String LENDER = "LENDER";
    public static final String TRADER = "TRADER";
    
    
    public static final String REPLACE_TRANSACTION_ID = "REPLACE_TRANSACTION_ID";
    public static final String REPLACE_EVENTS_DATE_TIME = "REPLACE_EVENTS_DATE_TIME";
    public static final String REPLACE_FNMA_LENDER_SESSION_ID = "REPLACE_FNMA_LENDER_SESSION_ID";
    public static final String REPLACE_FNMA_TRADER_SESSION_ID = "REPLACE_FNMA_TRADER_SESSION_ID";
    public static final String REPLACE_CURRENT_DATE = "REPLACE_CURRENT_DATE";
    public static final String REPLACE_CURRENT_DATE_MINUS_30 = "REPLACE_CURRENT_DATE_MINUS_30";
    public static final String REPLACE_CURRENT_DATE_PLUS_1 = "REPLACE_CURRENT_DATE_PLUS_1";
    public static final String REPLACE_CURRENT_DATE_MINUS_400 = "REPLACE_CURRENT_DATE_MINUS_400";
    public static final String REPLACE_CURRENT_DATE_MINUS_400_WITH_WRONG_FORMAT = "REPLACE_CURRENT_DATE_MINUS_400_WITH_WRONG_FORMAT";
    public static final String REPLACE_CURRENT_DATE_WITH_WRONG_FORMAT = "REPLACE_CURRENT_DATE_WITH_WRONG_FORMAT";
    public static final String REPLACE_CURRENT_DATE_PLUS_400 = "REPLACE_CURRENT_DATE_PLUS_400";
    
    public static final String REPLACE_PRODUCT_SOURCE_TYPE = "REPLACE_PRODUCT_SOURCE_TYPE";
    public static final String REPLACE_PRODUCT_TYPE = "REPLACE_PRODUCT_TYPE";
    
    public static final String REPLACE_PRODUCT_ID_0 = "REPLACE_PRODUCT_ID_0";
    public static final String REPLACE_PRODUCT_COUPON_0 = "REPLACE_PRODUCT_COUPON_0";
    public static final String REPLACE_PRODUCT_SETTLEMNET_DATE_0= "REPLACE_PRODUCT_SETTLEMNET_DATE_0";
    
    public static final String REPLACE_PRODUCT_ID_1 = "REPLACE_PRODUCT_ID_1";
    public static final String REPLACE_PRODUCT_COUPON_1 = "REPLACE_PRODUCT_COUPON_1";
    public static final String REPLACE_PRODUCT_SETTLEMNET_DATE_1 = "REPLACE_PRODUCT_SETTLEMNET_DATE_1";
    
    public static final String REPLACE_PRODUCT_ID_2 = "REPLACE_PRODUCT_ID_2";
    public static final String REPLACE_PRODUCT_COUPON_2 = "REPLACE_PRODUCT_COUPON_2";
    public static final String REPLACE_PRODUCT_SETTLEMNET_DATE_2 = "REPLACE_PRODUCT_SETTLEMNET_DATE_2";
    
    public static final String MBSP_PRODUCT_ID_0 = "mbsp.product.id.0";
    public static final String MBSP_PRODUCT_COUPON_0 = "mbsp.product.coupon.0";
    public static final String MBSP_PRODUCT_SETTLEMNET_DATE_0 = "mbsp.product.settlementdate.0";
    
    public static final String MBSP_PRODUCT_ID_1 = "mbsp.product.id.1";
    public static final String MBSP_PRODUCT_COUPON_1 = "mbsp.product.coupon.1";
    public static final String MBSP_PRODUCT_SETTLEMNET_DATE_1 = "mbsp.product.settlementdate.1";
    
    public static final String MBSP_PRODUCT_ID_2 = "mbsp.product.id.2";
    public static final String MBSP_PRODUCT_COUPON_2 = "mbsp.product.coupon.2";
    public static final String MBSP_PRODUCT_SETTLEMNET_DATE_2 = "mbsp.product.settlementdate.2";
    
    
    
    public static final String MBSP_PRODUCT_SOURCE_TYPE= "mbsp.product.sourcetype";
    public static final String MBSP_PRODUCT_TYPE = "mbsp.product.type";
}
