/*
 * 
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.framework;

import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.fanniemae.mbsportal.util.MBSTradingPortalConstants;
import com.fanniemae.mbsportal.util.MBSTradingPortalUtil;

/**
 * 
 * @author Rajiv Chaudhuri
 * @Date: Mar 22, 2018
 * @File: com.fanniemae.mbsportal.framework.ExcelSheetReader.java
 * @Revision : 
 * @Description: ExcelSheetReader.java
 */
public class ExcelSheetReader {

    static volatile Map<String, ExcelSheetData> excelData = new LinkedHashMap<>();

    public enum ColumnNameIndex {
		TEST_CASE(0), COMMENTS(1), METHOD(2), ENDPOINT(3), PATH_VARIABLE(4), PATH_VARIABLE_VALUE(5), REQUEST_PARAM(
				6), REQUEST_PARAM_VALUE(7), CODE(8), INPUT_PROP(9), INPUT_VALUE(10), OUTPUT_PROP(
						11), OUTPUT_VALUE(12), MESSAGE(13), BODY_TEMPLATE(14), HEADER(15), HEADER_VALUE(16),
		TIME_LAPSE(17), JSON_BODY_IN_ARRAY(18);

        private final int value;

        private ColumnNameIndex(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }
    
    static Map<String, String> excelHeaderMap = new LinkedHashMap<>();
    static{
    	excelHeaderMap.put("ACCEPT", "Accept");
    	excelHeaderMap.put("FNMA_CHANNEL", "x-fnma-channel");
    	excelHeaderMap.put("FNMA_SUB_CHANNEL", "x-fnma-sub-channel");
    	excelHeaderMap.put("FNMA_SESSION_ID", "x-fnma-sessionid");
    	excelHeaderMap.put("USER_NAME", "username");
    	excelHeaderMap.put("AUTHORIZATION_HEADER", "Authorization");
    }

    /**
     * @author gaur5c
     * @Description: Get the data for the case from same work sheet
     */
    public static synchronized ExcelSheetData getRestRequestData(String testCase) {
        return excelData.get(testCase);
    }

    /**
     * @author gaur5c
     * @Description:Read Excel Sheet Data for the work book
     */
    public static synchronized void readTestData(String workSheet) throws Exception {
        excelData.clear();

        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        InputStream stream = loader.getResourceAsStream("excel/MBS_TRADING_PORTAL_API_DATA.xlsx");
        XSSFWorkbook workbook = new XSSFWorkbook(stream);

//         FileInputStream file = new
//         FileInputStream("C:/Rajiv/MBS_TRADING_PORTAL_API_DATA.xlsx");
//         XSSFWorkbook workbook = new XSSFWorkbook(file);

        XSSFSheet sheet = workbook.getSheet(workSheet);

        String caseID = null;
        for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
            XSSFRow currentRow = sheet.getRow(i);
            String value;
            String value1;

            // Case
            if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.TEST_CASE.value))) {
                caseID = getCellValue(currentRow.getCell(ColumnNameIndex.TEST_CASE.value));
                ExcelSheetData data = new ExcelSheetData();

                data.setScenario(workSheet);
                data.setTestCase(caseID);

                excelData.put(caseID, data);
            }
            // ENDPOINT
            if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.ENDPOINT.value))) {
                value = getCellValue(currentRow.getCell(ColumnNameIndex.ENDPOINT.value));
                excelData.get(caseID).setEndPoint(value);
            }

            // PATH_VARIABLE & PATH_VARIABLE_VALUE
            if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.PATH_VARIABLE.value))
                    && cellNotEmpty(currentRow.getCell(ColumnNameIndex.PATH_VARIABLE_VALUE.value))) {
                value = getCellValue(currentRow.getCell(ColumnNameIndex.PATH_VARIABLE.value));
                value1 = "";
                if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.PATH_VARIABLE_VALUE.value))) {
                    value1 = getCellValue(currentRow.getCell(ColumnNameIndex.PATH_VARIABLE_VALUE.value));
                }
                excelData.get(caseID).getPathVariableMap().put(value, value1);
            }

            // COMMENTS
            if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.COMMENTS.value))) {
                value = getCellValue(currentRow.getCell(ColumnNameIndex.COMMENTS.value));
                excelData.get(caseID).setComments(value);
            }
            // METHOD
            if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.METHOD.value))) {
                value = getCellValue(currentRow.getCell(ColumnNameIndex.METHOD.value));
                excelData.get(caseID).setHttpMethod(value);
            }
            // REQUEST_PARAM & REQUEST_PARAM_VALUE
            if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.REQUEST_PARAM.value))
                    && cellNotEmpty(currentRow.getCell(ColumnNameIndex.REQUEST_PARAM_VALUE.value))) {
                value = getCellValue(currentRow.getCell(ColumnNameIndex.REQUEST_PARAM.value));
                value1 = getCellValue(currentRow.getCell(ColumnNameIndex.REQUEST_PARAM_VALUE.value));
                excelData.get(caseID).getReqParamMap().put(ExcelSheetParamEnum.getIntProp(value), value1);
            }
            // CODE
            if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.CODE.value))) {
                value = getCellValue(currentRow.getCell(ColumnNameIndex.CODE.value));
                excelData.get(caseID).setCode(value);
            }
            // INPUT_PROP & INPUT_VALUE
            if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.INPUT_PROP.value))
            // && cellNotEmpty(currentRow.getCell(7))
            ) {
                value = getCellValue(currentRow.getCell(ColumnNameIndex.INPUT_PROP.value));
                value1 = "";
                if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.INPUT_VALUE.value))) {
                    value1 = getCellValue(currentRow.getCell(ColumnNameIndex.INPUT_VALUE.value));
                }
                if (MBSTradingPortalConstants.TRADE_SUBMISSION_DATE.equalsIgnoreCase(value1)) {
                    value1 = MBSTradingPortalUtil.getCurrentDate();
                }
                excelData.get(caseID).getInputPropMap().put(ExcelSheetParamEnum.getIntProp(value), value1.trim());

            }
            // OUTPUT_PROP & OUTPUT_VALUE
            if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.OUTPUT_PROP.value))
            // && cellNotEmpty(currentRow.getCell(9))
            ) {
                value = getCellValue(currentRow.getCell(ColumnNameIndex.OUTPUT_PROP.value));
                value1 = "";
                if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.OUTPUT_VALUE.value))) {
                    value1 = getCellValue(currentRow.getCell(ColumnNameIndex.OUTPUT_VALUE.value));
                }
                if (MBSTradingPortalConstants.TRADE_SUBMISSION_DATE.equalsIgnoreCase(value1)) {
                    value1 = MBSTradingPortalUtil.getCurrentDate();
                }
                excelData.get(caseID).getOutputPropMap().put(ExcelSheetParamEnum.getIntProp(value), value1.trim());
            }
            // MESSAGE
            if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.MESSAGE.value))) {
                value = getCellValue(currentRow.getCell(ColumnNameIndex.MESSAGE.value));
                excelData.get(caseID).setMessage(value);
            }
            // BODY_TEMPLATE
            if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.BODY_TEMPLATE.value))) {
                value = getCellValue(currentRow.getCell(ColumnNameIndex.BODY_TEMPLATE.value));
                excelData.get(caseID).setBodyTemplate(value);
            }
            
            // HEADER & HEADER_VALUE
            if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.HEADER.value))
            ) {
                value = getCellValue(currentRow.getCell(ColumnNameIndex.HEADER.value));
                value1 = "";
                if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.HEADER_VALUE.value))) {
                    value1 = getCellValue(currentRow.getCell(ColumnNameIndex.HEADER_VALUE.value));
                }
                excelData.get(caseID).getReqHeaderMap().put(excelHeaderMap.get(value), value1.trim());
            }
            
            // TIME_LAPSE
            if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.TIME_LAPSE.value))
            ) {
            	value = getCellValue(currentRow.getCell(ColumnNameIndex.TIME_LAPSE.value));
                excelData.get(caseID).setTimeLapse(value);
            }
            
            
            // JSON_BODY_IN_ARRAY
            if (cellNotEmpty(currentRow.getCell(ColumnNameIndex.JSON_BODY_IN_ARRAY.value))
            ) {
            	value = getCellValue(currentRow.getCell(ColumnNameIndex.JSON_BODY_IN_ARRAY.value));
            	if(value != null & MBSTradingPortalConstants.YES.equalsIgnoreCase(value)){
            		excelData.get(caseID).setReqBodyInArray(true);
            		
            	}
            }

        }

        // for (Map.Entry<String, ExcelSheetData> entry : excelData.entrySet())
        // {
        // String key = entry.getKey();
        // ExcelSheetData value = (ExcelSheetData)entry.getValue();
        // System.out.println("Key:"+key);
        // System.out.println("value:"+value);
        // }
    }

    private static String getCellValue(XSSFCell currentCell) {
        String value = null;
        switch (currentCell.getCellType()) {
        case XSSFCell.CELL_TYPE_STRING:
            value = currentCell.getStringCellValue();
            break;
        case XSSFCell.CELL_TYPE_NUMERIC:
            currentCell.setCellType(XSSFCell.CELL_TYPE_STRING);
            value = currentCell.getStringCellValue();
            break;
        case XSSFCell.CELL_TYPE_BOOLEAN:
        	currentCell.setCellType(XSSFCell.CELL_TYPE_STRING);
            value = currentCell.getStringCellValue();
            break;
        }
        return value;

    }

    private static boolean cellNotEmpty(XSSFCell currentCell) {

        if (currentCell == null || currentCell.getCellType() == XSSFCell.CELL_TYPE_BLANK) {
            return false;
        } else {
            return true;
        }
    }

}
