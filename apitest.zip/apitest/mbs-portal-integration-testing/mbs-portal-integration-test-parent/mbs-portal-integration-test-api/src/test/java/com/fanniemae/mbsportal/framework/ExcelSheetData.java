/*
 * 
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.framework;

import java.util.LinkedHashMap;

/**
 * 
 * @author Rajiv Chaudhuri
 * @Date: Mar 22, 2018
 * @File: com.fanniemae.mbsportal.framework.ExcelSheetData.java
 * @Revision : 
 * @Description: ExcelSheetData.java
 */
public class ExcelSheetData {

    private String scenario;
    private String testCase;
    private String comments;
    private String httpMethod;
    private String endPoint;
    private LinkedHashMap<String, String> pathVariableMap = new LinkedHashMap<>();
    private LinkedHashMap<String, String> reqParamMap = new LinkedHashMap<>();
    private String code;
    private LinkedHashMap<String, String> inputPropMap = new LinkedHashMap<>();
    private LinkedHashMap<String, String> outputPropMap = new LinkedHashMap<>();
    private String message;
    private String bodyTemplate;
    private String timeLapse;
    private boolean reqBodyInArray;
    
    private LinkedHashMap<String, String> reqHeaderMap = new LinkedHashMap<>();

    public String getScenario() {
        return scenario;
    }

    public void setScenario(String scenario) {
        this.scenario = scenario;
    }

    public String getTestCase() {
        return testCase;
    }

    public void setTestCase(String testCase) {
        this.testCase = testCase;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getHttpMethod() {
        return httpMethod;
    }

    public void setHttpMethod(String httpMethod) {
        this.httpMethod = httpMethod;
    }

    public String getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(String endPoint) {
        this.endPoint = endPoint;
    }

    public LinkedHashMap<String, String> getPathVariableMap() {
        return pathVariableMap;
    }

    public void setPathVariableMap(LinkedHashMap<String, String> pathVariableMap) {
        this.pathVariableMap = pathVariableMap;
    }

    public LinkedHashMap<String, String> getReqParamMap() {
        return reqParamMap;
    }

    public void setReqParamMap(LinkedHashMap<String, String> reqParamMap) {
        this.reqParamMap = reqParamMap;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public LinkedHashMap<String, String> getInputPropMap() {
        return inputPropMap;
    }

    public void setInputPropMap(LinkedHashMap<String, String> inputPropMap) {
        this.inputPropMap = inputPropMap;
    }

    public LinkedHashMap<String, String> getOutputPropMap() {
        return outputPropMap;
    }

    public void setOutputPropMap(LinkedHashMap<String, String> outputPropMap) {
        this.outputPropMap = outputPropMap;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getBodyTemplate() {
        return bodyTemplate;
    }

    public void setBodyTemplate(String bodyTemplate) {
        this.bodyTemplate = bodyTemplate;
    }
    
	public String getTimeLapse() {
		return timeLapse;
	}

	public void setTimeLapse(String timeLapse) {
		this.timeLapse = timeLapse;
	}

	public LinkedHashMap<String, String> getReqHeaderMap() {
		return reqHeaderMap;
	}

	public void setReqHeaderMap(LinkedHashMap<String, String> reqHeaderMap) {
		this.reqHeaderMap = reqHeaderMap;
	}

	public boolean isReqBodyInArray() {
		return reqBodyInArray;
	}

	public void setReqBodyInArray(boolean reqBodyInArray) {
		this.reqBodyInArray = reqBodyInArray;
	}

	@Override
    public String toString() {
        return "ExcelSheetData [scenario=" + scenario + ", testCase=" + testCase + ", comments=" + comments
                + ", httpMethod=" + httpMethod + ", endPoint=" + endPoint + ", pathVariableMap=" + pathVariableMap
                + ", reqParamMap=" + reqParamMap + ", code=" + code + ", inputPropMap=" + inputPropMap
                + ", outputPropMap=" + outputPropMap + ", message=" + message + ", bodyTemplate=" + bodyTemplate + ", timeLapse=" + timeLapse + ", reqHeaderMap=" + reqHeaderMap+ "]";
    }

}
