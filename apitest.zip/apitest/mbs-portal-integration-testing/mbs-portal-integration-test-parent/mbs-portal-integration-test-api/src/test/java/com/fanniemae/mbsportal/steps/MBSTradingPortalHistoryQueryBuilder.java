package com.fanniemae.mbsportal.steps;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.fanniemae.mbsportal.util.MBSTradingPortalUtil;
import com.fanniemae.mbsportal.utils.exception.MBSBaseException;

public class MBSTradingPortalHistoryQueryBuilder {
	
	public static String getMBSTradeQuery(List<String> transIdLst, List<Object> queryArgsLst) {
    	StringBuilder query = new StringBuilder();
    	query.append(buildFilterQuery("transReqNumber", transIdLst, "IN", queryArgsLst));
    	return query.toString();
	}

    public static String getMBSTransReqHistoryQuery(String mbsRoleType,
            boolean accepted, String sellerServiceNumber, List<Object> queryArgsLst) {
        List<String> strStateTypeLst = createStateTypeStringList(accepted);
        // create the param args here
        Map<String, List<String>> mbsFilterLst = new HashMap<>();
        //Filter for stateType
        
        mbsFilterLst.put("stateType", strStateTypeLst);
        //Filter for users
        //CMMBSSTA01-1373 - Adding TSP name - Start
        List<String> sellerServiceNumberLst = new ArrayList();                                  
        sellerServiceNumberLst.add(sellerServiceNumber);
        if(mbsRoleType.equalsIgnoreCase("Lender")){
            mbsFilterLst.put("lenderSellerServiceNumber", sellerServiceNumberLst);
        } else if (mbsRoleType.equalsIgnoreCase("TSP")){
            mbsFilterLst.put("tspSellerServiceNumber", sellerServiceNumberLst);
        }
        
        
        //CMMBSSTA01-1373 - Adding TSP name - End
        //Filter based on date
        int cutOffDays = -90;
        List<String> subDateLst = new ArrayList<>();
        subDateLst.add(MBSTradingPortalUtil.getCurrentDate(cutOffDays, MBSTradingPortalUtil.DATE_FORMAT_NO_TIMESTAMP));
        mbsFilterLst.put("tradeSettlementDate", subDateLst);
        mbsFilterLst.put("lenderShortName",Arrays.asList("TEST-I"));
        return createQuery(mbsFilterLst, queryArgsLst).toString();
    }

	private static List<String> createStateTypeStringList(boolean accepted) {
		List<String> stateTypes = new ArrayList<>();
		if (!accepted) {
	        stateTypes.add("LENDER_REJECTED");
	        stateTypes.add("TRADER_PASSED");
	        stateTypes.add("TRADER_REJECTED");
	        stateTypes.add("TRADER_CONFIRMED");
	        stateTypes.add("EXECUTION_IN_PROGRESS");
	        stateTypes.add("PENDING_EXECUTION");
	        stateTypes.add("EXECUTED");
	        stateTypes.add("LENDER_TIMEOUT");
	        stateTypes.add("TRADER_TIMEOUT");
		} else {
	        stateTypes.add("TRADER_CONFIRMED");
	        stateTypes.add("EXECUTION_IN_PROGRESS");
	        stateTypes.add("PENDING_EXECUTION");
	        stateTypes.add("EXECUTED");
        }
		return stateTypes;
	}
	
	private static StringBuilder createQuery(Map<String, List<String>> mbsFilterLst, List<Object> queryArgsLst) {
    	StringBuilder query = new StringBuilder();
    	for (String key : mbsFilterLst.keySet()) {
    		switch (key) {
    		case "stateType":
    		case "lenderSellerServiceNumber":
    		case "tspSellerServiceNumber":
    			query.append(buildFilterQuery(key, mbsFilterLst.get(key), "IN", queryArgsLst));
    			break;
    		case "lenderShortName":
    			query.append(buildFilterQuery(key, mbsFilterLst.get(key), "NOT IN", queryArgsLst));
    			break;
    		case "tradeSettlementDate":
    			query.append(buildFilterQuery(key, mbsFilterLst.get(key), "GREATER THAN", queryArgsLst));
    			break;
    		}
    		query.append(" AND ");
    	}
        query.delete(query.length() - 5, query.length());
    	
		return query;
	}

	private static String buildFilterQuery(String key, List<String> list, String operator, List<Object> queryArgsLst) {
		StringBuilder query = new StringBuilder();
        int counter = 1;
        if (Objects.nonNull(queryArgsLst)) {
            counter = queryArgsLst.size() + 1;
        }
		if (operator.equals("NOT IN")) {
			query.append(" NOT (").append(key).append(" ");
	        query.append("IN SET( "); // "counterpartyTraderIdentifier
	        // in
//            for (String value : list) {
//                query.append("$").append(counter).append(", ");
//                queryArgsLst.add(value);
//                counter++;
//            }
	        for (String value : list) {
	        	query.append("'").append(value).append("', ");
	        }
	        // remove the last comma
	        query.deleteCharAt(query.length() - 2);
	        query.append(" )) ");
		} else if (operator.equals("GREATER THAN")) {
			query.append(" ").append(key).append(" ");
			query.append("> ");
        	query.append("DATE '").append(list.get(0)).append("' ");
//            query.append("$").append(counter).append(" ");
//            queryArgsLst.add(list.get(0));
//            counter++;
		} else if (operator.equals("IN")){
			query.append(" ").append(key).append(" ");
	        query.append(operator).append(" SET( "); // "counterpartyTraderIdentifier
	        // in
//            for (String value : list) {
//                query.append("$").append(counter).append(", ");
//                queryArgsLst.add(value);
//                counter++;
//            }
	        for (String value : list) {
	        	query.append("'").append(value).append("', ");
	        }
	        // remove the last comma
	        query.deleteCharAt(query.length() - 2);
	        query.append(" ) ");
		}
		return query.toString();
	}
}
