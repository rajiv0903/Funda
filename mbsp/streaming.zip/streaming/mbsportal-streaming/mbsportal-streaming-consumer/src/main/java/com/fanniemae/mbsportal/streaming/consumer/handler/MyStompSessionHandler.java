package com.fanniemae.mbsportal.streaming.consumer.handler;


import java.lang.reflect.Type;

import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandlerAdapter;

import com.fanniemae.mbsportal.streaming.consumer.message.po.SampleMessage;

public class MyStompSessionHandler extends StompSessionHandlerAdapter {

    @Override
    public void afterConnected(StompSession session, StompHeaders connectedHeaders) {
        System.out.println("New session established : " + connectedHeaders);
        System.out.println("New session established : " + session.getSessionId());
        session.subscribe("/mbsp/topic/transaction/trader", this);
//        System.out.println("Subscribed to /topic/messages");
//        session.send("/mbsp/topic/transaction", getSampleMessage());
//        System.out.println("Message sent to websocket server");
    }

    @Override
    public void handleException(StompSession session, StompCommand command, StompHeaders headers, byte[] payload, Throwable exception) {
        System.out.println("Got an exception"+ exception);
        exception.printStackTrace();
    }

    @Override
    public Type getPayloadType(StompHeaders headers) {
        return String.class;
        // return Message.class;
    }

    @Override
    public void handleFrame(StompHeaders headers, Object payload) {
        // Message msg = (Message) payload;
        String msg = (String) payload;
        System.out.println("headers : " +headers);
        System.out.println("Received : " +msg);
    }

    /**
     * A sample message instance.
     * @return instance of <code>Message</code>
     */
    private SampleMessage getSampleMessage() {
        SampleMessage msg = new SampleMessage();
        msg.setFrom("Nicky");
        msg.setText("Howdy!!");
        return msg;
    }
}
