package com.fanniemae.mbsportal.streaming.consumer.client;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.springframework.messaging.converter.StringMessageConverter;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSessionHandler;
import org.springframework.web.socket.WebSocketHttpHeaders;
import org.springframework.web.socket.client.WebSocketClient;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;
import org.springframework.web.socket.sockjs.client.SockJsClient;
import org.springframework.web.socket.sockjs.client.Transport;
import org.springframework.web.socket.sockjs.client.WebSocketTransport;

import com.fanniemae.mbsportal.streaming.consumer.handler.MyStompSessionHandler;



public class StreamingWebSocketClient2 {
    
    private static String URL = "wss://dlv-fmn-a001.fanniemae.com:8443/mbsp-streaming";
    
    static {
        disableSslVerification();
    }
    public static void main(String[] args) throws Exception{
        
//       System.setProperty("javax.net.ssl.keyStore", "C:/Rajiv/mbs-stream.jks");
//       System.setProperty("javax.net.ssl.keyStorePassword", "streamservice");
        
        System.setProperty("javax.net.ssl.keyStore", "C:/Rajiv/mbs.jks");
        System.setProperty("javax.net.ssl.keyStorePassword", "password");
       
       //WebSocketClient client = new StandardWebSocketClient();
       //WebSocketStompClient stompClient = new WebSocketStompClient(client);
       
       List<Transport> transports = new ArrayList<>(1);
       transports.add(new WebSocketTransport( new StandardWebSocketClient()) );
       SockJsClient sockJsClient = new SockJsClient(transports);
       
       
       
       sockJsClient.setHttpHeaderNames("x-fnma-channel", "x-fnma-sub-channel", "x-fnma-sessionid");
       
//       MyWebSocketHandler myWebSocketHandler = new MyWebSocketHandler();
//       sockJsClient.doHandshake(myWebSocketHandler, URL);
//       
       WebSocketClient transport = sockJsClient;
       WebSocketStompClient stompClient = new WebSocketStompClient(transport);
       
       //Message Converter
       //stompClient.setMessageConverter(new MappingJackson2MessageConverter());
       stompClient.setMessageConverter(new StringMessageConverter());

       StompSessionHandler sessionHandler = new MyStompSessionHandler();
       
       
       String sessionId = "725fcedb-3039-4ec7-8579-b3c3539daeac";
       
       WebSocketHttpHeaders webSocketHttpHeaders = new WebSocketHttpHeaders();
       webSocketHttpHeaders.add("x-fnma-channel", "web");
       webSocketHttpHeaders.add("x-fnma-sub-channel", "MBSP");
       webSocketHttpHeaders.add("x-fnma-sessionid",sessionId);
       
       
       StompHeaders stompHeaders = new StompHeaders();
       stompHeaders.add("x-fnma-channel", "web");
       stompHeaders.add("x-fnma-sub-channel", "MBSP");
       stompHeaders.add("x-fnma-sessionid", sessionId);
       
       
       stompClient.connect(URL, webSocketHttpHeaders, stompHeaders, sessionHandler);
       

       new Scanner(System.in).nextLine(); // Don't close immediately.
    }
    
    private static void disableSslVerification() {
        try
        {
            // Create a trust manager that does not validate certificate chains
            TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }
                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            }
            };

            // Install the all-trusting trust manager
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            // Create all-trusting host name verifier
            HostnameVerifier allHostsValid = new HostnameVerifier() {
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };

            // Install the all-trusting host verifier
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        }
    }

}
