package com.fanniemae.mbsportal.streaming.consumer.client;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.springframework.messaging.converter.StringMessageConverter;
import org.springframework.messaging.simp.stomp.StompSessionHandler;
import org.springframework.web.socket.WebSocketHttpHeaders;
import org.springframework.web.socket.client.WebSocketClient;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;
import org.springframework.web.socket.sockjs.client.SockJsClient;
import org.springframework.web.socket.sockjs.client.Transport;
import org.springframework.web.socket.sockjs.client.WebSocketTransport;

import com.fanniemae.mbsportal.streaming.consumer.handler.MyStompSessionHandler;



public class StreamingWebSocketClient {
    
    private static String URL = "wss://dlv-fmn-a001.fanniemae.com:8443/mbsp-streaming";
    
    static {
        disableSslVerification();
    }
    public static void main(String[] args) throws Exception{
        
//       System.setProperty("javax.net.ssl.keyStore", "C:/Rajiv/mbs-stream.jks");
//       System.setProperty("javax.net.ssl.keyStorePassword", "streamservice");
        
        System.setProperty("javax.net.ssl.keyStore", "C:/Rajiv/mbs.jks");
        System.setProperty("javax.net.ssl.keyStorePassword", "password");
       
       //WebSocketClient client = new StandardWebSocketClient();
       //WebSocketStompClient stompClient = new WebSocketStompClient(client);
       
       List<Transport> transports = new ArrayList<>(1);
       transports.add(new WebSocketTransport( new StandardWebSocketClient()) );
       SockJsClient sockJsClient = new SockJsClient(transports);
       
       
       
       sockJsClient.setHttpHeaderNames("x-fnma-channel", "x-fnma-sub-channel", "x-fnma-sessionid");
       
       WebSocketClient transport = sockJsClient;
       WebSocketStompClient stompClient = new WebSocketStompClient(transport);
       
       
       //stompClient.setMessageConverter(new MappingJackson2MessageConverter());
       stompClient.setMessageConverter(new StringMessageConverter());

       StompSessionHandler sessionHandler = new MyStompSessionHandler();
       
       WebSocketHttpHeaders webSocketHttpHeaders = new WebSocketHttpHeaders();
       webSocketHttpHeaders.add("x-fnma-channel", "web");
       webSocketHttpHeaders.add("x-fnma-sub-channel", "MBSP");
       webSocketHttpHeaders.add("x-fnma-sessionid", "0cb35dd3-2a65-417d-9fe3-bbf4117f0ae2");
       
       stompClient.connect(URL, webSocketHttpHeaders,  sessionHandler);
       

       new Scanner(System.in).nextLine(); // Don't close immediately.
    }
    
    private static void disableSslVerification() {
        try
        {
            // Create a trust manager that does not validate certificate chains
            TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }
                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            }
            };

            // Install the all-trusting trust manager
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            // Create all-trusting host name verifier
            HostnameVerifier allHostsValid = new HostnameVerifier() {
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };

            // Install the all-trusting host verifier
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        }
    }

}
