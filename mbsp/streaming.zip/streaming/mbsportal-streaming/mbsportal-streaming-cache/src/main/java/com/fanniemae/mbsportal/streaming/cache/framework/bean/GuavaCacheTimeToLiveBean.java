/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.cache.framework.bean;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.FactoryBean;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 10, 2018
 * @File: com.fanniemae.mbsportal.streaming.cache.GuavaCacheFactoryBean.java
 * @Revision:
 * @Description: GuavaCacheFactoryBean.java
 */
public class GuavaCacheTimeToLiveBean<K, V> implements FactoryBean<Cache<K, V>> {

    private Map<String, Object> propertiesMap;
    
    // Properties used by the Guava Cache builder
    private Long expireMinutesAfterWrite;
    private Long maximumSize;

    @SuppressWarnings("unchecked")
    @Override
    public Cache<K, V> getObject() throws Exception {
        CacheBuilder<K, V> builder = (CacheBuilder<K, V>) CacheBuilder.newBuilder();
        if (expireMinutesAfterWrite != null && expireMinutesAfterWrite.longValue()>0) {
                builder.expireAfterWrite(expireMinutesAfterWrite, TimeUnit.MINUTES);
        }
        if (maximumSize != null && maximumSize.longValue()>0) {
                builder.maximumSize(maximumSize);
        }
        return builder.build();
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Class<Cache> getObjectType() {
        return Cache.class;
    }

    @Override
    public boolean isSingleton() {
        return false;
    }

    public void setMaximumSize(Long maximumSize) {
        this.maximumSize = maximumSize;
    }

    public void setExpireMinutesAfterWrite(Long expireMinutesAfterWrite) {
        this.expireMinutesAfterWrite = expireMinutesAfterWrite;
    }

    public Map<String, Object> getPropertiesMap() {
        return propertiesMap;
    }

    public void setPropertiesMap(Map<String, Object> propertiesMap) {
        this.propertiesMap = propertiesMap;
    }

}
