/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.streaming.util.exception;

import java.util.List;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.util.exception.MBSSystemException.java 
 * @Revision: 
 * @Description: MBSSystemException.java
 */
public class MBSSystemException extends MBSBaseException {
        
        private static final long serialVersionUID = 6407005224349091728L;
        
        /**
         *
         * @param errMsg String
         */
        public MBSSystemException(String errMsg) {
                super(errMsg, MBSExceptionConstants.SYSTEM_EXCEPTION);
        }
        
        /**
        *
        * @param errMsg String
        * @param excepList List<ExceptionLookupPO>
        */
       public MBSSystemException(String errMsg, List<ExceptionLookupPO> excepList) {
               super(errMsg, MBSExceptionConstants.SYSTEM_EXCEPTION, excepList);
       }
        
        /**
         *
         * @param errMsg String
         * @param processId long
         */
        public MBSSystemException(String errMsg, long processId) {
                super(errMsg, processId);
        }
        
        /**
         * MBSSystemException with root exception info
         * @param errMsg
         * @param rootExp
         */
        public MBSSystemException(String errMsg, Exception rootExp,  List<ExceptionLookupPO> excepList) {
                super(errMsg, MBSExceptionConstants.SYSTEM_EXCEPTION, rootExp, excepList);
        }
        
        /**
         * 
         * @param errMsg 
         * @param rootExp
         */
        public MBSSystemException(String errMsg,Exception rootExp) {
            super(errMsg, MBSExceptionConstants.SYSTEM_EXCEPTION, rootExp);
        }
        
        /**
         *
         * @param errMsg
         * @param processId
         * @param rootExp
         */
        public MBSSystemException(String errMsg, long processId, Exception rootExp) {
                super(errMsg, processId, rootExp);
        }
        
}
