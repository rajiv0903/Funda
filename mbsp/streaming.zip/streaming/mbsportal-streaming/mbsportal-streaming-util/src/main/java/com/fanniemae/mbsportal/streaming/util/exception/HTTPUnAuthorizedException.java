/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.util.exception;

import org.springframework.http.HttpStatus;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: Jun 18, 2018
 * @File: com.fanniemae.mbsportal.streaming.util.exception.HTTPUnAuthorizedException.java 
 * @Revision: 
 * @Description: HTTPUnAuthorizedException.java
 */
public class HTTPUnAuthorizedException extends Exception{

    /**
     * 
     * serialVersionUID long
     */
    private static final long serialVersionUID = -2027653515665810607L;
    
    /**
     * 
     * rootExp Exception
     */
    private Exception rootExp;
    
    /**
     * 
     * processId long
     */
    private long processId;
    
    /**
     * httpStatus HttpStatus
     */
    private HttpStatus httpStatus;
    
    
    /**
     * 
     * 
     * @param errMsg String
     * @param processId long
     * @param httpStatus HttpStatus
     */
    public HTTPUnAuthorizedException(String errMsg, long processId, HttpStatus httpStatus) {
        this.processId = processId;
        this.httpStatus = httpStatus;
        setRootExp(new Exception(errMsg));
    }
    
    public HTTPUnAuthorizedException(String errMsg, long processId, Exception rootExp) {
        this.processId = processId;
        this.setRootExp(new Exception(errMsg,rootExp));
    }
    
    /**
     * 
     * @param errMsg String
     */
    public HTTPUnAuthorizedException(String errMsg) {
        setRootExp(new Exception(errMsg));
    }
    
    /**
     * 
     * 
     * @param rootExp Exception
     */
    public HTTPUnAuthorizedException(Exception rootExp) {
        this.setRootExp(rootExp);
    }

    /**
     * @return the rootExp
     */
    public Exception getRootException() {
        return rootExp;
    }
    
    /**
     * 
     * 
     * @return String
     */
    public String getRootExceptionMessage() {
        return this.rootExp.getMessage();
    }

    /**
     * @param rootExp the rootExp to set
     */
    public void setRootExp(Exception rootExp) {
        this.rootExp = rootExp;
    }
    
    /**
     * 
     * 
     * @return long
     */
    public long getProcessId() {
        return processId;
    }
    
    /**
     * 
     * 
     * @param processId long
     */
    public void setProcessId(long processId) {
        this.processId = processId;
    }

    /**
     * 
     * 
     * @return httpStatus
     */
    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    /**
     * 
     * 
     * @param httpStatus HttpStatus
     */
    public void setHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }
    
    
}
