/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.streaming.util.exception;

import java.util.List;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.util.exception.MBSBaseException.java 
 * @Revision: 
 * @Description: MBSBaseException.java
 */
public class MBSBaseException extends Exception{
    
    /**
     * 
     * serialVersionUID long
     */
    private static final long serialVersionUID = 6407005224349091728L;
    
    /**
     * 
     * rootExp Exception
     */
    private Exception rootExp;
    
    /**
     * 
     * excepList List<ExceptionLookupPO>
     */
    private List<ExceptionLookupPO> excepList;
    
    /**
     * 
     * processId long
     */
    //Added for Exception Handling
    private long processId;
    
    /**
     * 
     * 
     * @param errMsg String
     * @param processId long
     */
    public MBSBaseException(String errMsg, long processId) {
        this.processId = processId;
        rootExp=new Exception(errMsg);
    }
    
    /**
     * 
     * 
     * @param errMsg String
     * @param processId long
     * @param excepList List<ExceptionLookupPO>
     */
    public MBSBaseException(String errMsg, long processId, List<ExceptionLookupPO> excepList) {
        this.processId = processId;
        this.excepList = excepList;
        rootExp=new Exception(errMsg);
    }
    
    /**
     * 
     * 
     * @param errMsg String
     * @param processId long
     * @param rootExp Exception
     */
    public MBSBaseException(String errMsg, long processId, Exception rootExp, List<ExceptionLookupPO> excepList) {
        this.processId = processId;
        this.excepList = excepList;
        this.rootExp=new Exception(errMsg,rootExp);
    }
    
    public MBSBaseException(String errMsg, long processId, Exception rootExp) {
        this.processId = processId;
        this.rootExp=new Exception(errMsg,rootExp);
    }
    
    /**
     * 
     * @param errMsg String
     */
    public MBSBaseException(String errMsg) {
        rootExp=new Exception(errMsg);
    }
    
    /**
     * 
     * 
     * @param rootExp Exception
     */
    public MBSBaseException(Exception rootExp) {
        this.rootExp=rootExp;
    }
    
    /**
     * 
     * 
     * @param errorMsg String
     * @param rootExp Exception
     */
    public MBSBaseException(String errorMsg,Exception rootExp) {
        this.rootExp=new Exception(errorMsg,rootExp);
    }
    
    /**
     * 
     * 
     * @param errorMsg String
     * @param rootT Throwable
     */
    public MBSBaseException(String errorMsg,Throwable rootT) {
        this.rootExp=new Exception(errorMsg,rootT);
    }
    
    /**
     * 
     * 
     * @return Exception
     */
    public Exception getRootException(){
        return this.rootExp;
    }
    
    /**
     * 
     * 
     * @return String
     */
    public String getRootExceptionMessage() {
        return this.rootExp.getMessage();
    }
    
    /**
     * 
     * 
     * @return long
     */
    public long getProcessId() {
        return processId;
    }
    
    /**
     * 
     * 
     * @param processId long
     */
    public void setProcessId(long processId) {
        this.processId = processId;
    }
    /**
     * 
     * @return List<ExceptionLookupPO> the excepList
     */
    public List<ExceptionLookupPO> getExcepList() {
        return excepList;
    }
    /**
     * 
     * @param excepList the excepList to set
     */
    public void setExcepList(List<ExceptionLookupPO> excepList) {
        this.excepList = excepList;
    }
    

   
    
}
