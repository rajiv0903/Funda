/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.streaming.util.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.io.Serializable;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.util.exception.ExceptionLookupPO.java 
 * @Revision: 
 * @Description: ExceptionLookupPO.java
 */
@JsonInclude(Include.NON_NULL)
public class ExceptionLookupPO implements Serializable {

    /**
     *
     * serialVersionUID long
     */
    private static final long serialVersionUID = 2018120541964470822L;

    /**
     * 
     * errorCode String The error code value. Example: TRANS_00001
     */
    private String errorCode;

    /**
     * 
     * errorMessage String
     */
    private String errorMessage;
	
    /**
     * 
     * errorCategory String
     */
    private String errorCategory;
    
    /**
     * 
     * errorField String
     */
    private String errorField;

    /**
     * 
     * @return String the errorCode
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * 
     * @param errorCode String the errorCode to set
     */
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    /**
     * 
     * @return String the errorMessage
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * 
     * @param errorMessage String the errorMessage to set
     */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    /**
     * 
     * @return String the errorCategory
     */
    public String getErrorCategory() {
        return errorCategory;
    }

    /**
     * 
     * @param errorCategory String the errorCategory to set
     */
    public void setErrorCategory(String errorCategory) {
        this.errorCategory = errorCategory;
    }

    /**
     * @return the errorField
     */
    public String getErrorField() {
        return errorField;
    }

    /**
     * @param errorField the errorField to set
     */
    public void setErrorField(String errorField) {
        this.errorField = errorField;
    }

    /** 
     * 
     * 
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     * @return String
     */
    @Override
    public String toString() {
        return "ExceptionLookupPO [errorCode=" + errorCode + ", errorMessage=" + errorMessage + ", errorCategory="
                + errorCategory + ", errorField=" + errorField + "]";
    }
	
}
