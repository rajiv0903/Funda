/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.util.logging;

import org.slf4j.MDC;

import com.fanniemae.mbsportal.streaming.util.constants.LoggingConstants;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.util.logging.LoggingUtil.java 
 * @Revision: 
 * @Description: LoggingUtil.java
 */
public class LoggingUtil {

   /**
    * 
    * Utility method to log for background tasks
    * 
    * @param methodName
    * @param methodSignature
    * @param errType
    * @param errProcId
    * @param actionCmd
    * @param httpSessionID
    * @param socketSessionID
    * @param topicDestination
    * @param cdxSessionID
    * @param userID
    * @param shrtMsg
    */
    public static void logItForAlert(String methodName, String methodSignature, String errType, String errProcId,
            String actionCmd, String httpSessionID, String socketSessionID, String topicDestination,
            String cdxSessionID, String userID, String shrtMsg) {

        MDC.put(LoggingConstants.METHOD_NAME, methodName);
        MDC.put(LoggingConstants.METHOD_ARGS, methodSignature);
        MDC.put(LoggingConstants.ERROR_TYPE, errType);
        MDC.put(LoggingConstants.ERROR_PROCESS_ID, errProcId);
        MDC.put(LoggingConstants.ACTION_COMMAND, actionCmd);
        MDC.put(LoggingConstants.HTTP_SESSION_ID, httpSessionID);
        MDC.put(LoggingConstants.SOCKET_SESSION_ID, socketSessionID);
        MDC.put(LoggingConstants.TOPIC_DESTINATION, topicDestination);
        MDC.put(LoggingConstants.CDX_SESSION_ID, cdxSessionID);
        MDC.put(LoggingConstants.USER_ID, userID);
        MDC.put(LoggingConstants.SHORT_MSG, shrtMsg);
    }

    /**
     * resetLogAlert
     */
    public static void resetLogAlert() {
        MDC.remove(LoggingConstants.METHOD_NAME);
        MDC.remove(LoggingConstants.METHOD_ARGS);
        MDC.remove(LoggingConstants.ERROR_TYPE);
        MDC.remove(LoggingConstants.ERROR_PROCESS_ID);
        MDC.remove(LoggingConstants.ACTION_COMMAND);
        MDC.remove(LoggingConstants.HTTP_SESSION_ID);
        MDC.remove(LoggingConstants.SOCKET_SESSION_ID);
        MDC.remove(LoggingConstants.TOPIC_DESTINATION);
        MDC.remove(LoggingConstants.CDX_SESSION_ID);
        MDC.remove(LoggingConstants.USER_ID);
        MDC.remove(LoggingConstants.SHORT_MSG);
    }
}
