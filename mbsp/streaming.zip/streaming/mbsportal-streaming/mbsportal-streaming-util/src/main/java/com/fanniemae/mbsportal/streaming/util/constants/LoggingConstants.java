/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.util.constants;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.util.constants.LoggingConstants.java 
 * @Revision: 
 * @Description: LoggingConstants.java
 */
public class LoggingConstants {
    
    public static final String METHOD_NAME = "METHOD_NAME";
    public static final String METHOD_ARGS = "METHOD_ARGS";
    public static final String ERROR_TYPE = "ERROR_TYPE";
    public static final String ERROR_PROCESS_ID = "ERROR_PROCESS_ID";
    public static final String ACTION_COMMAND = "ACTION_COMMAND";
    public static final String HTTP_SESSION_ID = "HTTP_SESSION_ID";
    public static final String SOCKET_SESSION_ID = "SOCKET_SESSION_ID";
    public static final String TOPIC_DESTINATION = "TOPIC_DESTINATION";
    public static final String CDX_SESSION_ID = "CDX_SESSION_ID";
    public static final String USER_ID = "USER_ID";
    public static final String SHORT_MSG = "SHORT_MSG";
}
