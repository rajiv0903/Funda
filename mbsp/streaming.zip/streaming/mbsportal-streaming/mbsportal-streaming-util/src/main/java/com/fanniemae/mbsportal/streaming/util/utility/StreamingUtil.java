/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.util.utility;

import org.apache.commons.lang3.StringUtils;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: Jun 25, 2018
 * @File: com.fanniemae.mbsportal.streaming.util.utility.StreamingUtil.java
 * @Revision:
 * @Description: StreamingUtil.java
 */
public class StreamingUtil {

    public static final int DEFAULT_NUMBER_OF_CHARACTER = 5;
    public static final char DEFAULT_PAD_CHARACTER = '*';

    public static final String TOPIC_TRANSACTION_TRADER_USERNAME_PREFIX = "trader";
    public static final String TOPIC_PRICING_PREFIX = "tbapricing";

    public static String getLeftPaddedString(String str, int len, char padChar) {

        if (StringUtils.isBlank(str)) {
            return str;
        }
        return StringUtils.leftPad(StringUtils.right(str, len), str.length(), padChar);
    }

    public static String getLeftPaddedString(String str) {

        if (StringUtils.isBlank(str)) {
            return str;
        }
        return getLeftPaddedString(str, DEFAULT_NUMBER_OF_CHARACTER, DEFAULT_PAD_CHARACTER);
    }

    public static boolean isLenderTopic(String topic, String userName) {
        return (!topic.endsWith(TOPIC_TRANSACTION_TRADER_USERNAME_PREFIX) && !topic.endsWith(TOPIC_PRICING_PREFIX) &&topic.endsWith(userName));
    }
}
