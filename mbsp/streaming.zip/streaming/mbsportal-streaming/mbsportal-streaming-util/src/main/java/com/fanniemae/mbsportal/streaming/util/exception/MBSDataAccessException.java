/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.streaming.util.exception;

import java.util.List;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.util.exception.MBSDataAccessException.java 
 * @Revision: 
 * @Description: MBSDataAccessException.java
 */
public class MBSDataAccessException extends MBSSystemException{

    /**
     * 
     * serialVersionUID long
     */
    private static final long serialVersionUID = 6407005224349091728L;
    
    /**
     * 
     * @param errMsg String
     * @param processId long
     */
    public MBSDataAccessException(String errMsg) {
        super( errMsg,  MBSExceptionConstants.SYSTEM_EXCEPTION);
    }
    
    /**
     * 
     * 
     * @param errMsg String
     * @param excepList List<ExceptionLookupPO>
     */
    public MBSDataAccessException(String errMsg, List<ExceptionLookupPO> excepList) {
        super( errMsg, excepList);
    }
    
    /**
     * 
     * @param errMsg
     * @param processId
     * @param rootExp
     */
    public MBSDataAccessException(String errMsg, long processId,  Exception rootExp) {
        super( errMsg,  processId, rootExp);
    }
}
