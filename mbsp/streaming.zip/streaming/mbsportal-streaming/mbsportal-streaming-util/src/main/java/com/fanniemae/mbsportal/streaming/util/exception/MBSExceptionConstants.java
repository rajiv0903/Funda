/*
 *
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 *
 */

package com.fanniemae.mbsportal.streaming.util.exception;

import org.slf4j.MDC;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.util.exception.MBSExceptionConstants.java 
 * @Revision: 
 * @Description: MBSExceptionConstants.java
 */
public class MBSExceptionConstants {

    public static final String ERROR_TYPE = "ERROR_TYPE";
    public static final String ERROR_PROCESS_ID = "ERROR_PROCESS_ID";
    public static final String ERROR_MESSGE = "ERROR_MESSGE";
    public static final String ERROR_SOURCE_METHOD = "ERROR_SOURCE_METHOD";
    public static final String ERROR_SOURCE_METHOD_SIGNATURE = "ERROR_SOURCE_METHOD_SIGNATURE";
    public static final String SOURCE_METHOD_ARGS = "SOURCE_METHOD_ARGS";

    // Constant Related to UI Logging
    public static final String UI_LOGGING_USER_ID = "USER_ID";
    public static final String UI_LOGGING_HTTP_CODE = "HTTP_CODE";
    public static final String UI_LOGGING_CHANNEL = "CHANNEL";
    public static final String UI_LOGGING_TRANSACTION_ID = "TRANSACTION_ID";
    public static final String UI_LOGGING_MSG_TYPE = "MSG_TYPE";
    public static final String UI_LOGGING_MODULE = "MODULE";
    public static final String UI_LOGGING_PAGE = "PAGE";
    public static final String UI_LOGGING_FUNCTIONALITY = "FUNCTIONALITY";
    public static final String UI_LOGGING_MSG = "MESSAGE";
    public static final String UI_LOGGING_TIME_STAMP = "TIME_STAMP";

    public static final Long SYSTEM_EXCEPTION = 10001L;
    public static final Long BUSINESS_EXCEPTION = 20001L;
    
    /**
     * 
     * BASE_EXCEPTION_IDENTIFIER String
     */
    public static final String BASE_EXCEPTION_IDENTIFIER = "MBSP_ERROR";
    /**
     * 
     * BUSINESS_EXCEPTION_IDENTIFIER String
     */
    public static final String BUSINESS_EXCEPTION_IDENTIFIER = "MBSP_BUSINESS_ERROR";
    /**
     * 
     * SYSTEM_EXCEPTION_IDENTIFIER String
     */
    public static final String SYSTEM_EXCEPTION_IDENTIFIER = "MBSP_SYSTEM_ERROR";

    /**
     * Utility method to log for background tasks
     * 
     * @param errType
     * @param errProcId
     * @param errMsg
     * @param errSrcMethod
     * @param errSrcMethodSignature
     * @param errSrcMethodArgs
     */
    public static void logItForAlert(String errType, String errProcId, String errMsg,
            String errSrcMethod, String errSrcMethodSignature, String errSrcMethodArgs) {
        
        MDC.put(MBSExceptionConstants.ERROR_TYPE, errType);
        MDC.put(MBSExceptionConstants.ERROR_PROCESS_ID, errProcId);
        MDC.put(MBSExceptionConstants.ERROR_SOURCE_METHOD, errSrcMethod);
        MDC.put(MBSExceptionConstants.ERROR_SOURCE_METHOD_SIGNATURE, errSrcMethodSignature);
        MDC.put(MBSExceptionConstants.SOURCE_METHOD_ARGS, errSrcMethodArgs);
        MDC.put(MBSExceptionConstants.ERROR_MESSGE, errMsg);
    }

    /**
     * resetLogAlert
     */
    public static void resetLogAlert() {
        MDC.remove(MBSExceptionConstants.ERROR_TYPE);
        MDC.remove(MBSExceptionConstants.ERROR_PROCESS_ID);
        MDC.remove(MBSExceptionConstants.ERROR_SOURCE_METHOD);
        MDC.remove(MBSExceptionConstants.ERROR_SOURCE_METHOD_SIGNATURE);
        MDC.remove(MBSExceptionConstants.SOURCE_METHOD_ARGS);
        MDC.remove(MBSExceptionConstants.ERROR_MESSGE);
    }
}
