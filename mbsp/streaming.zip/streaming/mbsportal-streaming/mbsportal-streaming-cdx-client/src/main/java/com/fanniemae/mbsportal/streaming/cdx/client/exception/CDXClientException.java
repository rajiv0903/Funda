/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.cdx.client.exception;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.cdx.client.exception.CDXClientException.java 
 * @Revision: 
 * @Description: CDXClientException.java
 */
public class CDXClientException extends Exception{

    /**
     * 
     * serialVersionUID long
     */
    private static final long serialVersionUID = -2027653515665810607L;
    
    /**
     * 
     * rootExp Exception
     */
    private Exception rootExp;
    
    /**
     * 
     * processId long
     */
    private long processId;
    
    
    /**
     * 
     * 
     * @param errMsg String
     * @param processId long
     */
    public CDXClientException(String errMsg, long processId) {
        this.processId = processId;
        setRootExp(new Exception(errMsg));
    }
    
    public CDXClientException(String errMsg, long processId, Exception rootExp) {
        this.processId = processId;
        this.setRootExp(new Exception(errMsg,rootExp));
    }
    
    /**
     * 
     * @param errMsg String
     */
    public CDXClientException(String errMsg) {
        setRootExp(new Exception(errMsg));
    }
    
    /**
     * 
     * 
     * @param rootExp Exception
     */
    public CDXClientException(Exception rootExp) {
        this.setRootExp(rootExp);
    }

    /**
     * @return the rootExp
     */
    public Exception getRootException() {
        return rootExp;
    }
    
    /**
     * 
     * 
     * @return String
     */
    public String getRootExceptionMessage() {
        return this.rootExp.getMessage();
    }
    

    /**
     * @param rootExp the rootExp to set
     */
    public void setRootExp(Exception rootExp) {
        this.rootExp = rootExp;
    }
    
    /**
     * 
     * 
     * @return long
     */
    public long getProcessId() {
        return processId;
    }
    
    /**
     * 
     * 
     * @param processId long
     */
    public void setProcessId(long processId) {
        this.processId = processId;
    }
}
