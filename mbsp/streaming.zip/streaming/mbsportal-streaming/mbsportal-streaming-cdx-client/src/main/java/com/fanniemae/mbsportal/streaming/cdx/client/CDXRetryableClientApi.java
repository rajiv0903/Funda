/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.cdx.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;

import com.fanniemae.mbsportal.streaming.cdx.client.constants.CDXHeaderMap;
import com.fanniemae.mbsportal.streaming.cdx.client.exception.CDXClientException;
import com.fanniemae.mbsportal.streaming.cdx.client.model.CDXUserProfile;
import com.fanniemae.mbsportal.streaming.cdx.client.model.CDXUserProfileRole;
import com.fanniemae.mbsportal.streaming.util.exception.HTTPUnAuthorizedException;
import com.fanniemae.mbsportal.streaming.util.exception.MBSBaseException;
import com.fanniemae.mbsportal.streaming.util.exception.MBSExceptionConstants;
import com.fanniemae.mbsportal.streaming.util.logging.LoggingUtil;

@Component
public class CDXRetryableClientApi {

    /**
     * LOGGER Logger variable
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(CDXRetryableClientApi.class);
    /**
     * cDXClientApi API
     */
    @Autowired
    CDXClientApi cDXClientApi;

    @Value("${cdx.api.client.retryMaxAttempts}")
    private Integer retryMaxAttempts;

    @Value("${cdx.api.client.retryBackoff}")
    private Integer retryBackoff;

    /**
     * Throw HTTPUnAuthorizedException for 4XX Status - For any other exception
     * CDXClientException Return Profile and check the Authorization
     *
     * @param cDXUserProfile
     *            CDXUserProfile
     * @param authorizedRoles
     *            Array of Roles
     * @return User Profile
     * @throws CDXClientException
     * @throws HTTPUnAuthorizedException
     */
    public CDXUserProfile authorizedSubscriber(CDXUserProfile cDXUserProfile, String[] authorizedRoles)
            throws CDXClientException, HTTPUnAuthorizedException {

        LOGGER.debug("Entering authorizedSubscriber method in CDXClientApi");

        List<String> userRoles = new ArrayList<>();
        // Get the roles
        for (CDXUserProfileRole cDXUserProfileRole : cDXUserProfile.getRoles()) {
            userRoles.add(cDXUserProfileRole.getName());
        }
        // convert the roles to lower case
        userRoles = userRoles.stream().map(String::toLowerCase).collect(Collectors.toList());

        // Lender Role - Then does support
        List<String> supportedRoles = Arrays.asList(authorizedRoles);
        supportedRoles = supportedRoles.stream().map(String::toLowerCase).collect(Collectors.toList());

        // check if supported role presence at user profile roles
        if (!CollectionUtils.containsAny(supportedRoles, userRoles)) {

            throw new CDXClientException("User is not authorized with roles:" + userRoles,
                    MBSExceptionConstants.SYSTEM_EXCEPTION);
        }
        LOGGER.debug("Exiting authorizedSubscriber method in CDXClientApi");
        LoggingUtil.resetLogAlert();
        return cDXUserProfile;
    }

    /**
     * This will method will check the validity of session - if session is not
     * valid then it will throw error HTTPUnAuthorizedException for 4xx and for
     * any unknown CDXClientException
     *
     * @param headerMap
     * @return session validity status
     * @throws CDXClientException
     * @throws HTTPUnAuthorizedException
     */

    public boolean sessionValidRetry(Map<String, String> headerMap)
            throws CDXClientException, HTTPUnAuthorizedException {

        LOGGER.debug("Entering sessionValidRetry method in CDXClientApi");
        boolean retVal = false;
        int retryCounter = 0;

        while (retryCounter < (retryMaxAttempts + 1)) {
            try {
                retVal = cDXClientApi.sessionValid(headerMap);
                // No Exception - Hence loop the break
                break;

            } catch (HttpClientErrorException exe) {

                retryCounter++;
                if (retryCounter == retryMaxAttempts) {

                    throw new HTTPUnAuthorizedException(
                            "HttpClientErrorException:  Status Code: {" + exe.getStatusCode() + "}, Status Text: {"
                                    + exe.getStatusText() + "},  Session ID:{"
                                    + headerMap.get(CDXHeaderMap.SESSION_ID.getValue()) + "}",
                            MBSExceptionConstants.SYSTEM_EXCEPTION, exe.getStatusCode());

                } else {
                    mySleep(retryBackoff);

                }

            } catch (CDXClientException exe) {

                retryCounter++;
                if (retryCounter == retryMaxAttempts) {
                    throw exe;

                } else {
                    mySleep(retryBackoff);

                }

            }
        }
        LOGGER.debug("Exiting sessionValidRetry method in CDXClientApi");
        return retVal;
    }

    /**
     * 
     * 
     * @param headerMap
     *            - Header Map from Request
     * @return CDXUserProfile from CDX
     * @throws MBSBaseException
     */
    public CDXUserProfile getProfileFromSessionRetry(Map<String, String> headerMap)
            throws CDXClientException, HTTPUnAuthorizedException {

        LOGGER.debug("Entering getProfileFromSessionRetry method in CDXClientApi");

        CDXUserProfile cDXUserProfile = null;
        int retryCounter = 0;

        while (retryCounter < (retryMaxAttempts + 1)) {
            try {

                cDXUserProfile = cDXClientApi.getProfileFromSession(headerMap);
                // No Exception - Hence loop the break
                break;

            } catch (HttpClientErrorException exe) {

                retryCounter++;
                HttpStatus httpStatus = exe.getStatusCode();

                /*
                 * if status code other then 401 then retry
                 */
                if (retryCounter == retryMaxAttempts || HttpStatus.UNAUTHORIZED.value() == httpStatus.value()) {

                    throw new HTTPUnAuthorizedException(
                            "HttpClientErrorException: Status Code: {" + exe.getStatusCode() + "}, Status Text: {"
                                    + exe.getStatusText() + "},  Session ID:{"
                                    + headerMap.get(CDXHeaderMap.SESSION_ID.getValue()) + "}",
                            MBSExceptionConstants.SYSTEM_EXCEPTION, exe.getStatusCode());

                } else {
                    mySleep(retryBackoff);

                }

            } catch (CDXClientException exe) {

                retryCounter++;
                if (retryCounter == retryMaxAttempts) {
                    throw exe;

                } else {
                    mySleep(retryBackoff);

                }

            }
        }
        return cDXUserProfile;
    }

    public void mySleep(int val) {
        try {
            Thread.sleep(val);
            // TimeUnit.MILLISECONDS.sleep(val);
        } catch (InterruptedException e) {
            LOGGER.error("Thread interrupted");
        }
    }
}
