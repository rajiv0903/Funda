/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.cdx.client.model;

import java.util.List;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.cdx.client.model.CDXUserProfileRole.java 
 * @Revision: 
 * @Description: CDXUserProfileRole.java
 */
public class CDXUserProfileRole {

    /**
     * 
     *  name String
     */
    private String name;
    /**
     * 
     * appCode String
     */
    private String appCode;
    /**
     * 
     * permissions List<String>
     */
    private List<String> permissions;
    
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getAppCode() {
        return appCode;
    }
    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }
    public List<String> getPermissions() {
        return permissions;
    }
    public void setPermissions(List<String> permissions) {
        this.permissions = permissions;
    }
    @Override
    public String toString() {
        return "CDXUserProfileRole [name=" + name + "]";
    }
    
    
}
