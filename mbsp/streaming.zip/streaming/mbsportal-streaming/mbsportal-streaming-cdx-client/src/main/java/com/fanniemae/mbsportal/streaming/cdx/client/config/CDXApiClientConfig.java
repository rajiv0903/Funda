/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */
package com.fanniemae.mbsportal.streaming.cdx.client.config;


import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.cdx.client.config.CDXApiClientConfig.java 
 * @Revision: 
 * @Description: CDXApiClientConfig.java
 */
@Component
@ConfigurationProperties("cdx.api.client")
public class CDXApiClientConfig {
    /**
     * 
     * certlocation Location path of the certificate
     */
    @NotEmpty
    private String[] certlocation;
    /**
     * 
     * entitlementpassthrough entitlement pass through flag
     */
    private boolean entitlementpassthrough;

    /**
     * 
     * proxyHost CDX Proxy Host
     */
    private String proxyHost;

    /**
     * 
     * proxyPort CDX Proxy Port
     */
    private int proxyPort;
    
    /**
     * 
     * baseurl CDX Base URL
     */
    @NotEmpty
    private String baseurl;
    
    /**
     * 
     * loginapi CDX Login API Url
     */
    
    @NotEmpty
    private String loginapi;
    
    /**
     * 
     * profileapi CDX profile API Url
     */
    @NotEmpty
    private String profileapi;
    
    /**
     * 
     * sessionapi CDX session API URL
     */
    @NotEmpty
    private String sessionapi;

    /**
     * 
     * @return String[]
     */
    public String[] getCertlocation() {
        return certlocation;
    }

    /**
     * 
     * @param certlocation the certificate location being set
     */
    public void setCertlocation(String[] certlocation) {
        this.certlocation = certlocation;
    }

    /**
     * 
     * getter method for entitlement pass through field
     * 
     * @return boolean
     */
    public boolean isEntitlementpassthrough() {
        return entitlementpassthrough;
    }

    /**
     * 
     * setter method for entitlement pass through field
     * 
     * @param entitlementpassthrough pass through entitlement flag being set
     */
    public void setEntitlementpassthrough(boolean entitlementpassthrough) {
        this.entitlementpassthrough = entitlementpassthrough;
    }

    /**
     * 
     * Getter method for proxyHost
     * 
     * @return String
     */
    public String getProxyHost() {
        return proxyHost;
    }

    /**
     * 
     * Setter method for proxyHost
     * 
     * @param proxyHost Proxy Host for DC 
     */
    public void setProxyHost(String proxyHost) {
        this.proxyHost = proxyHost;
    }

    /**
     * 
     * Getter method for proxyPort
     * 
     * @return int proxyPort
     */
    public int getProxyPort() {
        return proxyPort;
    }

    /**
     * 
     * Setter method for proxyPort
     * 
     * @param proxyPort Proxy Port for DC 
     */
    public void setProxyPort(int proxyPort) {
        this.proxyPort = proxyPort;
    }

    
    public String getBaseurl() {
        return baseurl;
    }

    public void setBaseurl(String baseurl) {
        this.baseurl = baseurl;
    }

    public String getLoginapi() {
        return loginapi;
    }

    public void setLoginapi(String loginapi) {
        this.loginapi = loginapi;
    }

    public String getProfileapi() {
        return profileapi;
    }

    public void setProfileapi(String profileapi) {
        this.profileapi = profileapi;
    }

    public String getSessionapi() {
        return sessionapi;
    }

    public void setSessionapi(String sessionapi) {
        this.sessionapi = sessionapi;
    }
    
    

}
