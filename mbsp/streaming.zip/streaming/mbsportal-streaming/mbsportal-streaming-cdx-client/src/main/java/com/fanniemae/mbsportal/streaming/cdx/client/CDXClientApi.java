/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.cdx.client;

import java.security.interfaces.RSAPublicKey;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.fanniemae.mbsportal.streaming.cdx.client.config.CDXApiClientConfig;
import com.fanniemae.mbsportal.streaming.cdx.client.constants.CDXHeaderMap;
import com.fanniemae.mbsportal.streaming.cdx.client.exception.CDXClientException;
import com.fanniemae.mbsportal.streaming.cdx.client.model.CDXUserProfile;
import com.fanniemae.mbsportal.streaming.util.exception.HTTPUnAuthorizedException;
import com.fanniemae.mbsportal.streaming.util.exception.MBSBaseException;
import com.fanniemae.mbsportal.streaming.util.exception.MBSExceptionConstants;
import com.fanniemae.mbsportal.streaming.util.logging.LoggingUtil;
import com.fanniemae.mbsportal.streaming.util.template.rest.CDXProxyTemplate;
import com.fanniemae.mbsportal.streaming.util.utility.StreamingUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.cdx.client.CDXClientApi.java
 * @Revision:
 * @Description: CDXClientApi.java
 */
@Component
public class CDXClientApi {

    /**
     * LOGGER Logger variable
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(CDXClientApi.class);
    /**
     * cDXApiClientConfig API client config obj
     */
    @Autowired
    CDXApiClientConfig cDXApiClientConfig;
    /**
     * rsaPublicKeys RSAPublicKey[]
     */
    RSAPublicKey[] rsaPublicKeys;

    /**
     * mbsRestInternalTemplate MBSRestInternalTemplate
     */
    @Autowired
    private CDXProxyTemplate cDXProxyTemplate;

    /**
     * This will method will check the validity of session - if session is not
     * valid then it will throw error HTTPUnAuthorizedException for 4xx and for
     * any unknown CDXClientException
     *
     * @param headerMap
     * @return session validity status
     * @throws CDXClientException
     * @throws HTTPUnAuthorizedException
     */
    public boolean sessionValid(Map<String, String> headerMap) throws CDXClientException, HTTPUnAuthorizedException {

        LOGGER.debug("Entering sessionValid method in CDXClientApi");
        boolean retVal = false;
        ResponseEntity<String> response = null;
        String url = null;

        try {
            url = cDXApiClientConfig.getBaseurl() + cDXApiClientConfig.getSessionapi();
            HttpHeaders headers = new HttpHeaders();
            headers.add(CDXHeaderMap.CHANNEL.getValue(), headerMap.get(CDXHeaderMap.CHANNEL.getValue()));
            headers.add(CDXHeaderMap.SUB_CHANNEL.getValue(), headerMap.get(CDXHeaderMap.SUB_CHANNEL.getValue()));
            headers.add(CDXHeaderMap.SESSION_ID.getValue(), headerMap.get(CDXHeaderMap.SESSION_ID.getValue()));

            HttpEntity<String> request = new HttpEntity<>(headers);
            response = cDXProxyTemplate.exchange(url, HttpMethod.POST, request, String.class);

            if (HttpStatus.CREATED.value() == response.getStatusCode().value()
                    || HttpStatus.OK.value() == response.getStatusCode().value()) {

                LOGGER.debug("Response Body: {}", response.getBody());
                if ("Y".equalsIgnoreCase(response.getBody())) {
                    retVal = true;
                }
            }

        } catch (HttpClientErrorException exe) {
            LOGGER.warn(exe.getMessage());
            throw exe;

        } catch (Exception exe) {
            
            LOGGER.warn(exe.getMessage());
            throw new CDXClientException("Exception: URL: {" + url + "}, Session ID:{"
                    + headerMap.get(CDXHeaderMap.SESSION_ID.getValue()) + "}",
                    MBSExceptionConstants.BUSINESS_EXCEPTION);

        }
        LOGGER.debug("Exiting sessionValid method in CDXClientApi");
        return retVal;
    }

    /**
     * @param headerMap
     *            - Header Map from Request
     * @return CDXUserProfile from CDX
     * @throws MBSBaseException
     */
    public CDXUserProfile getProfileFromSession(Map<String, String> headerMap)
            throws CDXClientException, HTTPUnAuthorizedException {

        LOGGER.debug("Entering getProfileFromSession method in CDXClientApi");

        CDXUserProfile cDXUserProfile = null;
        ResponseEntity<String> response = null;
        String url = null;

        try {
            /// Local cache check for bad session id . Filter bad session
            /// repeated calls
            url = cDXApiClientConfig.getBaseurl() + cDXApiClientConfig.getProfileapi();
            HttpHeaders headers = new HttpHeaders();
            headers.add(CDXHeaderMap.CHANNEL.getValue(), headerMap.get(CDXHeaderMap.CHANNEL.getValue()));
            headers.add(CDXHeaderMap.SUB_CHANNEL.getValue(), headerMap.get(CDXHeaderMap.SUB_CHANNEL.getValue()));
            headers.add(CDXHeaderMap.SESSION_ID.getValue(), headerMap.get(CDXHeaderMap.SESSION_ID.getValue()));
            if (headerMap.get(CDXHeaderMap.SESSION_ID.getValue()) != null) {
                String sessionIdToBeUsed = headerMap.get(CDXHeaderMap.SESSION_ID.getValue());
                LOGGER.info("Going to get cdx profile using session id {}",
                        StreamingUtil.getLeftPaddedString(sessionIdToBeUsed));
            }
            HttpEntity<String> request = new HttpEntity<>(headers);
            response = cDXProxyTemplate.exchange(url, HttpMethod.POST, request, String.class);

            if (HttpStatus.CREATED.value() == response.getStatusCode().value()
                    || HttpStatus.OK.value() == response.getStatusCode().value()) {

                LOGGER.debug("Response Body: {}", response.getBody());
                ObjectMapper mapper = new ObjectMapper();
                cDXUserProfile = mapper.readValue(response.getBody(), CDXUserProfile.class);
            } else {
                LoggingUtil.logItForAlert("getProfileFromSession", "", "", "", "", "", "", "",
                        headerMap.get(CDXHeaderMap.SESSION_ID.getValue()), "", "");
                LOGGER.error("Status Code: {}", response.getStatusCodeValue());
                LoggingUtil.resetLogAlert();

                throw new CDXClientException(response.getBody(), response.getStatusCode().value());
            }
            LOGGER.debug("Exiting getProfileFromSession method in CDXClientApi");
            return cDXUserProfile;

        } catch (HttpClientErrorException exe) {
            LOGGER.warn(exe.getMessage());
            throw exe;

        } catch (Exception exe) {
            LOGGER.warn(exe.getMessage());
            throw new CDXClientException("Exception: URL: {" + url + "}, Session ID:{"
                    + headerMap.get(CDXHeaderMap.SESSION_ID.getValue()) + "}", MBSExceptionConstants.SYSTEM_EXCEPTION);
        }
    }

}
