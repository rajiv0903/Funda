/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.cdx.client.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.cdx.client.model.CDXUserProfile.java
 * @Revision:
 * @Description: CDXUserProfile.java
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class CDXUserProfile implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -8950536153226030379L;

    /**
     * 
     * firstName String
     */
    private String firstName;
    /**
     * 
     * lastName String
     */
    private String lastName;
    /**
     * 
     * emailAddress String
     */
    private String emailAddress;
    /**
     * 
     * mobileNumber String
     */
    private String mobileNumber;
    /**
     * 
     * workNumber String
     */
    private String workNumber;
    /**
     * 
     * cutstomerName String
     */
    private String cutstomerName;
    /**
     * 
     * userName String
     */
    private String userName;
    /**
     * 
     * sellerSerivcerNo String
     */
    private String sellerSerivcerNo;
    /**
     * 
     * dealerOrgName String
     */
    private String dealerOrgName;
    /**
     * 
     * dealerOrgId String
     */
    private String dealerOrgId;
    /**
     * 
     * roles List<ProfileEntitlementRolePO>
     */
    private List<CDXUserProfileRole> roles;
    /**
     * 
     * sellerServiceDetails List<String>
     */
    private List<String> sellerServiceDetails;
    /**
     * 
     * institutionId String
     */
    private String institutionId;
    /**
     * 
     * defaultSellerServicerNo String
     */
    private String defaultSellerServicerNo;
    /**
     * 
     * lenderDetails String
     */
    private String lenderDetails;
    /**
     * 
     * fannieMaeUser boolean
     */
    private boolean fannieMaeUser;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getWorkNumber() {
        return workNumber;
    }

    public void setWorkNumber(String workNumber) {
        this.workNumber = workNumber;
    }

    public String getCutstomerName() {
        return cutstomerName;
    }

    public void setCutstomerName(String cutstomerName) {
        this.cutstomerName = cutstomerName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getSellerSerivcerNo() {
        return sellerSerivcerNo;
    }

    public void setSellerSerivcerNo(String sellerSerivcerNo) {
        this.sellerSerivcerNo = sellerSerivcerNo;
    }

    public String getDealerOrgName() {
        return dealerOrgName;
    }

    public void setDealerOrgName(String dealerOrgName) {
        this.dealerOrgName = dealerOrgName;
    }

    public String getDealerOrgId() {
        return dealerOrgId;
    }

    public void setDealerOrgId(String dealerOrgId) {
        this.dealerOrgId = dealerOrgId;
    }

    public List<CDXUserProfileRole> getRoles() {
        return roles;
    }

    public void setRoles(List<CDXUserProfileRole> roles) {
        this.roles = roles;
    }

    public List<String> getSellerServiceDetails() {
        return sellerServiceDetails;
    }

    public void setSellerServiceDetails(List<String> sellerServiceDetails) {
        this.sellerServiceDetails = sellerServiceDetails;
    }

    public String getInstitutionId() {
        return institutionId;
    }

    public void setInstitutionId(String institutionId) {
        this.institutionId = institutionId;
    }

    public String getDefaultSellerServicerNo() {
        return defaultSellerServicerNo;
    }

    public void setDefaultSellerServicerNo(String defaultSellerServicerNo) {
        this.defaultSellerServicerNo = defaultSellerServicerNo;
    }

    public String getLenderDetails() {
        return lenderDetails;
    }

    public void setLenderDetails(String lenderDetails) {
        this.lenderDetails = lenderDetails;
    }

    public boolean isFannieMaeUser() {
        return fannieMaeUser;
    }

    public void setFannieMaeUser(boolean fannieMaeUser) {
        this.fannieMaeUser = fannieMaeUser;
    }

    @Override
    public String toString() {
        return "CDXUserProfile [firstName=" + firstName + ", lastName=" + lastName + ", userName=" + userName
                + ", roles=" + roles + ", fannieMaeUser=" + fannieMaeUser + "]";
    }

}
