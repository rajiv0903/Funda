MBSP - Trade Automation Streaming Project
	- This is for Long Connection and Streaming
	- Current Approach is MBSP will notify the Streaming Server to inform client (UI) who is subscibed to 
		topic about the transaction