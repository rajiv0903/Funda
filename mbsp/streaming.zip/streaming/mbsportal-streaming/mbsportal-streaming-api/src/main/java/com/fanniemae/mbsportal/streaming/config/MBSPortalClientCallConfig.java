/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.config;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;

import com.fanniemae.mbsportal.streaming.util.template.rest.MBSPortalProxyTemplate;


/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.config.MBSPortalClientCallConfig.java 
 * @Revision: 
 * @Description: MBSPortalClientCallConfig.java
 */

@Configuration
@Profile({ "default", "LOCAL", "DEV", "ACPT", "TEST", "PROD", "PERF" })
public class MBSPortalClientCallConfig {

    /**
     * 
     * MBS Rest template without proxy for internal use
     * 
     * @return MBSRestTemplate
     * @throws KeyStoreException
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     */

    @Bean
    public MBSPortalProxyTemplate mBSPortalProxyTemplate()
            throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {

        MBSPortalProxyTemplate mBSPortalProxyTemplate = new MBSPortalProxyTemplate(
                httpComponentsClientHttpRequestFactory());
        return mBSPortalProxyTemplate;
    }
    


    /**
     * 
     * DMZ HTTP Client Factory with SSL Ignore
     * 
     * @return HttpComponentsClientHttpRequestFactory
     * @throws KeyStoreException
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     */
    @SuppressWarnings({ "deprecation" })
    private HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory()
            throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
        // To ignore SSL for DMZ 
        HttpClientBuilder b = HttpClientBuilder.create();
        
        SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
            public boolean isTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
                return true;
            }
        }).build();
        b.setSslcontext(sslContext);
        HostnameVerifier hostnameVerifier = SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER;
        SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(sslContext, hostnameVerifier);
        Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory> create()
                .register("http", PlainConnectionSocketFactory.getSocketFactory()).register("https", sslSocketFactory)
                .build();
        // Allows Multi-Thread use
        PoolingHttpClientConnectionManager connMgr = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
        connMgr.setMaxTotal(20);
        b.setConnectionManager(connMgr);
        CloseableHttpClient httpClient = b.setDefaultRequestConfig(requestConfig()).build();
        HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
        httpComponentsClientHttpRequestFactory.setHttpClient(httpClient);       
        return httpComponentsClientHttpRequestFactory;
    }

    /**
     * requestConfig
     * 
     * @return RequestConfig
     */
    private RequestConfig requestConfig() {
        RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(5000)
                .setConnectTimeout(5000).setSocketTimeout(5000).build();
        return requestConfig;
    }

}