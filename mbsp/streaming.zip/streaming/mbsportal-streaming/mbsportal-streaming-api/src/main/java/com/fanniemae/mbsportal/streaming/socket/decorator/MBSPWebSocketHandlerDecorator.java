/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.socket.decorator;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.WebSocketMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.WebSocketHandlerDecorator;

import com.fanniemae.mbsportal.streaming.cdx.SocketCdxSession;
import com.fanniemae.mbsportal.streaming.cdx.client.constants.CDXHeaderMap;
import com.fanniemae.mbsportal.streaming.util.exception.MBSExceptionConstants;
import com.fanniemae.mbsportal.streaming.util.logging.LoggingUtil;
import com.fanniemae.mbsportal.streaming.util.utility.StreamingUtil;
import com.google.common.cache.Cache;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.socket.decorator.MBSPWebSocketHandlerDecorator.java
 * @Revision:
 * @Description: MBSPWebSocketHandlerDecorator.java
 */
public class MBSPWebSocketHandlerDecorator extends WebSocketHandlerDecorator {

    private static final Logger LOGGER = LoggerFactory.getLogger(MBSPWebSocketHandlerDecorator.class);

    private final Cache<String, SocketCdxSession> guavaCacheTimeToLiveCdxSession;

    /**
     * @param delegate
     */
    public MBSPWebSocketHandlerDecorator(WebSocketHandler delegate,
            final Cache<String, SocketCdxSession> guavaCacheTimeToLiveCdxSession) {
        super(delegate);
        this.guavaCacheTimeToLiveCdxSession = guavaCacheTimeToLiveCdxSession;
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {

        String cdxSessionID = session.getHandshakeHeaders().getFirst(CDXHeaderMap.SESSION_ID.getValue());
        String wsSessionId = session.getId();

        LoggingUtil.logItForAlert("afterConnectionEstablished", "", "", "", "", "", wsSessionId, "", StreamingUtil.getLeftPaddedString(cdxSessionID), "",
                "");

        /*
         * CMMBSSTA01-1696: Streaming - Stealing Session Security
         */
        SocketCdxSession socketCdxSession = guavaCacheTimeToLiveCdxSession.getIfPresent(wsSessionId);

        if (Objects.isNull(socketCdxSession)) {
            socketCdxSession = new SocketCdxSession(wsSessionId, session);
        } else {
            socketCdxSession.setSession(session);
        }
        guavaCacheTimeToLiveCdxSession.put(wsSessionId, socketCdxSession);
        // END
        
        LOGGER.info("After Connection Has Been Established for Client IP: {}, CDX Session ID: {}, WS Session ID: {}", session.getRemoteAddress(), cdxSessionID, wsSessionId);
     
        LoggingUtil.resetLogAlert();

        super.afterConnectionEstablished(session);
    }

    @Override
    public void handleMessage(WebSocketSession session, WebSocketMessage<?> message) throws Exception {

        String cdxSessionID = session.getHandshakeHeaders().getFirst(CDXHeaderMap.SESSION_ID.getValue());

        LoggingUtil.logItForAlert("handleMessage", "", "", "", "", "", session.getId(), "", StreamingUtil.getLeftPaddedString(cdxSessionID), "", "");
        LOGGER.debug("After Message Has Been Handled");
        LoggingUtil.resetLogAlert();
        
        //To prevent connection time out - Broken Pipe Issue
        if(session.isOpen()){
            super.getDelegate().handleMessage(session, message);
        }
    }

    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) throws Exception {

        String cdxSessionID = session.getHandshakeHeaders().getFirst(CDXHeaderMap.SESSION_ID.getValue());

        LoggingUtil.logItForAlert("handleTransportError", "", MBSExceptionConstants.SYSTEM_EXCEPTION_IDENTIFIER,
                MBSExceptionConstants.SYSTEM_EXCEPTION.toString(), "", "", session.getId(), "", StreamingUtil.getLeftPaddedString(cdxSessionID), "", "");
        LOGGER.error("Exception: {}", exception);
        LoggingUtil.resetLogAlert();

        super.getDelegate().handleTransportError(session, exception);
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus closeStatus) throws Exception {

        String cdxSessionID = session.getHandshakeHeaders().getFirst(CDXHeaderMap.SESSION_ID.getValue());
        String wsSessionId = session.getId();

        LoggingUtil.logItForAlert("afterConnectionClosed", "", "", "", "", "", wsSessionId, "", StreamingUtil.getLeftPaddedString(cdxSessionID), "", "");
        /*
         * CMMBSSTA01-1696: Streaming - Stealing Session Security
         */
        SocketCdxSession socketCdxSession = guavaCacheTimeToLiveCdxSession.getIfPresent(wsSessionId);
        if (Objects.nonNull(socketCdxSession)) {
            guavaCacheTimeToLiveCdxSession.invalidate(wsSessionId);
        }
        // End
        LOGGER.info("After Connection Has Been Closed for Client IP: {}, CDX Session ID: {}, WS Session ID: {}", session.getRemoteAddress(), cdxSessionID, wsSessionId);
        LoggingUtil.resetLogAlert();

        super.getDelegate().afterConnectionClosed(session, closeStatus);

    }

}
