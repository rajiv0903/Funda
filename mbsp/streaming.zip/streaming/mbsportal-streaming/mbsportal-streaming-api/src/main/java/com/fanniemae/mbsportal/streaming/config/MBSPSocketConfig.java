/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */


package com.fanniemae.mbsportal.streaming.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.config.MBSPSocketConfig.java 
 * @Revision: 
 * @Description: MBSPSocketConfig.java
 */
@Component
@ConfigurationProperties("mbs.streaming.socket")
public class MBSPSocketConfig {

    private String socketEndpoint;
    private String destinationPrefixes;
    private String appDestinationPrefixes;    
    private Integer messageBrokerStatusFrequency;

    public String getSocketEndpoint() {
        return socketEndpoint;
    }

    public void setSocketEndpoint(String socketEndpoint) {
        this.socketEndpoint = socketEndpoint;
    }

    public String getDestinationPrefixes() {
        return destinationPrefixes;
    }

    public void setDestinationPrefixes(String destinationPrefixes) {
        this.destinationPrefixes = destinationPrefixes;
    }

    public String getAppDestinationPrefixes() {
        return appDestinationPrefixes;
    }

    public void setAppDestinationPrefixes(String appDestinationPrefixes) {
        this.appDestinationPrefixes = appDestinationPrefixes;
    }

    public Integer getMessageBrokerStatusFrequency() {
        return messageBrokerStatusFrequency;
    }

    public void setMessageBrokerStatusFrequency(Integer messageBrokerStatusFrequency) {
        this.messageBrokerStatusFrequency = messageBrokerStatusFrequency;
    }

    @Override
    public String toString() {
        return "MBSPSocketConfig [socketEndpoint=" + socketEndpoint + ", destinationPrefixes=" + destinationPrefixes
                + ", appDestinationPrefixes=" + appDestinationPrefixes + ", messageBrokerStatusFrequency="
                + messageBrokerStatusFrequency + "]";
    }

    

}
