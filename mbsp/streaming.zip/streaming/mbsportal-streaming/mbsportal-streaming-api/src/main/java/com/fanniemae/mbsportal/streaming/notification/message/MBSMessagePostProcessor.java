/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.notification.message;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.Message;
import org.springframework.messaging.core.MessagePostProcessor;
import org.springframework.stereotype.Component;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.notification.message.MBSMessagePostProcessor.java 
 * @Revision: 
 * @Description: MBSMessagePostProcessor.java
 */
@Component
public class MBSMessagePostProcessor implements MessagePostProcessor{

    private static final Logger LOGGER = LoggerFactory.getLogger(MBSMessagePostProcessor.class);
    
    /* (non-Javadoc)
     * @see org.springframework.messaging.core.MessagePostProcessor#postProcessMessage(org.springframework.messaging.Message)
     */
    @Override
    public Message<?> postProcessMessage(Message<?> message) {
        LOGGER.debug("Message Headers: {}", message.getHeaders());
        return message;
    }

}
