/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: Jun 4, 2018
 * @File: com.fanniemae.mbsportal.streaming.config.StreamingCdxCacheSessionConfig.java 
 * @Revision: 
 * @Description: StreamingCdxCacheSessionConfig.java
 */
@Component
@ConfigurationProperties("mbs.streaming.cdx.cache.session")
public class StreamingCdxCacheSessionConfig {

    private Long expireMinutesAfterWrite;
    private Long maximumSize;
    
    
    public Long getExpireMinutesAfterWrite() {
        return expireMinutesAfterWrite;
    }
    public void setExpireMinutesAfterWrite(Long expireMinutesAfterWrite) {
        this.expireMinutesAfterWrite = expireMinutesAfterWrite;
    }
    public Long getMaximumSize() {
        return maximumSize;
    }
    public void setMaximumSize(Long maximumSize) {
        this.maximumSize = maximumSize;
    }
    
}
