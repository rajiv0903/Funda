/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.jobs;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentMap;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.socket.CloseStatus;

import com.fanniemae.mbsportal.streaming.cdx.SocketCdxSession;
import com.fanniemae.mbsportal.streaming.cdx.client.CDXRetryableClientApi;
import com.fanniemae.mbsportal.streaming.cdx.client.constants.CDXHeaderMap;
import com.fanniemae.mbsportal.streaming.cdx.client.exception.CDXClientException;
import com.fanniemae.mbsportal.streaming.util.exception.HTTPUnAuthorizedException;
import com.fanniemae.mbsportal.streaming.util.exception.MBSExceptionConstants;
import com.fanniemae.mbsportal.streaming.util.logging.LoggingUtil;
import com.fanniemae.mbsportal.streaming.util.utility.StreamingUtil;
import com.google.common.cache.Cache;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: Jun 4, 2018
 * @File: com.fanniemae.mbsportal.streaming.jobs.SocketCdxSessionValidity.java
 * @Revision:
 * @Description: SocketCdxSessionValidity.java
 */
@Configuration
@EnableScheduling
@EnableAsync
public class SocketCdxSessionValidity {

    private static final Logger LOGGER = LoggerFactory.getLogger(SocketCdxSessionValidity.class);

    @Autowired
    CDXRetryableClientApi cDXRetryableClientApi;

    private final Cache<String, SocketCdxSession> guavaCacheTimeToLiveCdxSession;

    @Autowired
    public SocketCdxSessionValidity(
            @Qualifier("guavaCacheTimeToLiveCdxSession") final Cache<String, SocketCdxSession> guavaCacheTimeToLiveCdxSession) {

        this.guavaCacheTimeToLiveCdxSession = guavaCacheTimeToLiveCdxSession;
    }

    // @Scheduled(fixedRate = 1200000, initialDelay = 60000)
    public void sessionValidateJob() {

        LoggingUtil.logItForAlert("sessionValidateJob", "", "", "", "", "", "", "", "", "", "");
        LOGGER.debug("Session Map {}", guavaCacheTimeToLiveCdxSession.asMap());
        LoggingUtil.resetLogAlert();

        ConcurrentMap<String, SocketCdxSession> cacheDataMap = guavaCacheTimeToLiveCdxSession.asMap();
        if (Objects.nonNull(cacheDataMap)) {

            try {
                for (Map.Entry<String, SocketCdxSession> entry : cacheDataMap.entrySet()) {

                    String wsSessionId = (String) entry.getKey();
                    SocketCdxSession socketCdxSession = (SocketCdxSession) entry.getValue();

                    if (Objects.nonNull(socketCdxSession)
                            && StringUtils.isNotBlank(socketCdxSession.getCdxSessionID())) {
                        try {
                            Map<String, String> headerMap = new HashMap<>();
                            headerMap.put(CDXHeaderMap.CHANNEL.getValue(), socketCdxSession.getCdxChannel());
                            headerMap.put(CDXHeaderMap.SUB_CHANNEL.getValue(), socketCdxSession.getCdxSubChannel());
                            headerMap.put(CDXHeaderMap.SESSION_ID.getValue(), socketCdxSession.getCdxSessionID());
                            boolean sessionValid = cDXRetryableClientApi.sessionValidRetry(headerMap);
                            if (!sessionValid) {
                                LoggingUtil.logItForAlert("sessionValidateJob", "", "", "", "", "", wsSessionId,
                                        String.join(",", socketCdxSession.getDestinations()),
                                        StreamingUtil.getLeftPaddedString(socketCdxSession.getCdxSessionID()), "", "");
                                LOGGER.debug("Going to Destoy the WS Channel as session is no more valid");
                                if (socketCdxSession.getSession().isOpen()) {
                                    socketCdxSession.getSession().close(CloseStatus.NORMAL);
                                }
                                guavaCacheTimeToLiveCdxSession.invalidate(wsSessionId);
                                LoggingUtil.resetLogAlert();
                            }
                        } catch (HTTPUnAuthorizedException exe) {

                            LoggingUtil.logItForAlert("sessionValidateJob", "", MBSExceptionConstants.SYSTEM_EXCEPTION_IDENTIFIER, MBSExceptionConstants.SYSTEM_EXCEPTION.toString(), "", "", wsSessionId,
                                    String.join(",", socketCdxSession.getDestinations()),
                                    socketCdxSession.getCdxSessionID(), "", "");
                            LOGGER.error(
                                    "Going to Destoy the WS Channel as session is no more valid, HTTPUnAuthorizedException : {}",
                                    exe.getRootExceptionMessage());
                            LoggingUtil.resetLogAlert();

                            if (socketCdxSession.getSession().isOpen()) {
                                socketCdxSession.getSession().close(CloseStatus.POLICY_VIOLATION);
                            }
                            guavaCacheTimeToLiveCdxSession.invalidate(wsSessionId);

                        } catch (CDXClientException exe) {

                            LoggingUtil.logItForAlert("sessionValidateJob", "", MBSExceptionConstants.SYSTEM_EXCEPTION_IDENTIFIER, MBSExceptionConstants.SYSTEM_EXCEPTION.toString(), "", "", wsSessionId,
                                    String.join(",", socketCdxSession.getDestinations()),
                                    socketCdxSession.getCdxSessionID(), "", "");
                            LOGGER.error(
                                    "Going to Destoy the WS Channel as session is no more valid, CDXClientException : {}",
                                    exe.getRootExceptionMessage());
                            LoggingUtil.resetLogAlert();

                            if (socketCdxSession.getSession().isOpen()) {
                                socketCdxSession.getSession().close(CloseStatus.POLICY_VIOLATION);
                            }

                        }
                    }
                }
            } catch (IOException exe) {
                LoggingUtil.logItForAlert("sessionValidateJob", "", "", "", "", "", "", "", "", "", "");
                LOGGER.error("IOException : {}", exe);
                LoggingUtil.resetLogAlert();
            }
        } else {
            LoggingUtil.logItForAlert("sessionValidateJob", "", "", "", "", "", "", "", "", "", "");
            LOGGER.debug("No data in cache");
            LoggingUtil.resetLogAlert();
        }
        LoggingUtil.resetLogAlert();
    }

    @Scheduled(cron = "0 0 0 * * *")
    public void midNightJob() {

        LoggingUtil.logItForAlert("midNightJob", "", "", "", "", "", "", "", "", "", "");
        LOGGER.info("Session Map {}", guavaCacheTimeToLiveCdxSession.asMap());
        LoggingUtil.resetLogAlert();

        ConcurrentMap<String, SocketCdxSession> cacheDataMap = guavaCacheTimeToLiveCdxSession.asMap();
        if (Objects.nonNull(cacheDataMap)) {
            for (Map.Entry<String, SocketCdxSession> entry : cacheDataMap.entrySet()) {

                String wsSessionId = (String) entry.getKey();
                SocketCdxSession socketCdxSession = (SocketCdxSession) entry.getValue();
                if (Objects.nonNull(socketCdxSession) && Objects.nonNull(socketCdxSession.getSession())
                        && socketCdxSession.getSession().isOpen()) {
                    try {
                        LoggingUtil.logItForAlert("midNightJob", "", "", "", "", "", wsSessionId,
                                String.join(",", socketCdxSession.getDestinations()),
                                StreamingUtil.getLeftPaddedString(socketCdxSession.getCdxSessionID()), "", "");
                        LOGGER.debug("Going to Destoy the WS Channel as session is no more valid");
                        socketCdxSession.getSession().close(CloseStatus.NORMAL);
                        guavaCacheTimeToLiveCdxSession.invalidate(wsSessionId);
                        LoggingUtil.resetLogAlert();

                    } catch (Exception exe) {
                        LoggingUtil.logItForAlert("midNightJob", "", "", "", "", "", wsSessionId,
                                String.join(",", socketCdxSession.getDestinations()),
                                StreamingUtil.getLeftPaddedString(socketCdxSession.getCdxSessionID()), "", "");
                        LOGGER.error("Exception : {}", exe);
                        LoggingUtil.resetLogAlert();
                    }
                }

            }
            // finally if any left then it will clear all
            guavaCacheTimeToLiveCdxSession.invalidateAll();
        }
    }
}
