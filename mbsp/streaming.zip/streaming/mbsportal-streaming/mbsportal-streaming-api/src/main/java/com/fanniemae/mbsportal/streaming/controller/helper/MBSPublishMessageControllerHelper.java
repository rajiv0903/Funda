/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */
package com.fanniemae.mbsportal.streaming.controller.helper;

import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

import com.fanniemae.mbsportal.streaming.cdx.client.constants.CDXHeaderMap;
import com.fanniemae.mbsportal.streaming.cdx.client.exception.CDXClientException;
import com.fanniemae.mbsportal.streaming.config.MBSPHandshakeClientConfig;
import com.fanniemae.mbsportal.streaming.handshake.MBSSystemHandshakeClient;
import com.fanniemae.mbsportal.streaming.model.StreamingMessage;
import com.fanniemae.mbsportal.streaming.model.StreamingMessageDetails;
import com.fanniemae.mbsportal.streaming.notification.message.MBSMessagePostProcessor;
import com.fanniemae.mbsportal.streaming.util.constants.MBSStreamingConstants;
import com.fanniemae.mbsportal.streaming.util.exception.HTTPUnAuthorizedException;
import com.fanniemae.mbsportal.streaming.util.exception.MBSBaseException;
import com.fanniemae.mbsportal.streaming.util.exception.MBSExceptionConstants;
import com.fanniemae.mbsportal.streaming.util.exception.MBSSystemException;
import com.fanniemae.mbsportal.streaming.util.logging.LoggingUtil;
import com.fanniemae.mbsportal.streaming.util.utility.StreamingUtil;
import com.google.common.cache.Cache;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: Jun 8, 2018
 * @File: com.fanniemae.mbsportal.streaming.controller.helper.MBSPublishMessageControllerHelper.java
 * @Revision:
 * @Description: MBSPublishMessageControllerHelper.java
 */
@Component
public class MBSPublishMessageControllerHelper {

    private static final Logger LOGGER = LoggerFactory.getLogger(MBSPublishMessageControllerHelper.class);

    @Autowired
    private SimpMessagingTemplate template;

    @Autowired
    private MBSMessagePostProcessor mbsMessagePostProcessor;

    @Autowired
    private MBSSystemHandshakeClient mBSSystemHandshakeClient;

    @Autowired
    private MBSPHandshakeClientConfig mBSPHandshakeClientConfig;

    private final Cache<String, String> guavaCacheTimeToLiveHandshake;

    @Autowired
    public MBSPublishMessageControllerHelper(
            @Qualifier("guavaCacheTimeToLiveHandshake") final Cache<String, String> guavaCacheTimeToLiveHandshake) {

        this.guavaCacheTimeToLiveHandshake = guavaCacheTimeToLiveHandshake;
    }

    public void publish(StreamingMessage streamingMessage, Map<String, String> headers)
            throws MBSBaseException, ExecutionException {

        LOGGER.debug("Entering publish method in MBSPublishMessageControllerHelper");

        LoggingUtil.logItForAlert("publish", "", "", "", "PUBLISH", "", "", "", "", "", "");
        LOGGER.debug("streamingMessage: {}", streamingMessage);
        LoggingUtil.resetLogAlert();

        performHandshake(headers);

        for (StreamingMessageDetails streamingMessageDetails : streamingMessage.getMessages()) {
            for (String topic : streamingMessageDetails.getTopics()) {

                LoggingUtil.logItForAlert("publish", "", "", "", "PUBLISH", "", "", topic, "", "", "");
                LOGGER.info("streamingMessageDetails (Identifier) : {}",
                        streamingMessageDetails.getMessageIdentifierMap());
                LoggingUtil.resetLogAlert();

                template.convertAndSend(topic, streamingMessageDetails.getMessage(),
                        streamingMessageDetails.getMessageHeader(), mbsMessagePostProcessor);
            }
        }

        LOGGER.debug("Exiting publish in MBSPublishMessageControllerHelper");
    }
    
    /**
     * 
     * 
     * @param headersMap
     * @throws MBSBaseException
     */
    private void performHandshake(final Map<String, String> headersMap) throws MBSBaseException, ExecutionException {

        LOGGER.debug("Entering performHandshake method in MBSPublishMessageControllerHelper");

        String sessionId = null;
        String cdxSessionId = null;
        
        if (mBSPHandshakeClientConfig.isPassthrough()) {
            return;
        }
        cdxSessionId = headersMap.get(CDXHeaderMap.SESSION_ID.getValue());
        
        // Passing CDX Session ID
        if (StringUtils.isBlank(cdxSessionId)) {
            throw new MBSSystemException("Failed to Perform Handshake with MBSP for headersMap: {" + headersMap + "}",
                    MBSExceptionConstants.SYSTEM_EXCEPTION);

        }
        // Get existing session ID
        sessionId = guavaCacheTimeToLiveHandshake.getIfPresent(MBSStreamingConstants.MBS_HANDNSHAKE_CACHE_KEY);
        
        // If existing session does not exist or mismatch then perform authorize
        // and save the session
        if (StringUtils.isBlank(sessionId) || StringUtils.compare(cdxSessionId, sessionId) != 0) {

            try {
                LOGGER.info("Going to Authorize the session ID: {}", StreamingUtil.getLeftPaddedString(cdxSessionId));                
                mBSSystemHandshakeClient.authorize(headersMap);

            } catch (HTTPUnAuthorizedException exe) {
                
                LoggingUtil.logItForAlert("performHandshake", "", MBSExceptionConstants.SYSTEM_EXCEPTION_IDENTIFIER,
                        MBSExceptionConstants.SYSTEM_EXCEPTION.toString(), "HANDSHAKE", "", "", "", "", "", "");
                LOGGER.error("HTTPUnAuthorizedException: {}", exe.getRootExceptionMessage());
                LoggingUtil.resetLogAlert();

                throw new MBSSystemException(
                        "Failed to Perform Handshake with MBSP for headersMap: {" + headersMap + "}",
                        MBSExceptionConstants.SYSTEM_EXCEPTION);

            } catch (CDXClientException exe) {
                
                LoggingUtil.logItForAlert("performHandshake", "", MBSExceptionConstants.SYSTEM_EXCEPTION_IDENTIFIER,
                        MBSExceptionConstants.SYSTEM_EXCEPTION.toString(), "HANDSHAKE", "", "", "", "", "", "");
                LOGGER.error("CDXClientException: {}", exe.getRootExceptionMessage());
                LoggingUtil.resetLogAlert();

                throw new MBSSystemException(
                        "Failed to Perform Handshake with MBSP for headersMap: {" + headersMap + "}",
                        MBSExceptionConstants.SYSTEM_EXCEPTION);
                
            }
            //save the new session ID
            guavaCacheTimeToLiveHandshake.put(MBSStreamingConstants.MBS_HANDNSHAKE_CACHE_KEY, cdxSessionId);
        }

        LOGGER.debug("Exiting performHandshake method  in MBSPublishMessageControllerHelper");

    }
}
