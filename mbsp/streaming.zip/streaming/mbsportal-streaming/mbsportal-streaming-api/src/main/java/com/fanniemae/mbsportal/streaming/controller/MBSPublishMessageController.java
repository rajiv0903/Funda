/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.controller;

import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fanniemae.mbsportal.streaming.controller.helper.MBSPublishMessageControllerHelper;
import com.fanniemae.mbsportal.streaming.model.StreamingMessage;
import com.fanniemae.mbsportal.streaming.util.exception.MBSBaseException;
import com.fanniemae.mbsportal.streaming.util.exception.MBSExceptionConstants;
import com.fanniemae.mbsportal.streaming.util.logging.LoggingUtil;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: Jun 8, 2018
 * @File: com.fanniemae.mbsportal.streaming.controller.MBSPublishMessageController.java
 * @Revision:
 * @Description: MBSPublishMessageController.java
 */
@RestController
public class MBSPublishMessageController extends BaseController {

    private static final Logger LOGGER = LoggerFactory.getLogger(MBSPublishMessageController.class);

    @Autowired
    private MBSPublishMessageControllerHelper mBSPublishMessageControllerHelper;

    @RequestMapping(value = "/publish/message", method = RequestMethod.POST, produces = {
            MediaType.APPLICATION_JSON_VALUE, "application/vnd.fnma-v1+json" })
    public ResponseEntity<Void> publishMessage(@RequestBody StreamingMessage streamingMessage,
            @RequestHeader Map<String, String> headers) {

        LOGGER.debug("Entering publishMessage method in MBSPublishMessageController");

        try {

            mBSPublishMessageControllerHelper.publish(streamingMessage, headers);

        } catch (MBSBaseException ex) {
            LoggingUtil.logItForAlert("publishMessage", "", MBSExceptionConstants.SYSTEM_EXCEPTION_IDENTIFIER,
                    MBSExceptionConstants.SYSTEM_EXCEPTION.toString(), "PUBLISH", "", "", "", "", "", "");
            LOGGER.error("MBSBaseException: {}", ex.getRootExceptionMessage());
            LoggingUtil.resetLogAlert();
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        } catch (Exception ex) {
            LoggingUtil.logItForAlert("publishMessage", "", MBSExceptionConstants.SYSTEM_EXCEPTION_IDENTIFIER,
                    MBSExceptionConstants.SYSTEM_EXCEPTION.toString(), "PUBLISH", "", "", "", "", "", "");
            LOGGER.error("Exception: {}", ex);
            LoggingUtil.resetLogAlert();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
        LOGGER.debug("Exiting publishMessage in MBSPublishMessageController");

        return ResponseEntity.status(HttpStatus.OK).build();
    }
}
