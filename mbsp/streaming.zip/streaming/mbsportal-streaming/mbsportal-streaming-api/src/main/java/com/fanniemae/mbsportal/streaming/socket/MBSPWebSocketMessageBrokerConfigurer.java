/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */
package com.fanniemae.mbsportal.streaming.socket;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.converter.MessageConverter;
import org.springframework.messaging.simp.config.ChannelRegistration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.config.annotation.AbstractWebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketTransportRegistration;
import org.springframework.web.socket.handler.WebSocketHandlerDecorator;
import org.springframework.web.socket.handler.WebSocketHandlerDecoratorFactory;

import com.fanniemae.mbsportal.streaming.cdx.SocketCdxSession;
import com.fanniemae.mbsportal.streaming.cdx.client.CDXRetryableClientApi;
import com.fanniemae.mbsportal.streaming.cdx.client.config.CDXApiClientConfig;
import com.fanniemae.mbsportal.streaming.config.MBSPSocketConfig;
import com.fanniemae.mbsportal.streaming.socket.decorator.MBSPWebSocketHandlerDecorator;
import com.fanniemae.mbsportal.streaming.socket.interceptor.MBSPChannelInterceptorAdapterImpl;
import com.fanniemae.mbsportal.streaming.socket.interceptor.MBSPHttpSessionIdHandshakeInterceptor;
import com.google.common.cache.Cache;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.socket.MBSPWebSocketMessageBrokerConfigurer.java 
 * @Revision: 
 * @Description: MBSPWebSocketMessageBrokerConfigurer.java
 */
@Configuration
@EnableWebSocketMessageBroker()
public class MBSPWebSocketMessageBrokerConfigurer 
extends AbstractWebSocketMessageBrokerConfigurer
        implements WebSocketMessageBrokerConfigurer {

    @Autowired
    MBSPSocketConfig mBSPSocketConfig;
    
    @Autowired
    CDXRetryableClientApi cDXRetryableClientApi;
    
    @Autowired
    CDXApiClientConfig cDXApiClientConfig;
    
    private final Cache<String, SocketCdxSession> guavaCacheTimeToLiveCdxSession;
    
    @Autowired
    public MBSPWebSocketMessageBrokerConfigurer(@Qualifier("guavaCacheTimeToLiveCdxSession") final Cache<String, SocketCdxSession> guavaCacheTimeToLiveCdxSession){
        this.guavaCacheTimeToLiveCdxSession = guavaCacheTimeToLiveCdxSession;
    }
    
    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        registry.enableSimpleBroker(mBSPSocketConfig.getDestinationPrefixes().split(","));
        registry.setApplicationDestinationPrefixes(mBSPSocketConfig.getAppDestinationPrefixes());
        ThreadPoolTaskExecutor taskExecutorBrokerChannel = new  ThreadPoolTaskExecutor();
        taskExecutorBrokerChannel.setMaxPoolSize(20);
        taskExecutorBrokerChannel.setCorePoolSize(10);
        registry.configureBrokerChannel().taskExecutor(taskExecutorBrokerChannel);
 
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint(mBSPSocketConfig.getSocketEndpoint()).setAllowedOrigins("*").withSockJS()
                .setInterceptors(new MBSPHttpSessionIdHandshakeInterceptor());
        
        
    }

    @Override
    public void configureClientInboundChannel(final ChannelRegistration registration) {
        registration.interceptors(new MBSPChannelInterceptorAdapterImpl(cDXRetryableClientApi, cDXApiClientConfig, guavaCacheTimeToLiveCdxSession));
        ThreadPoolTaskExecutor taskExecutorInboundChannel = new  ThreadPoolTaskExecutor();
        taskExecutorInboundChannel.setMaxPoolSize(20);
        taskExecutorInboundChannel.setCorePoolSize(10);
		registration.taskExecutor(taskExecutorInboundChannel);
    }

    @Override
    public void configureWebSocketTransport(WebSocketTransportRegistration registration) {
        registration.setDecoratorFactories(new WebSocketHandlerDecoratorFactory() {
            @Override
            public WebSocketHandlerDecorator decorate(WebSocketHandler handler) {
                return new MBSPWebSocketHandlerDecorator(handler, guavaCacheTimeToLiveCdxSession);
            }
        });

    }

	@Override
	public void configureClientOutboundChannel(ChannelRegistration registration) {
		
		 ThreadPoolTaskExecutor taskExecutorOutboundChannel = new  ThreadPoolTaskExecutor();
	        taskExecutorOutboundChannel.setMaxPoolSize(20);
	        taskExecutorOutboundChannel.setCorePoolSize(10);
			registration.taskExecutor(taskExecutorOutboundChannel);
	}

	//@Override
//	public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
//		// TODO Auto-generated method stub
		
//	}

//	@Override
//	public void addReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers) {
//		// TODO Auto-generated method stub
//		
//	}

	@Override
	public boolean configureMessageConverters(List<MessageConverter> messageConverters) {
		// TODO Auto-generated method stub
		return false;
	}

}
