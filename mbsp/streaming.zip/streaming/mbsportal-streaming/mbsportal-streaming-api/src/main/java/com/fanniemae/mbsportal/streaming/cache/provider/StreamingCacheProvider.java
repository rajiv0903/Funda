/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.cache.provider;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Profile;

import com.fanniemae.mbsportal.streaming.cache.framework.bean.GuavaCacheTimeToLiveBean;
import com.fanniemae.mbsportal.streaming.cdx.SocketCdxSession;
import com.fanniemae.mbsportal.streaming.config.StreamingCacheHandshakeConfig;
import com.fanniemae.mbsportal.streaming.config.StreamingCdxCacheSessionConfig;
import com.google.common.cache.Cache;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 11, 2018
 * @File: com.fanniemae.mbsportal.streaming.cache.provider.StreamingCacheProvider.java
 * @Revision:
 * @Description: StreamingCacheProvider.java
 */
@Configuration
@Import({ StreamingCacheHandshakeConfig.class })
@Profile({ "default", "LOCAL", "DEV", "ACPT", "TEST", "PROD" , "PERF"})
public class StreamingCacheProvider {


    /**
     * 
     * streamingCacheHandshakeConfig StreamingCacheHandshakeConfig
     */
    @Autowired
    StreamingCacheHandshakeConfig streamingCacheHandshakeConfig;
    
    /**
     * 
     * streamingCdxCacheSessionConfig StreamingCdxCacheSessionConfig
     */
    @Autowired
    StreamingCdxCacheSessionConfig streamingCdxCacheSessionConfig;

    @Bean(name = "guavaCacheTimeToLiveHandshake")
    public Cache<String, String> guavaCacheTimeToLiveHandshake() throws Exception {

        Cache<String, String> guavaCacheTimeToLiveHandshake = null;
        GuavaCacheTimeToLiveBean<String, String> guavaCacheTimeToLiveBean = new GuavaCacheTimeToLiveBean<String, String>();
        guavaCacheTimeToLiveBean.setExpireMinutesAfterWrite(streamingCacheHandshakeConfig.getExpireMinutesAfterWrite());
        guavaCacheTimeToLiveBean.setMaximumSize(streamingCacheHandshakeConfig.getMaximumSize());
        guavaCacheTimeToLiveHandshake = guavaCacheTimeToLiveBean.getObject();
        return guavaCacheTimeToLiveHandshake;
    }
    
    @Bean(name = "guavaCacheTimeToLiveCdxSession")
    public Cache<String, SocketCdxSession> guavaCacheTimeToLiveCdxSession() throws Exception {

        Cache<String, SocketCdxSession> guavaCacheTimeToLiveCdxSession = null;
        GuavaCacheTimeToLiveBean<String, SocketCdxSession> guavaCacheTimeToLiveBean = new GuavaCacheTimeToLiveBean<String, SocketCdxSession>();
        guavaCacheTimeToLiveBean.setExpireMinutesAfterWrite(null);
        guavaCacheTimeToLiveBean.setMaximumSize(streamingCdxCacheSessionConfig.getMaximumSize());
        guavaCacheTimeToLiveCdxSession = guavaCacheTimeToLiveBean.getObject();
        return guavaCacheTimeToLiveCdxSession;
    }
}
