/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.handshake;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fanniemae.mbsportal.streaming.cdx.client.CDXRetryableClientApi;
import com.fanniemae.mbsportal.streaming.cdx.client.exception.CDXClientException;
import com.fanniemae.mbsportal.streaming.config.MBSPHandshakeClientConfig;
import com.fanniemae.mbsportal.streaming.util.exception.HTTPUnAuthorizedException;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.handshake.MBSSystemHandshakeClient.java
 * @Revision:
 * @Description: MBSSystemHandshakeClient.java
 */
@Component
public class MBSSystemHandshakeClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(MBSSystemHandshakeClient.class);

    /**
     * 
     * mbsRestInternalTemplate MBSRestInternalTemplate
     */
    @Autowired
    private MBSPHandshakeClientConfig mBSPHandshakeClientConfig;

    /**
     * 
     * cDXRetryableClientApi CDXRetryableClientApi
     */
    @Autowired
    private CDXRetryableClientApi cDXRetryableClientApi;

    /**
     * It will check whether the session being passed is valid or not if not
     * valid will throw CDXClientException or HTTPUnAuthorizedException
     * 
     * @param headersMap
     * @throws CDXClientException
     * @throws HTTPUnAuthorizedException
     */
    public void authorize(Map<String, String> headersMap) throws CDXClientException, HTTPUnAuthorizedException {

        LOGGER.debug("Entering authorize method in MBSSystemHandshakeClient");
        if (mBSPHandshakeClientConfig.isPassthrough()) {
            return;
        }
        // It will throw error if session is not valid
        cDXRetryableClientApi.sessionValidRetry(headersMap);

        LOGGER.debug("Exiting authorize method in MBSSystemHandshakeClient");
    }

}
