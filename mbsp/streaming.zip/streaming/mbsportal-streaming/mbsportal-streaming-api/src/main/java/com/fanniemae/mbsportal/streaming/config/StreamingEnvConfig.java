/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Profile;

import com.fanniemae.mbsportal.streaming.cdx.client.config.CDXApiClientConfig;


/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.config.StreamingEnvConfig.java 
 * @Revision: 
 * @Description: StreamingEnvConfig.java
 */

@Configuration
@Import({ CDXApiClientConfig.class })
@Profile({ "default", "LOCAL", "DEV", "ACPT", "TEST", "PROD", "PERF" })
public class StreamingEnvConfig {

   
}