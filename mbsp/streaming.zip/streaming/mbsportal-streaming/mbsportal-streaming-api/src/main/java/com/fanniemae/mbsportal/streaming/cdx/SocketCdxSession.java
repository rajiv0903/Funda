/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.cdx;

import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.socket.WebSocketSession;

import com.fanniemae.mbsportal.streaming.cdx.client.model.CDXUserProfile;
import com.fanniemae.mbsportal.streaming.util.utility.StreamingUtil;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: Jun 4, 2018
 * @File: com.fanniemae.mbsportal.streaming.cdx.SocketCdxSession.java
 * @Revision:
 * @Description: SocketCdxSession.java
 */
public class SocketCdxSession {

    private String wsSessionId;
    private String cdxChannel;
    private String cdxSubChannel;
    private String cdxSessionID;
    private String userName;
    private List<String> destinations;
    private WebSocketSession session;
    private CDXUserProfile cDXUserProfile;

    public SocketCdxSession() {
    }

    public SocketCdxSession(String wsSessionId, WebSocketSession session) {
        super();
        this.wsSessionId = wsSessionId;
        this.session = session;
    }

    public SocketCdxSession assignCdxIdentifier(String cdxChannel, String cdxSubChannel, String cdxSessionID,
            String userName, String destination, CDXUserProfile cDXUserProfile) {
        this.cdxChannel = cdxChannel;
        this.cdxSubChannel = cdxSubChannel;
        this.cdxSessionID = cdxSessionID;
        this.userName = userName;
        if (this.destinations == null) {
            this.destinations = new LinkedList<>();
        }
        this.assignDestination(destination);
        this.cDXUserProfile = cDXUserProfile;
        return this;
    }

    public String getWsSessionId() {
        return wsSessionId;
    }

    public void setWsSessionId(String wsSessionId) {
        this.wsSessionId = wsSessionId;
    }

    public String getCdxChannel() {
        return cdxChannel;
    }

    public void setCdxChannel(String cdxChannel) {
        this.cdxChannel = cdxChannel;
    }

    public String getCdxSubChannel() {
        return cdxSubChannel;
    }

    public void setCdxSubChannel(String cdxSubChannel) {
        this.cdxSubChannel = cdxSubChannel;
    }

    public String getCdxSessionID() {
        return cdxSessionID;
    }

    public void setCdxSessionID(String cdxSessionID) {
        this.cdxSessionID = cdxSessionID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public WebSocketSession getSession() {
        return session;
    }

    public void setSession(WebSocketSession session) {
        this.session = session;
    }

    public List<String> getDestinations() {
        return destinations;
    }

    public void setDestinations(List<String> destinations) {
        this.destinations = destinations;
    }

    public void assignDestination(String destination) {
        if (this.destinations == null) {
            this.destinations = new LinkedList<>();
        }

        if (StringUtils.isNotBlank(destination)) {
            this.destinations.add(destination);
        }
    }
    
    public CDXUserProfile getcDXUserProfile() {
        return cDXUserProfile;
    }

    public void setcDXUserProfile(CDXUserProfile cDXUserProfile) {
        this.cDXUserProfile = cDXUserProfile;
    }

    @Override
    public String toString() {
        return "SocketCdxSession [wsSessionId=" + wsSessionId + ", cdxSessionID=" + StreamingUtil.getLeftPaddedString(cdxSessionID) + ", userName="
                + userName + ", destinations=" + destinations + ", cDXUserProfile=" + cDXUserProfile +"]";
    }

}
