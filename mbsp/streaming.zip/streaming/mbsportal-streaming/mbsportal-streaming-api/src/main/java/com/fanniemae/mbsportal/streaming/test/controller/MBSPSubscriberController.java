/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */
package com.fanniemae.mbsportal.streaming.test.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fanniemae.mbsportal.streaming.controller.BaseController;
import com.fanniemae.mbsportal.streaming.controller.interceptor.entitlement.EntitlementRequired;
import com.fanniemae.mbsportal.streaming.controller.interceptor.header.HeaderRequired;
import com.fanniemae.mbsportal.streaming.test.model.MBSSubscriptionMessageImpl;
import com.fanniemae.mbsportal.streaming.test.model.SubscriptionMessage;
import com.fanniemae.mbsportal.streaming.test.notification.MBSPSubscriberNotificationImpl;
import com.fanniemae.mbsportal.streaming.test.subscriber.SubscriberInfo;
import com.fanniemae.mbsportal.streaming.util.logging.LoggingUtil;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.test.controller.MBSPSubscriberController.java 
 * @Revision: 
 * @Description: MBSPSubscriberController.java
 */
@RestController
public class MBSPSubscriberController extends BaseController {

    private static final Logger LOGGER = LoggerFactory.getLogger(MBSPSubscriberController.class);

    @Autowired
    private MBSPSubscriberNotificationImpl mBSPSubscriberNotificationImpl;
    
    private static final String DESTINATION_PREFIX= "/mbsp/topic/";


    @HeaderRequired
    @EntitlementRequired(roles = { "ADMIN" })
    @RequestMapping(value = "/register/{topic}/{username}", method = RequestMethod.POST, produces = {
            MediaType.APPLICATION_JSON_VALUE, "application/vnd.fnma-v1+json" })
    public ResponseEntity<String> registerUser(@PathVariable("topic") String topic, @PathVariable("username") String username) {

        String topicDestination = DESTINATION_PREFIX +topic +"/"+ username;
        
        LoggingUtil.logItForAlert("registerUser", "", "", "", "REGISTER_USER", "", "", topicDestination, "", username, "");
        LOGGER.debug("Username : {}", username);
        LoggingUtil.resetLogAlert();
        
        SubscriberInfo subscriberInfo = new SubscriberInfo();
        subscriberInfo.setDestination(topicDestination);
        SubscriptionMessage subscriptionMessage = new MBSSubscriptionMessageImpl();
        subscriptionMessage.setDestination(topicDestination);
        subscriptionMessage.setContent("{ Hello, " + username + "!}");
        subscriberInfo.setSubscriptionMessage(subscriptionMessage);

        mBSPSubscriberNotificationImpl.getSubscribers().add(subscriberInfo);
        return ResponseEntity.ok("SUCCESS");
    }

    @HeaderRequired
    @EntitlementRequired(roles = { "ADMIN" })
    @RequestMapping(value = "/unregister/{topic}/{username}", method = RequestMethod.POST, produces = {
            MediaType.APPLICATION_JSON_VALUE, "application/vnd.fnma-v1+json" })
    public ResponseEntity<String> unRegisterUser(@PathVariable("topic") String topic, @PathVariable("username") String username) {
        
        String topicDestination = DESTINATION_PREFIX  +topic +"/"+ username;
        
        LoggingUtil.logItForAlert("unRegisterUser", "", "", "", "UN_REGISTER_USER", "", "", topicDestination, "", username, "");
        LOGGER.debug("Username : {}", username);
        LoggingUtil.resetLogAlert();
        
        SubscriberInfo subscriberInfo = new SubscriberInfo();
        subscriberInfo.setDestination(topicDestination);

        mBSPSubscriberNotificationImpl.getSubscribers().remove(subscriberInfo);

        return ResponseEntity.ok("SUCCESS");
    }
}
