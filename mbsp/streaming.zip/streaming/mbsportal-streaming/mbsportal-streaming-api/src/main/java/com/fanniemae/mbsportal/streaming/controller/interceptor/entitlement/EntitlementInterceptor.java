/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */


package com.fanniemae.mbsportal.streaming.controller.interceptor.entitlement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.fanniemae.mbsportal.streaming.cdx.client.config.CDXApiClientConfig;
import com.fanniemae.mbsportal.streaming.util.logging.LoggingUtil;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.controller.interceptor.entitlement.EntitlementInterceptor.java 
 * @Revision: 
 * @Description: EntitlementInterceptor.java
 */
@Component
public class EntitlementInterceptor extends HandlerInterceptorAdapter {

    private static final Logger LOGGER = LoggerFactory.getLogger(EntitlementInterceptor.class);

    /**
     * 
     * cDXApiClientConfig CDXApiClientConfig
     */
    @Autowired
    CDXApiClientConfig cDXApiClientConfig;

    /**
     * 
     * 
     * @param request
     *            the HttpServletRequest
     * @param response
     *            the HttpServletResponse
     * @param handler
     *            the handler
     * @return boolena
     * @throws Exception
     * 
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {

        if (handler instanceof HandlerMethod) {

            HandlerMethod handlerMethod = (HandlerMethod) handler;
            EntitlementRequired entitlementRequired = handlerMethod.getMethodAnnotation(EntitlementRequired.class);

            if (entitlementRequired != null) {
                
                LoggingUtil.logItForAlert("preHandle", "", "", "", "", "", "", "", "", "", "");
                LOGGER.debug("Request Header Names: {}",request.getHeaderNames());
                LoggingUtil.resetLogAlert();
                
                // response.reset();
                // response.sendError(HttpStatus.BAD_REQUEST.value(), "Token for
                // Authorization is missing!");
                // return false;
                return super.preHandle(request, response, handler);
            }
        }
        return super.preHandle(request, response, handler);
    }
}
