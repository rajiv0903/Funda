/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */
package com.fanniemae.mbsportal.streaming.socket.interceptor;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptorAdapter;
import org.springframework.messaging.support.MessageHeaderAccessor;
import org.springframework.web.socket.CloseStatus;

import com.fanniemae.mbsportal.streaming.cdx.SocketCdxSession;
import com.fanniemae.mbsportal.streaming.cdx.client.CDXRetryableClientApi;
import com.fanniemae.mbsportal.streaming.cdx.client.config.CDXApiClientConfig;
import com.fanniemae.mbsportal.streaming.cdx.client.constants.CDXHeaderMap;
import com.fanniemae.mbsportal.streaming.cdx.client.constants.EntitlementRole;
import com.fanniemae.mbsportal.streaming.cdx.client.exception.CDXClientException;
import com.fanniemae.mbsportal.streaming.cdx.client.model.CDXUserProfile;
import com.fanniemae.mbsportal.streaming.util.exception.HTTPUnAuthorizedException;
import com.fanniemae.mbsportal.streaming.util.exception.MBSExceptionConstants;
import com.fanniemae.mbsportal.streaming.util.logging.LoggingUtil;
import com.fanniemae.mbsportal.streaming.util.utility.StreamingUtil;
import com.google.common.cache.Cache;

/**
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.socket.interceptor.MBSPChannelInterceptorAdapterImpl.java
 * @Revision:
 * @Description: MBSPChannelInterceptorAdapterImpl.java
 */
public class MBSPChannelInterceptorAdapterImpl extends ChannelInterceptorAdapter {

    private static final Logger LOGGER = LoggerFactory.getLogger(MBSPChannelInterceptorAdapterImpl.class);
    private final Cache<String, SocketCdxSession> guavaCacheTimeToLiveCdxSession;
    private CDXRetryableClientApi cDXRetryableClientApi;
    private CDXApiClientConfig cDXApiClientConfig;

    public MBSPChannelInterceptorAdapterImpl(CDXRetryableClientApi cDXRetryableClientApi,
            CDXApiClientConfig cDXApiClientConfig,
            final Cache<String, SocketCdxSession> guavaCacheTimeToLiveCdxSession) {
        this.cDXRetryableClientApi = cDXRetryableClientApi;
        this.cDXApiClientConfig = cDXApiClientConfig;
        this.guavaCacheTimeToLiveCdxSession = guavaCacheTimeToLiveCdxSession;
    }

    @Override
    public Message<?> preSend(final Message<?> message, final MessageChannel channel) {
        CDXUserProfile cDXUserProfile = null;
        String wsSessionId = null;
        String cdxSessionID = null;
        StompCommand command = null;
        String destination = null;
        LOGGER.debug("Entitlement Pass Through: {}", cDXApiClientConfig.isEntitlementpassthrough());
        try {
            if (!cDXApiClientConfig.isEntitlementpassthrough()) {
                final StompHeaderAccessor accessor = MessageHeaderAccessor.getAccessor(message,
                        StompHeaderAccessor.class);
                String cdxChannel = accessor.getFirstNativeHeader(CDXHeaderMap.CHANNEL.getValue());
                String cdxSubChannel = accessor.getFirstNativeHeader(CDXHeaderMap.SUB_CHANNEL.getValue());
                cdxSessionID = accessor.getFirstNativeHeader(CDXHeaderMap.SESSION_ID.getValue());

                destination = accessor.getDestination();
                wsSessionId = accessor.getSessionId();
                command = accessor.getCommand();

                if (StompCommand.DISCONNECT == command
                        || (StompCommand.CONNECT == command && !StringUtils.isBlank(destination)))
                    return null;

                LoggingUtil.logItForAlert("preSend", "", "", "", command.name(), "", wsSessionId, destination,
                        StreamingUtil.getLeftPaddedString(cdxSessionID), "", "");
                LoggingUtil.resetLogAlert();
                Map<String, String> headerMap = new HashMap<>();
                headerMap.put(CDXHeaderMap.CHANNEL.getValue(), cdxChannel);
                headerMap.put(CDXHeaderMap.SUB_CHANNEL.getValue(), cdxSubChannel);
                headerMap.put(CDXHeaderMap.SESSION_ID.getValue(), cdxSessionID);
                // validate headers for null
                if (Objects.isNull(cdxChannel) || Objects.isNull(cdxSubChannel) || Objects.isNull(cdxSessionID)) {
                    LOGGER.info("CDX header is null cdxChannel: {} cdxSubChannel: {} cdxSessionID: {} ", cdxChannel,
                            cdxSubChannel, cdxSessionID);
                    // throw new RuntimeException("Mandatory header missing for
                    // Auth");
                }
                // During connect or Subscribe
                SocketCdxSession socketCdxSession = guavaCacheTimeToLiveCdxSession.getIfPresent(wsSessionId);

                if (StompCommand.CONNECT == command) {
                    /*
                     * First Time User Coming to System - Connect with session
                     * ID Socket CDX Session already Established CDX Session ID
                     * does not exists
                     */
                    if (Objects.nonNull(socketCdxSession) && StringUtils.isBlank(socketCdxSession.getCdxSessionID())) {

                        cDXUserProfile = cDXRetryableClientApi.getProfileFromSessionRetry(headerMap);

                        // Get the user name
                        String userName = cDXUserProfile.getUserName();

                        // Log the information
                        LoggingUtil.logItForAlert("preSend", "", "", "", command.name(), "", wsSessionId, destination,
                                StreamingUtil.getLeftPaddedString(cdxSessionID), userName, "");
                        LOGGER.info("First time user coming, User Name: {}", cDXUserProfile.getUserName());
                        LoggingUtil.resetLogAlert();

                        guavaCacheTimeToLiveCdxSession.put(wsSessionId, socketCdxSession.assignCdxIdentifier(cdxChannel,
                                cdxSubChannel, cdxSessionID, userName, destination, cDXUserProfile));
                    }

                } else if (StompCommand.SUBSCRIBE == command || StompCommand.UNSUBSCRIBE == command) {

                    /*
                     * First Time User Coming to System - Connect with session
                     * ID Socket CDX Session already Established CDX Session ID
                     * registered
                     */
                    if (Objects.nonNull(socketCdxSession)
                            && StringUtils.isNotBlank(socketCdxSession.getCdxSessionID())) {

                        LoggingUtil.logItForAlert("preSend", "", "", "", command.name(), "", wsSessionId, destination,
                                StreamingUtil.getLeftPaddedString(cdxSessionID), socketCdxSession.getUserName(), "");
                        LOGGER.info("Session already registered: {}, {}", socketCdxSession.getCdxSessionID(),
                                socketCdxSession.getUserName());
                        LoggingUtil.resetLogAlert();

                        socketCdxSession.assignDestination(destination);

                        LOGGER.info("User {} Subscribing to  {} ", socketCdxSession.getUserName(), destination);

                        // Lender
                        if (StreamingUtil.isLenderTopic(destination, socketCdxSession.getUserName())) {
                            cDXRetryableClientApi.authorizedSubscriber(socketCdxSession.getcDXUserProfile(),
                                    EntitlementRole.MBS_MESSAGE_RECEIVER_SUPPORTED_ROLES);
                        } // trader
                        else if (socketCdxSession.getcDXUserProfile().isFannieMaeUser()) {
                            cDXRetryableClientApi.authorizedSubscriber(socketCdxSession.getcDXUserProfile(),
                                    EntitlementRole.MBS_TRADER_MESSAGE_RECEIVER_SUPPORTED_ROLES);
                        } else {
                            throw new RuntimeException(
                                    "User is not authorized for destination with  session" + " Id" + cdxSessionID);
                        }

                    } else {
                        throw new RuntimeException("User is not authorized for  session Id" + cdxSessionID);
                    }

                }
            }
        } catch (CDXClientException exe) {
            // if any error occurs - close the session
            SocketCdxSession socketCdxSession = guavaCacheTimeToLiveCdxSession.getIfPresent(wsSessionId);

            if (Objects.nonNull(socketCdxSession) && Objects.nonNull(socketCdxSession.getSession())
                    && socketCdxSession.getSession().isOpen()) {
                try {

                    LoggingUtil.logItForAlert("preSend", "", MBSExceptionConstants.SYSTEM_EXCEPTION_IDENTIFIER, MBSExceptionConstants.SYSTEM_EXCEPTION.toString(), command.name(), "", wsSessionId, destination,
                            StreamingUtil.getLeftPaddedString(cdxSessionID), "", "");
                    LOGGER.error("Goig to close the session; CDXClientException Message: {}",
                            exe.getRootExceptionMessage());
                    LoggingUtil.resetLogAlert();

                    socketCdxSession.getSession().close(CloseStatus.POLICY_VIOLATION);
                    guavaCacheTimeToLiveCdxSession.invalidate(wsSessionId);
                } catch (IOException e) {
                    LOGGER.error("IOException: {}", e.getMessage());
                }
            }
            throw new RuntimeException(exe.getMessage());
        } catch (HTTPUnAuthorizedException exe) {

            // if any error occurs - close the session
            SocketCdxSession socketCdxSession = guavaCacheTimeToLiveCdxSession.getIfPresent(wsSessionId);

            if (Objects.nonNull(socketCdxSession) && Objects.nonNull(socketCdxSession.getSession())
                    && socketCdxSession.getSession().isOpen()) {
                try {

                    LoggingUtil.logItForAlert("preSend", "", MBSExceptionConstants.SYSTEM_EXCEPTION_IDENTIFIER, MBSExceptionConstants.SYSTEM_EXCEPTION.toString(), command.name(), "", wsSessionId, destination,
                            StreamingUtil.getLeftPaddedString(cdxSessionID), "", "");
                    LOGGER.error("Goig to close the session; HTTPUnAuthorizedException Message: {}",
                            exe.getRootExceptionMessage());
                    LoggingUtil.resetLogAlert();

                    socketCdxSession.getSession().close(CloseStatus.POLICY_VIOLATION);
                    guavaCacheTimeToLiveCdxSession.invalidate(wsSessionId);
                } catch (IOException e) {
                    LOGGER.error("IOException: {}", e.getMessage());
                }
            }
            throw new RuntimeException(exe.getMessage());
        }
        // reset the logger
        LoggingUtil.resetLogAlert();
        return message;
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * org.springframework.messaging.support.ChannelInterceptorAdapter#postSend(
     * org.springframework.messaging.Message,
     * org.springframework.messaging.MessageChannel, boolean)
     */
    @Override
    public void postSend(Message<?> message, MessageChannel channel, boolean sent) {

        final StompHeaderAccessor accessor = MessageHeaderAccessor.getAccessor(message, StompHeaderAccessor.class);
        String destination = accessor.getDestination();
        String socketSessionID = accessor.getSessionId();
        StompCommand command = accessor.getCommand();
        String cdxSessionID = accessor.getFirstNativeHeader(CDXHeaderMap.SESSION_ID.getValue());

        LoggingUtil.logItForAlert("postSend", "", "", "", command.name(), "", socketSessionID, destination,
                StreamingUtil.getLeftPaddedString(cdxSessionID), "", "");
        LOGGER.debug("Entitlement Pass Through: {}, Message: {}", cDXApiClientConfig.isEntitlementpassthrough(),
                message);
        LOGGER.info("Message: {}", message);
        LoggingUtil.resetLogAlert();

        super.postSend(message, channel, sent);
    }
}
