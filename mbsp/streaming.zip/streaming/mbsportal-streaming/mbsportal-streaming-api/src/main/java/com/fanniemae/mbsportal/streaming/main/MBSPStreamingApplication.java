/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */
package com.fanniemae.mbsportal.streaming.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.main.MBSPStreamingApplication.java 
 * @Revision: 
 * @Description: MBSPStreamingApplication.java
 */
@SpringBootApplication(scanBasePackages = "com.fanniemae.mbsportal.streaming.*")
@EnableWebSecurity
@EnableSwagger2
public class MBSPStreamingApplication {

    public static void main(String[] args) {
        SpringApplication.run(MBSPStreamingApplication.class, args);
    }

}