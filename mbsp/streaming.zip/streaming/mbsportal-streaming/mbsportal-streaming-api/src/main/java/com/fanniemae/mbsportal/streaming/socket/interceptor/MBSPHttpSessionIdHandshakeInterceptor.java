/*
 *  Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 *  reserved under the copyright laws of the United States and international
 *  conventions. Use of a copyright notice is precautionary only and does not
 *  imply publication or disclosure. This software contains confidential
 *  information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 *  is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.mbsportal.streaming.socket.interceptor;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.server.HandshakeInterceptor;

import com.fanniemae.mbsportal.streaming.util.logging.LoggingUtil;

/**
 * 
 * @author: Rajiv Chaudhuri
 * @Date: May 9, 2018
 * @File: com.fanniemae.mbsportal.streaming.socket.interceptor.MBSPHttpSessionIdHandshakeInterceptor.java 
 * @Revision: 
 * @Description: MBSPHttpSessionIdHandshakeInterceptor.java
 */
public class MBSPHttpSessionIdHandshakeInterceptor implements HandshakeInterceptor {

    private static final Logger LOGGER = LoggerFactory.getLogger(MBSPHttpSessionIdHandshakeInterceptor.class);

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.web.socket.server.HandshakeInterceptor#
     * beforeHandshake(org.springframework.http.server.ServerHttpRequest,
     * org.springframework.http.server.ServerHttpResponse,
     * org.springframework.web.socket.WebSocketHandler, java.util.Map)
     */
    @Override
    public boolean beforeHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler wsHandler,
            Map<String, Object> attributes) throws Exception {

        if (request instanceof ServletServerHttpRequest) {

            ServletServerHttpRequest servletRequest = (ServletServerHttpRequest) request;
            HttpSession session = servletRequest.getServletRequest().getSession(true);
            if (session != null) {
                String httpSessionID = session.getId();
                
                LoggingUtil.logItForAlert("beforeHandshake", "", "", "", "", httpSessionID, "", "", "", "", "");
                LOGGER.debug("Requested URI: {}", request.getURI());
                LoggingUtil.resetLogAlert();
            }
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.web.socket.server.HandshakeInterceptor#afterHandshake
     * (org.springframework.http.server.ServerHttpRequest,
     * org.springframework.http.server.ServerHttpResponse,
     * org.springframework.web.socket.WebSocketHandler, java.lang.Exception)
     */
    @Override
    public void afterHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler wsHandler,
            Exception exception) {

        if (request instanceof ServletServerHttpRequest) {

            ServletServerHttpRequest servletRequest = (ServletServerHttpRequest) request;
            HttpSession session = servletRequest.getServletRequest().getSession(false);
            if (session != null) {
                String httpSessionID = session.getId();
                
                LoggingUtil.logItForAlert("afterHandshake", "", "", "", "", httpSessionID, "", "", "", "", "");
                LOGGER.debug("Requested URI: {}", request.getURI());
                LoggingUtil.resetLogAlert();
                
            }
        }
    }

}
