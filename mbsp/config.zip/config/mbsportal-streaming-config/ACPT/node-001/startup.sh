#!/bin/sh
die () {
    echo >&2 "$@"
    exit 1
}
[ "$#" -eq 1 ] || die "env profile argument required {DEV,TEST,ACPT,PROD,PERF} , $# provided"
export SPRING_PROFILES_ACTIVE=$1
export APP_HOME=$HOME/mbsp/mbspstreaming
#export JAR_NAME=mbsportal-streaming-api-2.7.50f8544-SNAPSHOT.jar
export JAVA_HOME=/appl/mbspacpt/mbsp/jdk/jdk1.8.0_121-x86_64

nohup $JAVA_HOME/bin/java -XX:+UseConcMarkSweepGC -XX:+UnlockCommercialFeatures -XX:+FlightRecorder -Xmx16g -server -cp .:$APP_HOME:$APP_HOME/$JAR_NAME  -Dcom.sun.management.jmxremote.port=8855 -Dcom.sun.management.jmxremote.authenticate=false  -XX:NewSize=1g -XX:MaxNewSize=1g -XX:CMSInitiatingOccupancyFraction=60 -XX:+PrintGCDetails -XX:+PrintGCTimeStamps  -verbose:gc  -XX:+UseParNewGC -Dcom.sun.management.jmxremote.ssl=false -Dloader.main=com.fanniemae.mbsportal.streaming.main.MBSPStreamingApplication org.springframework.boot.loader.PropertiesLauncher >/dev/null 2>&1 &

echo $! > mbsportal-streaming-api.pid