#!/bin/sh
kill -9 $(ps aux | grep '[m]bsportal-streaming-api-0.0.1-SNAPSHOT.jar' | awk '{print $2}')
export APP_HOME=$HOME/mbsp/mbspstreaming
cd $APP_HOME
rm mbsportal-streaming-api-0.0.1-SNAPSHOT.jar nohup.out