#!/bin/sh
kill -9 $(ps aux | grep '[m]bsportal-streaming-api-0.0.1-SNAPSHOT.pid' | awk '{print $2}')
cd $HOME/mbsp/mbspstreaming
rm mbsportal-streaming-api-0.0.1-SNAPSHOT.pid nohup.out


