#!/bin/sh
kill -9 $(ps aux | grep '[m]bsportal-streaming-api-0.0.1-SNAPSHOT.jar' | awk '{print $2}')
cd $HOME/mbsp/mbspstreaming
rm mbsportal-streaming-api.pid nohup.out

