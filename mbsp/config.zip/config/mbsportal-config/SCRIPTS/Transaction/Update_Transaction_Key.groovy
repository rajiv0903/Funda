   /**
    * To Load the Transaction
    **/

   import org.apache.geode.cache.client.ClientCacheFactory
   import org.apache.geode.cache.client.ClientRegionShortcut
   import org.apache.geode.cache.Region;
   import org.apache.geode.pdx.*;
   import org.apache.geode.cache.query.SelectResults;
   import org.apache.geode.pdx.internal.PdxInstanceImpl;
   import org.apache.geode.internal.cache.PreferBytesCachedDeserializable;
   import com.fanniemae.fnmpfj.gemfire.utils.client.identity.*;
   import com.fanniemae.mbsportal.model.*;
   import java.math.BigDecimal;
   import java.time.ZoneId;
   import java.util.Calendar;
   import java.util.TimeZone;

   class FetchMBSTransaction {

       static void main(String[] args) {

           try {
		   
			   Calendar calendar = Calendar.getInstance();
			   calendar.set(2017, 10, 15);
			   calendar.setTimeZone(TimeZone.getTimeZone(ZoneId.of("America/New_York")));
			   println "Date: ${calendar.getTime()}"
			   
               def cache = ClientCacheFactory.getAnyInstance();
               String regionName = "MBSTransaction";
               Region mBSTransactionRegion = cache.getRegion(regionName);

               if (mBSTransactionRegion == null) {
                   println "${regionName} does not exist at client cache; hence going to create"
                   mBSTransactionRegion = cache.createClientRegionFactory("PROXY").create(regionName);
               }
               def queryString = "select a from  /MBSTransaction a ";


               def results = (SelectResults < MBSTransactionRequest > ) mBSTransactionRegion.query(queryString);
               println "${results.size()} - Results size"
               results.each {
                   obj ->
                       def transaction = null;
                   if (obj instanceof PdxInstanceImpl) {
                       PdxInstanceImpl pdxImpl = (PdxInstanceImpl) obj;
                       transaction = (MBSTransactionRequest) pdxImpl.getObject();
                   } else if (obj instanceof PreferBytesCachedDeserializable) {
                       PreferBytesCachedDeserializable pdxImpl = (PreferBytesCachedDeserializable) obj;
                       transaction = (MBSTransactionRequest) pdxImpl.getValue();
                   } else {
                       transaction = (MBSTransactionRequest) obj;
                   }
		   println "Transaction Key: ${transaction.getKey()}"
		   mBSTransactionRegion.put(transaction.getKey(), transaction);
		   mBSTransactionRegion.remove(transaction.getTransReqNumber());
               }
           } catch (Exception ex) {
               ex.printStackTrace();
               println("Catching the exception");
           }
       }
   }
