   /**
    * To Load the Transaction
    **/

   import org.apache.geode.cache.client.ClientCacheFactory
   import org.apache.geode.cache.client.ClientRegionShortcut
   import org.apache.geode.cache.Region;
   import org.apache.geode.pdx.*;
   import org.apache.geode.cache.query.SelectResults;
   import org.apache.geode.pdx.internal.PdxInstanceImpl;
   import org.apache.geode.internal.cache.PreferBytesCachedDeserializable;
   import com.fanniemae.fnmpfj.gemfire.utils.client.identity.*;
   import com.fanniemae.mbsportal.model.*;
   import java.math.BigDecimal;
   import java.time.ZoneId;
   import java.util.Calendar;
   import java.util.TimeZone;

   class CMMBSSTA01Transaction {

       static void main(String[] args) {

           try {
		   
			   Calendar calendar = null;
			   
               def cache = ClientCacheFactory.getAnyInstance();
               String regionName = "MBSTransaction";
               Region mBSTransactionRegion = cache.getRegion(regionName);

               if (mBSTransactionRegion == null) {
                   println "${regionName} does not exist at client cache; hence going to create"
                   mBSTransactionRegion = cache.createClientRegionFactory("PROXY").create(regionName);
               }
               def queryString = "select a from  /MBSTransaction a where a.transReqNumber in SET ('18B00038' ,  '18B00037' , '18B00036' , '18B00032', '18B00019', '18B00016')";


               def results = (SelectResults < MBSTransactionRequest > ) mBSTransactionRegion.query(queryString);
               println "${results.size()} - Results size"
               results.each {
                   obj ->
                       def transaction = null;
                   if (obj instanceof PdxInstanceImpl) {
                       PdxInstanceImpl pdxImpl = (PdxInstanceImpl) obj;
                       transaction = (MBSTransactionRequest) pdxImpl.getObject();
                   } else if (obj instanceof PreferBytesCachedDeserializable) {
                       PreferBytesCachedDeserializable pdxImpl = (PreferBytesCachedDeserializable) obj;
                       transaction = (MBSTransactionRequest) pdxImpl.getValue();
                   } else {
                       transaction = (MBSTransactionRequest) obj;
                   }
				    
				   if(transaction.getId() == "18B00038" || transaction.getId() == "18B00037" || transaction.getId() == "18B00036"){
						calendar = Calendar.getInstance();
						calendar.set(2018, 02, 13);
						calendar.setTimeZone(TimeZone.getTimeZone(ZoneId.of("America/New_York")));
						println "Date: ${calendar.getTime()}"
						println "Transaction ID: ${transaction.getId()}"
						println "Transaction: ${transaction}"
						
						transaction.setTradeSettlementDate(calendar.getTime());
						mBSTransactionRegion.put(transaction.getId(), transaction);
				   }
				   
				   if(transaction.getId() == "18B00032" || transaction.getId() == "18B00019"){
						calendar = Calendar.getInstance();
						calendar.set(2018, 03, 12);
						calendar.setTimeZone(TimeZone.getTimeZone(ZoneId.of("America/New_York")));
						println "Date: ${calendar.getTime()}"
						println "Transaction ID: ${transaction.getId()}"
						println "Transaction: ${transaction}"
						
						transaction.setTradeSettlementDate(calendar.getTime());
						mBSTransactionRegion.put(transaction.getId(), transaction);
				   }
				   
				   if(transaction.getId() == "18B00016"){
						calendar = Calendar.getInstance();
						calendar.set(2018, 03, 17);
						calendar.setTimeZone(TimeZone.getTimeZone(ZoneId.of("America/New_York")));
						println "Date: ${calendar.getTime()}"
						println "Transaction ID: ${transaction.getId()}"
						println "Transaction: ${transaction}"
						
						transaction.setTradeSettlementDate(calendar.getTime());
						mBSTransactionRegion.put(transaction.getId(), transaction);
				   }
               }
           } catch (Exception ex) {
               ex.printStackTrace();
               println("Catching the exception");
           }
       }
   }