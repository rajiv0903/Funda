   /**
    * To Load the Profile
    **/

   import org.apache.geode.cache.client.ClientCacheFactory
   import org.apache.geode.cache.client.ClientRegionShortcut
   import org.apache.geode.cache.Region;
   import org.apache.geode.pdx.*;
   import org.apache.geode.cache.query.SelectResults;
   import org.apache.geode.pdx.internal.PdxInstanceImpl;
   import org.apache.geode.internal.cache.PreferBytesCachedDeserializable;
   import com.fanniemae.fnmpfj.gemfire.utils.client.identity.*;
   import com.fanniemae.mbsportal.model.*;
   import java.math.BigDecimal;

   class FetchMBSProfile {

       static void main(String[] args) {

           try {

               def cache = ClientCacheFactory.getAnyInstance();
               String regionName = "MBSProfile";
               Region mBSProfileRegion = cache.getRegion(regionName);

               if (mBSProfileRegion == null) {
                   println "${regionName} does not exist at client cache; hence going to create"
                   mBSProfileRegion = cache.createClientRegionFactory("PROXY").create(regionName);
               }
               def queryString = "select entry.value from  /MBSProfile.entrySet entry";


               def results = (SelectResults < MBSProfile > ) mBSProfileRegion.query(queryString);
               println "${results.size()} - Results size"
               results.each {
                   obj ->
                       def profile = null;
                   if (obj instanceof PdxInstanceImpl) {
                       PdxInstanceImpl pdxImpl = (PdxInstanceImpl) obj;
                       profile = (MBSProfile) pdxImpl.getObject();
                   } else if (obj instanceof PreferBytesCachedDeserializable) {
                       PreferBytesCachedDeserializable pdxImpl = (PreferBytesCachedDeserializable) obj;
                       profile = (MBSProfile) pdxImpl.getValue();
                   } else {
                       profile = (MBSProfile) obj;
                   }
                   println "Profile Data For: ${profile.getId()} :: ${profile}"
               }
           } catch (Exception ex) {
               ex.printStackTrace();
               println("Catching the exception");
           }
       }
   }