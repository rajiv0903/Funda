   /**
    * To Load the Product
    **/

   import org.apache.geode.cache.client.ClientCacheFactory
   import org.apache.geode.cache.client.ClientRegionShortcut
   import org.apache.geode.cache.Region;
   import org.apache.geode.pdx.*;
   import org.apache.geode.cache.query.SelectResults;
   import org.apache.geode.pdx.internal.PdxInstanceImpl;
   import org.apache.geode.internal.cache.PreferBytesCachedDeserializable;
   import com.fanniemae.fnmpfj.gemfire.utils.client.identity.*;
   import com.fanniemae.mbsportal.model.*;
   import java.math.BigDecimal;

   class FetchMBSProduct {

       static void main(String[] args) {

           try {

               def cache = ClientCacheFactory.getAnyInstance();
               //def cache = new ClientCacheFactory().setPdxSerializer(new ReflectionBasedAutoSerializer("com.fanniemae.mbsportal.model.MBSProduct")).create();
               String regionName = "MBSProduct";
               Region mBSProductRegion = cache.getRegion(regionName);

               if (mBSProductRegion == null) {
                   println "${regionName} does not exist at client cache; hence going to create"
                   mBSProductRegion = cache.createClientRegionFactory("PROXY").create(regionName);
               }
               def queryString = "select entry.value from  /MBSProduct.entrySet entry";


               def results = (SelectResults < MBSProduct > ) mBSProductRegion.query(queryString);
               println "${results.size()} - Results size"
               results.each {
                   obj ->
                       def product = null;
                   if (obj instanceof PdxInstanceImpl) {
                       PdxInstanceImpl pdxImpl = (PdxInstanceImpl) obj;
                       product = (MBSProduct) pdxImpl.getObject();
                   } else if (obj instanceof PreferBytesCachedDeserializable) {
                       PreferBytesCachedDeserializable pdxImpl = (PreferBytesCachedDeserializable) obj;
                       product = (MBSProduct) pdxImpl.getValue();
                   } else {
                       product = (MBSProduct) obj;
                   }
                   println "Product Data For: ${product.getId()} :: ${product}"
               }
           } catch (Exception ex) {
               ex.printStackTrace();
               println("Catching the exception");
           }
       }
   }