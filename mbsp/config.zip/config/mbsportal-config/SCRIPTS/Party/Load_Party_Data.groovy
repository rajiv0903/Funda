   /**
    * To Load the Transaction
    **/

   import org.apache.geode.cache.client.ClientCacheFactory
   import org.apache.geode.cache.client.ClientRegionShortcut
   import org.apache.geode.cache.Region;
   import org.apache.geode.pdx.*;
   import org.apache.geode.cache.query.SelectResults;
   import org.apache.geode.pdx.internal.PdxInstanceImpl;
   import org.apache.geode.internal.cache.PreferBytesCachedDeserializable;
   import com.fanniemae.fnmpfj.gemfire.utils.client.identity.*;
   import com.fanniemae.mbsportal.model.*;
   import java.math.BigDecimal;
   import java.time.ZoneId;
   import java.util.Calendar;
   import java.util.TimeZone;
   import java.text.SimpleDateFormat;
   import java.text.DateFormat;
   import java.util.Date;

   class LoadParty {

       static void main(String[] args) {

           try {
		  
			   
               def cache = ClientCacheFactory.getAnyInstance();
               String regionName = "MBSParty";
               Region mBSMBSPartyRegion = cache.getRegion(regionName);

               if (mBSMBSPartyRegion == null) {
                   println "${regionName} does not exist at client cache; hence going to create"
                   mBSMBSPartyRegion = cache.createClientRegionFactory("PROXY").create(regionName);
               }
			   
			   DateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			   Date date = new Date();
			   date = simpleDateFormat.parse("2018-06-15");
			   
			   MBSParty mBSParty = new MBSParty();
			   mBSParty.setSellerServicerNumber("1000");
			   mBSParty.setName("Fannie Mae");
			   mBSParty.setShortName("FNM");
			   mBSParty.setEffectiveDate(date);
			   mBSParty.setNameEffectiveDate(date);
			   mBSParty.setInstitutionType("INTERNAL");
			   mBSParty.setStateType("ACTIVE");
			   
			   mBSMBSPartyRegion.put(mBSParty.getId(), mBSParty);

           } catch (Exception ex) {
               ex.printStackTrace();
               println("Catching the exception");
           }
       }
   }