   /**
    * To Load the Product Pricing
    **/

   import org.apache.geode.cache.client.ClientCacheFactory
   import org.apache.geode.cache.client.ClientRegionShortcut
   import org.apache.geode.cache.Region;
   import org.apache.geode.pdx.*;
   import org.apache.geode.cache.query.SelectResults;
   import org.apache.geode.pdx.internal.PdxInstanceImpl;
   import org.apache.geode.internal.cache.PreferBytesCachedDeserializable;
   import com.fanniemae.fnmpfj.gemfire.utils.client.identity.*;
   import com.fanniemae.mbsportal.model.*;
   import java.math.BigDecimal;

   class FetchMBSProductPricing {

       static void main(String[] args) {

           try {

               def cache = ClientCacheFactory.getAnyInstance();
               String regionName = "MBSProductPricing";
               Region mBSProductPricingRegion = cache.getRegion(regionName);

               if (mBSProductPricingRegion == null) {
                   println "${regionName} does not exist at client cache; hence going to create"
                   mBSProductPricingRegion = cache.createClientRegionFactory("PROXY").create(regionName);
               }
               def queryString = "select entry.value from  /MBSProductPricing.entrySet entry";


               def results = (SelectResults < MBSProductPricingRequest > ) mBSProductPricingRegion.query(queryString);
               println "${results.size()} - Results size"
               results.each {
                   obj ->
                       def productPrice = null;
                   if (obj instanceof PdxInstanceImpl) {
                       PdxInstanceImpl pdxImpl = (PdxInstanceImpl) obj;
                       productPrice = (MBSProductPricingRequest) pdxImpl.getObject();
                   } else if (obj instanceof PreferBytesCachedDeserializable) {
                       PreferBytesCachedDeserializable pdxImpl = (PreferBytesCachedDeserializable) obj;
                       productPrice = (MBSProductPricingRequest) pdxImpl.getValue();
                   } else {
                       productPrice = (MBSProductPricingRequest) obj;
                   }
                   println "Product Price Data For: ${productPrice.getId()} :: ${productPrice}"
               }
           } catch (Exception ex) {
               ex.printStackTrace();
               println("Catching the exception");
           }
       }
   }