   /**
    * To Load the Transaction
    **/

   import org.apache.geode.cache.client.ClientCacheFactory
   import org.apache.geode.cache.client.ClientRegionShortcut
   import org.apache.geode.cache.Region;
   import org.apache.geode.pdx.*;
   import org.apache.geode.cache.query.SelectResults;
   import org.apache.geode.pdx.internal.PdxInstanceImpl;
   import org.apache.geode.internal.cache.PreferBytesCachedDeserializable;
   import com.fanniemae.fnmpfj.gemfire.utils.client.identity.*;
   import com.fanniemae.mbsportal.model.*;
   import com.fanniemae.securitiesods.ods_core.domain.Trade;
   import java.math.BigDecimal;
   import java.time.ZoneId;
   import java.util.Calendar;
   import java.util.TimeZone;
   import java.text.DateFormat;
   import java.text.SimpleDateFormat;
   import java.util.Date;

   class CMMBSSTA01Trade {

       static void main(String[] args) {

           try {
		   
			   char deleteIndicator = 'Y' ;
		   
               def cache = ClientCacheFactory.getAnyInstance();
               String regionName = "MBSTrade";
               Region mBSTradeRegion = cache.getRegion(regionName);

               if (mBSTradeRegion == null) {
                   println "${regionName} does not exist at client cache; hence going to create"
                   mBSTradeRegion = cache.createClientRegionFactory("PROXY").create(regionName);
               }
               def queryString = "select a  from  /MBSTrade a where a.sourcePrimaryTradeId = -1208502 and a.transReqNumber = '18B00038'";
			   //def queryString = "select a  from  /MBSTrade a where a.sourcePrimaryTradeId = -3606  and a.transReqNumber = '18A08171'";
			  
               def results = (SelectResults < MBSTrade > ) mBSTradeRegion.query(queryString);
               println "${results.size()} - 1 Results size"
               results.each {
                   obj ->
                       def trade = null;
                   if (obj instanceof PdxInstanceImpl) {
                       PdxInstanceImpl pdxImpl = (PdxInstanceImpl) obj;
                       trade = (MBSTrade) pdxImpl.getObject();
                   } else if (obj instanceof PreferBytesCachedDeserializable) {
                       PreferBytesCachedDeserializable pdxImpl = (PreferBytesCachedDeserializable) obj;
                       trade = (MBSTrade) pdxImpl.getValue();
                   } else {
                       trade = (MBSTrade) obj;
                   }
				    
				   //18B00038
				   println "Trade 18B00038 : Seetlement Date : ${trade.getSettlementDate()}"
				   if(trade.getSettlementDate() != null && new SimpleDateFormat("MM-dd-yyyy").format(trade.getSettlementDate()) == "03-20-2018"){
				   //if(trade.getSettlementDate() != null && new SimpleDateFormat("MM-dd-yyyy").format(trade.getSettlementDate()) == "02-15-2018"){
							
						trade.setLogicalDeleteIndicator(deleteIndicator);
						mBSTradeRegion.put(trade.getId(), trade);
						println "Trade: ${trade}"
				   }
				}
				
			   queryString = "select a  from  /MBSTrade a where a.sourcePrimaryTradeId = -1208492 and a.transReqNumber = '18B00037'";
			  
               results = (SelectResults < MBSTrade > ) mBSTradeRegion.query(queryString);
               println "${results.size()} - 2 Results size"
               results.each {
                   obj ->
                       def trade = null;
                   if (obj instanceof PdxInstanceImpl) {
                       PdxInstanceImpl pdxImpl = (PdxInstanceImpl) obj;
                       trade = (MBSTrade) pdxImpl.getObject();
                   } else if (obj instanceof PreferBytesCachedDeserializable) {
                       PreferBytesCachedDeserializable pdxImpl = (PreferBytesCachedDeserializable) obj;
                       trade = (MBSTrade) pdxImpl.getValue();
                   } else {
                       trade = (MBSTrade) obj;
                   }
				    
				   //18B00037
				   println "Trade 18B00037 : Seetlement Date : ${trade.getSettlementDate()}"
				   if(trade.getSettlementDate() != null && new SimpleDateFormat("MM-dd-yyyy").format(trade.getSettlementDate()) 
						== "03-15-2018"){
							
						trade.setLogicalDeleteIndicator(deleteIndicator);
						mBSTradeRegion.put(trade.getId(), trade);
						println "Trade: ${trade}"
				   }
				}
				
			   queryString = "select a  from  /MBSTrade a where a.sourcePrimaryTradeId = -1208484 and a.transReqNumber = '18B00036'";
			  
               results = (SelectResults < MBSTrade > ) mBSTradeRegion.query(queryString);
               println "${results.size()} - 3 Results size"
               results.each {
                   obj ->
                       def trade = null;
                   if (obj instanceof PdxInstanceImpl) {
                       PdxInstanceImpl pdxImpl = (PdxInstanceImpl) obj;
                       trade = (MBSTrade) pdxImpl.getObject();
                   } else if (obj instanceof PreferBytesCachedDeserializable) {
                       PreferBytesCachedDeserializable pdxImpl = (PreferBytesCachedDeserializable) obj;
                       trade = (MBSTrade) pdxImpl.getValue();
                   } else {
                       trade = (MBSTrade) obj;
                   }
				    
				   //18B00036
				   println "Trade 18B00036 : Seetlement Date : ${trade.getSettlementDate()}"
				   if(trade.getSettlementDate() != null && new SimpleDateFormat("MM-dd-yyyy").format(trade.getSettlementDate()) 
						== "03-15-2018"){
							
						trade.setLogicalDeleteIndicator(deleteIndicator);
						mBSTradeRegion.put(trade.getId(), trade);
						println "Trade: ${trade}"
				   }
				}
				
			   queryString = "select a  from  /MBSTrade a where a.sourcePrimaryTradeId in SET ( -1208326, -177591) and a.transReqNumber = '18B00032'";
			  
               results = (SelectResults < MBSTrade > ) mBSTradeRegion.query(queryString);
               println "${results.size()} - 4 Results size"
               results.each {
                   obj ->
                       def trade = null;
                   if (obj instanceof PdxInstanceImpl) {
                       PdxInstanceImpl pdxImpl = (PdxInstanceImpl) obj;
                       trade = (MBSTrade) pdxImpl.getObject();
                   } else if (obj instanceof PreferBytesCachedDeserializable) {
                       PreferBytesCachedDeserializable pdxImpl = (PreferBytesCachedDeserializable) obj;
                       trade = (MBSTrade) pdxImpl.getValue();
                   } else {
                       trade = (MBSTrade) obj;
                   }
				    
				   //18B00032							
				   trade.setLogicalDeleteIndicator(deleteIndicator);
				   mBSTradeRegion.put(trade.getId(), trade);
				   println "Trade: ${trade}"
				}
           } 
		   catch (Exception ex) {
               ex.printStackTrace();
               println("Catching the exception");
           }
       }
   }