//DCU Script to Remove FNMPFJSequences

import com.fanniemae.fnmpfj.gemfire.utils.client.identity.*;

GemFireSequenceHelper.removeSequence("MBSP_ProductPricingID");

println "Removed Sequence"