Config Repository for MBSP Portal Application
