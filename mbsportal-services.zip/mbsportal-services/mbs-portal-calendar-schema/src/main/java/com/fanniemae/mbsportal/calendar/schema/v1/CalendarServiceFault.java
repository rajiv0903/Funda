
package com.fanniemae.mbsportal.calendar.schema.v1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Fault">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="FaultCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="FaultDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="Params" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="Param" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="5" minOccurs="0"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fault"
})
@XmlRootElement(name = "CalendarServiceFault", namespace = "http://www.fanniemae.com/services/enterpriseCalendarServiceFault_v1.0")
public class CalendarServiceFault {

    @XmlElement(name = "Fault", namespace = "http://www.fanniemae.com/services/enterpriseCalendarServiceFault_v1.0", required = true)
    protected CalendarServiceFault.Fault fault;

    /**
     * Gets the value of the fault property.
     * 
     * @return
     *     possible object is
     *     {@link CalendarServiceFault.Fault }
     *     
     */
    public CalendarServiceFault.Fault getFault() {
        return fault;
    }

    /**
     * Sets the value of the fault property.
     * 
     * @param value
     *     allowed object is
     *     {@link CalendarServiceFault.Fault }
     *     
     */
    public void setFault(CalendarServiceFault.Fault value) {
        this.fault = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="FaultCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="FaultDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="Params" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Param" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="5" minOccurs="0"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "faultCode",
        "faultDescription",
        "params"
    })
    public static class Fault {

        @XmlElement(name = "FaultCode", namespace = "http://www.fanniemae.com/services/enterpriseCalendarServiceFault_v1.0", required = true)
        protected String faultCode;
        @XmlElement(name = "FaultDescription", namespace = "http://www.fanniemae.com/services/enterpriseCalendarServiceFault_v1.0", required = true)
        protected String faultDescription;
        @XmlElement(name = "Params", namespace = "http://www.fanniemae.com/services/enterpriseCalendarServiceFault_v1.0")
        protected CalendarServiceFault.Fault.Params params;

        /**
         * Gets the value of the faultCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFaultCode() {
            return faultCode;
        }

        /**
         * Sets the value of the faultCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFaultCode(String value) {
            this.faultCode = value;
        }

        /**
         * Gets the value of the faultDescription property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFaultDescription() {
            return faultDescription;
        }

        /**
         * Sets the value of the faultDescription property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFaultDescription(String value) {
            this.faultDescription = value;
        }

        /**
         * Gets the value of the params property.
         * 
         * @return
         *     possible object is
         *     {@link CalendarServiceFault.Fault.Params }
         *     
         */
        public CalendarServiceFault.Fault.Params getParams() {
            return params;
        }

        /**
         * Sets the value of the params property.
         * 
         * @param value
         *     allowed object is
         *     {@link CalendarServiceFault.Fault.Params }
         *     
         */
        public void setParams(CalendarServiceFault.Fault.Params value) {
            this.params = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Param" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="5" minOccurs="0"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "param"
        })
        public static class Params {

            @XmlElement(name = "Param", namespace = "http://www.fanniemae.com/services/enterpriseCalendarServiceFault_v1.0")
            protected List<String> param;

            /**
             * Gets the value of the param property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the param property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getParam().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link String }
             * 
             * 
             */
            public List<String> getParam() {
                if (param == null) {
                    param = new ArrayList<String>();
                }
                return this.param;
            }

        }

    }

}
