
package com.fanniemae.mbsportal.calendar.schema.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.fanniemae.com/services/enterpriseCalendarService_v1.0}GetCalendarDayRequest" minOccurs="0"/>
 *         &lt;element ref="{http://www.fanniemae.com/services/enterpriseCalendarService_v1.0}GetLastBusinessDayOfMonthRequest" minOccurs="0"/>
 *         &lt;element ref="{http://www.fanniemae.com/services/enterpriseCalendarService_v1.0}GetListOfCalendarDaysRequest" minOccurs="0"/>
 *         &lt;element ref="{http://www.fanniemae.com/services/enterpriseCalendarService_v1.0}UpdateCalendarDataRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getCalendarDayRequest",
    "getLastBusinessDayOfMonthRequest",
    "getListOfCalendarDaysRequest",
    "updateCalendarDataRequest"
})
@XmlRootElement(name = "CalendarServiceRequest")
public class CalendarServiceRequest {

    @XmlElement(name = "GetCalendarDayRequest")
    protected GetCalendarDayRequest getCalendarDayRequest;
    @XmlElement(name = "GetLastBusinessDayOfMonthRequest")
    protected GetLastBusinessDayOfMonthRequest getLastBusinessDayOfMonthRequest;
    @XmlElement(name = "GetListOfCalendarDaysRequest")
    protected GetListOfCalendarDaysRequest getListOfCalendarDaysRequest;
    @XmlElement(name = "UpdateCalendarDataRequest")
    protected UpdateCalendarDataRequest updateCalendarDataRequest;

    /**
     * Gets the value of the getCalendarDayRequest property.
     * 
     * @return
     *     possible object is
     *     {@link GetCalendarDayRequest }
     *     
     */
    public GetCalendarDayRequest getGetCalendarDayRequest() {
        return getCalendarDayRequest;
    }

    /**
     * Sets the value of the getCalendarDayRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetCalendarDayRequest }
     *     
     */
    public void setGetCalendarDayRequest(GetCalendarDayRequest value) {
        this.getCalendarDayRequest = value;
    }

    /**
     * Gets the value of the getLastBusinessDayOfMonthRequest property.
     * 
     * @return
     *     possible object is
     *     {@link GetLastBusinessDayOfMonthRequest }
     *     
     */
    public GetLastBusinessDayOfMonthRequest getGetLastBusinessDayOfMonthRequest() {
        return getLastBusinessDayOfMonthRequest;
    }

    /**
     * Sets the value of the getLastBusinessDayOfMonthRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetLastBusinessDayOfMonthRequest }
     *     
     */
    public void setGetLastBusinessDayOfMonthRequest(GetLastBusinessDayOfMonthRequest value) {
        this.getLastBusinessDayOfMonthRequest = value;
    }

    /**
     * Gets the value of the getListOfCalendarDaysRequest property.
     * 
     * @return
     *     possible object is
     *     {@link GetListOfCalendarDaysRequest }
     *     
     */
    public GetListOfCalendarDaysRequest getGetListOfCalendarDaysRequest() {
        return getListOfCalendarDaysRequest;
    }

    /**
     * Sets the value of the getListOfCalendarDaysRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetListOfCalendarDaysRequest }
     *     
     */
    public void setGetListOfCalendarDaysRequest(GetListOfCalendarDaysRequest value) {
        this.getListOfCalendarDaysRequest = value;
    }

    /**
     * Gets the value of the updateCalendarDataRequest property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateCalendarDataRequest }
     *     
     */
    public UpdateCalendarDataRequest getUpdateCalendarDataRequest() {
        return updateCalendarDataRequest;
    }

    /**
     * Sets the value of the updateCalendarDataRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateCalendarDataRequest }
     *     
     */
    public void setUpdateCalendarDataRequest(UpdateCalendarDataRequest value) {
        this.updateCalendarDataRequest = value;
    }

}
