@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.fanniemae.com/services/enterpriseCalendarService_v1.0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.fanniemae.mbsportal.calendar.schema.v1;
