
package com.fanniemae.mbsportal.calendar.schema.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.fanniemae.com/services/enterpriseCalendarService_v1.0}CalendarServiceRequest"/>
 *         &lt;element ref="{http://www.fanniemae.com/services/enterpriseCalendarService_v1.0}CalendarServiceResponse"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "calendarServiceRequest",
    "calendarServiceResponse"
})
@XmlRootElement(name = "CalendarService")
public class CalendarService {

    @XmlElement(name = "CalendarServiceRequest", required = true)
    protected CalendarServiceRequest calendarServiceRequest;
    @XmlElement(name = "CalendarServiceResponse", required = true)
    protected CalendarServiceResponse calendarServiceResponse;

    /**
     * Gets the value of the calendarServiceRequest property.
     * 
     * @return
     *     possible object is
     *     {@link CalendarServiceRequest }
     *     
     */
    public CalendarServiceRequest getCalendarServiceRequest() {
        return calendarServiceRequest;
    }

    /**
     * Sets the value of the calendarServiceRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link CalendarServiceRequest }
     *     
     */
    public void setCalendarServiceRequest(CalendarServiceRequest value) {
        this.calendarServiceRequest = value;
    }

    /**
     * Gets the value of the calendarServiceResponse property.
     * 
     * @return
     *     possible object is
     *     {@link CalendarServiceResponse }
     *     
     */
    public CalendarServiceResponse getCalendarServiceResponse() {
        return calendarServiceResponse;
    }

    /**
     * Sets the value of the calendarServiceResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link CalendarServiceResponse }
     *     
     */
    public void setCalendarServiceResponse(CalendarServiceResponse value) {
        this.calendarServiceResponse = value;
    }

}
