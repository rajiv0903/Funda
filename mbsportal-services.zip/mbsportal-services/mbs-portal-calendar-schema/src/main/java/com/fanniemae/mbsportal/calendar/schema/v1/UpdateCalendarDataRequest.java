
package com.fanniemae.mbsportal.calendar.schema.v1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CalendarData" maxOccurs="5" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Date" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *                   &lt;element name="CalendarType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="DayType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="UpdatedBy" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="UpdateDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="EarlyCloseTime" type="{http://www.w3.org/2001/XMLSchema}time" minOccurs="0"/>
 *                   &lt;element name="HolidayDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "calendarData"
})
@XmlRootElement(name = "UpdateCalendarDataRequest")
public class UpdateCalendarDataRequest {

    @XmlElement(name = "CalendarData")
    protected List<UpdateCalendarDataRequest.CalendarData> calendarData;

    /**
     * Gets the value of the calendarData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the calendarData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCalendarData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link UpdateCalendarDataRequest.CalendarData }
     * 
     * 
     */
    public List<UpdateCalendarDataRequest.CalendarData> getCalendarData() {
        if (calendarData == null) {
            calendarData = new ArrayList<UpdateCalendarDataRequest.CalendarData>();
        }
        return this.calendarData;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Date" type="{http://www.w3.org/2001/XMLSchema}date"/>
     *         &lt;element name="CalendarType" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="DayType" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="UpdatedBy" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="UpdateDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="EarlyCloseTime" type="{http://www.w3.org/2001/XMLSchema}time" minOccurs="0"/>
     *         &lt;element name="HolidayDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "date",
        "calendarType",
        "dayType",
        "updatedBy",
        "updateDescription",
        "earlyCloseTime",
        "holidayDescription"
    })
    public static class CalendarData {

        @XmlElement(name = "Date", required = true)
        @XmlSchemaType(name = "date")
        protected XMLGregorianCalendar date;
        @XmlElement(name = "CalendarType", required = true)
        protected String calendarType;
        @XmlElement(name = "DayType", required = true)
        protected String dayType;
        @XmlElement(name = "UpdatedBy", required = true)
        protected String updatedBy;
        @XmlElement(name = "UpdateDescription", required = true)
        protected String updateDescription;
        @XmlElementRef(name = "EarlyCloseTime", namespace = "http://www.fanniemae.com/services/enterpriseCalendarService_v1.0", type = JAXBElement.class)
        protected JAXBElement<XMLGregorianCalendar> earlyCloseTime;
        @XmlElement(name = "HolidayDescription")
        protected String holidayDescription;

        /**
         * Gets the value of the date property.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getDate() {
            return date;
        }

        /**
         * Sets the value of the date property.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setDate(XMLGregorianCalendar value) {
            this.date = value;
        }

        /**
         * Gets the value of the calendarType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCalendarType() {
            return calendarType;
        }

        /**
         * Sets the value of the calendarType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCalendarType(String value) {
            this.calendarType = value;
        }

        /**
         * Gets the value of the dayType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDayType() {
            return dayType;
        }

        /**
         * Sets the value of the dayType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDayType(String value) {
            this.dayType = value;
        }

        /**
         * Gets the value of the updatedBy property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getUpdatedBy() {
            return updatedBy;
        }

        /**
         * Sets the value of the updatedBy property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setUpdatedBy(String value) {
            this.updatedBy = value;
        }

        /**
         * Gets the value of the updateDescription property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getUpdateDescription() {
            return updateDescription;
        }

        /**
         * Sets the value of the updateDescription property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setUpdateDescription(String value) {
            this.updateDescription = value;
        }

        /**
         * Gets the value of the earlyCloseTime property.
         * 
         * @return
         *     possible object is
         *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
         *     
         */
        public JAXBElement<XMLGregorianCalendar> getEarlyCloseTime() {
            return earlyCloseTime;
        }

        /**
         * Sets the value of the earlyCloseTime property.
         * 
         * @param value
         *     allowed object is
         *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
         *     
         */
        public void setEarlyCloseTime(JAXBElement<XMLGregorianCalendar> value) {
            this.earlyCloseTime = ((JAXBElement<XMLGregorianCalendar> ) value);
        }

        /**
         * Gets the value of the holidayDescription property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getHolidayDescription() {
            return holidayDescription;
        }

        /**
         * Sets the value of the holidayDescription property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setHolidayDescription(String value) {
            this.holidayDescription = value;
        }

    }

}
