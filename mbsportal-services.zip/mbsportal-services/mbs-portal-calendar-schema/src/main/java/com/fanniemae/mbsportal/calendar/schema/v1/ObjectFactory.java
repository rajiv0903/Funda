
package com.fanniemae.mbsportal.calendar.schema.v1;

import java.math.BigInteger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.fanniemae.mbsportal.calendar.schema.v1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetCalendarDayResponseCalendarDaysEarlyCloseTime_QNAME = new QName("http://www.fanniemae.com/services/enterpriseCalendarService_v1.0", "EarlyCloseTime");
    private final static QName _GetLastBusinessDayOfMonthRequestNumOfDaysInPastOrFuture_QNAME = new QName("http://www.fanniemae.com/services/enterpriseCalendarService_v1.0", "NumOfDaysInPastOrFuture");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.fanniemae.mbsportal.calendar.schema.v1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetCalendarDayResponse.CalendarDays }
     * 
     */
    public GetCalendarDayResponse.CalendarDays createGetCalendarDayResponseCalendarDays() {
        return new GetCalendarDayResponse.CalendarDays();
    }

    /**
     * Create an instance of {@link UpdateCalendarDataResponse }
     * 
     */
    public UpdateCalendarDataResponse createUpdateCalendarDataResponse() {
        return new UpdateCalendarDataResponse();
    }

    /**
     * Create an instance of {@link CalendarServiceFault }
     * 
     */
    public CalendarServiceFault createCalendarServiceFault() {
        return new CalendarServiceFault();
    }

    /**
     * Create an instance of {@link GetListOfCalendarDaysResponse }
     * 
     */
    public GetListOfCalendarDaysResponse createGetListOfCalendarDaysResponse() {
        return new GetListOfCalendarDaysResponse();
    }

    /**
     * Create an instance of {@link GetLastBusinessDayOfMonthRequest }
     * 
     */
    public GetLastBusinessDayOfMonthRequest createGetLastBusinessDayOfMonthRequest() {
        return new GetLastBusinessDayOfMonthRequest();
    }

    /**
     * Create an instance of {@link CalendarService }
     * 
     */
    public CalendarService createCalendarService() {
        return new CalendarService();
    }

    /**
     * Create an instance of {@link GetListOfCalendarDaysResponse.CalendarDays }
     * 
     */
    public GetListOfCalendarDaysResponse.CalendarDays createGetListOfCalendarDaysResponseCalendarDays() {
        return new GetListOfCalendarDaysResponse.CalendarDays();
    }

    /**
     * Create an instance of {@link UpdateCalendarDataRequest.CalendarData }
     * 
     */
    public UpdateCalendarDataRequest.CalendarData createUpdateCalendarDataRequestCalendarData() {
        return new UpdateCalendarDataRequest.CalendarData();
    }

    /**
     * Create an instance of {@link GetLastBusinessDayOfMonthResponse.CalendarDay }
     * 
     */
    public GetLastBusinessDayOfMonthResponse.CalendarDay createGetLastBusinessDayOfMonthResponseCalendarDay() {
        return new GetLastBusinessDayOfMonthResponse.CalendarDay();
    }

    /**
     * Create an instance of {@link CalendarServiceFault.Fault.Params }
     * 
     */
    public CalendarServiceFault.Fault.Params createCalendarServiceFaultFaultParams() {
        return new CalendarServiceFault.Fault.Params();
    }

    /**
     * Create an instance of {@link GetCalendarDayRequest.CalendarDays }
     * 
     */
    public GetCalendarDayRequest.CalendarDays createGetCalendarDayRequestCalendarDays() {
        return new GetCalendarDayRequest.CalendarDays();
    }

    /**
     * Create an instance of {@link GetCalendarDayResponse }
     * 
     */
    public GetCalendarDayResponse createGetCalendarDayResponse() {
        return new GetCalendarDayResponse();
    }

    /**
     * Create an instance of {@link GetLastBusinessDayOfMonthResponse }
     * 
     */
    public GetLastBusinessDayOfMonthResponse createGetLastBusinessDayOfMonthResponse() {
        return new GetLastBusinessDayOfMonthResponse();
    }

    /**
     * Create an instance of {@link CalendarServiceResponse }
     * 
     */
    public CalendarServiceResponse createCalendarServiceResponse() {
        return new CalendarServiceResponse();
    }

    /**
     * Create an instance of {@link CalendarServiceFault.Fault }
     * 
     */
    public CalendarServiceFault.Fault createCalendarServiceFaultFault() {
        return new CalendarServiceFault.Fault();
    }

    /**
     * Create an instance of {@link GetCalendarDayRequest }
     * 
     */
    public GetCalendarDayRequest createGetCalendarDayRequest() {
        return new GetCalendarDayRequest();
    }

    /**
     * Create an instance of {@link UpdateCalendarDataResponse.CalendarData }
     * 
     */
    public UpdateCalendarDataResponse.CalendarData createUpdateCalendarDataResponseCalendarData() {
        return new UpdateCalendarDataResponse.CalendarData();
    }

    /**
     * Create an instance of {@link UpdateCalendarDataRequest }
     * 
     */
    public UpdateCalendarDataRequest createUpdateCalendarDataRequest() {
        return new UpdateCalendarDataRequest();
    }

    /**
     * Create an instance of {@link GetListOfCalendarDaysResponse.CalendarDays.ListOfDates }
     * 
     */
    public GetListOfCalendarDaysResponse.CalendarDays.ListOfDates createGetListOfCalendarDaysResponseCalendarDaysListOfDates() {
        return new GetListOfCalendarDaysResponse.CalendarDays.ListOfDates();
    }

    /**
     * Create an instance of {@link CalendarServiceRequest }
     * 
     */
    public CalendarServiceRequest createCalendarServiceRequest() {
        return new CalendarServiceRequest();
    }

    /**
     * Create an instance of {@link GetListOfCalendarDaysRequest }
     * 
     */
    public GetListOfCalendarDaysRequest createGetListOfCalendarDaysRequest() {
        return new GetListOfCalendarDaysRequest();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.fanniemae.com/services/enterpriseCalendarService_v1.0", name = "EarlyCloseTime", scope = GetCalendarDayResponse.CalendarDays.class)
    public JAXBElement<XMLGregorianCalendar> createGetCalendarDayResponseCalendarDaysEarlyCloseTime(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_GetCalendarDayResponseCalendarDaysEarlyCloseTime_QNAME, XMLGregorianCalendar.class, GetCalendarDayResponse.CalendarDays.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.fanniemae.com/services/enterpriseCalendarService_v1.0", name = "NumOfDaysInPastOrFuture", scope = GetLastBusinessDayOfMonthRequest.class)
    public JAXBElement<BigInteger> createGetLastBusinessDayOfMonthRequestNumOfDaysInPastOrFuture(BigInteger value) {
        return new JAXBElement<BigInteger>(_GetLastBusinessDayOfMonthRequestNumOfDaysInPastOrFuture_QNAME, BigInteger.class, GetLastBusinessDayOfMonthRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.fanniemae.com/services/enterpriseCalendarService_v1.0", name = "EarlyCloseTime", scope = GetLastBusinessDayOfMonthResponse.CalendarDay.class)
    public JAXBElement<XMLGregorianCalendar> createGetLastBusinessDayOfMonthResponseCalendarDayEarlyCloseTime(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_GetCalendarDayResponseCalendarDaysEarlyCloseTime_QNAME, XMLGregorianCalendar.class, GetLastBusinessDayOfMonthResponse.CalendarDay.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.fanniemae.com/services/enterpriseCalendarService_v1.0", name = "EarlyCloseTime", scope = UpdateCalendarDataRequest.CalendarData.class)
    public JAXBElement<XMLGregorianCalendar> createUpdateCalendarDataRequestCalendarDataEarlyCloseTime(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_GetCalendarDayResponseCalendarDaysEarlyCloseTime_QNAME, XMLGregorianCalendar.class, UpdateCalendarDataRequest.CalendarData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.fanniemae.com/services/enterpriseCalendarService_v1.0", name = "NumOfDaysInPastOrFuture", scope = GetCalendarDayRequest.CalendarDays.class)
    public JAXBElement<BigInteger> createGetCalendarDayRequestCalendarDaysNumOfDaysInPastOrFuture(BigInteger value) {
        return new JAXBElement<BigInteger>(_GetLastBusinessDayOfMonthRequestNumOfDaysInPastOrFuture_QNAME, BigInteger.class, GetCalendarDayRequest.CalendarDays.class, value);
    }

}
