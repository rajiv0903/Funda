
package com.fanniemae.mbsportal.calendar.schema.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.fanniemae.com/services/enterpriseCalendarService_v1.0}GetCalendarDayResponse" minOccurs="0"/>
 *         &lt;element ref="{http://www.fanniemae.com/services/enterpriseCalendarService_v1.0}GetLastBusinessDayOfMonthResponse" minOccurs="0"/>
 *         &lt;element ref="{http://www.fanniemae.com/services/enterpriseCalendarService_v1.0}GetListOfCalendarDaysResponse" minOccurs="0"/>
 *         &lt;element ref="{http://www.fanniemae.com/services/enterpriseCalendarService_v1.0}UpdateCalendarDataResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getCalendarDayResponse",
    "getLastBusinessDayOfMonthResponse",
    "getListOfCalendarDaysResponse",
    "updateCalendarDataResponse"
})
@XmlRootElement(name = "CalendarServiceResponse")
public class CalendarServiceResponse {

    @XmlElement(name = "GetCalendarDayResponse")
    protected GetCalendarDayResponse getCalendarDayResponse;
    @XmlElement(name = "GetLastBusinessDayOfMonthResponse")
    protected GetLastBusinessDayOfMonthResponse getLastBusinessDayOfMonthResponse;
    @XmlElement(name = "GetListOfCalendarDaysResponse")
    protected GetListOfCalendarDaysResponse getListOfCalendarDaysResponse;
    @XmlElement(name = "UpdateCalendarDataResponse")
    protected UpdateCalendarDataResponse updateCalendarDataResponse;

    /**
     * Gets the value of the getCalendarDayResponse property.
     * 
     * @return
     *     possible object is
     *     {@link GetCalendarDayResponse }
     *     
     */
    public GetCalendarDayResponse getGetCalendarDayResponse() {
        return getCalendarDayResponse;
    }

    /**
     * Sets the value of the getCalendarDayResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetCalendarDayResponse }
     *     
     */
    public void setGetCalendarDayResponse(GetCalendarDayResponse value) {
        this.getCalendarDayResponse = value;
    }

    /**
     * Gets the value of the getLastBusinessDayOfMonthResponse property.
     * 
     * @return
     *     possible object is
     *     {@link GetLastBusinessDayOfMonthResponse }
     *     
     */
    public GetLastBusinessDayOfMonthResponse getGetLastBusinessDayOfMonthResponse() {
        return getLastBusinessDayOfMonthResponse;
    }

    /**
     * Sets the value of the getLastBusinessDayOfMonthResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetLastBusinessDayOfMonthResponse }
     *     
     */
    public void setGetLastBusinessDayOfMonthResponse(GetLastBusinessDayOfMonthResponse value) {
        this.getLastBusinessDayOfMonthResponse = value;
    }

    /**
     * Gets the value of the getListOfCalendarDaysResponse property.
     * 
     * @return
     *     possible object is
     *     {@link GetListOfCalendarDaysResponse }
     *     
     */
    public GetListOfCalendarDaysResponse getGetListOfCalendarDaysResponse() {
        return getListOfCalendarDaysResponse;
    }

    /**
     * Sets the value of the getListOfCalendarDaysResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetListOfCalendarDaysResponse }
     *     
     */
    public void setGetListOfCalendarDaysResponse(GetListOfCalendarDaysResponse value) {
        this.getListOfCalendarDaysResponse = value;
    }

    /**
     * Gets the value of the updateCalendarDataResponse property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateCalendarDataResponse }
     *     
     */
    public UpdateCalendarDataResponse getUpdateCalendarDataResponse() {
        return updateCalendarDataResponse;
    }

    /**
     * Sets the value of the updateCalendarDataResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateCalendarDataResponse }
     *     
     */
    public void setUpdateCalendarDataResponse(UpdateCalendarDataResponse value) {
        this.updateCalendarDataResponse = value;
    }

}
