
package com.fanniemae.mbsportal.calendar.schema.v1;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CalendarDays" maxOccurs="5">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="NumberOfCalendarDays" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *                   &lt;element name="CalendarType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="ListOfDates" maxOccurs="5" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="Date" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                             &lt;element name="DayType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="EarlyCloseTime" type="{http://www.w3.org/2001/XMLSchema}time" minOccurs="0"/>
 *                             &lt;element name="HolidayDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="DayOfWeek" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="TransactionID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "calendarDays",
    "transactionID"
})
@XmlRootElement(name = "GetListOfCalendarDaysResponse")
public class GetListOfCalendarDaysResponse {

    @XmlElement(name = "CalendarDays", required = true)
    protected List<GetListOfCalendarDaysResponse.CalendarDays> calendarDays;
    @XmlElement(name = "TransactionID", required = true)
    protected String transactionID;

    /**
     * Gets the value of the calendarDays property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the calendarDays property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCalendarDays().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GetListOfCalendarDaysResponse.CalendarDays }
     * 
     * 
     */
    public List<GetListOfCalendarDaysResponse.CalendarDays> getCalendarDays() {
        if (calendarDays == null) {
            calendarDays = new ArrayList<GetListOfCalendarDaysResponse.CalendarDays>();
        }
        return this.calendarDays;
    }

    /**
     * Gets the value of the transactionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionID() {
        return transactionID;
    }

    /**
     * Sets the value of the transactionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionID(String value) {
        this.transactionID = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="NumberOfCalendarDays" type="{http://www.w3.org/2001/XMLSchema}integer"/>
     *         &lt;element name="CalendarType" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="ListOfDates" maxOccurs="5" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Date" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *                   &lt;element name="DayType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="EarlyCloseTime" type="{http://www.w3.org/2001/XMLSchema}time" minOccurs="0"/>
     *                   &lt;element name="HolidayDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="DayOfWeek" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "numberOfCalendarDays",
        "calendarType",
        "listOfDates"
    })
    public static class CalendarDays {

        @XmlElement(name = "NumberOfCalendarDays", required = true)
        protected BigInteger numberOfCalendarDays;
        @XmlElement(name = "CalendarType", required = true)
        protected String calendarType;
        @XmlElement(name = "ListOfDates")
        protected List<GetListOfCalendarDaysResponse.CalendarDays.ListOfDates> listOfDates;

        /**
         * Gets the value of the numberOfCalendarDays property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getNumberOfCalendarDays() {
            return numberOfCalendarDays;
        }

        /**
         * Sets the value of the numberOfCalendarDays property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setNumberOfCalendarDays(BigInteger value) {
            this.numberOfCalendarDays = value;
        }

        /**
         * Gets the value of the calendarType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCalendarType() {
            return calendarType;
        }

        /**
         * Sets the value of the calendarType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCalendarType(String value) {
            this.calendarType = value;
        }

        /**
         * Gets the value of the listOfDates property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the listOfDates property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getListOfDates().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link GetListOfCalendarDaysResponse.CalendarDays.ListOfDates }
         * 
         * 
         */
        public List<GetListOfCalendarDaysResponse.CalendarDays.ListOfDates> getListOfDates() {
            if (listOfDates == null) {
                listOfDates = new ArrayList<GetListOfCalendarDaysResponse.CalendarDays.ListOfDates>();
            }
            return this.listOfDates;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Date" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
         *         &lt;element name="DayType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="EarlyCloseTime" type="{http://www.w3.org/2001/XMLSchema}time" minOccurs="0"/>
         *         &lt;element name="HolidayDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="DayOfWeek" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "date",
            "dayType",
            "earlyCloseTime",
            "holidayDescription",
            "dayOfWeek"
        })
        public static class ListOfDates {

            @XmlElement(name = "Date")
            @XmlSchemaType(name = "date")
            protected XMLGregorianCalendar date;
            @XmlElement(name = "DayType")
            protected String dayType;
            @XmlElement(name = "EarlyCloseTime")
            @XmlSchemaType(name = "time")
            protected XMLGregorianCalendar earlyCloseTime;
            @XmlElement(name = "HolidayDescription")
            protected String holidayDescription;
            @XmlElement(name = "DayOfWeek")
            protected String dayOfWeek;

            /**
             * Gets the value of the date property.
             * 
             * @return
             *     possible object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public XMLGregorianCalendar getDate() {
                return date;
            }

            /**
             * Sets the value of the date property.
             * 
             * @param value
             *     allowed object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public void setDate(XMLGregorianCalendar value) {
                this.date = value;
            }

            /**
             * Gets the value of the dayType property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getDayType() {
                return dayType;
            }

            /**
             * Sets the value of the dayType property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setDayType(String value) {
                this.dayType = value;
            }

            /**
             * Gets the value of the earlyCloseTime property.
             * 
             * @return
             *     possible object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public XMLGregorianCalendar getEarlyCloseTime() {
                return earlyCloseTime;
            }

            /**
             * Sets the value of the earlyCloseTime property.
             * 
             * @param value
             *     allowed object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public void setEarlyCloseTime(XMLGregorianCalendar value) {
                this.earlyCloseTime = value;
            }

            /**
             * Gets the value of the holidayDescription property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getHolidayDescription() {
                return holidayDescription;
            }

            /**
             * Sets the value of the holidayDescription property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setHolidayDescription(String value) {
                this.holidayDescription = value;
            }

            /**
             * Gets the value of the dayOfWeek property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getDayOfWeek() {
                return dayOfWeek;
            }

            /**
             * Sets the value of the dayOfWeek property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setDayOfWeek(String value) {
                this.dayOfWeek = value;
            }

        }

    }

}
